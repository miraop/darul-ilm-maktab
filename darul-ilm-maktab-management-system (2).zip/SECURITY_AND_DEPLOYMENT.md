# Darul Ilm Maktab Management System — Setup, Deployment & Security Guide

## 1. Architecture Overview
- **Frontend**: React 19, TypeScript, Tailwind CSS v4, Recharts, jsPDF + jspdf-autotable, SheetJS (`xlsx`), Lucide Icons.
- **Backend**: Node.js + Express (`server.ts` + `src/routes/api.ts`).
- **Database**: Cloud SQL for PostgreSQL managed via Drizzle ORM (`src/db/schema.ts`, `src/db/index.ts`).
- **Authentication**: Firebase Authentication (Google Sign-In verified via `firebase-admin`) and `bcryptjs` password hashing with HMAC-SHA256 signed session tokens.
- **Multilingual**: Complete English (`en`), Hindi (`hi`), and Urdu (`ur` with automatic `dir="rtl"` and Nastaliq/Naskh typography).

## 2. Database Schema (24 Relational Tables)
Defined in `src/db/schema.ts` with foreign keys, unique constraints, and indexes:
- `users`, `roles`, `classes`, `subjects`, `students`, `enrollments`
- `attendance`, `namaz_records` (Fajr, Zuhr, Asr, Maghrib, Isha with explicit `performed` | `not_performed` | `not_recorded`)
- `health_records` (restricted access + parental consent controls)
- `daily_activities` (breakfast, lunch, dinner, homework completion, discipline, deeni activities)
- `homework`, `assignments`, `exams`, `marks` (including interactive online MCQ quizzes)
- `fees`, `payments` (unique receipt numbers), `notifications`
- `study_materials`, `recorded_lessons`, `timetable`
- `admissions`, `notices`, `website_settings`, `audit_logs`

## 3. Local Setup & Schema Migration
1. Install dependencies: `npm install`
2. Ensure runtime environment variables are configured (`SQL_HOST`, `SQL_DB_NAME`, `SQL_USER`, `SQL_PASSWORD`, `SQL_ADMIN_USER`, `SQL_ADMIN_PASSWORD`, `SESSION_SECRET`).
3. Push Drizzle schema to PostgreSQL: `npx drizzle-kit push --config=src/db/drizzle.config.ts`
4. Start development server on port 3000: `npm run dev`
5. Build production bundle: `npm run build` and start via `npm start`.

## 4. Security Architecture
- **RBAC Enforcement**: Every `/api/*` portal route enforces `requireAuth` and `requireRole(...)`.
- **Strict Data Scoping**:
  - **Teachers** are restricted to students, attendance, Namaz, daily activities, and marks belonging to their assigned `classes` or `subjects`.
  - **Parents** are strictly restricted to linked children (`students.parentId`) and can toggle `parentalConsent`.
  - **Students** only access their own records, timetable, materials, and online quizzes.
  - **Health Records** enforce restricted access and write audit trail entries on read/write.
- **Rate Limiting & Audit Logs**: Public forms and authentication endpoints apply sliding-window rate limiting; all sensitive actions log to `audit_logs`.
- **Demo vs Production Isolation**: Initial demonstration records are flagged `isDemo = true` and can be purged by an Admin from Administration -> Website Settings.
