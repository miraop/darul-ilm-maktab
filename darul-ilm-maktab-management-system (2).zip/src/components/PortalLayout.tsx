import React, { useEffect, useState } from 'react';
import {
  BarChart3,
  Bell,
  BookOpen,
  CalendarCheck,
  CreditCard,
  Globe,
  HeartPulse,
  LayoutDashboard,
  LogOut,
  Menu,
  Shield,
  ShieldCheck,
  Users,
  Video,
  X,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext.tsx';
import { t } from '../i18n/translations.ts';
import { LanguageSwitcher } from './LanguageSwitcher.tsx';
import { DashboardOverview } from './portal/DashboardOverview.tsx';
import { StudentsClassesView } from './portal/StudentsClassesView.tsx';
import { AttendanceNamazView } from './portal/AttendanceNamazView.tsx';
import { HealthDailyView } from './portal/HealthDailyView.tsx';
import { AcademicsView } from './portal/AcademicsView.tsx';
import { OnlineEducationView } from './portal/OnlineEducationView.tsx';
import { FeesView } from './portal/FeesView.tsx';
import { ReportsAdminView } from './portal/ReportsAdminView.tsx';
import { SuperAdminView } from './portal/SuperAdminView.tsx';
import { NotificationsMessagesView } from './portal/NotificationsMessagesView.tsx';

export const PortalLayout: React.FC<{ onGoPublic: () => void }> = ({ onGoPublic }) => {
  const { user, lang, logout } = useAuth();
  const [activeTab, setActiveTab] = useState<string>(
    user?.role === 'super_admin' ? 'super-admin' : 'dashboard'
  );
  const [sidebarOpen, setSidebarOpen] = useState(false);

  useEffect(() => {
    if (user?.role === 'super_admin') {
      setActiveTab('super-admin');
    } else if (user) {
      setActiveTab((prev) => (prev === 'super-admin' ? 'dashboard' : prev));
    }
  }, [user?.id, user?.role, user?.institutionId]);

  const isStudent = user?.role === 'student';

  const navItems = [
    { id: 'super-admin', label: t(lang, 'menuSuperAdmin'), icon: ShieldCheck, roles: ['super_admin'] },
    { id: 'dashboard', label: isStudent ? 'My Analytics' : t(lang, 'menuDashboard'), icon: LayoutDashboard, roles: ['admin', 'teacher', 'student', 'parent'] },
    { id: 'students', label: isStudent ? 'My Profile & Syllabus' : t(lang, 'menuStudents'), icon: Users, roles: ['admin', 'teacher', 'student', 'parent'] },
    { id: 'attendance-namaz', label: isStudent ? 'My Attendance & Namaz' : t(lang, 'menuAttendanceNamaz'), icon: CalendarCheck, roles: ['admin', 'teacher', 'student', 'parent'] },
    { id: 'health-daily', label: t(lang, 'menuHealthDaily'), icon: HeartPulse, roles: ['admin', 'teacher', 'parent'] },
    { id: 'academics', label: isStudent ? 'My Academics & Tests' : t(lang, 'menuAcademics'), icon: BookOpen, roles: ['admin', 'teacher', 'student', 'parent'] },
    { id: 'online-edu', label: isStudent ? 'My Classes & Timetable' : t(lang, 'menuOnlineEdu'), icon: Video, roles: ['admin', 'teacher', 'student', 'parent'] },
    { id: 'fees', label: t(lang, 'menuFees'), icon: CreditCard, roles: ['admin', 'parent'] },
    { id: 'notifications', label: t(lang, 'menuNotifications'), icon: Bell, roles: ['admin', 'teacher', 'student', 'parent'] },
    { id: 'reports', label: t(lang, 'menuReports'), icon: BarChart3, roles: ['admin', 'teacher', 'parent'] },
    { id: 'admin', label: t(lang, 'menuAdmin'), icon: Shield, roles: ['admin'] },
  ].filter((item) => item.roles.includes(user?.role || 'parent'));

  const currentItem = navItems.find((n) => n.id === activeTab) || navItems[0];
  const workspaceTitle =
    user?.role === 'super_admin' ? 'Platform Owner Console' : user?.institutionName || t(lang, 'brandName');
  const roleLabel =
    user?.role === 'super_admin'
      ? t(lang, 'roleSuperAdmin')
      : t(lang, `role${(user?.role || 'parent').charAt(0).toUpperCase() + (user?.role || 'parent').slice(1)}`);

  const renderContent = () => {
    if (user?.role === 'super_admin') {
      return <SuperAdminView />;
    }
    switch (activeTab) {
      case 'dashboard':
        return <DashboardOverview onNavigate={setActiveTab} />;
      case 'students':
        return <StudentsClassesView />;
      case 'attendance-namaz':
        return <AttendanceNamazView />;
      case 'health-daily':
        return user?.role !== 'student' ? <HealthDailyView /> : <DashboardOverview onNavigate={setActiveTab} />;
      case 'academics':
        return <AcademicsView />;
      case 'online-edu':
        return <OnlineEducationView />;
      case 'fees':
        return user?.role === 'admin' || user?.role === 'parent' ? <FeesView /> : <DashboardOverview onNavigate={setActiveTab} />;
      case 'notifications':
        return <NotificationsMessagesView />;
      case 'reports':
        return user?.role !== 'student' ? <ReportsAdminView initialTab="reports" /> : <DashboardOverview onNavigate={setActiveTab} />;
      case 'admin':
        return user?.role === 'admin' ? <ReportsAdminView initialTab="admin" /> : <DashboardOverview onNavigate={setActiveTab} />;
      default:
        return <DashboardOverview onNavigate={setActiveTab} />;
    }
  };

  return (
    <div className="min-h-screen bg-[#FAFBF9] flex">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex lg:w-[260px] lg:flex-col border-e border-emerald-900/10 bg-emerald-950 text-emerald-50 shrink-0">
        <div className="p-6 border-b border-emerald-800/60">
          <div className="font-display text-base font-bold text-white leading-snug">{workspaceTitle}</div>
          <div className="text-xs text-amber-300 mt-1 font-medium">{roleLabel}</div>
        </div>

        <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
          {navItems.map((item) => {
            const Icon = item.icon;
            const active = (currentItem?.id || activeTab) === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-medium transition-colors cursor-pointer text-start ${
                  active
                    ? 'bg-emerald-800 text-white'
                    : 'text-emerald-100/80 hover:bg-emerald-900/70 hover:text-white'
                }`}
              >
                <Icon className="h-4 w-4 shrink-0" />
                <span className="truncate">{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="p-4 border-t border-emerald-800/60 space-y-2">
          <button
            type="button"
            onClick={onGoPublic}
            className="w-full flex items-center gap-2.5 px-3.5 py-2 rounded-xl text-xs text-emerald-100/85 hover:bg-emerald-900/70 cursor-pointer"
          >
            <Globe className="h-4 w-4 shrink-0" />
            <span>{t(lang, 'backToWebsite')}</span>
          </button>
          <button
            type="button"
            onClick={logout}
            className="w-full flex items-center gap-2.5 px-3.5 py-2 rounded-xl text-xs text-amber-200 hover:bg-emerald-900/70 cursor-pointer"
          >
            <LogOut className="h-4 w-4 shrink-0" />
            <span>{t(lang, 'signOut')}</span>
          </button>
        </div>
      </aside>

      {/* Mobile Sidebar Overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div className="fixed inset-0 bg-black/50" onClick={() => setSidebarOpen(false)} />
          <aside className="relative w-64 max-w-[80vw] bg-emerald-950 text-white flex flex-col z-10">
            <div className="p-5 border-b border-emerald-800/60 flex items-center justify-between">
              <span className="font-display font-bold text-sm">{workspaceTitle}</span>
              <button type="button" onClick={() => setSidebarOpen(false)} className="cursor-pointer">
                <X className="h-5 w-5" />
              </button>
            </div>
            <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
              {navItems.map((item) => {
                const Icon = item.icon;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => {
                      setActiveTab(item.id);
                      setSidebarOpen(false);
                    }}
                    className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-medium cursor-pointer text-start ${
                      (currentItem?.id || activeTab) === item.id ? 'bg-emerald-800 text-white' : 'text-emerald-100/80'
                    }`}
                  >
                    <Icon className="h-4 w-4 shrink-0" />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </nav>
            <div className="p-4 border-t border-emerald-800/60 space-y-2">
              <button type="button" onClick={onGoPublic} className="w-full text-start px-3 py-2 text-xs text-emerald-100 cursor-pointer">
                {t(lang, 'backToWebsite')}
              </button>
              <button type="button" onClick={logout} className="w-full text-start px-3 py-2 text-xs text-amber-200 cursor-pointer">
                {t(lang, 'signOut')}
              </button>
            </div>
          </aside>
        </div>
      )}

      {/* Main Content Area */}
      <div className="flex-1 min-w-0 flex flex-col">
        <header className="sticky top-0 z-30 bg-white/95 backdrop-blur border-b border-emerald-900/10 px-6 py-3.5 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setSidebarOpen(true)}
              className="lg:hidden p-2 rounded-lg border border-slate-200 text-slate-700 cursor-pointer"
              aria-label="Open navigation"
            >
              <Menu className="h-4 w-4" />
            </button>
            <div className="text-xs text-slate-500 truncate">
              <span>{workspaceTitle}</span>
              <span className="mx-2">/</span>
              <span className="font-semibold text-slate-900">{currentItem?.label}</span>
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <LanguageSwitcher compact />
            <div className="hidden sm:block text-end">
              <div className="text-xs font-semibold text-slate-900 truncate max-w-[180px]">{user?.name}</div>
              <div className="text-[11px] text-slate-500">{roleLabel}</div>
            </div>
          </div>
        </header>

        <main className="flex-1 p-6 max-w-7xl w-full mx-auto">{renderContent()}</main>
      </div>
    </div>
  );
};
