import React, { useEffect, useState } from 'react';
import { Bell, CheckCircle2, MessageSquare, Send, Settings2, ShieldCheck } from 'lucide-react';
import { useAuth } from '../../context/AuthContext.tsx';
import { t } from '../../i18n/translations.ts';

interface NotificationPref {
  absentAlerts: boolean;
  attendanceUpdates: boolean;
  homeworkAlerts: boolean;
  examAlerts: boolean;
  liveClassAlerts: boolean;
  prayerUpdates: boolean;
  foodUpdates: boolean;
  healthAlerts: boolean;
  teacherMessages: boolean;
  fcmConsentGranted: boolean;
  deliveryStatus: string;
}

const DEFAULT_PREFS: NotificationPref = {
  absentAlerts: true,
  attendanceUpdates: true,
  homeworkAlerts: true,
  examAlerts: true,
  liveClassAlerts: true,
  prayerUpdates: true,
  foodUpdates: true,
  healthAlerts: true,
  teacherMessages: true,
  fcmConsentGranted: false,
  deliveryStatus: 'in_app_only',
};

export const NotificationsMessagesView: React.FC = () => {
  const { user, lang, apiFetch } = useAuth();
  const [subTab, setSubTab] = useState<'notifications' | 'messages' | 'preferences'>('notifications');
  const [notifications, setNotifications] = useState<any[]>([]);
  const [students, setStudents] = useState<any[]>([]);
  const [messages, setMessages] = useState<any[]>([]);
  const [selectedStudentId, setSelectedStudentId] = useState<string>('all');
  const [prefs, setPrefs] = useState<NotificationPref>(DEFAULT_PREFS);
  const [browserPermission, setBrowserPermission] = useState<string>(
    typeof window !== 'undefined' && 'Notification' in window ? window.Notification.permission : 'unsupported'
  );
  const [loading, setLoading] = useState(true);
  const [feedback, setFeedback] = useState<string | null>(null);

  // Forms
  const [notifForm, setNotifForm] = useState({
    title: '',
    message: '',
    type: 'announcement',
    targetRole: 'all',
  });
  const [msgStudentId, setMsgStudentId] = useState<string>('');
  const [msgBody, setMsgBody] = useState('');
  const [sending, setSending] = useState(false);
  const [savingPrefs, setSavingPrefs] = useState(false);

  const isStudent = user?.role === 'student';
  const canBroadcast = user?.role === 'admin' || user?.role === 'teacher';
  const canMessage = user?.role === 'admin' || user?.role === 'teacher' || user?.role === 'parent';

  const loadAll = async () => {
    setLoading(true);
    try {
      const [notifs, stList, msgList, prefRes] = await Promise.all([
        apiFetch('/api/notifications'),
        isStudent ? Promise.resolve([]) : apiFetch('/api/students'),
        isStudent ? Promise.resolve([]) : apiFetch('/api/messages'),
        apiFetch('/api/notification-preferences'),
      ]);
      setNotifications(notifs || []);
      setStudents(stList || []);
      setMessages(msgList || []);
      if (prefRes) {
        setPrefs({
          absentAlerts: Boolean(prefRes.absentAlerts),
          attendanceUpdates: Boolean(prefRes.attendanceUpdates),
          homeworkAlerts: Boolean(prefRes.homeworkAlerts),
          examAlerts: Boolean(prefRes.examAlerts),
          liveClassAlerts: Boolean(prefRes.liveClassAlerts),
          prayerUpdates: Boolean(prefRes.prayerUpdates),
          foodUpdates: Boolean(prefRes.foodUpdates),
          healthAlerts: Boolean(prefRes.healthAlerts),
          teacherMessages: Boolean(prefRes.teacherMessages),
          fcmConsentGranted: Boolean(prefRes.fcmConsentGranted),
          deliveryStatus: prefRes.deliveryStatus || 'in_app_only',
        });
      }
      if ((stList || []).length > 0 && !msgStudentId) {
        setMsgStudentId(String(stList[0].id));
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAll();
  }, []);

  const handleMarkRead = async (id: number) => {
    try {
      const updated = await apiFetch(`/api/notifications/${id}/read`, { method: 'PATCH' });
      setNotifications((prev) => prev.map((n) => (n.id === id ? updated : n)));
    } catch {
      // ignore
    }
  };

  const handleSendAnnouncement = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!notifForm.title.trim() || !notifForm.message.trim()) return;
    setSending(true);
    try {
      const created = await apiFetch('/api/notifications', {
        method: 'POST',
        body: JSON.stringify(notifForm),
      });
      setNotifications((prev) => [created, ...prev]);
      setNotifForm({ title: '', message: '', type: 'announcement', targetRole: 'all' });
      setFeedback('Notification published to the targeted recipients.');
    } finally {
      setSending(false);
    }
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!msgStudentId || !msgBody.trim()) return;
    setSending(true);
    try {
      const created = await apiFetch('/api/messages', {
        method: 'POST',
        body: JSON.stringify({ studentId: Number(msgStudentId), message: msgBody.trim() }),
      });
      setMessages((prev) => [created, ...prev]);
      setMsgBody('');
      setFeedback('Message delivered cleanly.');
    } finally {
      setSending(false);
    }
  };

  const handleRequestBrowserConsent = async () => {
    if (typeof window === 'undefined' || !('Notification' in window)) {
      setBrowserPermission('unsupported');
      return;
    }
    try {
      const permission = await window.Notification.requestPermission();
      setBrowserPermission(permission);
      const granted = permission === 'granted';
      const updated = await apiFetch('/api/notification-preferences', {
        method: 'PUT',
        body: JSON.stringify({
          ...prefs,
          fcmConsentGranted: granted,
          deliveryStatus: granted ? 'browser_permission_granted' : 'in_app_only',
        }),
      });
      setPrefs((prev) => ({
        ...prev,
        fcmConsentGranted: Boolean(updated.fcmConsentGranted),
        deliveryStatus: updated.deliveryStatus || prev.deliveryStatus,
      }));
      setFeedback(
        granted
          ? 'Browser alert consent recorded alongside in-app notifications.'
          : 'Browser notifications declined; alerts remain active inside the Maktab portal.'
      );
    } catch {
      setFeedback('Could not update browser alert permission.');
    }
  };

  const handleSavePrefs = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingPrefs(true);
    try {
      const updated = await apiFetch('/api/notification-preferences', {
        method: 'PUT',
        body: JSON.stringify(prefs),
      });
      setPrefs((prev) => ({ ...prev, ...updated }));
      setFeedback('Notification event preferences saved.');
    } finally {
      setSavingPrefs(false);
    }
  };

  const filteredMessages =
    selectedStudentId === 'all'
      ? messages
      : messages.filter((m) => String(m.studentId) === selectedStudentId);

  const unreadCount = notifications.filter((n) => !n.isRead).length;

  const prefToggles: Array<{ key: keyof NotificationPref; label: string; desc: string }> = [
    { key: 'absentAlerts', label: 'Absentee Alerts', desc: 'Notify immediately when student is marked absent.' },
    { key: 'attendanceUpdates', label: 'Late & Leave Attendance Updates', desc: 'Notify on late arrivals or approved leave records.' },
    { key: 'homeworkAlerts', label: 'Homework & Assignment Notices', desc: 'Alert when new homework is published or graded.' },
    { key: 'examAlerts', label: 'Exams & Result Publishing', desc: 'Schedule updates, quiz reviews, and published marks.' },
    { key: 'liveClassAlerts', label: 'Live Class & Lesson Updates', desc: 'Links and schedules for upcoming live sessions.' },
    { key: 'prayerUpdates', label: 'Five-Times Namaz Guidance Updates', desc: 'Privacy-preserving prayer guidance updates.' },
    { key: 'foodUpdates', label: 'Daily Meal & Activity Summary', desc: 'Updates when meal or daily activity logs are posted.' },
    { key: 'healthAlerts', label: 'Health & Care Updates', desc: 'Urgent parent follow-up requests remain always active.' },
    { key: 'teacherMessages', label: 'Direct Teacher-Parent Messages', desc: 'In-app alerts when a direct remark is received.' },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-1 p-1 bg-white border border-emerald-900/10 rounded-xl self-start">
          <button
            type="button"
            onClick={() => setSubTab('notifications')}
            className={`px-4 py-2 text-xs font-semibold rounded-lg inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
              subTab === 'notifications' ? 'bg-emerald-800 text-white' : 'text-slate-600 hover:text-emerald-900'
            }`}
          >
            <Bell className="h-3.5 w-3.5" />
            <span>{t(lang, 'recentNotices')} ({unreadCount})</span>
          </button>
          {!isStudent && (
            <button
              type="button"
              onClick={() => setSubTab('messages')}
              className={`px-4 py-2 text-xs font-semibold rounded-lg inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
                subTab === 'messages' ? 'bg-emerald-800 text-white' : 'text-slate-600 hover:text-emerald-900'
              }`}
            >
              <MessageSquare className="h-3.5 w-3.5" />
              <span>Teacher–Parent Messages ({messages.length})</span>
            </button>
          )}
          <button
            type="button"
            onClick={() => setSubTab('preferences')}
            className={`px-4 py-2 text-xs font-semibold rounded-lg inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
              subTab === 'preferences' ? 'bg-emerald-800 text-white' : 'text-slate-600 hover:text-emerald-900'
            }`}
          >
            <Settings2 className="h-3.5 w-3.5" />
            <span>{t(lang, 'notificationSettings')}</span>
          </button>
        </div>
      </div>

      {feedback && (
        <div className="rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-2.5 text-xs text-emerald-900">
          {feedback}
        </div>
      )}

      {loading ? (
        <div className="bg-white border border-emerald-900/10 rounded-2xl p-8 text-center text-xs text-slate-500">
          {t(lang, 'loading')}
        </div>
      ) : subTab === 'notifications' ? (
        <div className="space-y-6">
          {canBroadcast && (
            <form onSubmit={handleSendAnnouncement} className="bg-white border border-emerald-900/10 rounded-2xl p-6 space-y-3 text-xs">
              <h2 className="font-display text-base font-bold text-slate-950">Send Institutional Alert / Announcement</h2>
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                <input
                  type="text"
                  required
                  placeholder="Notification Title *"
                  value={notifForm.title}
                  onChange={(e) => setNotifForm({ ...notifForm, title: e.target.value })}
                  className="sm:col-span-2 rounded-xl border border-slate-200 px-3 py-2"
                />
                <select
                  value={notifForm.type}
                  onChange={(e) => setNotifForm({ ...notifForm, type: e.target.value })}
                  className="rounded-xl border border-slate-200 px-3 py-2 bg-white"
                >
                  <option value="announcement">Announcement</option>
                  <option value="attendance">Attendance</option>
                  <option value="homework">Homework</option>
                  <option value="exam">Examination</option>
                  <option value="live_class">Live Class</option>
                  <option value="fee">Fee Reminder</option>
                </select>
                <select
                  value={notifForm.targetRole}
                  onChange={(e) => setNotifForm({ ...notifForm, targetRole: e.target.value })}
                  className="rounded-xl border border-slate-200 px-3 py-2 bg-white"
                >
                  <option value="all">All Users</option>
                  <option value="parent">Parents</option>
                  <option value="student">Students</option>
                  <option value="teacher">Teachers</option>
                </select>
              </div>
              <div className="flex flex-col sm:flex-row gap-2.5">
                <input
                  type="text"
                  required
                  placeholder="Write detailed announcement or reminder..."
                  value={notifForm.message}
                  onChange={(e) => setNotifForm({ ...notifForm, message: e.target.value })}
                  className="flex-1 rounded-xl border border-slate-200 px-3 py-2"
                />
                <button
                  type="submit"
                  disabled={sending}
                  className="px-4 py-2 rounded-xl bg-emerald-800 hover:bg-emerald-900 text-white font-semibold inline-flex items-center justify-center gap-1.5 cursor-pointer whitespace-nowrap"
                >
                  <Send className="h-3.5 w-3.5" />
                  <span>Publish Alert</span>
                </button>
              </div>
            </form>
          )}

          <div className="bg-white border border-emerald-900/10 rounded-2xl divide-y divide-slate-100">
            {notifications.length === 0 ? (
              <div className="p-8 text-center text-xs text-slate-500">{t(lang, 'noRecords')}</div>
            ) : (
              notifications.map((n) => (
                <div
                  key={n.id}
                  className={`p-4 flex items-start justify-between gap-4 ${
                    n.isRead ? 'bg-white' : 'bg-emerald-50/35'
                  }`}
                >
                  <div className="space-y-1">
                    <div className="flex flex-wrap items-center gap-2 text-[11px] text-slate-500">
                      <span className="font-semibold text-emerald-800 uppercase">{n.type}</span>
                      <span>·</span>
                      <span>Audience: {n.targetRole}</span>
                      <span>·</span>
                      <span className="font-mono-num">{new Date(n.createdAt).toLocaleString()}</span>
                    </div>
                    <div className="font-semibold text-slate-950 text-xs">{n.title}</div>
                    <p className="text-xs text-slate-600 leading-relaxed">{n.message}</p>
                  </div>
                  {!n.isRead && (
                    <button
                      type="button"
                      onClick={() => handleMarkRead(n.id)}
                      className="px-2.5 py-1 rounded-lg border border-emerald-800/30 text-emerald-900 hover:bg-emerald-50 text-[11px] font-medium inline-flex items-center gap-1 shrink-0 cursor-pointer"
                    >
                      <CheckCircle2 className="h-3.5 w-3.5" />
                      <span>Mark Read</span>
                    </button>
                  )}
                </div>
              ))
            )}
          </div>
        </div>
      ) : subTab === 'messages' ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {canMessage && (
            <form onSubmit={handleSendMessage} className="lg:col-span-4 bg-white border border-emerald-900/10 rounded-2xl p-5 space-y-3 text-xs self-start">
              <h2 className="font-display text-base font-bold text-slate-950">Send Direct Note</h2>
              <p className="text-[11px] text-slate-500">
                Messages are strictly scoped to authorized parents, class teachers, and institution administration.
              </p>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Student Context</label>
                <select
                  required
                  value={msgStudentId}
                  onChange={(e) => setMsgStudentId(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 px-3 py-2 bg-white"
                >
                  <option value="">Select Student...</option>
                  {students.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.fullName} ({s.admissionNo})
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Message</label>
                <textarea
                  required
                  rows={4}
                  placeholder="Write note regarding attendance, homework, behavior, or care..."
                  value={msgBody}
                  onChange={(e) => setMsgBody(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 px-3 py-2"
                />
              </div>
              <button
                type="submit"
                disabled={sending || !msgStudentId}
                className="w-full py-2.5 rounded-xl bg-emerald-800 hover:bg-emerald-900 text-white font-semibold inline-flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Send className="h-3.5 w-3.5" />
                <span>Send Message</span>
              </button>
            </form>
          )}

          <div className={`${canMessage ? 'lg:col-span-8' : 'lg:col-span-12'} bg-white border border-emerald-900/10 rounded-2xl p-5 space-y-4`}>
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-3">
              <h2 className="font-display text-base font-bold text-slate-950">Conversation History</h2>
              <select
                value={selectedStudentId}
                onChange={(e) => setSelectedStudentId(e.target.value)}
                className="rounded-xl border border-slate-200 px-3 py-1.5 text-xs bg-white"
              >
                <option value="all">All Authorized Students</option>
                {students.map((s) => (
                  <option key={s.id} value={String(s.id)}>
                    {s.fullName}
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-3 max-h-[520px] overflow-y-auto">
              {filteredMessages.length === 0 ? (
                <div className="py-10 text-center text-xs text-slate-500">{t(lang, 'noRecords')}</div>
              ) : (
                filteredMessages.map((m) => {
                  const isMine = m.senderId === user?.id;
                  return (
                    <div
                      key={m.id}
                      className={`p-3.5 rounded-xl border text-xs ${
                        isMine
                          ? 'border-emerald-900/20 bg-emerald-50/40'
                          : 'border-slate-200 bg-[#FAFBF9]'
                      }`}
                    >
                      <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-500 mb-1">
                        <div>
                          <span className="font-semibold text-slate-900">{m.senderName}</span>
                          <span className="uppercase text-emerald-800 ms-1.5 font-medium">({m.senderRole})</span>
                          <span className="mx-1.5">·</span>
                          <span>Student: {m.studentName}</span>
                        </div>
                        <span className="font-mono-num">{new Date(m.createdAt).toLocaleString()}</span>
                      </div>
                      <p className="text-slate-800 leading-relaxed">{m.message}</p>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>
      ) : (
        <div className="space-y-6">
          <div className="bg-white border border-emerald-900/10 rounded-2xl p-6 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
              <div>
                <h2 className="font-display text-base font-bold text-slate-950 flex items-center gap-2">
                  <ShieldCheck className="h-4 w-4 text-emerald-800" />
                  <span>Browser Alert Permission & Delivery Channel</span>
                </h2>
                <p className="text-xs text-slate-600 mt-1">
                  In-app portal alerts are always active. Server-side Firebase Cloud Messaging (FCM) push keys are not configured on this instance, so browser notifications operate via local browser permission when enabled.
                </p>
              </div>
              <button
                type="button"
                onClick={handleRequestBrowserConsent}
                className="px-4 py-2 rounded-xl border border-emerald-800 text-emerald-900 hover:bg-emerald-50 text-xs font-semibold cursor-pointer whitespace-nowrap shrink-0"
              >
                {browserPermission === 'granted' ? 'Browser Permission Active' : 'Enable Browser Alerts'}
              </button>
            </div>
            <div className="text-xs text-slate-600 flex flex-wrap gap-4">
              <span>Current Delivery Mode: <strong className="text-emerald-900">{prefs.deliveryStatus}</strong></span>
              <span>·</span>
              <span>Browser Status: <strong className="text-slate-900 uppercase">{browserPermission}</strong></span>
            </div>
          </div>

          <form onSubmit={handleSavePrefs} className="bg-white border border-emerald-900/10 rounded-2xl p-6 space-y-4">
            <h2 className="font-display text-base font-bold text-slate-950">Event Notification Controls</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {prefToggles.map((item) => (
                <label
                  key={item.key}
                  className="p-3.5 rounded-xl border border-slate-200 hover:border-emerald-800/30 flex items-start justify-between gap-3 cursor-pointer"
                >
                  <div>
                    <div className="text-xs font-semibold text-slate-900">{item.label}</div>
                    <div className="text-[11px] text-slate-500 mt-0.5">{item.desc}</div>
                  </div>
                  <input
                    type="checkbox"
                    checked={Boolean(prefs[item.key])}
                    onChange={(e) => setPrefs((prev) => ({ ...prev, [item.key]: e.target.checked }))}
                    className="mt-0.5 h-4 w-4 accent-emerald-800"
                  />
                </label>
              ))}
            </div>
            <div className="flex justify-end pt-2">
              <button
                type="submit"
                disabled={savingPrefs}
                className="px-5 py-2.5 rounded-xl bg-emerald-800 hover:bg-emerald-900 text-white text-xs font-semibold cursor-pointer"
              >
                {t(lang, 'save')}
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
