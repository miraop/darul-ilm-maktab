import React, { useEffect, useState } from 'react';
import { CreditCard, Download, Plus } from 'lucide-react';
import { useAuth } from '../../context/AuthContext.tsx';
import { t } from '../../i18n/translations.ts';
import { exportFeeReceiptPdf } from '../../utils/exports.ts';

export const FeesView: React.FC = () => {
  const { user, lang, apiFetch } = useAuth();
  const [students, setStudents] = useState<any[]>([]);
  const [fees, setFees] = useState<any[]>([]);
  const [payments, setPayments] = useState<any[]>([]);
  const [payingFee, setPayingFee] = useState<any | null>(null);
  const [paymentMethod, setPaymentMethod] = useState('upi');
  const [showCreateFee, setShowCreateFee] = useState(false);
  const [feeForm, setFeeForm] = useState({
    studentId: '',
    monthYear: '2026-11',
    title: 'Monthly Maktab Tuition',
    amount: 1800,
    dueDate: '2026-11-30',
  });
  const [notice, setNotice] = useState<string | null>(null);

  const loadAll = async () => {
    const [st, fData] = await Promise.all([apiFetch('/api/students'), apiFetch('/api/fees')]);
    setStudents(st);
    setFees(fData.fees || []);
    setPayments(fData.payments || []);
    if (st.length > 0 && !feeForm.studentId) {
      setFeeForm((p) => ({ ...p, studentId: String(st[0].id) }));
    }
  };

  useEffect(() => {
    loadAll();
  }, []);

  const studentMap = new Map(students.map((s) => [s.id, s]));
  const paymentByFee = new Map(payments.map((p) => [p.feeId, p]));

  const totalPaid = fees.filter((f) => f.status === 'paid').reduce((a, b) => a + b.amount, 0);
  const totalPending = fees.filter((f) => f.status !== 'paid').reduce((a, b) => a + b.amount, 0);

  const handleCreateFee = async (e: React.FormEvent) => {
    e.preventDefault();
    await apiFetch('/api/fees', { method: 'POST', body: JSON.stringify(feeForm) });
    setShowCreateFee(false);
    setNotice('Fee invoice created and guardian notified.');
    loadAll();
  };

  const handleProcessPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!payingFee) return;
    const res = await apiFetch(`/api/fees/${payingFee.id}/pay`, {
      method: 'POST',
      body: JSON.stringify({ paymentMethod }),
    });
    setPayingFee(null);
    setNotice(`Payment verified! Receipt ${res.payment.receiptNo} generated.`);
    loadAll();
  };

  const handleDownloadReceipt = (fee: any) => {
    const p = paymentByFee.get(fee.id);
    const st = studentMap.get(fee.studentId);
    if (!p) return;
    exportFeeReceiptPdf({
      receiptNo: p.receiptNo,
      studentName: st?.fullName || `Student #${fee.studentId}`,
      admissionNo: st?.admissionNo || 'N/A',
      feeTitle: fee.title,
      monthYear: fee.monthYear,
      amount: p.amountPaid,
      paymentMethod: p.paymentMethod,
      transactionRef: p.transactionRef,
      paidAt: p.paidAt,
    });
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white border border-emerald-900/10 rounded-xl p-5">
          <div className="text-xs text-slate-500">{t(lang, 'paidFees')}</div>
          <div className="font-mono-num text-2xl font-bold text-emerald-800 mt-1">₹{totalPaid.toLocaleString()}</div>
        </div>
        <div className="bg-white border border-emerald-900/10 rounded-xl p-5">
          <div className="text-xs text-slate-500">{t(lang, 'pendingFees')}</div>
          <div className="font-mono-num text-2xl font-bold text-amber-700 mt-1">₹{totalPending.toLocaleString()}</div>
        </div>
        <div className="bg-white border border-emerald-900/10 rounded-xl p-5 flex items-center justify-between">
          <div>
            <div className="text-xs text-slate-500">Verified Receipts</div>
            <div className="font-mono-num text-2xl font-bold text-slate-900 mt-1">{payments.length}</div>
          </div>
          {user?.role === 'admin' && (
            <button
              type="button"
              onClick={() => setShowCreateFee(true)}
              className="px-3.5 py-2 rounded-xl bg-emerald-800 text-white text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="h-4 w-4" />
              <span>Generate Invoice</span>
            </button>
          )}
        </div>
      </div>

      {notice && (
        <div className="rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-2.5 text-xs text-emerald-900">
          {notice}
        </div>
      )}

      <div className="bg-white border border-emerald-900/10 rounded-2xl overflow-hidden">
        <table className="w-full text-start border-collapse text-xs">
          <thead>
            <tr className="border-b border-slate-100 bg-slate-50/70 text-[11px] font-semibold text-slate-500">
              <th className="py-3 px-4 text-start">Student</th>
              <th className="py-3 px-4 text-start">Fee Title & Month</th>
              <th className="py-3 px-4 text-end">Amount</th>
              <th className="py-3 px-4 text-start">Due Date</th>
              <th className="py-3 px-4 text-start">Status</th>
              <th className="py-3 px-4 text-end">Action / Receipt</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {fees.map((f) => {
              const st = studentMap.get(f.studentId);
              const p = paymentByFee.get(f.id);
              return (
                <tr key={f.id}>
                  <td className="py-3.5 px-4 font-semibold text-slate-900">
                    {st?.fullName || `Student #${f.studentId}`}
                  </td>
                  <td className="py-3.5 px-4">
                    <div className="text-slate-800 font-medium">{f.title}</div>
                    <div className="text-[11px] font-mono-num text-slate-500">{f.monthYear}</div>
                  </td>
                  <td className="py-3.5 px-4 text-end font-mono-num font-bold text-slate-900">
                    ₹{f.amount.toLocaleString()}
                  </td>
                  <td className="py-3.5 px-4 font-mono-num text-slate-600">{f.dueDate}</td>
                  <td className="py-3.5 px-4">
                    <span className={`font-semibold uppercase ${f.status === 'paid' ? 'text-emerald-700' : 'text-amber-700'}`}>
                      {f.status}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 text-end">
                    {f.status === 'paid' && p ? (
                      <button
                        type="button"
                        onClick={() => handleDownloadReceipt(f)}
                        className="px-3 py-1.5 rounded-lg border border-emerald-800 text-emerald-900 hover:bg-emerald-50 text-[11px] font-semibold inline-flex items-center gap-1 cursor-pointer"
                      >
                        <Download className="h-3.5 w-3.5" />
                        <span>{p.receiptNo}</span>
                      </button>
                    ) : (user?.role === 'admin' || user?.role === 'parent') ? (
                      <button
                        type="button"
                        onClick={() => setPayingFee(f)}
                        className="px-3 py-1.5 rounded-lg bg-emerald-800 text-white hover:bg-emerald-900 text-[11px] font-semibold inline-flex items-center gap-1 cursor-pointer"
                      >
                        <CreditCard className="h-3.5 w-3.5" />
                        <span>{t(lang, 'payNow')}</span>
                      </button>
                    ) : (
                      <span className="text-slate-400">Pending</span>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Payment Gateway Checkout Modal */}
      {payingFee && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <form onSubmit={handleProcessPayment} className="bg-white rounded-2xl max-w-md w-full p-6 space-y-4">
            <h3 className="font-display text-lg font-bold text-slate-950">Maktab Fee Payment Gateway</h3>
            <div className="p-4 rounded-xl bg-[#FAFBF9] border border-emerald-900/10 text-xs space-y-1">
              <div className="font-semibold text-slate-900">{payingFee.title}</div>
              <div className="text-slate-600">Student: {studentMap.get(payingFee.studentId)?.fullName}</div>
              <div className="font-mono-num text-lg font-bold text-emerald-900 pt-1">
                ₹{payingFee.amount.toLocaleString()}
              </div>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">Select Payment Channel</label>
              <select
                value={paymentMethod}
                onChange={(e) => setPaymentMethod(e.target.value)}
                className="w-full rounded-xl border border-slate-200 px-3 py-2 text-xs bg-white"
              >
                <option value="upi">UPI Instant Pay (GPay / PhonePe / Paytm)</option>
                <option value="card">Debit / Credit Card</option>
                <option value="bank_transfer">NEFT / Net Banking</option>
                {user?.role === 'admin' && <option value="cash">Maktab Office Cash Counter</option>}
              </select>
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button type="button" onClick={() => setPayingFee(null)} className="px-4 py-2 text-xs rounded-xl border border-slate-200 cursor-pointer">
                {t(lang, 'cancel')}
              </button>
              <button type="submit" className="px-4 py-2 text-xs font-semibold rounded-xl bg-emerald-800 text-white cursor-pointer">
                Confirm & Generate Receipt
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Admin Create Fee Modal */}
      {showCreateFee && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <form onSubmit={handleCreateFee} className="bg-white rounded-2xl max-w-md w-full p-6 space-y-3 text-xs">
            <h3 className="font-display text-lg font-bold text-slate-950">Generate Student Fee Invoice</h3>
            <select
              value={feeForm.studentId}
              onChange={(e) => setFeeForm({ ...feeForm, studentId: e.target.value })}
              className="w-full rounded-xl border border-slate-200 px-3 py-2 bg-white"
            >
              {students.map((s) => <option key={s.id} value={s.id}>{s.fullName}</option>)}
            </select>
            <input
              type="text"
              required
              placeholder="Invoice Title"
              value={feeForm.title}
              onChange={(e) => setFeeForm({ ...feeForm, title: e.target.value })}
              className="w-full rounded-xl border border-slate-200 px-3 py-2"
            />
            <div className="grid grid-cols-3 gap-2">
              <input
                type="month"
                required
                value={feeForm.monthYear}
                onChange={(e) => setFeeForm({ ...feeForm, monthYear: e.target.value })}
                className="rounded-xl border border-slate-200 px-3 py-2"
              />
              <input
                type="number"
                required
                value={feeForm.amount}
                onChange={(e) => setFeeForm({ ...feeForm, amount: Number(e.target.value) })}
                className="rounded-xl border border-slate-200 px-3 py-2"
              />
              <input
                type="date"
                required
                value={feeForm.dueDate}
                onChange={(e) => setFeeForm({ ...feeForm, dueDate: e.target.value })}
                className="rounded-xl border border-slate-200 px-3 py-2"
              />
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button type="button" onClick={() => setShowCreateFee(false)} className="px-4 py-2 rounded-xl border border-slate-200 cursor-pointer">
                {t(lang, 'cancel')}
              </button>
              <button type="submit" className="px-4 py-2 rounded-xl bg-emerald-800 text-white font-semibold cursor-pointer">
                Create Invoice
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
