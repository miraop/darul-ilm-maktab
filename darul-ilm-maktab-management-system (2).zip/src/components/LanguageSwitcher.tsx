import React from 'react';
import { Globe } from 'lucide-react';
import { useAuth } from '../context/AuthContext.tsx';
import { Lang, LANGUAGES } from '../i18n/translations.ts';

export const LanguageSwitcher: React.FC<{ compact?: boolean }> = ({ compact = false }) => {
  const { lang, setLang } = useAuth();

  return (
    <div
      className="inline-flex items-center gap-1 rounded-lg border border-emerald-900/15 bg-white p-1"
      role="group"
      aria-label="Language switcher"
    >
      {!compact && <Globe className="mx-1.5 h-3.5 w-3.5 text-emerald-800 shrink-0" />}
      {LANGUAGES.map((l) => {
        const active = lang === l.code;
        return (
          <button
            key={l.code}
            type="button"
            onClick={() => setLang(l.code as Lang)}
            className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              active
                ? 'bg-emerald-800 text-white'
                : 'text-slate-600 hover:text-emerald-900 hover:bg-emerald-50'
            }`}
          >
            {l.native}
          </button>
        );
      })}
    </div>
  );
};
