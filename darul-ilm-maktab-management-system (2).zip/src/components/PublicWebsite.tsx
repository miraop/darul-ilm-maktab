import React, { useEffect, useState } from 'react';
import {
  BookOpen,
  Calendar,
  CheckCircle2,
  GraduationCap,
  Mail,
  MapPin,
  Menu,
  Phone,
  Users,
  X,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext.tsx';
import { t } from '../i18n/translations.ts';
import { LanguageSwitcher } from './LanguageSwitcher.tsx';

interface PublicWebsiteProps {
  onOpenLogin: () => void;
  onOpenPortal: () => void;
}

const ASSETS = {
  hero: '/src/assets/images/hero_maktab_campus_1794553568085.jpg',
  quran: '/src/assets/images/course_quran_hifz_1794553569142.jpg',
  studies: '/src/assets/images/course_islamic_studies_1794553569399.jpg',
  classroom: '/src/assets/images/gallery_classroom_study_1794553569685.jpg',
  scholar: '/src/assets/images/teacher_portrait_scholar_1794553588213.jpg',
};

export const PublicWebsite: React.FC<PublicWebsiteProps> = ({ onOpenLogin, onOpenPortal }) => {
  const { lang, user } = useAuth();
  const [institutions, setInstitutions] = useState<{ id: number; name: string; slug: string; city?: string | null }[]>([]);
  const [selectedSlug, setSelectedSlug] = useState<string>('darul-ilm');
  const [overview, setOverview] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [courseFilter, setCourseFilter] = useState<string>('All');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeLightbox, setActiveLightbox] = useState<{ src: string; caption: string } | null>(null);

  // Admission form state
  const [admForm, setAdmForm] = useState({
    applicantName: '',
    dob: '',
    gender: 'Male',
    guardianName: '',
    guardianPhone: '',
    guardianEmail: '',
    desiredClass: 'Hifz & Nazra — Level 1',
    previousEducation: '',
    address: '',
  });
  const [admStatus, setAdmStatus] = useState<{ ok?: string; err?: string; busy?: boolean }>({});

  // Contact form state
  const [contactForm, setContactForm] = useState({ name: '', email: '', phone: '', subject: '', message: '' });
  const [contactStatus, setContactStatus] = useState<{ ok?: string; err?: string; busy?: boolean }>({});

  useEffect(() => {
    fetch('/api/public/institutions')
      .then((r) => r.json())
      .then((rows) => {
        if (Array.isArray(rows) && rows.length > 0) {
          setInstitutions(rows);
          if (!rows.some((r: any) => r.slug === 'darul-ilm')) {
            setSelectedSlug(rows[0].slug);
          }
        }
      })
      .catch(() => {});
  }, []);

  useEffect(() => {
    setLoading(true);
    fetch(`/api/public/overview?slug=${encodeURIComponent(selectedSlug)}`)
      .then((r) => r.json())
      .then((d) => setOverview(d))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [selectedSlug]);

  const settings = overview?.settings || {};
  const subjects: any[] = overview?.subjects || [];
  const teachers: any[] = overview?.teachers || [];
  const notices: any[] = overview?.notices || [];
  const stats = overview?.stats || { totalStudents: 0, totalTeachers: 0, totalClasses: 0, totalSubjects: 0 };

  const filteredSubjects =
    courseFilter === 'All' ? subjects : subjects.filter((s) => s.category === courseFilter);

  const handleAdmissionSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAdmStatus({ busy: true });
    try {
      const res = await fetch('/api/public/admission', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...admForm, institutionSlug: selectedSlug }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Submission failed');
      setAdmStatus({
        ok: `Application #${data.id} received for ${data.applicantName}. Our admissions office will contact ${data.guardianPhone}.`,
      });
      setAdmForm({
        applicantName: '',
        dob: '',
        gender: 'Male',
        guardianName: '',
        guardianPhone: '',
        guardianEmail: '',
        desiredClass: 'Hifz & Nazra — Level 1',
        previousEducation: '',
        address: '',
      });
    } catch (err: any) {
      setAdmStatus({ err: err.message });
    }
  };

  const handleContactSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setContactStatus({ busy: true });
    try {
      const res = await fetch('/api/public/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...contactForm, institutionSlug: selectedSlug }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to send inquiry');
      setContactStatus({ ok: 'Thank you. Your message has been delivered to the Maktab administration office.' });
      setContactForm({ name: '', email: '', phone: '', subject: '', message: '' });
    } catch (err: any) {
      setContactStatus({ err: err.message });
    }
  };

  return (
    <div className="min-h-screen bg-[#FAFBF9] text-slate-900">
      {/* Top Bar Contract: 3 clean zones separated by gap-8 */}
      <header className="sticky top-0 z-40 border-b border-emerald-900/10 bg-white/95 backdrop-blur">
        <div className="max-w-7xl mx-auto px-6 py-3.5 flex items-center justify-between gap-8">
          {/* Zone 1: Brand Title */}
          <a
            href="#home"
            className="font-display text-lg font-bold tracking-tight text-emerald-950 whitespace-nowrap shrink-0"
          >
            {settings.maktab_name || t(lang, 'brandName')}
          </a>

          {/* Zone 2: 5 concise single-line nav links */}
          <nav className="hidden lg:flex items-center gap-6 text-sm font-medium text-slate-600">
            <a href="#about" className="hover:text-emerald-800 transition-colors whitespace-nowrap shrink-0">
              {t(lang, 'navAbout')}
            </a>
            <a href="#courses" className="hover:text-emerald-800 transition-colors whitespace-nowrap shrink-0">
              {t(lang, 'navCourses')}
            </a>
            <a href="#teachers" className="hover:text-emerald-800 transition-colors whitespace-nowrap shrink-0">
              {t(lang, 'navTeachers')}
            </a>
            <a href="#notices" className="hover:text-emerald-800 transition-colors whitespace-nowrap shrink-0">
              {t(lang, 'navNotices')}
            </a>
            <a href="#admission" className="hover:text-emerald-800 transition-colors whitespace-nowrap shrink-0">
              {t(lang, 'navAdmission')}
            </a>
          </nav>

          {/* Zone 3: Language Switcher + Single Primary CTA */}
          <div className="hidden md:flex items-center gap-3 shrink-0">
            <LanguageSwitcher compact />
            <button
              type="button"
              onClick={user ? onOpenPortal : onOpenLogin}
              className="px-4 py-2 text-xs font-semibold text-white bg-emerald-800 hover:bg-emerald-900 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              {user ? t(lang, 'openPortal') : t(lang, 'portalLogin')}
            </button>
          </div>

          <button
            type="button"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 rounded-lg border border-slate-200 text-slate-700 cursor-pointer"
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>

        {/* Mobile Drawer */}
        {mobileMenuOpen && (
          <div className="lg:hidden border-t border-emerald-900/10 bg-white px-6 py-4 space-y-3">
            <div className="flex flex-wrap gap-3 text-sm font-medium text-slate-700">
              {['home', 'about', 'courses', 'teachers', 'notices', 'gallery', 'admission', 'contact'].map((sec) => (
                <a
                  key={sec}
                  href={`#${sec}`}
                  onClick={() => setMobileMenuOpen(false)}
                  className="py-1.5 px-2.5 rounded-md hover:bg-emerald-50 text-slate-700"
                >
                  {t(lang, `nav${sec.charAt(0).toUpperCase() + sec.slice(1)}`)}
                </a>
              ))}
            </div>
            <div className="flex items-center justify-between pt-2 border-t border-slate-100">
              <LanguageSwitcher compact />
              <button
                type="button"
                onClick={() => {
                  setMobileMenuOpen(false);
                  user ? onOpenPortal() : onOpenLogin();
                }}
                className="px-4 py-2 text-xs font-semibold text-white bg-emerald-800 rounded-lg cursor-pointer"
              >
                {user ? t(lang, 'openPortal') : t(lang, 'portalLogin')}
              </button>
            </div>
          </div>
        )}
      </header>

      {/* Hero Section */}
      <section id="home" className="islamic-lattice border-b border-emerald-900/10">
        <div className="max-w-7xl mx-auto px-6 py-14 lg:py-20 grid grid-cols-1 lg:grid-cols-12 gap-10 items-stretch">
          <div className="lg:col-span-6 flex flex-col justify-center">
            <div className="flex flex-wrap items-center justify-between gap-3 mb-3">
              <p className="text-xs font-semibold text-amber-700 tracking-wide">
                {t(lang, 'heroBadge')} · {overview?.institution?.name || settings.maktab_name || 'Kabeer Sb Maktab'}
              </p>
              {institutions.length > 1 && (
                <select
                  aria-label="Select Maktab Campus"
                  value={selectedSlug}
                  onChange={(e) => setSelectedSlug(e.target.value)}
                  className="text-xs font-medium text-emerald-900 bg-white border border-emerald-900/15 rounded-lg px-2.5 py-1 focus:outline-none focus:border-emerald-700 cursor-pointer"
                >
                  {institutions.map((inst) => (
                    <option key={inst.id} value={inst.slug}>
                      {inst.name}
                    </option>
                  ))}
                </select>
              )}
            </div>
            <h1
              className="font-display font-bold text-slate-950 tracking-tight leading-[1.15] mb-5"
              style={{ fontSize: 'clamp(2.15rem, 3.8vw, 3.35rem)', textWrap: 'balance' }}
            >
              {t(lang, 'heroTitle')}
            </h1>
            <p className="text-base text-slate-600 leading-relaxed max-w-xl mb-8">
              {t(lang, 'heroSubtitle')}
            </p>
            <div className="flex flex-wrap items-center gap-3">
              <a
                href="#admission"
                className="px-6 py-3 rounded-xl bg-emerald-800 hover:bg-emerald-900 text-white text-sm font-semibold transition-colors whitespace-nowrap"
              >
                {t(lang, 'applyAdmission')}
              </a>
              <button
                type="button"
                onClick={user ? onOpenPortal : onOpenLogin}
                className="px-6 py-3 rounded-xl border border-emerald-900/20 bg-white hover:bg-emerald-50 text-emerald-950 text-sm font-semibold transition-colors whitespace-nowrap cursor-pointer"
              >
                {user ? t(lang, 'openPortal') : t(lang, 'portalLogin')}
              </button>
            </div>
          </div>

          <div className="lg:col-span-6">
            <div className="relative h-72 sm:h-96 lg:h-full min-h-[340px] rounded-2xl overflow-hidden border border-emerald-900/15 bg-emerald-950">
              <img
                src={ASSETS.hero}
                alt="Kabeer Sb Maktab courtyard with white arches and emerald garden"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
                onError={(e) => {
                  (e.currentTarget as HTMLImageElement).style.display = 'none';
                }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-emerald-950/75 via-emerald-950/15 to-transparent flex items-end p-6">
                <div className="text-white">
                  <p className="text-xs font-medium text-amber-300">
                    Deeni Taleem · General Academics · Five-Time Namaz Care
                  </p>
                  <p className="font-display text-lg font-semibold mt-1">
                    {settings.address || 'Jamia Nagar Educational Campus, New Delhi'}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Full-Width 4-Column Live Institution Strip */}
        <div className="max-w-7xl mx-auto px-6 pb-12">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { label: t(lang, 'statStudents'), value: loading ? '—' : stats.totalStudents },
              { label: t(lang, 'statTeachers'), value: loading ? '—' : stats.totalTeachers },
              { label: t(lang, 'statClasses'), value: loading ? '—' : stats.totalClasses },
              { label: t(lang, 'statSubjects'), value: loading ? '—' : stats.totalSubjects },
            ].map((item) => (
              <div key={item.label} className="bg-white border border-emerald-900/10 rounded-xl px-5 py-4">
                <div className="text-xs font-medium text-slate-500">{item.label}</div>
                <div className="font-mono-num text-2xl font-bold text-emerald-900 mt-1">{item.value}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-16 border-b border-emerald-900/10 bg-white">
        <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          <div className="lg:col-span-5">
            <div className="rounded-2xl overflow-hidden border border-emerald-900/12 aspect-[4/3] bg-emerald-900/10">
              <img
                src={ASSETS.quran}
                alt="Open Quran on carved wooden Rehal bookstand"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
          <div className="lg:col-span-7">
            <p className="text-xs font-semibold text-amber-700 mb-2">01. Educational Philosophy</p>
            <h2 className="font-display text-3xl font-bold text-slate-950 mb-4" style={{ textWrap: 'balance' }}>
              {t(lang, 'aboutTitle')}
            </h2>
            <p className="text-slate-600 leading-relaxed mb-6">{t(lang, 'aboutLead')}</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {[
                {
                  title: 'Five-Times Namaz Care',
                  body: 'Structured prayer guidance across Fajr, Zuhr, Asr, Maghrib, and Isha with honest unmarked-record tracking.',
                },
                {
                  title: 'Parent Transparency',
                  body: 'Real-time daily meal logs, homework completion, restricted health summaries, and monthly PDF report cards.',
                },
                {
                  title: 'Bilingual & RTL Ready',
                  body: 'Full interface support across English, Hindi, and right-to-left Urdu for every family.',
                },
                {
                  title: 'Digital Classroom',
                  body: 'Live classes, recorded Tajweed and math lesson replays, downloadable PDFs, and interactive MCQ quizzes.',
                },
              ].map((feat) => (
                <div key={feat.title} className="p-4 rounded-xl border border-emerald-900/10 bg-[#FAFBF9]">
                  <h3 className="font-semibold text-sm text-emerald-950 mb-1">{feat.title}</h3>
                  <p className="text-xs text-slate-600 leading-relaxed">{feat.body}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Courses Section */}
      <section id="courses" className="py-16 border-b border-emerald-900/10">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
            <div>
              <p className="text-xs font-semibold text-amber-700 mb-1">02. Structured Syllabus</p>
              <h2 className="font-display text-3xl font-bold text-slate-950">{t(lang, 'coursesTitle')}</h2>
            </div>
            <div className="flex items-center gap-1 p-1 bg-white border border-emerald-900/10 rounded-xl self-start">
              {['All', 'Deeni', 'General', 'Language'].map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setCourseFilter(cat)}
                  className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
                    courseFilter === cat ? 'bg-emerald-800 text-white' : 'text-slate-600 hover:text-emerald-900'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {filteredSubjects.length === 0 ? (
            <div className="bg-white border border-emerald-900/10 rounded-2xl p-8 text-center text-sm text-slate-500">
              No subjects published for this institution yet. Administrators can add courses from their Maktab portal.
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredSubjects.map((sub) => {
                const pct =
                  sub.syllabusTotalUnits > 0
                    ? Math.min(100, Math.round((sub.syllabusCompletedUnits / sub.syllabusTotalUnits) * 100))
                    : 0;
                return (
                  <div key={sub.id} className="bg-white border border-emerald-900/10 rounded-2xl p-6 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center gap-2 text-xs text-slate-500 mb-2">
                        <span className="font-semibold text-emerald-800">{sub.category}</span>
                        <span aria-hidden="true">·</span>
                        <span className="font-mono-num">{sub.code}</span>
                      </div>
                      <h3 className="font-display text-lg font-bold text-slate-950 mb-2">{sub.name}</h3>
                      <p className="text-sm text-slate-600 leading-relaxed mb-4">
                        {sub.description || 'Comprehensive guided instruction and periodic assessment.'}
                      </p>
                    </div>
                    <div>
                      <div className="flex justify-between text-xs text-slate-500 mb-1.5">
                        <span>Syllabus Progress</span>
                        <span className="font-mono-num font-semibold text-emerald-900">{pct}%</span>
                      </div>
                      <div className="h-1.5 rounded-full bg-slate-100 overflow-hidden">
                        <div className="h-full bg-emerald-700 rounded-full" style={{ width: `${pct}%` }} />
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </section>

      {/* Teachers & Notice Board */}
      <section id="teachers" className="py-16 border-b border-emerald-900/10 bg-white">
        <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-12 gap-10">
          {/* Teachers */}
          <div className="lg:col-span-6">
            <p className="text-xs font-semibold text-amber-700 mb-1">03. Faculty</p>
            <h2 className="font-display text-2xl font-bold text-slate-950 mb-6">{t(lang, 'teachersTitle')}</h2>
            <div className="space-y-4">
              {teachers.length === 0 ? (
                <div className="p-6 rounded-xl border border-emerald-900/10 bg-[#FAFBF9] text-sm text-slate-500">
                  No faculty profiles listed for this institution yet.
                </div>
              ) : (
                teachers.map((tr) => (
                  <div key={tr.id} className="flex items-center gap-4 p-4 rounded-xl border border-emerald-900/10 bg-[#FAFBF9]">
                    <img
                      src={ASSETS.scholar}
                      alt={tr.name}
                      referrerPolicy="no-referrer"
                      className="h-14 w-14 rounded-xl object-cover border border-emerald-900/10 shrink-0"
                    />
                    <div className="min-w-0">
                      <h3 className="font-semibold text-slate-950 truncate">{tr.name}</h3>
                      <p className="text-xs text-emerald-800 font-medium mt-0.5">
                        {tr.specialization || 'Islamic & General Education'}
                      </p>
                      <p className="text-xs text-slate-500 mt-0.5">{tr.qualification || 'Certified Educator'}</p>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Notice Board */}
          <div id="notices" className="lg:col-span-6">
            <p className="text-xs font-semibold text-amber-700 mb-1">04. Announcements</p>
            <h2 className="font-display text-2xl font-bold text-slate-950 mb-6">{t(lang, 'noticesTitle')}</h2>
            <div className="space-y-4">
              {notices.length === 0 ? (
                <div className="p-6 rounded-xl border border-emerald-900/10 bg-[#FAFBF9] text-sm text-slate-500">
                  No public notices posted by this institution yet.
                </div>
              ) : (
                notices.map((n) => (
                  <div key={n.id} className="p-5 rounded-xl border border-emerald-900/10 bg-[#FAFBF9]">
                    <div className="flex items-center gap-2 text-xs text-slate-500 mb-1.5">
                      <span className="font-semibold text-amber-700">{n.category}</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono-num">{new Date(n.publishedAt).toLocaleDateString()}</span>
                    </div>
                    <h3 className="font-semibold text-slate-950 mb-1.5">{n.title}</h3>
                    <p className="text-sm text-slate-600 leading-relaxed">{n.content}</p>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Gallery */}
      <section id="gallery" className="py-16 border-b border-emerald-900/10">
        <div className="max-w-7xl mx-auto px-6">
          <p className="text-xs font-semibold text-amber-700 mb-1">05. Campus Gallery</p>
          <h2 className="font-display text-3xl font-bold text-slate-950 mb-8">{t(lang, 'galleryTitle')}</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {[
              { src: ASSETS.hero, caption: 'Main Courtyard & Morning Assembly Garden' },
              { src: ASSETS.classroom, caption: 'Bilingual Digital & Textbook Classroom' },
              { src: ASSETS.quran, caption: 'Hifz-ul-Quran & Tajweed Library' },
              { src: ASSETS.studies, caption: 'Calligraphy, Arabic & Urdu Study Corner' },
            ].map((img) => (
              <button
                key={img.caption}
                type="button"
                onClick={() => setActiveLightbox(img)}
                className="group text-start bg-white border border-emerald-900/10 rounded-2xl overflow-hidden cursor-pointer"
              >
                <div className="aspect-[4/3] overflow-hidden bg-slate-100">
                  <img
                    src={img.src}
                    alt={img.caption}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <div className="p-3.5 text-xs font-medium text-slate-700">{img.caption}</div>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Online Admission & Contact Us */}
      <section id="admission" className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-12 gap-10">
          {/* Online Admission Form */}
          <div className="lg:col-span-7 border border-emerald-900/12 rounded-2xl p-8 bg-[#FAFBF9]">
            <p className="text-xs font-semibold text-amber-700 mb-1">06. Admissions</p>
            <h2 className="font-display text-2xl font-bold text-slate-950 mb-2">{t(lang, 'admissionTitle')}</h2>
            <p className="text-sm text-slate-600 mb-6">
              Submit your child’s admission inquiry directly into our administrative register.
            </p>

            {admStatus.ok && (
              <div className="mb-4 p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-sm text-emerald-900 flex items-start gap-2.5">
                <CheckCircle2 className="h-4 w-4 text-emerald-700 mt-0.5 shrink-0" />
                <span>{admStatus.ok}</span>
              </div>
            )}
            {admStatus.err && (
              <div className="mb-4 p-4 rounded-xl bg-red-50 border border-red-200 text-sm text-red-800">{admStatus.err}</div>
            )}

            <form onSubmit={handleAdmissionSubmit} className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Student Full Name *</label>
                <input
                  type="text"
                  required
                  value={admForm.applicantName}
                  onChange={(e) => setAdmForm({ ...admForm, applicantName: e.target.value })}
                  className="w-full rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Date of Birth *</label>
                <input
                  type="date"
                  required
                  value={admForm.dob}
                  onChange={(e) => setAdmForm({ ...admForm, dob: e.target.value })}
                  className="w-full rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Guardian Name *</label>
                <input
                  type="text"
                  required
                  value={admForm.guardianName}
                  onChange={(e) => setAdmForm({ ...admForm, guardianName: e.target.value })}
                  className="w-full rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Guardian Phone *</label>
                <input
                  type="tel"
                  required
                  value={admForm.guardianPhone}
                  onChange={(e) => setAdmForm({ ...admForm, guardianPhone: e.target.value })}
                  className="w-full rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Desired Class *</label>
                <select
                  value={admForm.desiredClass}
                  onChange={(e) => setAdmForm({ ...admForm, desiredClass: e.target.value })}
                  className="w-full rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-sm"
                >
                  <option>Hifz & Nazra — Level 1</option>
                  <option>Primary Deeni & General — Grade 4</option>
                  <option>Middle Taleem — Grade 6</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Guardian Email</label>
                <input
                  type="email"
                  value={admForm.guardianEmail}
                  onChange={(e) => setAdmForm({ ...admForm, guardianEmail: e.target.value })}
                  className="w-full rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-sm"
                />
              </div>
              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-slate-700 mb-1">Residential Address *</label>
                <input
                  type="text"
                  required
                  value={admForm.address}
                  onChange={(e) => setAdmForm({ ...admForm, address: e.target.value })}
                  className="w-full rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-sm"
                />
              </div>
              <div className="sm:col-span-2">
                <button
                  type="submit"
                  disabled={admStatus.busy}
                  className="px-6 py-2.5 rounded-xl bg-emerald-800 hover:bg-emerald-900 text-white text-sm font-semibold transition-colors cursor-pointer"
                >
                  {admStatus.busy ? t(lang, 'loading') : t(lang, 'submit')}
                </button>
              </div>
            </form>
          </div>

          {/* Contact Us */}
          <div id="contact" className="lg:col-span-5 border border-emerald-900/12 rounded-2xl p-8 bg-white flex flex-col justify-between">
            <div>
              <p className="text-xs font-semibold text-amber-700 mb-1">07. Contact Office</p>
              <h2 className="font-display text-2xl font-bold text-slate-950 mb-4">{t(lang, 'contactTitle')}</h2>

              <div className="space-y-3 text-sm text-slate-600 mb-6">
                <div className="flex items-start gap-2.5">
                  <MapPin className="h-4 w-4 text-emerald-800 mt-1 shrink-0" />
                  <span>{settings.address || 'Lane 4, Jamia Nagar Educational Campus, New Delhi 110025'}</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <Phone className="h-4 w-4 text-emerald-800 shrink-0" />
                  <span className="font-mono-num">{settings.contact_phone || '+91 11 2698 4410'}</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <Mail className="h-4 w-4 text-emerald-800 shrink-0" />
                  <span>{settings.contact_email || 'admissions@darulilm.edu'}</span>
                </div>
              </div>

              {contactStatus.ok && (
                <div className="mb-4 p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-900">
                  {contactStatus.ok}
                </div>
              )}

              <form onSubmit={handleContactSubmit} className="space-y-3">
                <input
                  type="text"
                  required
                  placeholder="Your Name"
                  value={contactForm.name}
                  onChange={(e) => setContactForm({ ...contactForm, name: e.target.value })}
                  className="w-full rounded-xl border border-slate-200 px-3.5 py-2 text-sm"
                />
                <input
                  type="email"
                  placeholder="Email or Phone"
                  value={contactForm.email}
                  onChange={(e) => setContactForm({ ...contactForm, email: e.target.value })}
                  className="w-full rounded-xl border border-slate-200 px-3.5 py-2 text-sm"
                />
                <textarea
                  required
                  rows={3}
                  placeholder="Write your question for the Maktab Principal or Office..."
                  value={contactForm.message}
                  onChange={(e) => setContactForm({ ...contactForm, message: e.target.value })}
                  className="w-full rounded-xl border border-slate-200 px-3.5 py-2 text-sm"
                />
                <button
                  type="submit"
                  disabled={contactStatus.busy}
                  className="w-full py-2.5 px-4 rounded-xl border border-emerald-800 text-emerald-900 hover:bg-emerald-50 text-sm font-semibold transition-colors cursor-pointer"
                >
                  Send Inquiry
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Quiet Footer */}
      <footer className="border-t border-emerald-900/10 bg-emerald-950 text-emerald-100 py-8">
        <div className="max-w-7xl mx-auto px-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
          <div className="font-display font-semibold text-white text-sm">
            {settings.maktab_name || t(lang, 'brandName')}
          </div>
          <div className="flex items-center gap-5 text-emerald-200/80">
            <a href="#about" className="hover:text-white">{t(lang, 'navAbout')}</a>
            <a href="#courses" className="hover:text-white">{t(lang, 'navCourses')}</a>
            <a href="#admission" className="hover:text-white">{t(lang, 'navAdmission')}</a>
            <button type="button" onClick={onOpenLogin} className="hover:text-white cursor-pointer">
              {t(lang, 'portalLogin')}
            </button>
          </div>
          <div className="text-emerald-200/70">
            © {new Date().getFullYear()} {settings.maktab_name || 'Kabeer Sb Maktab'}
          </div>
        </div>
      </footer>

      {/* Lightbox Modal */}
      {activeLightbox && (
        <div
          className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4"
          onClick={() => setActiveLightbox(null)}
        >
          <div className="max-w-3xl w-full bg-white rounded-2xl overflow-hidden" onClick={(e) => e.stopPropagation()}>
            <img src={activeLightbox.src} alt={activeLightbox.caption} className="w-full max-h-[75vh] object-cover" />
            <div className="p-4 flex items-center justify-between">
              <span className="text-sm font-medium text-slate-800">{activeLightbox.caption}</span>
              <button
                type="button"
                onClick={() => setActiveLightbox(null)}
                className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-slate-100 hover:bg-slate-200 cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
