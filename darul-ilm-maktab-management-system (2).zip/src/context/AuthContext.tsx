import React, { useContext, createContext, useEffect, useState, useCallback } from 'react';
import { onAuthStateChanged, signInWithPopup, signOut } from 'firebase/auth';
import { auth, googleAuthProvider } from '../lib/firebase.ts';
import { Lang, LANGUAGES } from '../i18n/translations.ts';

export type UserRole = 'super_admin' | 'admin' | 'teacher' | 'student' | 'parent';

export interface UserProfile {
  id: number;
  uid: string;
  email: string;
  name: string;
  role: UserRole;
  institutionId?: number | null;
  institutionName?: string | null;
  institutionSlug?: string | null;
  institutionStatus?: string | null;
  phone?: string | null;
  preferredLang: string;
  specialization?: string | null;
  qualification?: string | null;
  isDemo?: boolean;
}

interface AuthContextValue {
  user: UserProfile | null;
  linkedStudents: any[];
  assignedClasses: any[];
  token: string | null;
  loading: boolean;
  lang: Lang;
  setLang: (l: Lang) => void;
  loginWithPassword: (email: string, password: string) => Promise<UserProfile>;
  registerAccount: (data: {
    name: string;
    email: string;
    password: string;
    phone?: string;
    role: 'parent' | 'student';
    institutionId?: number;
    studentName: string;
    admissionNo?: string;
  }) => Promise<UserProfile>;
  loginWithGoogle: () => Promise<UserProfile>;
  logout: () => Promise<void>;
  apiFetch: <T = any>(url: string, options?: RequestInit) => Promise<T>;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [linkedStudents, setLinkedStudents] = useState<any[]>([]);
  const [assignedClasses, setAssignedClasses] = useState<any[]>([]);
  const [token, setToken] = useState<string | null>(() => {
    try {
      return sessionStorage.getItem('maktab_session_token');
    } catch {
      return null;
    }
  });
  const [loading, setLoading] = useState<boolean>(true);
  const [lang, setLangState] = useState<Lang>(() => {
    try {
      const saved = localStorage.getItem('maktab_lang') as Lang;
      return ['en', 'hi', 'ur'].includes(saved) ? saved : 'en';
    } catch {
      return 'en';
    }
  });

  useEffect(() => {
    const meta = LANGUAGES.find((l) => l.code === lang) || LANGUAGES[0];
    document.documentElement.dir = meta.dir;
    document.documentElement.lang = meta.code;
    try {
      localStorage.setItem('maktab_lang', lang);
    } catch {
      // ignore
    }
  }, [lang]);

  const apiFetch = useCallback(
    async <T = any>(url: string, options: RequestInit = {}, overrideToken?: string): Promise<T> => {
      const activeToken = overrideToken || token;
      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
        ...(options.headers as Record<string, string>),
      };
      if (activeToken) {
        headers.Authorization = `Bearer ${activeToken}`;
      }
      const res = await fetch(url, { ...options, headers });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        throw new Error(data.error || `Request failed (${res.status})`);
      }
      return data as T;
    },
    [token]
  );

  const setLang = useCallback(
    (newLang: Lang) => {
      setLangState(newLang);
      if (token) {
        fetch('/api/auth/preferences', {
          method: 'PATCH',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({ preferredLang: newLang }),
        }).catch(() => {});
      }
    },
    [token]
  );

  const refreshProfile = useCallback(
    async (activeToken?: string) => {
      const useToken = activeToken || token;
      if (!useToken) {
        setLoading(false);
        return;
      }
      try {
        const res = await fetch('/api/auth/me', {
          headers: { Authorization: `Bearer ${useToken}` },
        });
        if (!res.ok) {
          throw new Error('Session expired');
        }
        const data = await res.json();
        setUser(data.user);
        setLinkedStudents(data.linkedStudents || []);
        setAssignedClasses(data.assignedClasses || []);
      } catch {
        setUser(null);
        setToken(null);
        try {
          sessionStorage.removeItem('maktab_session_token');
        } catch {
          // ignore
        }
      } finally {
        setLoading(false);
      }
    },
    [token]
  );

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (fbUser) => {
      if (fbUser && !sessionStorage.getItem('maktab_session_token')) {
        try {
          const idToken = await fbUser.getIdToken();
          setToken(idToken);
          await refreshProfile(idToken);
          return;
        } catch {
          // ignore
        }
      }
      if (sessionStorage.getItem('maktab_session_token')) {
        await refreshProfile(sessionStorage.getItem('maktab_session_token') || undefined);
      } else {
        setLoading(false);
      }
    });
    return () => unsub();
  }, [refreshProfile]);

  const loginWithPassword = async (email: string, password: string): Promise<UserProfile> => {
    const data = await apiFetch<{ token: string; user: UserProfile }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
    setToken(data.token);
    try {
      sessionStorage.setItem('maktab_session_token', data.token);
    } catch {
      // ignore
    }
    setUser(data.user);
    await refreshProfile(data.token);
    return data.user;
  };

  const registerAccount = async (payload: {
    name: string;
    email: string;
    password: string;
    phone?: string;
    role: 'parent' | 'student';
    institutionId?: number;
    studentName: string;
    admissionNo?: string;
  }): Promise<UserProfile> => {
    const data = await apiFetch<{ token: string; user: UserProfile }>('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    setToken(data.token);
    try {
      sessionStorage.setItem('maktab_session_token', data.token);
    } catch {
      // ignore
    }
    setUser(data.user);
    await refreshProfile(data.token);
    return data.user;
  };

  const loginWithGoogle = async (): Promise<UserProfile> => {
    const cred = await signInWithPopup(auth, googleAuthProvider);
    const idToken = await cred.user.getIdToken();
    try {
      sessionStorage.removeItem('maktab_session_token');
    } catch {
      // ignore
    }
    setToken(idToken);
    const me = await apiFetch<{ user: UserProfile; linkedStudents: any[]; assignedClasses: any[] }>(
      '/api/auth/me',
      { method: 'GET' },
      idToken
    );
    setUser(me.user);
    setLinkedStudents(me.linkedStudents || []);
    setAssignedClasses(me.assignedClasses || []);
    return me.user;
  };

  const logout = async () => {
    try {
      sessionStorage.removeItem('maktab_session_token');
    } catch {
      // ignore
    }
    setToken(null);
    setUser(null);
    setLinkedStudents([]);
    setAssignedClasses([]);
    await signOut(auth).catch(() => {});
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        linkedStudents,
        assignedClasses,
        token,
        loading,
        lang,
        setLang,
        loginWithPassword,
        registerAccount,
        loginWithGoogle,
        logout,
        apiFetch,
        refreshProfile: () => refreshProfile(),
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
