import React, { useEffect, useState } from 'react';
import { Building2, CheckCircle2, Clock, KeyRound, PauseCircle, Plus, ShieldCheck, Trash2, Users, XCircle } from 'lucide-react';
import { useAuth } from '../../context/AuthContext.tsx';

export const SuperAdminView: React.FC = () => {
  const { user, apiFetch } = useAuth();
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [tab, setTab] = useState<'institutions' | 'users' | 'audit'>('institutions');

  const [newInst, setNewInst] = useState({
    name: '',
    city: '',
    contactPhone: '',
    address: '',
    adminName: '',
    adminEmail: '',
    adminPassword: '',
  });
  const [submitting, setSubmitting] = useState(false);
  const [resetInstId, setResetInstId] = useState<number | null>(null);
  const [resetPassword, setResetPassword] = useState('');
  const [savingCredentials, setSavingCredentials] = useState(false);
  const [confirmDeleteInstId, setConfirmDeleteInstId] = useState<number | null>(null);

  const loadData = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await apiFetch('/api/super-admin/overview');
      setData(res);
    } catch (err: any) {
      setError(err.message || 'Failed to load Platform Owner console');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleCreateInstitution = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setError(null);
    setNotice(null);
    try {
      const res = await apiFetch('/api/super-admin/institutions', {
        method: 'POST',
        body: JSON.stringify(newInst),
      });
      setNotice(
        `Approved "${res.institution.name}" with a fresh empty workspace and created Institution Admin (${res.admin.email}).`
      );
      setNewInst({
        name: '',
        city: '',
        contactPhone: '',
        address: '',
        adminName: '',
        adminEmail: '',
        adminPassword: '',
      });
      await loadData();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  const handleApprovePending = async (instId: number, instName: string) => {
    setError(null);
    setNotice(null);
    try {
      const res = await apiFetch(`/api/super-admin/institutions/${instId}/approve`, { method: 'PATCH' });
      const adminEmail = res?.admin?.email ? ` (${res.admin.email})` : '';
      setNotice(`Approved "${instName}", initialized its fresh empty dashboard workspace, and activated its Institution Admin login${adminEmail}.`);
      await loadData();
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleActivateAdmin = async (instId: number, instName: string) => {
    setError(null);
    setNotice(null);
    try {
      const res = await apiFetch(`/api/super-admin/institutions/${instId}/admin-credentials`, {
        method: 'PATCH',
        body: JSON.stringify({}),
      });
      setNotice(`Activated Institution Admin login (${res.admin?.email}) for "${instName}". They can now sign in immediately.`);
      await loadData();
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleSaveAdminPassword = async (e: React.FormEvent, instId: number, instName: string) => {
    e.preventDefault();
    if (resetPassword.trim().length < 6) {
      setError('Admin password must be at least 6 characters.');
      return;
    }
    setSavingCredentials(true);
    setError(null);
    setNotice(null);
    try {
      const res = await apiFetch(`/api/super-admin/institutions/${instId}/admin-credentials`, {
        method: 'PATCH',
        body: JSON.stringify({ adminPassword: resetPassword.trim() }),
      });
      setNotice(`Updated Institution Admin password for "${instName}" (${res.admin?.email}). They can now sign in with the new password.`);
      setResetInstId(null);
      setResetPassword('');
      await loadData();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSavingCredentials(false);
    }
  };

  const handleToggleStatus = async (instId: number, nextStatus: 'approved' | 'suspended' | 'rejected') => {
    setError(null);
    setNotice(null);
    try {
      await apiFetch(`/api/super-admin/institutions/${instId}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ status: nextStatus }),
      });
      setNotice(`Updated institution status to ${nextStatus.toUpperCase()}.`);
      await loadData();
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleDeleteInstitution = async (instId: number, instName: string) => {
    setError(null);
    setNotice(null);
    try {
      await apiFetch(`/api/super-admin/institutions/${instId}`, { method: 'DELETE' });
      setConfirmDeleteInstId(null);
      setNotice(`Permanently removed Maktab "${instName}" and its workspace data.`);
      await loadData();
    } catch (err: any) {
      setError(err.message);
    }
  };

  if (loading) {
    return (
      <div className="space-y-4">
        <div className="h-28 rounded-2xl bg-white border border-emerald-900/10 animate-pulse" />
        <div className="h-64 rounded-2xl bg-white border border-emerald-900/10 animate-pulse" />
      </div>
    );
  }

  const stats = data?.stats || {};
  const institutions: any[] = data?.institutions || [];
  const pendingList = institutions.filter((i) => i.status === 'pending');
  const platformUsers: any[] = data?.platformUsers || [];
  const auditLogs: any[] = data?.auditLogs || [];

  return (
    <div className="space-y-6">
      {/* Platform Owner Header */}
      <div className="bg-emerald-950 text-white rounded-2xl p-6 islamic-lattice-gold flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-amber-300 mb-1">
            <ShieldCheck className="h-4 w-4" />
            <span>Platform Owner Exclusive Super Admin Panel</span>
          </div>
          <h1 className="font-display text-2xl font-bold">{user?.name}</h1>
          <p className="text-xs text-emerald-100/80 mt-1">
            Verified Platform Owner: {user?.email} · Multi-Tenant Isolation Active · {stats.superAdminCount ?? 1} Super Admin Account
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          {(
            [
              ['institutions', 'Institutions & Approvals'],
              ['users', 'Tenant Role Audit'],
              ['audit', 'Platform Security Logs'],
            ] as const
          ).map(([k, label]) => (
            <button
              key={k}
              type="button"
              onClick={() => setTab(k)}
              className={`px-3.5 py-2 text-xs font-semibold rounded-xl cursor-pointer transition-colors ${
                tab === k ? 'bg-amber-400 text-emerald-950' : 'bg-emerald-900/80 text-emerald-100 hover:bg-emerald-800'
              }`}
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      {/* KPI Strip */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        {[
          { label: 'Total Institutions', value: stats.totalInstitutions ?? 0 },
          { label: 'Pending Approvals', value: stats.pendingInstitutions ?? pendingList.length },
          { label: 'Approved Workspaces', value: stats.approvedInstitutions ?? 0 },
          { label: 'Suspended Maktabs', value: stats.suspendedInstitutions ?? 0 },
          { label: 'Total Users', value: stats.totalUsers ?? 0 },
        ].map((kpi) => (
          <div key={kpi.label} className="bg-white border border-emerald-900/10 rounded-xl p-5">
            <div className="text-xs font-medium text-slate-500">{kpi.label}</div>
            <div className="font-mono-num text-2xl font-bold text-emerald-900 mt-1">{kpi.value}</div>
          </div>
        ))}
      </div>

      {notice && (
        <div className="rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-xs text-emerald-900 flex items-center gap-2">
          <CheckCircle2 className="h-4 w-4 text-emerald-700 shrink-0" />
          <span>{notice}</span>
        </div>
      )}
      {error && (
        <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-xs text-red-800">{error}</div>
      )}

      {tab === 'institutions' && (
        <div className="space-y-6">
          {/* Highlighted Pending Maktab Approvals */}
          {pendingList.length > 0 && (
            <div className="bg-amber-50/70 border border-amber-300/80 rounded-2xl p-6 space-y-4">
              <div className="flex items-center justify-between gap-2">
                <h2 className="font-display text-lg font-bold text-amber-950 flex items-center gap-2">
                  <Clock className="h-4 w-4 text-amber-700" />
                  <span>Pending New Maktab Applications ({pendingList.length})</span>
                </h2>
                <span className="text-xs font-medium text-amber-800">
                  Approving immediately activates the Institution Admin login &amp; empty workspace
                </span>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {pendingList.map((inst) => (
                  <div key={inst.id} className="bg-white border border-amber-200 rounded-xl p-4 flex flex-col justify-between gap-3">
                    <div>
                      <div className="flex items-center justify-between gap-2">
                        <h3 className="font-semibold text-sm text-slate-950">{inst.name}</h3>
                        <span className="text-[11px] font-mono-num text-amber-800 font-semibold">{inst.code}</span>
                      </div>
                      <p className="text-xs text-slate-600 mt-1">
                        Admin: <span className="font-medium text-slate-900">{inst.requestedAdminName}</span> ·{' '}
                        <span className="font-mono-num text-emerald-800">{inst.requestedAdminEmail}</span>
                      </p>
                      {(inst.city || inst.contactPhone) && (
                        <p className="text-[11px] text-slate-500 mt-0.5">
                          {[inst.city, inst.contactPhone].filter(Boolean).join(' · ')}
                        </p>
                      )}
                    </div>
                    <div className="flex flex-wrap items-center gap-2 pt-1">
                      <button
                        type="button"
                        onClick={() => handleApprovePending(inst.id, inst.name)}
                        className="px-3.5 py-2 rounded-lg bg-emerald-800 hover:bg-emerald-900 text-white text-xs font-semibold cursor-pointer"
                      >
                        Approve & Activate Login
                      </button>
                      <button
                        type="button"
                        onClick={() => handleToggleStatus(inst.id, 'rejected')}
                        className="px-3 py-2 rounded-lg border border-red-200 text-red-700 hover:bg-red-50 text-xs font-semibold inline-flex items-center gap-1 cursor-pointer"
                      >
                        <XCircle className="h-3.5 w-3.5" />
                        <span>Reject</span>
                      </button>
                      {confirmDeleteInstId === inst.id ? (
                        <>
                          <button
                            type="button"
                            onClick={() => handleDeleteInstitution(inst.id, inst.name)}
                            className="px-3 py-2 rounded-lg bg-red-600 hover:bg-red-700 text-white text-xs font-semibold cursor-pointer"
                          >
                            Confirm Remove
                          </button>
                          <button
                            type="button"
                            onClick={() => setConfirmDeleteInstId(null)}
                            className="px-2.5 py-2 rounded-lg text-xs text-slate-600 hover:text-slate-900 cursor-pointer"
                          >
                            Keep
                          </button>
                        </>
                      ) : (
                        <button
                          type="button"
                          onClick={() => setConfirmDeleteInstId(inst.id)}
                          className="px-3 py-2 rounded-lg border border-red-200 text-red-700 hover:bg-red-50 text-xs font-semibold inline-flex items-center gap-1 cursor-pointer"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                          <span>Remove</span>
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Provision Brand-New Institution & Empty Workspace */}
          <form onSubmit={handleCreateInstitution} className="bg-white border border-emerald-900/10 rounded-2xl p-6 space-y-4">
            <div>
              <h2 className="font-display text-lg font-bold text-slate-950 flex items-center gap-2">
                <Plus className="h-4 w-4 text-emerald-800" />
                <span>Create & Approve New Institution (Fresh Empty Workspace)</span>
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Creates an isolated Maktab tenant with zero pre-filled students/records and provisions its dedicated Institution Admin account.
              </p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
              <input
                type="text"
                required
                placeholder="Institution Name *"
                value={newInst.name}
                onChange={(e) => setNewInst({ ...newInst, name: e.target.value })}
                className="rounded-xl border border-slate-200 px-3 py-2"
              />
              <input
                type="text"
                placeholder="City"
                value={newInst.city}
                onChange={(e) => setNewInst({ ...newInst, city: e.target.value })}
                className="rounded-xl border border-slate-200 px-3 py-2"
              />
              <input
                type="text"
                placeholder="Campus Phone"
                value={newInst.contactPhone}
                onChange={(e) => setNewInst({ ...newInst, contactPhone: e.target.value })}
                className="rounded-xl border border-slate-200 px-3 py-2"
              />
              <input
                type="text"
                placeholder="Campus Address"
                value={newInst.address}
                onChange={(e) => setNewInst({ ...newInst, address: e.target.value })}
                className="rounded-xl border border-slate-200 px-3 py-2"
              />
              <input
                type="text"
                required
                placeholder="Institution Admin Full Name *"
                value={newInst.adminName}
                onChange={(e) => setNewInst({ ...newInst, adminName: e.target.value })}
                className="rounded-xl border border-slate-200 px-3 py-2"
              />
              <input
                type="email"
                required
                placeholder="Institution Admin Email *"
                value={newInst.adminEmail}
                onChange={(e) => setNewInst({ ...newInst, adminEmail: e.target.value })}
                className="rounded-xl border border-slate-200 px-3 py-2"
              />
              <input
                type="password"
                required
                minLength={6}
                placeholder="Admin Password (min 6 chars) *"
                value={newInst.adminPassword}
                onChange={(e) => setNewInst({ ...newInst, adminPassword: e.target.value })}
                className="rounded-xl border border-slate-200 px-3 py-2"
              />
              <button
                type="submit"
                disabled={submitting}
                className="rounded-xl bg-emerald-800 hover:bg-emerald-900 text-white font-semibold px-4 py-2 cursor-pointer disabled:opacity-60"
              >
                {submitting ? 'Provisioning...' : 'Create Fresh Institution'}
              </button>
            </div>
          </form>

          {/* Institutions Directory */}
          <div className="bg-white border border-emerald-900/10 rounded-2xl overflow-hidden">
            <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
              <h2 className="font-display text-base font-bold text-slate-950 flex items-center gap-2">
                <Building2 className="h-4 w-4 text-emerald-800" />
                <span>Registered Maktab Institutions ({institutions.length})</span>
              </h2>
            </div>

            {/* Mobile Institutions Cards */}
            <div className="md:hidden divide-y divide-slate-100">
              {institutions.map((inst) => (
                <div key={inst.id} className="p-4 space-y-2.5 text-xs">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="font-semibold text-slate-950">{inst.name}</div>
                      <div className="text-[11px] font-mono-num text-slate-500">
                        {inst.code} · {inst.city || '—'}
                      </div>
                    </div>
                    <span
                      className={`font-semibold uppercase text-[11px] ${
                        inst.status === 'approved'
                          ? 'text-emerald-700'
                          : inst.status === 'pending'
                            ? 'text-amber-700'
                            : 'text-red-600'
                      }`}
                    >
                      {inst.status}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-600">
                    Admin: {inst.admins?.[0]?.email || inst.requestedAdminEmail || '—'}
                  </div>
                  <div className="flex flex-wrap items-center gap-2 pt-1">
                    {inst.status !== 'approved' && (
                      <button
                        type="button"
                        onClick={() => handleApprovePending(inst.id, inst.name)}
                        className="px-3 py-1.5 rounded-lg bg-emerald-800 text-white font-semibold cursor-pointer"
                      >
                        {inst.status === 'suspended' ? 'Reactivate' : 'Approve'}
                      </button>
                    )}
                    {inst.status === 'approved' && (
                      <button
                        type="button"
                        onClick={() => handleToggleStatus(inst.id, 'suspended')}
                        className="px-3 py-1.5 rounded-lg border border-amber-300 text-amber-800 font-semibold cursor-pointer"
                      >
                        Suspend
                      </button>
                    )}
                    {confirmDeleteInstId === inst.id ? (
                      <>
                        <button
                          type="button"
                          onClick={() => handleDeleteInstitution(inst.id, inst.name)}
                          className="px-3 py-1.5 rounded-lg bg-red-600 text-white font-semibold cursor-pointer"
                        >
                          Confirm Remove
                        </button>
                        <button
                          type="button"
                          onClick={() => setConfirmDeleteInstId(null)}
                          className="px-2 py-1.5 text-slate-600 cursor-pointer"
                        >
                          Keep
                        </button>
                      </>
                    ) : (
                      <button
                        type="button"
                        onClick={() => setConfirmDeleteInstId(inst.id)}
                        className="px-2.5 py-1.5 rounded-lg border border-red-200 text-red-700 font-semibold inline-flex items-center gap-1 cursor-pointer"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                        <span>Remove</span>
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>

            <div className="hidden md:block overflow-x-auto">
              <table className="w-full text-start border-collapse text-xs">
                <thead>
                  <tr className="border-b border-slate-100 bg-slate-50/70 text-[11px] font-semibold text-slate-500">
                    <th className="py-3 px-4 text-start">Institution & Code</th>
                    <th className="py-3 px-4 text-start">Institution Admin</th>
                    <th className="py-3 px-4 text-start">Workspace Data</th>
                    <th className="py-3 px-4 text-start">Status</th>
                    <th className="py-3 px-4 text-end">Governance Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {institutions.map((inst) => (
                    <React.Fragment key={inst.id}>
                      <tr className="hover:bg-emerald-50/20">
                        <td className="py-3.5 px-4">
                          <div className="font-semibold text-slate-950">{inst.name}</div>
                          <div className="text-[11px] font-mono-num text-slate-500">
                            {inst.code} · /{inst.slug} {inst.city ? `· ${inst.city}` : ''}
                          </div>
                        </td>
                        <td className="py-3.5 px-4">
                          {inst.admins && inst.admins.length > 0 ? (
                            inst.admins.map((a: any) => (
                              <div key={a.id}>
                                <div className="font-medium text-slate-800">{a.name}</div>
                                <div className="text-[11px] font-mono-num text-emerald-800">{a.email}</div>
                              </div>
                            ))
                          ) : (
                            <div>
                              <div className="text-slate-700">{inst.requestedAdminName || 'Pending Provision'}</div>
                              <div className="text-[11px] text-slate-500">{inst.requestedAdminEmail}</div>
                              {inst.status === 'approved' && (
                                <div className="text-[11px] font-semibold text-amber-700 mt-0.5">
                                  Admin login needs activation
                                </div>
                              )}
                            </div>
                          )}
                        </td>
                        <td className="py-3.5 px-4 font-mono-num text-slate-700">
                          {inst.studentCount} students · {inst.classCount} classes · {inst.userCount} users
                        </td>
                        <td className="py-3.5 px-4">
                          <span
                            className={`font-semibold uppercase ${
                              inst.status === 'approved'
                                ? 'text-emerald-700'
                                : inst.status === 'pending'
                                  ? 'text-amber-700'
                                  : 'text-red-600'
                            }`}
                          >
                            {inst.status}
                          </span>
                        </td>
                        <td className="py-3.5 px-4 text-end">
                          <div className="inline-flex flex-wrap items-center justify-end gap-2">
                            {inst.status === 'pending' && (
                              <>
                                <button
                                  type="button"
                                  onClick={() => handleApprovePending(inst.id, inst.name)}
                                  className="px-3 py-1.5 rounded-lg bg-emerald-800 hover:bg-emerald-900 text-white font-semibold cursor-pointer"
                                >
                                  Approve & Create Workspace
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handleToggleStatus(inst.id, 'rejected')}
                                  className="px-2.5 py-1.5 rounded-lg border border-red-200 text-red-700 hover:bg-red-50 font-semibold cursor-pointer"
                                >
                                  Reject
                                </button>
                              </>
                            )}
                            {inst.status === 'approved' && (!inst.admins || inst.admins.length === 0) && (
                              <button
                                type="button"
                                onClick={() => handleActivateAdmin(inst.id, inst.name)}
                                className="px-3 py-1.5 rounded-lg bg-emerald-800 hover:bg-emerald-900 text-white font-semibold cursor-pointer"
                              >
                                Activate Admin Login
                              </button>
                            )}
                            {inst.status === 'approved' && (
                              <>
                                <button
                                  type="button"
                                  onClick={() => {
                                    setResetInstId(resetInstId === inst.id ? null : inst.id);
                                    setResetPassword('');
                                  }}
                                  className="px-2.5 py-1.5 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-50 font-semibold inline-flex items-center gap-1 cursor-pointer"
                                >
                                  <KeyRound className="h-3.5 w-3.5" />
                                  <span>Reset Password</span>
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handleToggleStatus(inst.id, 'suspended')}
                                  className="px-3 py-1.5 rounded-lg border border-amber-300 text-amber-800 hover:bg-amber-50 font-semibold inline-flex items-center gap-1 cursor-pointer"
                                >
                                  <PauseCircle className="h-3.5 w-3.5" />
                                  <span>Suspend</span>
                                </button>
                              </>
                            )}
                            {(inst.status === 'suspended' || inst.status === 'rejected') && (
                              <button
                                type="button"
                                onClick={() => handleApprovePending(inst.id, inst.name)}
                                className="px-3 py-1.5 rounded-lg bg-emerald-800 text-white font-semibold cursor-pointer"
                              >
                                {inst.status === 'suspended' ? 'Reactivate' : 'Approve'}
                              </button>
                            )}
                            {confirmDeleteInstId === inst.id ? (
                              <span className="inline-flex items-center gap-1.5">
                                <button
                                  type="button"
                                  onClick={() => handleDeleteInstitution(inst.id, inst.name)}
                                  className="px-2.5 py-1.5 rounded-lg bg-red-600 hover:bg-red-700 text-white font-semibold cursor-pointer"
                                >
                                  Confirm Remove
                                </button>
                                <button
                                  type="button"
                                  onClick={() => setConfirmDeleteInstId(null)}
                                  className="px-2 py-1.5 text-slate-600 hover:text-slate-900 cursor-pointer"
                                >
                                  Keep
                                </button>
                              </span>
                            ) : (
                              <button
                                type="button"
                                onClick={() => setConfirmDeleteInstId(inst.id)}
                                className="px-2.5 py-1.5 rounded-lg border border-red-200 text-red-700 hover:bg-red-50 font-semibold inline-flex items-center gap-1 cursor-pointer"
                                title="Permanently remove this Maktab"
                              >
                                <Trash2 className="h-3.5 w-3.5" />
                                <span>Remove</span>
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                      {resetInstId === inst.id && (
                        <tr className="bg-emerald-50/40">
                          <td colSpan={5} className="px-4 py-3">
                            <form
                              onSubmit={(e) => handleSaveAdminPassword(e, inst.id, inst.name)}
                              className="flex flex-wrap items-center gap-2"
                            >
                              <span className="font-semibold text-slate-800">
                                Set new login password for{' '}
                                <span className="font-mono-num text-emerald-900">
                                  {inst.admins?.[0]?.email || inst.requestedAdminEmail}
                                </span>
                                :
                              </span>
                              <input
                                type="password"
                                required
                                minLength={6}
                                value={resetPassword}
                                onChange={(e) => setResetPassword(e.target.value)}
                                placeholder="New password (min 6 chars)"
                                className="rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs"
                              />
                              <button
                                type="submit"
                                disabled={savingCredentials}
                                className="px-3 py-1.5 rounded-lg bg-emerald-800 hover:bg-emerald-900 text-white font-semibold cursor-pointer disabled:opacity-60"
                              >
                                {savingCredentials ? 'Saving...' : 'Save Password'}
                              </button>
                              <button
                                type="button"
                                onClick={() => {
                                  setResetInstId(null);
                                  setResetPassword('');
                                }}
                                className="px-2.5 py-1.5 rounded-lg text-slate-600 hover:text-slate-900 cursor-pointer"
                              >
                                Cancel
                              </button>
                            </form>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {tab === 'users' && (
        <div className="bg-white border border-emerald-900/10 rounded-2xl overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
            <h2 className="font-display text-base font-bold text-slate-950 flex items-center gap-2">
              <Users className="h-4 w-4 text-emerald-800" />
              <span>Platform-Wide Role & Tenant Boundary Audit</span>
            </h2>
            <span className="text-xs text-emerald-800 font-semibold">
              Only Platform Owner holds super_admin
            </span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-start border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-100 bg-slate-50/70 text-[11px] font-semibold text-slate-500">
                  <th className="py-3 px-4 text-start">User</th>
                  <th className="py-3 px-4 text-start">Email</th>
                  <th className="py-3 px-4 text-start">Role</th>
                  <th className="py-3 px-4 text-start">Tenant Scope</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {platformUsers.map((u) => {
                  const inst = institutions.find((i) => i.id === u.institutionId);
                  return (
                    <tr key={u.id}>
                      <td className="py-3 px-4 font-semibold text-slate-900">{u.name}</td>
                      <td className="py-3 px-4 font-mono-num text-slate-600">{u.email}</td>
                      <td className="py-3 px-4">
                        <span
                          className={`font-semibold uppercase ${
                            u.role === 'super_admin' ? 'text-amber-700' : 'text-emerald-800'
                          }`}
                        >
                          {u.role}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-slate-700">
                        {u.role === 'super_admin'
                          ? 'Platform Owner (Global Governance Only)'
                          : inst
                            ? `${inst.name} (Tenant #${inst.id})`
                            : `Tenant #${u.institutionId}`}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {tab === 'audit' && (
        <div className="bg-white border border-emerald-900/10 rounded-2xl overflow-hidden">
          <table className="w-full text-start border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-100 bg-slate-50/70 text-[11px] font-semibold text-slate-500">
                <th className="py-3 px-4 text-start">Timestamp</th>
                <th className="py-3 px-4 text-start">Actor</th>
                <th className="py-3 px-4 text-start">Action</th>
                <th className="py-3 px-4 text-start">Tenant ID</th>
                <th className="py-3 px-4 text-start">Details</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {auditLogs.map((log) => (
                <tr key={log.id}>
                  <td className="py-2.5 px-4 font-mono-num text-slate-500">
                    {new Date(log.createdAt).toLocaleString()}
                  </td>
                  <td className="py-2.5 px-4 text-slate-800">{log.userEmail}</td>
                  <td className="py-2.5 px-4 font-semibold text-emerald-900">{log.action}</td>
                  <td className="py-2.5 px-4 font-mono-num text-slate-500">
                    {log.institutionId ?? 'Global'}
                  </td>
                  <td className="py-2.5 px-4 text-slate-600">{log.details}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
