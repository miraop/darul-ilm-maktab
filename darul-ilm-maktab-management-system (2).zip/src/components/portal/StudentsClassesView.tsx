import React, { useEffect, useState } from 'react';
import { BookOpen, Download, Edit2, Eye, Plus, Search, ShieldAlert, Trash2, User, X } from 'lucide-react';
import { useAuth } from '../../context/AuthContext.tsx';
import { t } from '../../i18n/translations.ts';
import { exportToPdf } from '../../utils/exports.ts';

export const StudentsClassesView: React.FC = () => {
  const { user, lang, apiFetch } = useAuth();
  const [students, setStudents] = useState<any[]>([]);
  const [classes, setClasses] = useState<any[]>([]);
  const [subjects, setSubjects] = useState<any[]>([]);
  const [syllabusTopics, setSyllabusTopics] = useState<any[]>([]);
  const [parents, setParents] = useState<any[]>([]);
  const [teachers, setTeachers] = useState<any[]>([]);
  const [search, setSearch] = useState('');
  const [classFilter, setClassFilter] = useState<string>('all');
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<'students' | 'classes'>('students');
  const [feedback, setFeedback] = useState<string | null>(null);

  const isStudent = user?.role === 'student';

  // Student Personal Profile Drawer / Modal state
  const [profileData, setProfileData] = useState<any | null>(null);
  const [selfProfile, setSelfProfile] = useState<any | null>(null);
  const [profileLoading, setProfileLoading] = useState(false);
  const [profileTab, setProfileTab] = useState<
    'overview' | 'attendance' | 'namaz_daily' | 'academics' | 'homework' | 'health'
  >('overview');

  // Add / Edit Student Modal
  const [showStudentModal, setShowStudentModal] = useState(false);
  const [editingStudentId, setEditingStudentId] = useState<number | null>(null);
  const [savingStudent, setSavingStudent] = useState(false);
  const [studentModalError, setStudentModalError] = useState<string | null>(null);
  const [studentForm, setStudentForm] = useState({
    fullName: '',
    photoUrl: '',
    fatherName: '',
    motherName: '',
    dob: '2016-01-01',
    gender: 'Male',
    classId: '',
    academicSession: '2026-2027',
    parentId: '',
    guardianName: '',
    guardianPhone: '',
    emergencyContact: '',
    address: '',
    bloodGroup: 'O+',
    allergies: 'None',
    medicalNotes: '',
  });

  // Class & Subject Modals
  const [showAddClass, setShowAddClass] = useState(false);
  const [classForm, setClassForm] = useState({
    name: '',
    gradeLevel: '',
    section: 'A',
    roomNumber: '',
    capacity: 30,
    teacherId: '',
  });

  const [showAddSubject, setShowAddSubject] = useState(false);
  const [subjectForm, setSubjectForm] = useState({
    name: '',
    code: '',
    category: 'Deeni',
    classId: '',
    teacherId: '',
    syllabusTotalUnits: 12,
  });

  // Syllabus Topic Form
  const [topicForm, setTopicForm] = useState({
    academicSession: '2026-2027',
    classId: '',
    subjectId: '',
    bookName: '',
    chapter: '',
    lesson: '',
    totalTopics: 10,
    completedTopics: 0,
    teacherRemarks: '',
  });
  const [syllabusClassFilter, setSyllabusClassFilter] = useState<string>('all');

  const loadAll = async () => {
    setLoading(true);
    try {
      const [st, cl, sb, us, topics] = await Promise.all([
        apiFetch('/api/students'),
        apiFetch('/api/classes'),
        apiFetch('/api/subjects'),
        isStudent ? Promise.resolve([]) : apiFetch('/api/users'),
        apiFetch('/api/syllabus-topics'),
      ]);
      setStudents(st);
      setClasses(cl);
      setSubjects(sb);
      setSyllabusTopics(topics || []);
      setTeachers((us || []).filter((u: any) => u.role === 'teacher'));
      setParents((us || []).filter((u: any) => u.role === 'parent'));
      if (isStudent && st.length > 0) {
        try {
          const prof = await apiFetch(`/api/students/${st[0].id}/profile`);
          setSelfProfile(prof);
        } catch {
          setSelfProfile(null);
        }
      }
      if (cl.length > 0 && !studentForm.classId) {
        setStudentForm((p) => ({ ...p, classId: String(cl[0].id) }));
        setSubjectForm((p) => ({ ...p, classId: String(cl[0].id) }));
        setTopicForm((p) => ({ ...p, classId: String(cl[0].id) }));
      }
      if (sb.length > 0 && !topicForm.subjectId) {
        setTopicForm((p) => ({ ...p, subjectId: String(sb[0].id) }));
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAll();
  }, [user?.id, user?.role]);

  const classMap = new Map(classes.map((c) => [c.id, c]));
  const subjectMap = new Map(subjects.map((s) => [s.id, s]));

  const filteredStudents = students.filter((s) => {
    const matchesSearch =
      s.fullName.toLowerCase().includes(search.toLowerCase()) ||
      s.admissionNo.toLowerCase().includes(search.toLowerCase()) ||
      (s.guardianName || '').toLowerCase().includes(search.toLowerCase()) ||
      (s.fatherName || '').toLowerCase().includes(search.toLowerCase());
    const matchesClass = classFilter === 'all' || String(s.classId) === classFilter;
    return matchesSearch && matchesClass;
  });

  const openProfileModal = async (studentId: number) => {
    setProfileLoading(true);
    setProfileTab('overview');
    setProfileData({ loading: true });
    try {
      const res = await apiFetch(`/api/students/${studentId}/profile`);
      setProfileData(res);
    } catch (err: any) {
      setFeedback(err.message || 'Failed to load student profile');
      setProfileData(null);
    } finally {
      setProfileLoading(false);
    }
  };

  const handlePrintProfilePdf = (targetProfile?: any) => {
    const prof = targetProfile || profileData;
    if (!prof?.student) return;
    const st = prof.student;
    const stats = prof.attendanceStats || {};
    const rows: any[][] = [
      ['Admission No / ID', st.admissionNo, 'Academic Session', st.academicSession || '2026-2027'],
      ['Student Name', st.fullName, 'Class / Section', `${prof.classInfo?.name || '—'} (${prof.classInfo?.section || 'A'})`],
      ['Father Name', st.fatherName || '—', 'Mother Name', st.motherName || '—'],
      ['Guardian Name', st.guardianName, 'Parent / Emergency Contact', `${st.guardianPhone} / ${st.emergencyContact || '—'}`],
      ['Date of Birth', st.dob, 'Admission Date', st.admissionDate || '—'],
      ['Attendance Rate', `${stats.rate ?? 0}% (${stats.present ?? 0} present of ${stats.total ?? 0})`, 'Blood Group', st.bloodGroup || '—'],
      ['Address', st.address || '—', 'Allergies / Medical Notes', `${st.allergies || 'None'} ${st.medicalNotes ? `· ${st.medicalNotes}` : ''}`],
    ];
    for (const m of prof.marks || []) {
      rows.push(['Exam Result', m.exam?.title || `Exam #${m.examId}`, `${m.obtainedMarks}/${m.totalMarks} (${m.grade})`, m.remarks || '—']);
    }
    exportToPdf({
      title: `Student Personal Profile — ${st.fullName}`,
      subtitle: `${user?.institutionName || 'Maktab'} · Complete Academic & Care Dossier`,
      headers: ['Field / Module', 'Primary Value', 'Secondary Field', 'Details'],
      rows,
      filename: `student-profile-${st.admissionNo}`,
    });
  };

  const openAddStudentModal = () => {
    setEditingStudentId(null);
    setStudentModalError(null);
    setStudentForm({
      fullName: '',
      photoUrl: '',
      fatherName: '',
      motherName: '',
      dob: '2016-01-01',
      gender: 'Male',
      classId: classes[0] ? String(classes[0].id) : '',
      academicSession: '2026-2027',
      parentId: '',
      guardianName: '',
      guardianPhone: '',
      emergencyContact: '',
      address: '',
      bloodGroup: 'O+',
      allergies: 'None',
      medicalNotes: '',
    });
    setShowStudentModal(true);
  };

  const openEditStudentModal = (st: any) => {
    setEditingStudentId(st.id);
    setStudentModalError(null);
    setStudentForm({
      fullName: st.fullName || '',
      photoUrl: st.photoUrl || '',
      fatherName: st.fatherName || '',
      motherName: st.motherName || '',
      dob: st.dob || '2016-01-01',
      gender: st.gender || 'Male',
      classId: st.classId ? String(st.classId) : '',
      academicSession: st.academicSession || '2026-2027',
      parentId: st.parentId ? String(st.parentId) : '',
      guardianName: st.guardianName || '',
      guardianPhone: st.guardianPhone || '',
      emergencyContact: st.emergencyContact || '',
      address: st.address || '',
      bloodGroup: st.bloodGroup || 'O+',
      allergies: st.allergies || 'None',
      medicalNotes: st.medicalNotes || '',
    });
    setShowStudentModal(true);
  };

  const handleSaveStudent = async (e: React.FormEvent) => {
    e.preventDefault();
    setStudentModalError(null);
    setSavingStudent(true);
    try {
      if (editingStudentId) {
        await apiFetch(`/api/students/${editingStudentId}`, {
          method: 'PATCH',
          body: JSON.stringify(studentForm),
        });
        setFeedback('Student profile updated.');
      } else {
        await apiFetch('/api/students', { method: 'POST', body: JSON.stringify(studentForm) });
        setFeedback('New student registered.');
      }
      setShowStudentModal(false);
      await loadAll();
    } catch (err: any) {
      setStudentModalError(err.message || 'Failed to save student record.');
    } finally {
      setSavingStudent(false);
    }
  };

  const handleDeleteStudent = async (id: number) => {
    try {
      await apiFetch(`/api/students/${id}`, { method: 'DELETE' });
      setFeedback('Student removed from institution directory.');
      await loadAll();
    } catch (err: any) {
      setFeedback(err.message || 'Failed to delete student.');
    }
  };

  const handleCreateClass = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await apiFetch('/api/classes', { method: 'POST', body: JSON.stringify(classForm) });
      setShowAddClass(false);
      setClassForm({ name: '', gradeLevel: '', section: 'A', roomNumber: '', capacity: 30, teacherId: '' });
      setFeedback('New class created.');
      await loadAll();
    } catch (err: any) {
      setFeedback(err.message || 'Failed to create class.');
    }
  };

  const handleCreateSubject = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await apiFetch('/api/subjects', { method: 'POST', body: JSON.stringify(subjectForm) });
      setShowAddSubject(false);
      setSubjectForm({ ...subjectForm, name: '', code: '' });
      setFeedback('Subject added.');
      await loadAll();
    } catch (err: any) {
      setFeedback(err.message || 'Failed to add subject.');
    }
  };

  const handleIncrementSyllabus = async (sub: any, delta: number) => {
    const nextUnits = Math.max(0, Math.min(sub.syllabusTotalUnits, sub.syllabusCompletedUnits + delta));
    const updated = await apiFetch(`/api/subjects/${sub.id}`, {
      method: 'PATCH',
      body: JSON.stringify({ syllabusCompletedUnits: nextUnits }),
    });
    setSubjects((prev) => prev.map((s) => (s.id === sub.id ? updated : s)));
  };

  const canManageTopic = (classId: number, subjectId: number) => {
    if (user?.role === 'admin') return true;
    if (user?.role !== 'teacher') return false;
    const sub = subjectMap.get(subjectId);
    const cls = classMap.get(classId);
    return sub?.teacherId === user.id || cls?.teacherId === user.id;
  };

  const handleCreateSyllabusTopic = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const created = await apiFetch('/api/syllabus-topics', {
        method: 'POST',
        body: JSON.stringify(topicForm),
      });
      setSyllabusTopics((prev) => [...prev, created]);
      setTopicForm((p) => ({ ...p, bookName: '', chapter: '', lesson: '', teacherRemarks: '' }));
      setFeedback('Syllabus topic saved.');
      const sb = await apiFetch('/api/subjects');
      setSubjects(sb);
    } catch (err: any) {
      setFeedback(err.message);
    }
  };

  const handleUpdateTopicProgress = async (topic: any, delta: number) => {
    const nextCompleted = Math.min(topic.totalTopics, Math.max(0, topic.completedTopics + delta));
    try {
      const updated = await apiFetch(`/api/syllabus-topics/${topic.id}`, {
        method: 'PATCH',
        body: JSON.stringify({ completedTopics: nextCompleted }),
      });
      setSyllabusTopics((prev) => prev.map((tItem) => (tItem.id === topic.id ? updated : tItem)));
      const sb = await apiFetch('/api/subjects');
      setSubjects(sb);
    } catch (err: any) {
      setFeedback(err.message);
    }
  };

  const handleDeleteTopic = async (id: number) => {
    try {
      await apiFetch(`/api/syllabus-topics/${id}`, { method: 'DELETE' });
      setSyllabusTopics((prev) => prev.filter((item) => item.id !== id));
      const sb = await apiFetch('/api/subjects');
      setSubjects(sb);
    } catch (err: any) {
      setFeedback(err.message);
    }
  };

  const filteredTopics =
    syllabusClassFilter === 'all'
      ? syllabusTopics
      : syllabusTopics.filter((tp) => String(tp.classId) === syllabusClassFilter);

  const teacherAssignableSubjects =
    user?.role === 'admin'
      ? subjects
      : subjects.filter((s) => s.teacherId === user?.id || classMap.get(s.classId)?.teacherId === user?.id);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-1 p-1 bg-white border border-emerald-900/10 rounded-xl self-start">
          <button
            type="button"
            onClick={() => setTab('students')}
            className={`px-4 py-2 text-xs font-semibold rounded-lg cursor-pointer whitespace-nowrap ${
              tab === 'students' ? 'bg-emerald-800 text-white' : 'text-slate-600 hover:text-emerald-900'
            }`}
          >
            {user?.role === 'parent' ? 'Linked Children' : user?.role === 'student' ? 'My Profile' : 'Students Directory'}
          </button>
          <button
            type="button"
            onClick={() => setTab('classes')}
            className={`px-4 py-2 text-xs font-semibold rounded-lg cursor-pointer whitespace-nowrap ${
              tab === 'classes' ? 'bg-emerald-800 text-white' : 'text-slate-600 hover:text-emerald-900'
            }`}
          >
            {isStudent ? `My Class & ${t(lang, 'syllabusTracking')}` : `Classes & ${t(lang, 'syllabusTracking')}`}
          </button>
        </div>

        {user?.role === 'admin' && tab === 'students' && (
          <button
            type="button"
            onClick={openAddStudentModal}
            className="px-4 py-2 text-xs font-semibold rounded-xl bg-emerald-800 hover:bg-emerald-900 text-white inline-flex items-center gap-1.5 cursor-pointer self-start whitespace-nowrap"
          >
            <Plus className="h-4 w-4" />
            <span>Register Student</span>
          </button>
        )}

        {user?.role === 'admin' && tab === 'classes' && (
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => setShowAddClass(true)}
              className="px-4 py-2 text-xs font-semibold rounded-xl bg-emerald-800 text-white inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
            >
              <Plus className="h-4 w-4" />
              <span>Add Class</span>
            </button>
            <button
              type="button"
              onClick={() => setShowAddSubject(true)}
              className="px-4 py-2 text-xs font-semibold rounded-xl border border-emerald-800 text-emerald-900 inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
            >
              <Plus className="h-4 w-4" />
              <span>Add Subject</span>
            </button>
          </div>
        )}
      </div>

      {feedback && (
        <div className="rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-2.5 text-xs text-emerald-900">
          {feedback}
        </div>
      )}

      {tab === 'students' && isStudent ? (
        loading ? (
          <div className="bg-white border border-emerald-900/10 rounded-2xl p-8 text-center text-xs text-slate-500">
            {t(lang, 'loading')}
          </div>
        ) : !selfProfile?.student ? (
          <div className="bg-white border border-emerald-900/10 rounded-2xl p-8 text-center text-xs text-slate-500">
            Your student admission record is not linked yet. Please contact your Maktab Admin.
          </div>
        ) : (
          <div className="bg-white border border-emerald-900/12 rounded-2xl overflow-hidden">
            <div className="p-6 bg-emerald-950 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-center gap-3.5">
                {selfProfile.student.photoUrl ? (
                  <img
                    src={selfProfile.student.photoUrl}
                    alt={selfProfile.student.fullName}
                    className="h-14 w-14 rounded-full object-cover border-2 border-amber-300"
                  />
                ) : (
                  <div className="h-14 w-14 rounded-full bg-emerald-800 text-amber-200 flex items-center justify-center font-display font-bold text-xl">
                    {selfProfile.student.fullName.charAt(0).toUpperCase()}
                  </div>
                )}
                <div>
                  <div className="text-[11px] font-mono-num text-amber-300">
                    ID: {selfProfile.student.admissionNo} · Session {selfProfile.student.academicSession || '2026-2027'}
                  </div>
                  <h2 className="font-display text-xl font-bold">{selfProfile.student.fullName}</h2>
                  <div className="text-xs text-emerald-100/85">
                    {selfProfile.classInfo?.name || 'Unassigned'} (Section {selfProfile.classInfo?.section || 'A'})
                  </div>
                </div>
              </div>
              <button
                type="button"
                onClick={() => handlePrintProfilePdf(selfProfile)}
                className="px-3.5 py-2 rounded-xl bg-emerald-800 hover:bg-emerald-700 text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer self-start sm:self-center"
              >
                <Download className="h-3.5 w-3.5" />
                <span>{t(lang, 'exportPdf')}</span>
              </button>
            </div>

            <div className="px-5 pt-3 border-b border-slate-100 flex flex-wrap gap-1 bg-[#FAFBF9]">
              {(
                [
                  ['overview', 'Personal & Family'],
                  ['attendance', `My Attendance (${selfProfile.attendanceStats?.rate ?? 0}%)`],
                  ['namaz_daily', 'My Namaz Summary'],
                  ['academics', 'My Marks & Syllabus'],
                  ['homework', 'My Homework'],
                ] as const
              ).map(([k, lbl]) => (
                <button
                  key={k}
                  type="button"
                  onClick={() => setProfileTab(k)}
                  className={`px-3.5 py-2 text-xs font-semibold border-b-2 cursor-pointer whitespace-nowrap ${
                    profileTab === k
                      ? 'border-emerald-800 text-emerald-900'
                      : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  {lbl}
                </button>
              ))}
            </div>

            <div className="p-6 space-y-4 text-xs">
              {profileTab === 'overview' && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="p-4 rounded-xl border border-slate-200 space-y-2">
                    <div className="font-semibold text-slate-900 flex items-center gap-1.5">
                      <User className="h-3.5 w-3.5 text-emerald-800" />
                      <span>Personal & Family Details</span>
                    </div>
                    <div className="grid grid-cols-2 gap-y-1.5 text-slate-600">
                      <span>Father Name:</span><strong className="text-slate-900">{selfProfile.student.fatherName || '—'}</strong>
                      <span>Mother Name:</span><strong className="text-slate-900">{selfProfile.student.motherName || '—'}</strong>
                      <span>Guardian:</span><strong className="text-slate-900">{selfProfile.student.guardianName}</strong>
                      <span>Date of Birth:</span><strong className="font-mono-num text-slate-900">{selfProfile.student.dob}</strong>
                      <span>Admission Date:</span><strong className="font-mono-num text-slate-900">{selfProfile.student.admissionDate || '—'}</strong>
                      <span>Gender:</span><strong className="text-slate-900">{selfProfile.student.gender}</strong>
                    </div>
                  </div>
                  <div className="p-4 rounded-xl border border-slate-200 space-y-2">
                    <div className="font-semibold text-slate-900">Contact & Address</div>
                    <div className="grid grid-cols-2 gap-y-1.5 text-slate-600">
                      <span>Parent Contact:</span><strong className="font-mono-num text-slate-900">{selfProfile.student.guardianPhone}</strong>
                      <span>Emergency Contact:</span><strong className="font-mono-num text-red-700">{selfProfile.student.emergencyContact || '—'}</strong>
                      <span>Blood Group:</span><strong className="text-slate-900">{selfProfile.student.bloodGroup || '—'}</strong>
                      <span>Address:</span><strong className="text-slate-900">{selfProfile.student.address || '—'}</strong>
                    </div>
                  </div>
                </div>
              )}

              {profileTab === 'attendance' && (
                <div className="space-y-3">
                  <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                    <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200">
                      <div className="text-slate-500">Rate</div>
                      <div className="font-mono-num font-bold text-lg text-emerald-900">{selfProfile.attendanceStats?.rate ?? 0}%</div>
                    </div>
                    <div className="p-3 rounded-xl border border-slate-200">
                      <div className="text-slate-500">Present</div>
                      <div className="font-mono-num font-bold text-lg text-emerald-700">{selfProfile.attendanceStats?.present ?? 0}</div>
                    </div>
                    <div className="p-3 rounded-xl border border-slate-200">
                      <div className="text-slate-500">Late</div>
                      <div className="font-mono-num font-bold text-lg text-amber-700">{selfProfile.attendanceStats?.late ?? 0}</div>
                    </div>
                    <div className="p-3 rounded-xl border border-slate-200">
                      <div className="text-slate-500">Absent</div>
                      <div className="font-mono-num font-bold text-lg text-red-600">{selfProfile.attendanceStats?.absent ?? 0}</div>
                    </div>
                    <div className="p-3 rounded-xl border border-slate-200">
                      <div className="text-slate-500">Leave</div>
                      <div className="font-mono-num font-bold text-lg text-slate-700">{selfProfile.attendanceStats?.leave ?? 0}</div>
                    </div>
                  </div>
                  <div className="divide-y divide-slate-100 border border-slate-200 rounded-xl">
                    {(selfProfile.attendance || []).map((a: any) => (
                      <div key={a.id} className="p-3 flex items-center justify-between">
                        <span className="font-mono-num text-slate-600">{a.date}</span>
                        <span className="font-semibold">{t(lang, a.status)}</span>
                        <span className="text-slate-500">{a.remarks || '—'}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {profileTab === 'namaz_daily' && (
                <div className="space-y-3">
                  {selfProfile.policy?.prayerTrackingEnabled && (
                    <div className="p-3 rounded-xl bg-amber-50/70 border border-amber-200 text-amber-950">
                      {selfProfile.policy?.prayerPolicyNote}
                    </div>
                  )}
                  <div className="space-y-2">
                    <div className="font-semibold text-slate-900">Recent Namaz Logs</div>
                    {(selfProfile.namazRecords || []).map((n: any) => (
                      <div key={n.id} className="p-3 rounded-xl border border-slate-200 flex flex-wrap justify-between gap-2">
                        <span className="font-mono-num font-semibold">{n.date}</span>
                        <span>
                          F: {t(lang, n.fajr)} · Z: {t(lang, n.zuhr)} · A: {t(lang, n.asr)} · M: {t(lang, n.maghrib)} · I: {t(lang, n.isha)}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {profileTab === 'academics' && (
                <div className="space-y-3">
                  <div className="font-semibold text-slate-900">My Exam Results</div>
                  {(selfProfile.marks || []).length === 0 ? (
                    <div className="text-slate-500">{t(lang, 'noRecords')}</div>
                  ) : (
                    (selfProfile.marks || []).map((m: any) => (
                      <div key={m.id} className="p-3 rounded-xl border border-slate-200 flex justify-between">
                        <span className="font-medium text-slate-900">{m.exam?.title || `Exam #${m.examId}`}</span>
                        <span className="font-mono-num font-bold text-emerald-900">
                          {m.obtainedMarks}/{m.totalMarks} ({m.grade})
                        </span>
                      </div>
                    ))
                  )}
                  <div className="font-semibold text-slate-900 pt-2">Class Syllabus Coverage</div>
                  {(selfProfile.syllabusTopics || []).map((tp: any) => (
                    <div key={tp.id} className="p-3 rounded-xl border border-slate-200 flex justify-between">
                      <span>{tp.bookName} — {tp.chapter}: {tp.lesson}</span>
                      <span className="font-mono-num font-semibold text-emerald-800">
                        {tp.completedTopics}/{tp.totalTopics}
                      </span>
                    </div>
                  ))}
                </div>
              )}

              {profileTab === 'homework' && (
                <div className="space-y-2">
                  {(selfProfile.homework || []).length === 0 ? (
                    <div className="text-slate-500">{t(lang, 'noRecords')}</div>
                  ) : (
                    (selfProfile.homework || []).map((hw: any) => (
                      <div key={hw.id} className="p-3 rounded-xl border border-slate-200 flex justify-between gap-3">
                        <div>
                          <div className="font-semibold text-slate-900">{hw.title}</div>
                          <div className="text-slate-500">Due: {hw.dueDate}</div>
                        </div>
                        <span className="font-semibold text-emerald-800">
                          {hw.assignment ? `${hw.assignment.status.toUpperCase()} (${hw.assignment.score ?? 'Submitted'})` : 'Pending'}
                        </span>
                      </div>
                    ))
                  )}
                </div>
              )}
            </div>
          </div>
        )
      ) : tab === 'students' ? (
        <div className="bg-white border border-emerald-900/10 rounded-2xl overflow-hidden">
          <div className="p-4 border-b border-slate-100 flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="h-4 w-4 text-slate-400 absolute top-2.5 start-3" />
              <input
                type="text"
                placeholder={t(lang, 'searchPlaceholder')}
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full rounded-xl border border-slate-200 ps-9 pe-3 py-2 text-xs"
              />
            </div>
            <select
              value={classFilter}
              onChange={(e) => setClassFilter(e.target.value)}
              className="rounded-xl border border-slate-200 px-3 py-2 text-xs bg-white"
            >
              <option value="all">{t(lang, 'all')} Classes</option>
              {classes.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-start border-collapse">
              <thead>
                <tr className="border-b border-slate-100 bg-slate-50/70 text-[11px] font-semibold text-slate-500">
                  <th className="py-3 px-4 text-start">Student ID</th>
                  <th className="py-3 px-4 text-start">Student & Parents</th>
                  <th className="py-3 px-4 text-start">Class / Session</th>
                  <th className="py-3 px-4 text-start">Guardian & Emergency</th>
                  <th className="py-3 px-4 text-start">Status</th>
                  <th className="py-3 px-4 text-end">Profile & Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-xs">
                {loading ? (
                  <tr>
                    <td colSpan={6} className="py-8 text-center text-slate-500">
                      {t(lang, 'loading')}
                    </td>
                  </tr>
                ) : filteredStudents.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-8 text-center text-slate-500">
                      {t(lang, 'noRecords')}
                    </td>
                  </tr>
                ) : (
                  filteredStudents.map((st) => (
                    <tr key={st.id} className="hover:bg-emerald-50/30">
                      <td className="py-3 px-4 font-mono-num font-semibold text-emerald-900">{st.admissionNo}</td>
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2.5">
                          {st.photoUrl ? (
                            <img
                              src={st.photoUrl}
                              alt={st.fullName}
                              className="h-8 w-8 rounded-full object-cover border border-emerald-900/15 shrink-0"
                            />
                          ) : (
                            <div className="h-8 w-8 rounded-full bg-emerald-100 text-emerald-900 font-semibold flex items-center justify-center shrink-0">
                              {st.fullName.charAt(0).toUpperCase()}
                            </div>
                          )}
                          <div>
                            <div className="font-semibold text-slate-900">{st.fullName}</div>
                            <div className="text-[11px] text-slate-500">
                              {st.fatherName ? `S/D of ${st.fatherName} · ` : ''}DOB: {st.dob}
                            </div>
                          </div>
                        </div>
                      </td>
                      <td className="py-3 px-4 text-slate-700">
                        <div>{classMap.get(st.classId)?.name || 'Unassigned'}</div>
                        <div className="text-[11px] text-slate-500 font-mono-num">{st.academicSession || '2026-2027'}</div>
                      </td>
                      <td className="py-3 px-4">
                        <div className="text-slate-800">{st.guardianName}</div>
                        <div className="text-[11px] font-mono-num text-slate-500">
                          {st.guardianPhone} {st.emergencyContact ? `· SOS: ${st.emergencyContact}` : ''}
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        <span className="font-semibold text-emerald-700">
                          {st.status} {st.isDemo ? '· Demo' : ''}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-end">
                        <div className="inline-flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => openProfileModal(st.id)}
                            className="px-2.5 py-1 rounded-lg border border-emerald-800/30 text-emerald-900 hover:bg-emerald-50 text-[11px] font-semibold inline-flex items-center gap-1 cursor-pointer whitespace-nowrap"
                          >
                            <Eye className="h-3.5 w-3.5" />
                            <span>View Profile</span>
                          </button>
                          {user?.role === 'admin' && (
                            <>
                              <button
                                type="button"
                                onClick={() => openEditStudentModal(st)}
                                className="p-1.5 text-slate-500 hover:text-emerald-800 cursor-pointer"
                                title="Edit student"
                              >
                                <Edit2 className="h-4 w-4" />
                              </button>
                              <button
                                type="button"
                                onClick={() => handleDeleteStudent(st.id)}
                                className="p-1.5 text-slate-400 hover:text-red-600 cursor-pointer"
                                title="Delete student"
                              >
                                <Trash2 className="h-4 w-4" />
                              </button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div className="space-y-6">
          {/* Active Classes */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {classes.map((c) => (
              <div key={c.id} className="bg-white border border-emerald-900/10 rounded-xl p-5">
                <div className="text-xs text-amber-700 font-semibold mb-1">
                  {c.gradeLevel} · Section {c.section}
                </div>
                <h3 className="font-display font-bold text-slate-950 text-base">{c.name}</h3>
                <div className="text-xs text-slate-500 mt-2">
                  Room {c.roomNumber || 'TBD'} · Capacity <span className="font-mono-num">{c.capacity}</span> · {c.academicYear}
                </div>
              </div>
            ))}
          </div>

          {/* Subject Overview Bars */}
          <div className="bg-white border border-emerald-900/10 rounded-2xl p-6">
            <h2 className="font-display text-lg font-bold text-slate-950 mb-4 flex items-center gap-2">
              <BookOpen className="h-4 w-4 text-emerald-800" />
              <span>Subjects Completion Summary</span>
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {subjects.map((sub) => {
                const pct =
                  sub.syllabusTotalUnits > 0
                    ? Math.min(100, Math.round((sub.syllabusCompletedUnits / sub.syllabusTotalUnits) * 100))
                    : 0;
                return (
                  <div key={sub.id} className="p-4 rounded-xl border border-slate-200 flex flex-col justify-between gap-3">
                    <div>
                      <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
                        <span>{sub.category} · {sub.code}</span>
                        <span>{classMap.get(sub.classId)?.name}</span>
                      </div>
                      <div className="font-semibold text-slate-900 text-sm">{sub.name}</div>
                    </div>
                    <div>
                      <div className="flex items-center justify-between text-xs mb-1.5">
                        <span className="font-mono-num text-slate-600">
                          {sub.syllabusCompletedUnits} / {sub.syllabusTotalUnits} Topics ({pct}%)
                        </span>
                        {canManageTopic(sub.classId, sub.id) && (
                          <div className="flex items-center gap-1">
                            <button
                              type="button"
                              onClick={() => handleIncrementSyllabus(sub, -1)}
                              className="px-2 py-0.5 rounded border border-slate-200 hover:bg-slate-100 text-xs cursor-pointer"
                            >
                              -1
                            </button>
                            <button
                              type="button"
                              onClick={() => handleIncrementSyllabus(sub, 1)}
                              className="px-2 py-0.5 rounded bg-emerald-800 text-white hover:bg-emerald-900 text-xs cursor-pointer"
                            >
                              +1 Topic
                            </button>
                          </div>
                        )}
                      </div>
                      <div className="h-2 rounded-full bg-slate-100 overflow-hidden">
                        <div className="h-full bg-emerald-700 rounded-full" style={{ width: `${pct}%` }} />
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Detailed Chapter & Lesson Syllabus Tracker */}
          <div className="bg-white border border-emerald-900/10 rounded-2xl p-6 space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h2 className="font-display text-lg font-bold text-slate-950">
                  Detailed {t(lang, 'syllabusTracking')} (Book, Chapter & Lesson)
                </h2>
                <p className="text-xs text-slate-500">
                  {isStudent
                    ? 'Chapter and lesson progress across your enrolled class subjects.'
                    : 'Teachers may only add or update syllabus entries for their assigned subjects and classes.'}
                </p>
              </div>
              {!isStudent && (
                <select
                  value={syllabusClassFilter}
                  onChange={(e) => setSyllabusClassFilter(e.target.value)}
                  className="rounded-xl border border-slate-200 px-3 py-1.5 text-xs bg-white self-start"
                >
                  <option value="all">{t(lang, 'all')} Classes</option>
                  {classes.map((c) => (
                    <option key={c.id} value={String(c.id)}>{c.name}</option>
                  ))}
                </select>
              )}
            </div>

            {(user?.role === 'admin' || user?.role === 'teacher') && teacherAssignableSubjects.length > 0 && (
              <form onSubmit={handleCreateSyllabusTopic} className="p-4 rounded-xl bg-[#FAFBF9] border border-emerald-900/10 space-y-3 text-xs">
                <div className="font-semibold text-slate-900">Add Book Chapter / Lesson Plan</div>
                <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
                  <select
                    required
                    value={topicForm.subjectId}
                    onChange={(e) => {
                      const chosen = subjectMap.get(Number(e.target.value));
                      setTopicForm({
                        ...topicForm,
                        subjectId: e.target.value,
                        classId: chosen ? String(chosen.classId) : topicForm.classId,
                      });
                    }}
                    className="sm:col-span-2 rounded-lg border border-slate-200 px-2.5 py-2 bg-white"
                  >
                    {teacherAssignableSubjects.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.name} ({classMap.get(s.classId)?.name || ''})
                      </option>
                    ))}
                  </select>
                  <input
                    type="text"
                    required
                    placeholder="Book Name *"
                    value={topicForm.bookName}
                    onChange={(e) => setTopicForm({ ...topicForm, bookName: e.target.value })}
                    className="rounded-lg border border-slate-200 px-2.5 py-2 bg-white"
                  />
                  <input
                    type="text"
                    required
                    placeholder="Chapter *"
                    value={topicForm.chapter}
                    onChange={(e) => setTopicForm({ ...topicForm, chapter: e.target.value })}
                    className="rounded-lg border border-slate-200 px-2.5 py-2 bg-white"
                  />
                  <input
                    type="text"
                    required
                    placeholder="Lesson *"
                    value={topicForm.lesson}
                    onChange={(e) => setTopicForm({ ...topicForm, lesson: e.target.value })}
                    className="rounded-lg border border-slate-200 px-2.5 py-2 bg-white"
                  />
                  <input
                    type="text"
                    placeholder="Session"
                    value={topicForm.academicSession}
                    onChange={(e) => setTopicForm({ ...topicForm, academicSession: e.target.value })}
                    className="rounded-lg border border-slate-200 px-2.5 py-2 bg-white"
                  />
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-2.5">
                  <input
                    type="number"
                    min={1}
                    placeholder="Total Topics"
                    value={topicForm.totalTopics}
                    onChange={(e) => setTopicForm({ ...topicForm, totalTopics: Number(e.target.value) })}
                    className="rounded-lg border border-slate-200 px-2.5 py-2 bg-white"
                  />
                  <input
                    type="number"
                    min={0}
                    placeholder="Completed Topics"
                    value={topicForm.completedTopics}
                    onChange={(e) => setTopicForm({ ...topicForm, completedTopics: Number(e.target.value) })}
                    className="rounded-lg border border-slate-200 px-2.5 py-2 bg-white"
                  />
                  <input
                    type="text"
                    placeholder="Teacher Remarks (optional)"
                    value={topicForm.teacherRemarks}
                    onChange={(e) => setTopicForm({ ...topicForm, teacherRemarks: e.target.value })}
                    className="sm:col-span-2 rounded-lg border border-slate-200 px-2.5 py-2 bg-white"
                  />
                </div>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-emerald-800 hover:bg-emerald-900 text-white font-semibold cursor-pointer"
                >
                  Add Syllabus Entry
                </button>
              </form>
            )}

            <div className="overflow-x-auto">
              <table className="w-full text-start border-collapse text-xs">
                <thead>
                  <tr className="border-b border-slate-100 bg-slate-50/70 text-[11px] font-semibold text-slate-500">
                    <th className="py-3 px-3 text-start">Class & Subject</th>
                    <th className="py-3 px-3 text-start">Book / Chapter / Lesson</th>
                    <th className="py-3 px-3 text-start">Progress</th>
                    <th className="py-3 px-3 text-start">Pending</th>
                    <th className="py-3 px-3 text-start">Completion & Remarks</th>
                    {(user?.role === 'admin' || user?.role === 'teacher') && (
                      <th className="py-3 px-3 text-end">Update</th>
                    )}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredTopics.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-8 text-center text-slate-500">
                        {t(lang, 'noRecords')}
                      </td>
                    </tr>
                  ) : (
                    filteredTopics.map((tp) => {
                      const pct = tp.totalTopics > 0 ? Math.min(100, Math.round((tp.completedTopics / tp.totalTopics) * 100)) : 0;
                      const pending = Math.max(0, tp.totalTopics - tp.completedTopics);
                      const editable = canManageTopic(tp.classId, tp.subjectId);
                      return (
                        <tr key={tp.id}>
                          <td className="py-3 px-3">
                            <div className="font-semibold text-slate-900">{subjectMap.get(tp.subjectId)?.name || `#${tp.subjectId}`}</div>
                            <div className="text-[11px] text-slate-500">
                              {classMap.get(tp.classId)?.name || ''} · {tp.academicSession}
                            </div>
                          </td>
                          <td className="py-3 px-3">
                            <div className="font-medium text-slate-800">{tp.bookName}</div>
                            <div className="text-[11px] text-slate-600">
                              {tp.chapter} — {tp.lesson}
                            </div>
                          </td>
                          <td className="py-3 px-3 min-w-[140px]">
                            <div className="flex justify-between text-[11px] font-mono-num mb-1">
                              <span>{tp.completedTopics}/{tp.totalTopics}</span>
                              <span className="font-semibold text-emerald-800">{pct}%</span>
                            </div>
                            <div className="h-1.5 rounded-full bg-slate-100 overflow-hidden">
                              <div className="h-full bg-emerald-700" style={{ width: `${pct}%` }} />
                            </div>
                          </td>
                          <td className="py-3 px-3 font-mono-num text-amber-700 font-semibold">{pending} left</td>
                          <td className="py-3 px-3 text-slate-600">
                            <div>{tp.completionDate ? `Completed: ${tp.completionDate}` : `Status: ${tp.status}`}</div>
                            {tp.teacherRemarks && <div className="text-[11px] text-slate-500 mt-0.5">{tp.teacherRemarks}</div>}
                          </td>
                          {(user?.role === 'admin' || user?.role === 'teacher') && (
                            <td className="py-3 px-3 text-end">
                              {editable ? (
                                <div className="inline-flex items-center gap-1">
                                  <button
                                    type="button"
                                    onClick={() => handleUpdateTopicProgress(tp, -1)}
                                    className="px-2 py-1 rounded border border-slate-200 hover:bg-slate-100 cursor-pointer"
                                  >
                                    -1
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => handleUpdateTopicProgress(tp, 1)}
                                    className="px-2 py-1 rounded bg-emerald-800 text-white hover:bg-emerald-900 cursor-pointer"
                                  >
                                    +1
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => handleDeleteTopic(tp.id)}
                                    className="p-1 text-slate-400 hover:text-red-600 cursor-pointer"
                                    title="Delete syllabus topic"
                                  >
                                    <Trash2 className="h-3.5 w-3.5" />
                                  </button>
                                </div>
                              ) : (
                                <span className="text-[11px] text-slate-400">Read only</span>
                              )}
                            </td>
                          )}
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Unified Student Personal Profile Modal */}
      {profileData && (
        <div
          className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4"
          onClick={() => setProfileData(null)}
        >
          <div
            className="bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden flex flex-col border border-emerald-900/15"
            onClick={(e) => e.stopPropagation()}
          >
            {profileLoading || profileData.loading ? (
              <div className="p-12 text-center text-xs text-slate-500">{t(lang, 'loading')}</div>
            ) : (
              <>
                <div className="p-5 bg-emerald-950 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="flex items-center gap-3.5">
                    {profileData.student.photoUrl ? (
                      <img
                        src={profileData.student.photoUrl}
                        alt={profileData.student.fullName}
                        className="h-14 w-14 rounded-full object-cover border-2 border-amber-300"
                      />
                    ) : (
                      <div className="h-14 w-14 rounded-full bg-emerald-800 text-amber-200 flex items-center justify-center font-display font-bold text-xl">
                        {profileData.student.fullName.charAt(0).toUpperCase()}
                      </div>
                    )}
                    <div>
                      <div className="text-[11px] font-mono-num text-amber-300">
                        ID: {profileData.student.admissionNo} · Session {profileData.student.academicSession || '2026-2027'}
                      </div>
                      <h3 className="font-display text-xl font-bold">{profileData.student.fullName}</h3>
                      <div className="text-xs text-emerald-100/85">
                        {profileData.classInfo?.name || 'Unassigned'} (Section {profileData.classInfo?.section || 'A'})
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 self-start sm:self-center">
                    <button
                      type="button"
                      onClick={() => handlePrintProfilePdf()}
                      className="px-3 py-1.5 rounded-lg bg-emerald-800 hover:bg-emerald-700 text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer"
                    >
                      <Download className="h-3.5 w-3.5" />
                      <span>{t(lang, 'exportPdf')}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setProfileData(null)}
                      className="p-1.5 rounded-lg hover:bg-emerald-900 cursor-pointer"
                    >
                      <X className="h-5 w-5" />
                    </button>
                  </div>
                </div>

                {/* Profile Tabs */}
                <div className="px-5 pt-3 border-b border-slate-100 flex flex-wrap gap-1 bg-[#FAFBF9]">
                  {(
                    [
                      ['overview', 'Personal & Family'],
                      ['attendance', `Attendance (${profileData.attendanceStats?.rate ?? 0}%)`],
                      ['namaz_daily', 'Namaz & Meals'],
                      ['academics', 'Marks & Syllabus'],
                      ['homework', 'Homework'],
                      ['health', 'Medical Notes (Restricted)'],
                    ] as const
                  ).map(([k, lbl]) => (
                    <button
                      key={k}
                      type="button"
                      onClick={() => setProfileTab(k)}
                      className={`px-3.5 py-2 text-xs font-semibold border-b-2 cursor-pointer whitespace-nowrap ${
                        profileTab === k
                          ? 'border-emerald-800 text-emerald-900'
                          : 'border-transparent text-slate-500 hover:text-slate-800'
                      }`}
                    >
                      {lbl}
                    </button>
                  ))}
                </div>

                <div className="p-5 overflow-y-auto space-y-4 text-xs">
                  {profileTab === 'overview' && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="p-4 rounded-xl border border-slate-200 space-y-2">
                        <div className="font-semibold text-slate-900 flex items-center gap-1.5">
                          <User className="h-3.5 w-3.5 text-emerald-800" />
                          <span>Student & Family Details</span>
                        </div>
                        <div className="grid grid-cols-2 gap-y-1.5 text-slate-600">
                          <span>Father Name:</span><strong className="text-slate-900">{profileData.student.fatherName || '—'}</strong>
                          <span>Mother Name:</span><strong className="text-slate-900">{profileData.student.motherName || '—'}</strong>
                          <span>Guardian:</span><strong className="text-slate-900">{profileData.student.guardianName}</strong>
                          <span>Date of Birth:</span><strong className="font-mono-num text-slate-900">{profileData.student.dob}</strong>
                          <span>Admission Date:</span><strong className="font-mono-num text-slate-900">{profileData.student.admissionDate || '—'}</strong>
                          <span>Gender:</span><strong className="text-slate-900">{profileData.student.gender}</strong>
                        </div>
                      </div>
                      <div className="p-4 rounded-xl border border-slate-200 space-y-2">
                        <div className="font-semibold text-slate-900">Contact & Address</div>
                        <div className="grid grid-cols-2 gap-y-1.5 text-slate-600">
                          <span>Parent Contact:</span><strong className="font-mono-num text-slate-900">{profileData.student.guardianPhone}</strong>
                          <span>Emergency Contact:</span><strong className="font-mono-num text-red-700">{profileData.student.emergencyContact || '—'}</strong>
                          <span>Blood Group:</span><strong className="text-slate-900">{profileData.student.bloodGroup || '—'}</strong>
                          <span>Address:</span><strong className="text-slate-900">{profileData.student.address || '—'}</strong>
                        </div>
                      </div>
                    </div>
                  )}

                  {profileTab === 'attendance' && (
                    <div className="space-y-3">
                      <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                        <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200">
                          <div className="text-slate-500">Rate</div>
                          <div className="font-mono-num font-bold text-lg text-emerald-900">{profileData.attendanceStats?.rate ?? 0}%</div>
                        </div>
                        <div className="p-3 rounded-xl border border-slate-200">
                          <div className="text-slate-500">Present</div>
                          <div className="font-mono-num font-bold text-lg text-emerald-700">{profileData.attendanceStats?.present ?? 0}</div>
                        </div>
                        <div className="p-3 rounded-xl border border-slate-200">
                          <div className="text-slate-500">Late</div>
                          <div className="font-mono-num font-bold text-lg text-amber-700">{profileData.attendanceStats?.late ?? 0}</div>
                        </div>
                        <div className="p-3 rounded-xl border border-slate-200">
                          <div className="text-slate-500">Absent</div>
                          <div className="font-mono-num font-bold text-lg text-red-600">{profileData.attendanceStats?.absent ?? 0}</div>
                        </div>
                        <div className="p-3 rounded-xl border border-slate-200">
                          <div className="text-slate-500">Leave</div>
                          <div className="font-mono-num font-bold text-lg text-slate-700">{profileData.attendanceStats?.leave ?? 0}</div>
                        </div>
                      </div>
                      <div className="divide-y divide-slate-100 border border-slate-200 rounded-xl">
                        {(profileData.attendance || []).map((a: any) => (
                          <div key={a.id} className="p-3 flex items-center justify-between">
                            <span className="font-mono-num text-slate-600">{a.date}</span>
                            <span className="font-semibold">{t(lang, a.status)}</span>
                            <span className="text-slate-500">{a.remarks || '—'}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {profileTab === 'namaz_daily' && (
                    <div className="space-y-4">
                      {profileData.policy?.prayerTrackingEnabled && (
                        <div className="p-3 rounded-xl bg-amber-50/70 border border-amber-200 text-amber-950">
                          {profileData.policy?.prayerPolicyNote}
                        </div>
                      )}
                      <div className="space-y-2">
                        <div className="font-semibold text-slate-900">Recent Namaz Logs</div>
                        {(profileData.namazRecords || []).map((n: any) => (
                          <div key={n.id} className="p-3 rounded-xl border border-slate-200 flex flex-wrap justify-between gap-2">
                            <span className="font-mono-num font-semibold">{n.date}</span>
                            <span>
                              F: {t(lang, n.fajr)} · Z: {t(lang, n.zuhr)} · A: {t(lang, n.asr)} · M: {t(lang, n.maghrib)} · I: {t(lang, n.isha)}
                            </span>
                          </div>
                        ))}
                      </div>
                      <div className="space-y-2">
                        <div className="font-semibold text-slate-900">Recent Meals & Daily Care</div>
                        {(profileData.dailyActivities || []).map((d: any) => (
                          <div key={d.id} className="p-3 rounded-xl border border-slate-200 space-y-1">
                            <div className="flex justify-between font-semibold">
                              <span className="font-mono-num">{d.date}</span>
                              <span>Discipline: {d.disciplineRating}/5</span>
                            </div>
                            <div className="text-slate-600">
                              B: {t(lang, d.breakfastStatus)} · L: {t(lang, d.lunchStatus)} · E: {t(lang, d.eveningMealStatus || 'not_recorded')} · D: {t(lang, d.dinnerStatus)} · O: {t(lang, d.otherMealStatus || 'not_recorded')}
                            </div>
                            {d.teacherRemarks && <div className="text-slate-700">Teacher: {d.teacherRemarks}</div>}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {profileTab === 'academics' && (
                    <div className="space-y-3">
                      <div className="font-semibold text-slate-900">Exam Results</div>
                      {(profileData.marks || []).map((m: any) => (
                        <div key={m.id} className="p-3 rounded-xl border border-slate-200 flex justify-between">
                          <span className="font-medium text-slate-900">{m.exam?.title || `Exam #${m.examId}`}</span>
                          <span className="font-mono-num font-bold text-emerald-900">
                            {m.obtainedMarks}/{m.totalMarks} ({m.grade})
                          </span>
                        </div>
                      ))}
                      <div className="font-semibold text-slate-900 pt-2">Class Syllabus Coverage</div>
                      {(profileData.syllabusTopics || []).map((tp: any) => (
                        <div key={tp.id} className="p-3 rounded-xl border border-slate-200 flex justify-between">
                          <span>{tp.bookName} — {tp.chapter}: {tp.lesson}</span>
                          <span className="font-mono-num font-semibold text-emerald-800">
                            {tp.completedTopics}/{tp.totalTopics}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}

                  {profileTab === 'homework' && (
                    <div className="space-y-2">
                      {(profileData.homework || []).map((hw: any) => (
                        <div key={hw.id} className="p-3 rounded-xl border border-slate-200 flex justify-between gap-3">
                          <div>
                            <div className="font-semibold text-slate-900">{hw.title}</div>
                            <div className="text-slate-500">Due: {hw.dueDate}</div>
                          </div>
                          <span className="font-semibold text-emerald-800">
                            {hw.assignment ? `${hw.assignment.status.toUpperCase()} (${hw.assignment.score ?? 'Submitted'})` : 'Pending'}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}

                  {profileTab === 'health' && (
                    <div className="space-y-3">
                      <div className="p-3 rounded-xl border border-amber-200 bg-amber-50 text-amber-950 flex items-center gap-2">
                        <ShieldAlert className="h-4 w-4 text-amber-700 shrink-0" />
                        <span>{t(lang, 'restrictedHealthNote')}</span>
                      </div>
                      <div className="p-4 rounded-xl border border-slate-200 space-y-1">
                        <div>Allergies: <strong>{profileData.student.allergies || 'Restricted / Not Provided'}</strong></div>
                        <div>Medical Notes: <strong>{profileData.student.medicalNotes || 'Restricted / None Recorded'}</strong></div>
                      </div>
                      {(profileData.healthRecords || []).map((h: any) => (
                        <div key={h.id} className="p-3 rounded-xl border border-slate-200 space-y-1">
                          <div className="flex justify-between font-semibold">
                            <span className="font-mono-num">{h.recordDate}</span>
                            <span className="text-emerald-800">{t(lang, h.healthStatus)}</span>
                          </div>
                          <div className="text-slate-600">{h.illnessInfo || 'General check-in'} {h.parentUpdateNotes ? `· Parent Note: ${h.parentUpdateNotes}` : ''}</div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* Add / Edit Student Modal */}
      {showStudentModal && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <form
            onSubmit={handleSaveStudent}
            className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6 space-y-4 border border-emerald-900/15"
          >
            <h3 className="font-display text-lg font-bold text-slate-950">
              {editingStudentId ? 'Edit Student Personal Profile' : 'Register New Student'}
            </h3>
            {studentModalError && (
              <div className="rounded-xl border border-red-200 bg-red-50 px-3.5 py-2.5 text-xs text-red-800">
                {studentModalError}
              </div>
            )}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <input
                type="text"
                required
                placeholder="Student Full Name *"
                value={studentForm.fullName}
                onChange={(e) => setStudentForm({ ...studentForm, fullName: e.target.value })}
                className="rounded-xl border border-slate-200 px-3 py-2"
              />
              <input
                type="text"
                placeholder="Photograph URL (optional)"
                value={studentForm.photoUrl}
                onChange={(e) => setStudentForm({ ...studentForm, photoUrl: e.target.value })}
                className="rounded-xl border border-slate-200 px-3 py-2"
              />
              <input
                type="text"
                placeholder="Father Name"
                value={studentForm.fatherName}
                onChange={(e) => setStudentForm({ ...studentForm, fatherName: e.target.value })}
                className="rounded-xl border border-slate-200 px-3 py-2"
              />
              <input
                type="text"
                placeholder="Mother Name"
                value={studentForm.motherName}
                onChange={(e) => setStudentForm({ ...studentForm, motherName: e.target.value })}
                className="rounded-xl border border-slate-200 px-3 py-2"
              />
              <input
                type="date"
                required
                value={studentForm.dob}
                onChange={(e) => setStudentForm({ ...studentForm, dob: e.target.value })}
                className="rounded-xl border border-slate-200 px-3 py-2"
              />
              <input
                type="text"
                placeholder="Academic Session (e.g. 2026-2027)"
                value={studentForm.academicSession}
                onChange={(e) => setStudentForm({ ...studentForm, academicSession: e.target.value })}
                className="rounded-xl border border-slate-200 px-3 py-2"
              />
              <select
                value={studentForm.classId}
                onChange={(e) => setStudentForm({ ...studentForm, classId: e.target.value })}
                className="rounded-xl border border-slate-200 px-3 py-2 bg-white"
              >
                <option value="">
                  {classes.length === 0 ? 'Unassigned (Create class anytime)' : 'Select Class (Optional)'}
                </option>
                {classes.map((c) => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
              <select
                value={studentForm.parentId}
                onChange={(e) => setStudentForm({ ...studentForm, parentId: e.target.value })}
                className="rounded-xl border border-slate-200 px-3 py-2 bg-white"
              >
                <option value="">Link Parent Account (Optional)</option>
                {parents.map((p) => (
                  <option key={p.id} value={p.id}>{p.name} ({p.email})</option>
                ))}
              </select>
              <input
                type="text"
                required
                placeholder="Guardian Name *"
                value={studentForm.guardianName}
                onChange={(e) => setStudentForm({ ...studentForm, guardianName: e.target.value })}
                className="rounded-xl border border-slate-200 px-3 py-2"
              />
              <input
                type="tel"
                required
                placeholder="Parent Contact Phone *"
                value={studentForm.guardianPhone}
                onChange={(e) => setStudentForm({ ...studentForm, guardianPhone: e.target.value })}
                className="rounded-xl border border-slate-200 px-3 py-2"
              />
              <input
                type="tel"
                placeholder="Emergency Contact Phone"
                value={studentForm.emergencyContact}
                onChange={(e) => setStudentForm({ ...studentForm, emergencyContact: e.target.value })}
                className="rounded-xl border border-slate-200 px-3 py-2"
              />
              <input
                type="text"
                placeholder="Blood Group"
                value={studentForm.bloodGroup}
                onChange={(e) => setStudentForm({ ...studentForm, bloodGroup: e.target.value })}
                className="rounded-xl border border-slate-200 px-3 py-2"
              />
              <input
                type="text"
                placeholder="Address"
                value={studentForm.address}
                onChange={(e) => setStudentForm({ ...studentForm, address: e.target.value })}
                className="sm:col-span-2 rounded-xl border border-slate-200 px-3 py-2"
              />
              <input
                type="text"
                placeholder="Allergies (if voluntarily provided)"
                value={studentForm.allergies}
                onChange={(e) => setStudentForm({ ...studentForm, allergies: e.target.value })}
                className="rounded-xl border border-slate-200 px-3 py-2"
              />
              <input
                type="text"
                placeholder="Restricted Medical Notes (voluntary)"
                value={studentForm.medicalNotes}
                onChange={(e) => setStudentForm({ ...studentForm, medicalNotes: e.target.value })}
                className="rounded-xl border border-slate-200 px-3 py-2"
              />
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowStudentModal(false)}
                className="px-4 py-2 text-xs rounded-xl border border-slate-200 cursor-pointer"
              >
                {t(lang, 'cancel')}
              </button>
              <button
                type="submit"
                disabled={savingStudent}
                className="px-4 py-2 text-xs font-semibold rounded-xl bg-emerald-800 hover:bg-emerald-900 text-white cursor-pointer disabled:opacity-60"
              >
                {savingStudent ? t(lang, 'loading') : t(lang, 'save')}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Add Class Modal */}
      {showAddClass && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <form onSubmit={handleCreateClass} className="bg-white rounded-2xl max-w-md w-full p-6 space-y-3 text-xs">
            <h3 className="font-display text-lg font-bold text-slate-950">Create New Class</h3>
            <input
              type="text"
              required
              placeholder="Class Name (e.g. Hifz Level 2)"
              value={classForm.name}
              onChange={(e) => setClassForm({ ...classForm, name: e.target.value })}
              className="w-full rounded-xl border border-slate-200 px-3 py-2"
            />
            <div className="grid grid-cols-2 gap-2">
              <input
                type="text"
                required
                placeholder="Grade / Level"
                value={classForm.gradeLevel}
                onChange={(e) => setClassForm({ ...classForm, gradeLevel: e.target.value })}
                className="rounded-xl border border-slate-200 px-3 py-2"
              />
              <input
                type="text"
                placeholder="Room Number"
                value={classForm.roomNumber}
                onChange={(e) => setClassForm({ ...classForm, roomNumber: e.target.value })}
                className="rounded-xl border border-slate-200 px-3 py-2"
              />
            </div>
            <select
              value={classForm.teacherId}
              onChange={(e) => setClassForm({ ...classForm, teacherId: e.target.value })}
              className="w-full rounded-xl border border-slate-200 px-3 py-2 bg-white"
            >
              <option value="">Assign Class Teacher</option>
              {teachers.map((tr) => (
                <option key={tr.id} value={tr.id}>{tr.name}</option>
              ))}
            </select>
            <div className="flex justify-end gap-2 pt-2">
              <button type="button" onClick={() => setShowAddClass(false)} className="px-4 py-2 rounded-xl border border-slate-200 cursor-pointer">
                {t(lang, 'cancel')}
              </button>
              <button type="submit" className="px-4 py-2 rounded-xl bg-emerald-800 text-white font-semibold cursor-pointer">
                {t(lang, 'save')}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Add Subject Modal */}
      {showAddSubject && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <form onSubmit={handleCreateSubject} className="bg-white rounded-2xl max-w-md w-full p-6 space-y-3 text-xs">
            <h3 className="font-display text-lg font-bold text-slate-950">Add Subject</h3>
            <input
              type="text"
              required
              placeholder="Subject Name"
              value={subjectForm.name}
              onChange={(e) => setSubjectForm({ ...subjectForm, name: e.target.value })}
              className="w-full rounded-xl border border-slate-200 px-3 py-2"
            />
            <div className="grid grid-cols-2 gap-2">
              <input
                type="text"
                required
                placeholder="Code (e.g. ARB-201)"
                value={subjectForm.code}
                onChange={(e) => setSubjectForm({ ...subjectForm, code: e.target.value })}
                className="rounded-xl border border-slate-200 px-3 py-2"
              />
              <select
                value={subjectForm.category}
                onChange={(e) => setSubjectForm({ ...subjectForm, category: e.target.value })}
                className="rounded-xl border border-slate-200 px-3 py-2 bg-white"
              >
                <option value="Deeni">Deeni</option>
                <option value="General">General</option>
                <option value="Language">Language</option>
              </select>
            </div>
            <select
              value={subjectForm.classId}
              onChange={(e) => setSubjectForm({ ...subjectForm, classId: e.target.value })}
              className="w-full rounded-xl border border-slate-200 px-3 py-2 bg-white"
            >
              {classes.map((c) => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>
            <select
              value={subjectForm.teacherId}
              onChange={(e) => setSubjectForm({ ...subjectForm, teacherId: e.target.value })}
              className="w-full rounded-xl border border-slate-200 px-3 py-2 bg-white"
            >
              <option value="">Assign Teacher</option>
              {teachers.map((tr) => (
                <option key={tr.id} value={tr.id}>{tr.name}</option>
              ))}
            </select>
            <div className="flex justify-end gap-2 pt-2">
              <button type="button" onClick={() => setShowAddSubject(false)} className="px-4 py-2 rounded-xl border border-slate-200 cursor-pointer">
                {t(lang, 'cancel')}
              </button>
              <button type="submit" className="px-4 py-2 rounded-xl bg-emerald-800 text-white font-semibold cursor-pointer">
                {t(lang, 'save')}
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
