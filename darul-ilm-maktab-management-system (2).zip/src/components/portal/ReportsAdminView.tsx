import React, { useEffect, useState } from 'react';
import { Download, Plus, Shield, Sliders, Trash2 } from 'lucide-react';
import { useAuth } from '../../context/AuthContext.tsx';
import { t } from '../../i18n/translations.ts';
import { exportToExcel, exportToPdf } from '../../utils/exports.ts';

export const ReportsAdminView: React.FC<{ initialTab?: 'reports' | 'admin' }> = ({ initialTab = 'reports' }) => {
  const { user, lang, apiFetch } = useAuth();
  const [tab, setTab] = useState<'reports' | 'admin'>(initialTab);
  const [adminSub, setAdminSub] = useState<
    'users' | 'admissions' | 'notices' | 'policies' | 'roles' | 'settings' | 'audit'
  >('users');
  const [notice, setNotice] = useState<string | null>(null);

  // Reports consolidated student filter
  const [reportStudents, setReportStudents] = useState<any[]>([]);
  const [selectedStudentId, setSelectedStudentId] = useState<string>('');
  const [consolidatedRange, setConsolidatedRange] = useState<'daily' | 'weekly' | 'monthly'>('daily');
  const [consolidatedDate, setConsolidatedDate] = useState(new Date().toISOString().slice(0, 10));

  // Admin datasets
  const [usersList, setUsersList] = useState<any[]>([]);
  const [admissionsList, setAdmissionsList] = useState<any[]>([]);
  const [rolesList, setRolesList] = useState<any[]>([]);
  const [auditList, setAuditList] = useState<any[]>([]);
  const [noticesList, setNoticesList] = useState<any[]>([]);
  const [settings, setSettings] = useState<Record<string, string>>({});
  const [policy, setPolicy] = useState<any>({
    prayerTrackingEnabled: true,
    prayerShowToParents: true,
    prayerStaffRoles: ['admin', 'teacher'],
    prayerPolicyNote: '',
    customActivities: [],
    urgentHealthProtocol: '',
  });
  const [newActivityItem, setNewActivityItem] = useState('');

  // Forms
  const [newUser, setNewUser] = useState({ name: '', email: '', password: '', role: 'teacher', phone: '', specialization: '', qualification: '' });
  const [newNotice, setNewNotice] = useState({ title: '', content: '', category: 'General', isPinned: true });

  const loadReportStudents = async () => {
    try {
      const sts = await apiFetch('/api/students');
      setReportStudents(sts || []);
      if ((sts || []).length > 0 && !selectedStudentId) {
        setSelectedStudentId(String(sts[0].id));
      }
    } catch {
      // ignore
    }
  };

  const loadAdminData = async () => {
    if (user?.role !== 'admin') return;
    const [us, adm, rl, aud, ntc, stg, pol] = await Promise.all([
      apiFetch('/api/users'),
      apiFetch('/api/admissions'),
      apiFetch('/api/roles'),
      apiFetch('/api/audit-logs'),
      apiFetch('/api/notices'),
      apiFetch('/api/settings'),
      apiFetch('/api/institution-policy'),
    ]);
    setUsersList(us);
    setAdmissionsList(adm);
    setRolesList(rl);
    setAuditList(aud);
    setNoticesList(ntc || []);
    setSettings(stg || {});
    if (pol) setPolicy(pol);
  };

  useEffect(() => {
    setTab(initialTab);
  }, [initialTab]);

  useEffect(() => {
    loadReportStudents();
    loadAdminData();
  }, [user?.role, user?.institutionId]);

  const runConsolidatedReport = async () => {
    if (!selectedStudentId) return;
    const rep = await apiFetch(
      `/api/daily-report?studentId=${selectedStudentId}&date=${consolidatedDate}&range=${consolidatedRange}`
    );
    const st = rep.student;
    const rows: any[][] = [];
    for (const a of rep.attendance || []) {
      rows.push([a.date, 'Attendance', t(lang, a.status), a.remarks || '—']);
    }
    for (const n of rep.namaz || []) {
      rows.push([
        n.date,
        'Five-Times Namaz',
        `F:${t(lang, n.fajr)} | Z:${t(lang, n.zuhr)} | A:${t(lang, n.asr)} | M:${t(lang, n.maghrib)} | I:${t(lang, n.isha)}`,
        n.remarks || n.notes || '—',
      ]);
    }
    for (const d of rep.activities || []) {
      rows.push([
        d.date,
        '5-Time Meals & Daily Care',
        `B:${t(lang, d.breakfastStatus)} | L:${t(lang, d.lunchStatus)} | E:${t(lang, d.eveningMealStatus || 'not_recorded')} | D:${t(lang, d.dinnerStatus)} | O:${t(lang, d.otherMealStatus || 'not_recorded')}`,
        d.teacherRemarks || d.deeniActivities || '—',
      ]);
    }
    for (const h of rep.health || []) {
      rows.push([h.recordDate, 'Health Observation (Restricted)', t(lang, h.healthStatus), h.illnessInfo || '—']);
    }
    exportToPdf({
      title: `Consolidated Student Report (${consolidatedRange.toUpperCase()}) — ${st.fullName}`,
      subtitle: `Admission No: ${st.admissionNo} · Range: ${rep.startDate} to ${rep.endDate}`,
      headers: ['Date', 'Section', 'Summary', 'Remarks'],
      rows: rows.length > 0 ? rows : [[consolidatedDate, 'Status', 'No entries recorded in range', 'Unmarked entries remain Not Recorded']],
      filename: `consolidated-${st.admissionNo}-${consolidatedDate}`,
    });
    setNotice(`Consolidated ${consolidatedRange} PDF generated for ${st.fullName}.`);
  };

  // Real Report Generators
  const runReportExport = async (
    type: 'attendance' | 'monthly_attendance' | 'namaz' | 'academic' | 'health' | 'daily' | 'fees' | 'teachers',
    format: 'pdf' | 'excel'
  ) => {
    const [students, classes] = await Promise.all([apiFetch('/api/students'), apiFetch('/api/classes')]);
    const stMap = new Map(students.map((s: any) => [s.id, s.fullName]));
    const clMap = new Map(classes.map((c: any) => [c.id, c.name]));

    let title = '';
    let headers: string[] = [];
    let rows: any[][] = [];

    if (type === 'attendance' || type === 'monthly_attendance') {
      const att = await apiFetch('/api/attendance');
      title = type === 'attendance' ? 'Daily Attendance Report' : 'Monthly Attendance Summary Report';
      headers = ['Date', 'Student', 'Class', 'Status', 'Remarks'];
      rows = att.map((a: any) => [a.date, stMap.get(a.studentId) || a.studentId, clMap.get(a.classId) || a.classId, a.status, a.remarks || '']);
    } else if (type === 'namaz') {
      const nmz = await apiFetch('/api/namaz');
      title = 'Five-Times Namaz Monitoring Report';
      headers = ['Date', 'Student', 'Fajr', 'Zuhr', 'Asr', 'Maghrib', 'Isha'];
      rows = nmz.map((n: any) => [n.date, stMap.get(n.studentId) || n.studentId, n.fajr, n.zuhr, n.asr, n.maghrib, n.isha]);
    } else if (type === 'academic') {
      const ex = await apiFetch('/api/exams');
      title = 'Academic Performance Report';
      headers = ['Student', 'Exam ID', 'Obtained', 'Total', 'Grade', 'Remarks'];
      rows = (ex.marks || []).map((m: any) => [stMap.get(m.studentId) || m.studentId, m.examId, m.obtainedMarks, m.totalMarks, m.grade, m.remarks || '']);
    } else if (type === 'health') {
      const hl = await apiFetch('/api/health');
      title = 'Student Health & Wellness Report (Confidential)';
      headers = ['Date', 'Student', 'Weight (kg)', 'Temp (°C)', 'Status', 'Notes'];
      rows = hl.map((h: any) => [h.recordDate, stMap.get(h.studentId) || h.studentId, h.weightKg || '', h.temperatureC || '', h.healthStatus, h.illnessInfo || '']);
    } else if (type === 'daily') {
      const da = await apiFetch('/api/daily-activities');
      title = '5-Time Meals & Daily Care Report';
      headers = ['Date', 'Student', 'Breakfast', 'Lunch', 'Evening', 'Dinner', 'Other', 'HW Done', 'Discipline'];
      rows = da.map((d: any) => [d.date, stMap.get(d.studentId) || d.studentId, d.breakfastStatus, d.lunchStatus, d.eveningMealStatus || 'not_recorded', d.dinnerStatus, d.otherMealStatus || 'not_recorded', d.homeworkCompleted ? 'Yes' : 'No', `${d.disciplineRating}/5`]);
    } else if (type === 'fees') {
      const fData = await apiFetch('/api/fees');
      title = 'Maktab Fee Collection Report';
      headers = ['Student', 'Month', 'Title', 'Amount (INR)', 'Due Date', 'Status'];
      rows = (fData.fees || []).map((f: any) => [stMap.get(f.studentId) || f.studentId, f.monthYear, f.title, f.amount, f.dueDate, f.status]);
    } else if (type === 'teachers') {
      const us = await apiFetch('/api/users');
      const trs = us.filter((u: any) => u.role === 'teacher');
      title = 'Teachers & Asatizah Directory Report';
      headers = ['Name', 'Specialization', 'Qualification'];
      rows = trs.map((tr: any) => [tr.name, tr.specialization || '', tr.qualification || '']);
    }

    if (format === 'pdf') {
      exportToPdf({ title, headers, rows, filename: `maktab-${type}-report` });
    } else {
      exportToExcel({ sheetName: title.slice(0, 28), headers, rows, filename: `maktab-${type}-report` });
    }
    setNotice(`${title} exported as ${format.toUpperCase()}.`);
  };

  const handleSavePolicies = async (e: React.FormEvent) => {
    e.preventDefault();
    const updated = await apiFetch('/api/institution-policy', {
      method: 'PUT',
      body: JSON.stringify(policy),
    });
    setPolicy(updated);
    setNotice('Institution prayer privacy rules & customizable daily activity checklist saved.');
  };

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    await apiFetch('/api/users', { method: 'POST', body: JSON.stringify(newUser) });
    setNewUser({ name: '', email: '', password: '', role: 'teacher', phone: '', specialization: '', qualification: '' });
    setNotice('User account created.');
    loadAdminData();
  };

  const handleUpdateAdmission = async (id: number, status: string) => {
    await apiFetch(`/api/admissions/${id}`, { method: 'PATCH', body: JSON.stringify({ status }) });
    loadAdminData();
  };

  const handleCreateNotice = async (e: React.FormEvent) => {
    e.preventDefault();
    await apiFetch('/api/notices', { method: 'POST', body: JSON.stringify(newNotice) });
    setNewNotice({ title: '', content: '', category: 'General', isPinned: true });
    loadAdminData();
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    await apiFetch('/api/settings', { method: 'PUT', body: JSON.stringify(settings) });
    setNotice('Public website settings updated in PostgreSQL.');
  };

  const handleClearDemo = async () => {
    await apiFetch('/api/admin/demo-data', { method: 'DELETE' });
    setNotice('Sample demonstration records cleared while retaining production data.');
    loadAdminData();
  };

  const allReportCards = [
    { id: 'attendance', title: 'Daily Attendance Report', desc: 'Date-wise presence, late arrivals, leave, and absences.', roles: ['admin', 'teacher', 'parent'] },
    { id: 'monthly_attendance', title: 'Monthly Attendance Report', desc: 'Full monthly attendance ledger across cohorts.', roles: ['admin', 'teacher', 'parent'] },
    { id: 'namaz', title: 'Five-Times Namaz Report', desc: 'Fajr, Zuhr, Asr, Maghrib, and Isha tracking without false penalties.', roles: ['admin', 'teacher', 'parent'] },
    { id: 'academic', title: 'Academic Performance Report', desc: 'Examination scores, percentages, grades, and evaluator remarks.', roles: ['admin', 'teacher', 'parent'] },
    { id: 'health', title: 'Student Health Report', desc: 'Confidential vitals, allergies, and medical notes.', roles: ['admin', 'teacher', 'parent'] },
    { id: 'daily', title: '5-Meal & Daily Care Report', desc: 'All 5 meals, homework, discipline, and custom activity logs.', roles: ['admin', 'teacher', 'parent'] },
    { id: 'fees', title: 'Fee & Revenue Report', desc: 'Paid vs pending monthly invoices and collection status.', roles: ['admin', 'parent'] },
    { id: 'teachers', title: 'Teacher Faculty Report', desc: 'Active Asatizah specializations and qualifications.', roles: ['admin'] },
  ] as const;

  const reportCards = allReportCards.filter((rc) => rc.roles.includes((user?.role as any) || 'parent'));

  if (user?.role === 'student') {
    return (
      <div className="bg-white border border-emerald-900/10 rounded-2xl p-8 text-center text-xs text-slate-600">
        Institutional reports and administration controls are restricted to Maktab Administrators.
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-1 p-1 bg-white border border-emerald-900/10 rounded-xl self-start inline-flex">
        <button
          type="button"
          onClick={() => setTab('reports')}
          className={`px-4 py-2 text-xs font-semibold rounded-lg cursor-pointer ${
            tab === 'reports' ? 'bg-emerald-800 text-white' : 'text-slate-600'
          }`}
        >
          Reports & Analytics (PDF / Excel)
        </button>
        {user?.role === 'admin' && (
          <button
            type="button"
            onClick={() => setTab('admin')}
            className={`px-4 py-2 text-xs font-semibold rounded-lg cursor-pointer ${
              tab === 'admin' ? 'bg-emerald-800 text-white' : 'text-slate-600'
            }`}
          >
            Admin Controls & Policies
          </button>
        )}
      </div>

      {notice && (
        <div className="rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-2.5 text-xs text-emerald-900">
          {notice}
        </div>
      )}

      {tab === 'reports' ? (
        <div className="space-y-6">
          {/* Consolidated Student Dossier Export Card */}
          <div className="bg-white border border-emerald-900/12 rounded-2xl p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
            <div>
              <h2 className="font-display font-bold text-slate-950 text-base">Consolidated Student Report (Parent / Guardian Dossier)</h2>
              <p className="text-xs text-slate-600 mt-0.5">
                Compile Attendance, Five-Times Namaz, 5 Meals, Health notes, and Remarks for a student across Daily, Weekly, or Monthly periods.
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-2 text-xs">
              <select
                value={selectedStudentId}
                onChange={(e) => setSelectedStudentId(e.target.value)}
                className="rounded-xl border border-slate-200 px-3 py-2 bg-white"
              >
                {reportStudents.map((s) => (
                  <option key={s.id} value={String(s.id)}>{s.fullName} ({s.admissionNo})</option>
                ))}
              </select>
              <input
                type="date"
                value={consolidatedDate}
                onChange={(e) => setConsolidatedDate(e.target.value)}
                className="rounded-xl border border-slate-200 px-3 py-2 font-mono-num"
              />
              <select
                value={consolidatedRange}
                onChange={(e) => setConsolidatedRange(e.target.value as any)}
                className="rounded-xl border border-slate-200 px-3 py-2 bg-white"
              >
                <option value="daily">Daily</option>
                <option value="weekly">Weekly</option>
                <option value="monthly">Monthly</option>
              </select>
              <button
                type="button"
                disabled={!selectedStudentId}
                onClick={runConsolidatedReport}
                className="px-4 py-2 rounded-xl bg-emerald-800 hover:bg-emerald-900 text-white font-semibold inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
              >
                <Download className="h-3.5 w-3.5" />
                <span>Consolidated PDF</span>
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {reportCards.map((rc) => (
              <div key={rc.id} className="bg-white border border-emerald-900/10 rounded-2xl p-5 flex flex-col justify-between gap-4">
                <div>
                  <h3 className="font-display font-bold text-slate-950 text-sm">{rc.title}</h3>
                  <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">{rc.desc}</p>
                </div>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => runReportExport(rc.id, 'pdf')}
                    className="flex-1 py-2 px-2.5 rounded-xl bg-emerald-800 hover:bg-emerald-900 text-white text-[11px] font-semibold inline-flex items-center justify-center gap-1 cursor-pointer"
                  >
                    <Download className="h-3 w-3" />
                    <span>{t(lang, 'exportPdf')}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => runReportExport(rc.id, 'excel')}
                    className="flex-1 py-2 px-2.5 rounded-xl border border-emerald-800 text-emerald-900 hover:bg-emerald-50 text-[11px] font-semibold inline-flex items-center justify-center gap-1 cursor-pointer"
                  >
                    <Download className="h-3 w-3" />
                    <span>{t(lang, 'exportExcel')}</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <div className="space-y-6">
          <div className="flex flex-wrap items-center gap-1 p-1 bg-white border border-emerald-900/10 rounded-xl self-start inline-flex">
            {(
              [
                ['users', 'Teachers & Parents'],
                ['admissions', 'Admissions'],
                ['notices', 'Notice Board'],
                ['policies', 'Policies & Activities'],
                ['roles', 'Roles & RBAC'],
                ['settings', 'Website Settings'],
                ['audit', 'Audit Logs'],
              ] as const
            ).map(([k, label]) => (
              <button
                key={k}
                type="button"
                onClick={() => setAdminSub(k)}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg cursor-pointer whitespace-nowrap ${
                  adminSub === k ? 'bg-emerald-800 text-white' : 'text-slate-600'
                }`}
              >
                {label}
              </button>
            ))}
          </div>

          {adminSub === 'policies' && (
            <form onSubmit={handleSavePolicies} className="bg-white border border-emerald-900/10 rounded-2xl p-6 space-y-5 text-xs">
              <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
                <Sliders className="h-4 w-4 text-emerald-800" />
                <h3 className="font-display text-base font-bold text-slate-950">
                  Prayer Privacy Rules, Urgent Health Protocol & Custom Daily Activities
                </h3>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <label className="p-3.5 rounded-xl border border-slate-200 flex items-center justify-between gap-3 cursor-pointer">
                  <div>
                    <div className="font-semibold text-slate-900">Enable Five-Times Prayer Monitoring</div>
                    <div className="text-[11px] text-slate-500">Allow authorized staff to log Fajr–Isha privately</div>
                  </div>
                  <input
                    type="checkbox"
                    checked={Boolean(policy.prayerTrackingEnabled)}
                    onChange={(e) => setPolicy({ ...policy, prayerTrackingEnabled: e.target.checked })}
                    className="h-4 w-4 accent-emerald-800"
                  />
                </label>

                <label className="p-3.5 rounded-xl border border-slate-200 flex items-center justify-between gap-3 cursor-pointer">
                  <div>
                    <div className="font-semibold text-slate-900">Show Prayer Logs to Linked Parents</div>
                    <div className="text-[11px] text-slate-500">Unmarked entries remain Not Recorded without penalty</div>
                  </div>
                  <input
                    type="checkbox"
                    checked={Boolean(policy.prayerShowToParents)}
                    onChange={(e) => setPolicy({ ...policy, prayerShowToParents: e.target.checked })}
                    className="h-4 w-4 accent-emerald-800"
                  />
                </label>
              </div>

              <div>
                <label className="block font-semibold text-slate-800 mb-1">Prayer Policy Banner Note</label>
                <input
                  type="text"
                  value={policy.prayerPolicyNote || ''}
                  onChange={(e) => setPolicy({ ...policy, prayerPolicyNote: e.target.value })}
                  className="w-full rounded-xl border border-slate-200 px-3 py-2"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-800 mb-1">Urgent Health Escalation Protocol</label>
                <input
                  type="text"
                  value={policy.urgentHealthProtocol || ''}
                  onChange={(e) => setPolicy({ ...policy, urgentHealthProtocol: e.target.value })}
                  className="w-full rounded-xl border border-slate-200 px-3 py-2"
                />
              </div>

              <div className="space-y-2.5">
                <label className="block font-semibold text-slate-800">Customizable Institution Daily Activity List</label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="Add custom activity (e.g. Evening Sabaq Revision)..."
                    value={newActivityItem}
                    onChange={(e) => setNewActivityItem(e.target.value)}
                    className="flex-1 rounded-xl border border-slate-200 px-3 py-2"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      if (!newActivityItem.trim()) return;
                      setPolicy({
                        ...policy,
                        customActivities: [...(policy.customActivities || []), newActivityItem.trim()],
                      });
                      setNewActivityItem('');
                    }}
                    className="px-4 py-2 rounded-xl border border-emerald-800 text-emerald-900 font-semibold cursor-pointer"
                  >
                    + Add Activity
                  </button>
                </div>
                <div className="space-y-1.5">
                  {(policy.customActivities || []).map((act: string, idx: number) => (
                    <div key={`${act}-${idx}`} className="flex items-center justify-between p-2.5 rounded-xl border border-slate-200 bg-[#FAFBF9]">
                      <span className="font-medium text-slate-800">{act}</span>
                      <button
                        type="button"
                        onClick={() =>
                          setPolicy({
                            ...policy,
                            customActivities: (policy.customActivities || []).filter((_: string, i: number) => i !== idx),
                          })
                        }
                        className="p-1 text-slate-400 hover:text-red-600 cursor-pointer"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              <button type="submit" className="px-5 py-2.5 rounded-xl bg-emerald-800 hover:bg-emerald-900 text-white font-semibold cursor-pointer">
                {t(lang, 'save')}
              </button>
            </form>
          )}

          {adminSub === 'users' && (
            <div className="space-y-6">
              <form onSubmit={handleCreateUser} className="bg-white border border-emerald-900/10 rounded-2xl p-6 space-y-3 text-xs">
                <h3 className="font-display text-base font-bold text-slate-950">Register Teacher / Parent / Staff</h3>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <input
                    type="text"
                    required
                    placeholder="Full Name *"
                    value={newUser.name}
                    onChange={(e) => setNewUser({ ...newUser, name: e.target.value })}
                    className="rounded-xl border border-slate-200 px-3 py-2"
                  />
                  <input
                    type="email"
                    required
                    placeholder="Email *"
                    value={newUser.email}
                    onChange={(e) => setNewUser({ ...newUser, email: e.target.value })}
                    className="rounded-xl border border-slate-200 px-3 py-2"
                  />
                  <select
                    value={newUser.role}
                    onChange={(e) => setNewUser({ ...newUser, role: e.target.value })}
                    className="rounded-xl border border-slate-200 px-3 py-2 bg-white"
                  >
                    <option value="teacher">Teacher (Ustad)</option>
                    <option value="parent">Parent (Wali)</option>
                    <option value="student">Student</option>
                    <option value="admin">Admin</option>
                  </select>
                  <input
                    type="password"
                    placeholder="Password (default Maktab@2026)"
                    value={newUser.password}
                    onChange={(e) => setNewUser({ ...newUser, password: e.target.value })}
                    className="rounded-xl border border-slate-200 px-3 py-2"
                  />
                  <input
                    type="text"
                    placeholder="Specialization (if teacher)"
                    value={newUser.specialization}
                    onChange={(e) => setNewUser({ ...newUser, specialization: e.target.value })}
                    className="rounded-xl border border-slate-200 px-3 py-2"
                  />
                  <input
                    type="text"
                    placeholder="Phone"
                    value={newUser.phone}
                    onChange={(e) => setNewUser({ ...newUser, phone: e.target.value })}
                    className="rounded-xl border border-slate-200 px-3 py-2"
                  />
                </div>
                <button type="submit" className="px-4 py-2 rounded-xl bg-emerald-800 text-white font-semibold inline-flex items-center gap-1.5 cursor-pointer">
                  <Plus className="h-4 w-4" />
                  <span>Create Account</span>
                </button>
              </form>

              <div className="bg-white border border-emerald-900/10 rounded-2xl overflow-hidden">
                <table className="w-full text-start border-collapse text-xs">
                  <thead>
                    <tr className="border-b border-slate-100 bg-slate-50/70 text-[11px] font-semibold text-slate-500">
                      <th className="py-3 px-4 text-start">Name</th>
                      <th className="py-3 px-4 text-start">Email</th>
                      <th className="py-3 px-4 text-start">Role</th>
                      <th className="py-3 px-4 text-start">Status</th>
                      <th className="py-3 px-4 text-end">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {usersList.map((u) => (
                      <tr key={u.id}>
                        <td className="py-3 px-4 font-semibold text-slate-900">{u.name}</td>
                        <td className="py-3 px-4 text-slate-600">{u.email}</td>
                        <td className="py-3 px-4 font-semibold uppercase text-emerald-800">{u.role}</td>
                        <td className="py-3 px-4 text-slate-600">
                          {u.isActive ? 'Active' : 'Disabled'} {u.isDemo ? '· Demo' : ''}
                        </td>
                        <td className="py-3 px-4 text-end">
                          {u.id !== user?.id && (
                            <button
                              type="button"
                              onClick={async () => {
                                await apiFetch(`/api/users/${u.id}`, { method: 'DELETE' });
                                loadAdminData();
                              }}
                              className="p-1 text-slate-400 hover:text-red-600 cursor-pointer"
                            >
                              <Trash2 className="h-4 w-4" />
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {adminSub === 'admissions' && (
            <div className="bg-white border border-emerald-900/10 rounded-2xl overflow-hidden">
              <table className="w-full text-start border-collapse text-xs">
                <thead>
                  <tr className="border-b border-slate-100 bg-slate-50/70 text-[11px] font-semibold text-slate-500">
                    <th className="py-3 px-4 text-start">Applicant</th>
                    <th className="py-3 px-4 text-start">Desired Class</th>
                    <th className="py-3 px-4 text-start">Guardian & Phone</th>
                    <th className="py-3 px-4 text-start">Status</th>
                    <th className="py-3 px-4 text-end">Decision</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {admissionsList.length === 0 ? (
                    <tr><td colSpan={5} className="py-6 text-center text-slate-500">No online admission applications yet.</td></tr>
                  ) : (
                    admissionsList.map((a) => (
                      <tr key={a.id}>
                        <td className="py-3 px-4 font-semibold text-slate-900">{a.applicantName} (DOB: {a.dob})</td>
                        <td className="py-3 px-4 text-slate-700">{a.desiredClass}</td>
                        <td className="py-3 px-4 text-slate-600">{a.guardianName} · {a.guardianPhone}</td>
                        <td className="py-3 px-4 font-semibold uppercase text-amber-700">{a.status}</td>
                        <td className="py-3 px-4 text-end space-x-2">
                          <button type="button" onClick={() => handleUpdateAdmission(a.id, 'accepted')} className="px-2.5 py-1 rounded bg-emerald-800 text-white cursor-pointer">
                            Accept
                          </button>
                          <button type="button" onClick={() => handleUpdateAdmission(a.id, 'rejected')} className="px-2.5 py-1 rounded border border-red-200 text-red-700 cursor-pointer">
                            Reject
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          )}

          {adminSub === 'notices' && (
            <div className="space-y-4">
              <form onSubmit={handleCreateNotice} className="bg-white border border-emerald-900/10 rounded-2xl p-6 space-y-3 text-xs">
                <h3 className="font-display text-base font-bold text-slate-950">Publish Public Notice</h3>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <input
                    type="text"
                    required
                    placeholder="Notice Title"
                    value={newNotice.title}
                    onChange={(e) => setNewNotice({ ...newNotice, title: e.target.value })}
                    className="sm:col-span-2 rounded-xl border border-slate-200 px-3 py-2"
                  />
                  <select
                    value={newNotice.category}
                    onChange={(e) => setNewNotice({ ...newNotice, category: e.target.value })}
                    className="rounded-xl border border-slate-200 px-3 py-2 bg-white"
                  >
                    <option value="General">General</option>
                    <option value="Admission">Admission</option>
                    <option value="Schedule">Schedule</option>
                    <option value="Event">Event</option>
                  </select>
                </div>
                <textarea
                  required
                  rows={2}
                  placeholder="Notice content..."
                  value={newNotice.content}
                  onChange={(e) => setNewNotice({ ...newNotice, content: e.target.value })}
                  className="w-full rounded-xl border border-slate-200 px-3 py-2"
                />
                <button type="submit" className="px-4 py-2 rounded-xl bg-emerald-800 text-white font-semibold cursor-pointer">
                  Publish to Website
                </button>
              </form>

              <div className="space-y-2">
                {noticesList.map((n) => (
                  <div key={n.id} className="bg-white border border-emerald-900/10 rounded-xl p-4 flex items-center justify-between text-xs">
                    <div>
                      <div className="font-bold text-slate-900">{n.title}</div>
                      <div className="text-slate-600 mt-0.5">{n.content}</div>
                    </div>
                    <button
                      type="button"
                      onClick={async () => {
                        await apiFetch(`/api/notices/${n.id}`, { method: 'DELETE' });
                        loadAdminData();
                      }}
                      className="p-1.5 text-slate-400 hover:text-red-600 cursor-pointer"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {adminSub === 'roles' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {rolesList.map((r) => (
                <div key={r.id} className="bg-white border border-emerald-900/10 rounded-2xl p-5 space-y-2">
                  <div className="flex items-center justify-between">
                    <h3 className="font-display font-bold text-slate-950 text-base">{r.displayName}</h3>
                    <Shield className="h-4 w-4 text-emerald-800" />
                  </div>
                  <p className="text-xs text-slate-600">{r.description}</p>
                  <div className="text-[11px] font-mono-num text-emerald-900 pt-2">
                    {(r.permissions || []).join(' · ')}
                  </div>
                </div>
              ))}
            </div>
          )}

          {adminSub === 'settings' && (
            <div className="space-y-4">
              <form onSubmit={handleSaveSettings} className="bg-white border border-emerald-900/10 rounded-2xl p-6 space-y-3 text-xs">
                <h3 className="font-display text-base font-bold text-slate-950">Website & Institution Settings</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {Object.entries(settings).map(([k, v]) => (
                    <div key={k}>
                      <label className="block font-semibold text-slate-700 mb-1">{k}</label>
                      <input
                        type="text"
                        value={v}
                        onChange={(e) => setSettings({ ...settings, [k]: e.target.value })}
                        className="w-full rounded-xl border border-slate-200 px-3 py-2"
                      />
                    </div>
                  ))}
                </div>
                <div className="flex items-center justify-between pt-2">
                  <button type="submit" className="px-4 py-2 rounded-xl bg-emerald-800 text-white font-semibold cursor-pointer">
                    Save Website Settings
                  </button>
                  <button
                    type="button"
                    onClick={handleClearDemo}
                    className="px-4 py-2 rounded-xl border border-red-200 text-red-700 hover:bg-red-50 font-semibold cursor-pointer"
                  >
                    Clear Sample Demo Data
                  </button>
                </div>
              </form>
            </div>
          )}

          {adminSub === 'audit' && (
            <div className="bg-white border border-emerald-900/10 rounded-2xl overflow-hidden">
              <table className="w-full text-start border-collapse text-xs">
                <thead>
                  <tr className="border-b border-slate-100 bg-slate-50/70 text-[11px] font-semibold text-slate-500">
                    <th className="py-3 px-4 text-start">Timestamp</th>
                    <th className="py-3 px-4 text-start">Actor</th>
                    <th className="py-3 px-4 text-start">Action</th>
                    <th className="py-3 px-4 text-start">Details</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {auditList.map((log) => (
                    <tr key={log.id}>
                      <td className="py-2.5 px-4 font-mono-num text-slate-500">
                        {new Date(log.createdAt).toLocaleString()}
                      </td>
                      <td className="py-2.5 px-4 text-slate-800">{log.userEmail}</td>
                      <td className="py-2.5 px-4 font-semibold text-emerald-900">{log.action}</td>
                      <td className="py-2.5 px-4 text-slate-600">{log.details}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
