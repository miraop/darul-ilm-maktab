import React, { useEffect, useState } from 'react';
import {
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
  AreaChart,
  Area,
} from 'recharts';
import { Bell, CheckCircle2, CreditCard, Download, MessageSquare, Send, ShieldAlert, UserCheck } from 'lucide-react';
import { useAuth } from '../../context/AuthContext.tsx';
import { t } from '../../i18n/translations.ts';
import { exportToPdf } from '../../utils/exports.ts';

export const DashboardOverview: React.FC<{ onNavigate: (tab: string) => void }> = ({ onNavigate }) => {
  const { user, lang, apiFetch, linkedStudents, assignedClasses } = useAuth();
  const [data, setData] = useState<any>(null);
  const [subjects, setSubjects] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Parent Child Monitoring Dashboard state
  const [selectedChildId, setSelectedChildId] = useState<number | null>(null);
  const [reportDate, setReportDate] = useState(new Date().toISOString().slice(0, 10));
  const [reportRange, setReportRange] = useState<'daily' | 'weekly' | 'monthly'>('daily');
  const [childReport, setChildReport] = useState<any>(null);
  const [loadingReport, setLoadingReport] = useState(false);

  // Quick announcement state for Admin/Teacher
  const [notifTitle, setNotifTitle] = useState('');
  const [notifMsg, setNotifMsg] = useState('');
  const [notifTarget, setNotifTarget] = useState('all');
  const [sending, setSending] = useState(false);

  const loadData = async () => {
    setLoading(true);
    setError(null);
    try {
      const [dash, subs] = await Promise.all([apiFetch('/api/dashboard'), apiFetch('/api/subjects')]);
      setData(dash);
      setSubjects(subs);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    if (linkedStudents.length > 0 && !selectedChildId) {
      setSelectedChildId(linkedStudents[0].id);
    }
  }, [linkedStudents]);

  useEffect(() => {
    const fetchChildReport = async () => {
      if (user?.role !== 'parent' || !selectedChildId) return;
      setLoadingReport(true);
      try {
        const res = await apiFetch(
          `/api/daily-report?studentId=${selectedChildId}&date=${reportDate}&range=${reportRange}`
        );
        setChildReport(res);
      } catch {
        setChildReport(null);
      } finally {
        setLoadingReport(false);
      }
    };
    fetchChildReport();
  }, [user?.role, selectedChildId, reportDate, reportRange]);

  const handleMarkRead = async (id: number) => {
    try {
      await apiFetch(`/api/notifications/${id}/read`, { method: 'PATCH' });
      setData((prev: any) => ({
        ...prev,
        notifications: prev.notifications.map((n: any) => (n.id === id ? { ...n, isRead: true } : n)),
      }));
    } catch {
      // ignore
    }
  };

  const handleSendNotification = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!notifTitle || !notifMsg) return;
    setSending(true);
    try {
      const created = await apiFetch('/api/notifications', {
        method: 'POST',
        body: JSON.stringify({
          title: notifTitle,
          message: notifMsg,
          type: 'announcement',
          targetRole: notifTarget,
        }),
      });
      setData((prev: any) => ({
        ...prev,
        notifications: [created, ...(prev?.notifications || [])],
      }));
      setNotifTitle('');
      setNotifMsg('');
    } catch {
      // ignore
    } finally {
      setSending(false);
    }
  };

  const handleExportConsolidatedPdf = () => {
    if (!childReport?.student) return;
    const st = childReport.student;
    const rows: any[][] = [];

    for (const a of childReport.attendance || []) {
      rows.push([a.date, 'Attendance', t(lang, a.status), a.remarks || '—']);
    }
    for (const n of childReport.namaz || []) {
      const summary = `Fajr: ${t(lang, n.fajr)}, Zuhr: ${t(lang, n.zuhr)}, Asr: ${t(lang, n.asr)}, Maghrib: ${t(lang, n.maghrib)}, Isha: ${t(lang, n.isha)}`;
      rows.push([n.date, 'Five-Times Namaz', summary, n.remarks || n.notes || 'Unmarked stays Not Recorded']);
    }
    for (const d of childReport.activities || []) {
      const meals = `B:${t(lang, d.breakfastStatus)} | L:${t(lang, d.lunchStatus)} | E:${t(lang, d.eveningMealStatus || 'not_recorded')} | D:${t(lang, d.dinnerStatus)} | O:${t(lang, d.otherMealStatus || 'not_recorded')}`;
      rows.push([d.date, 'Meals & Daily Activity', meals, d.teacherRemarks || d.deeniActivities || '—']);
    }
    for (const h of childReport.health || []) {
      rows.push([h.recordDate, 'Health Note (Restricted)', t(lang, h.healthStatus), h.illnessInfo || h.parentUpdateNotes || '—']);
    }

    exportToPdf({
      title: `Consolidated Student Report (${reportRange.toUpperCase()}) — ${st.fullName}`,
      subtitle: `Admission No: ${st.admissionNo} · Range: ${childReport.startDate} to ${childReport.endDate}`,
      headers: ['Date', 'Category', 'Recorded Status / Summary', 'Remarks'],
      rows: rows.length > 0 ? rows : [[reportDate, 'Status', 'No entries recorded for this window', 'Unmarked entries remain Not Recorded']],
      filename: `student-report-${st.admissionNo}-${reportDate}`,
    });
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="h-24 rounded-xl bg-white border border-emerald-900/10 animate-pulse" />
          ))}
        </div>
        <div className="h-72 rounded-xl bg-white border border-emerald-900/10 animate-pulse" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6 rounded-xl bg-red-50 border border-red-200 text-sm text-red-800">
        {error}
      </div>
    );
  }

  const stats = data?.stats || {};
  const pa = data?.personalAnalytics || null;
  const isStudent = user?.role === 'student';

  const kpis =
    user?.role === 'admin'
      ? [
          { label: t(lang, 'totalStudents'), value: stats.totalStudents ?? 0 },
          { label: t(lang, 'totalTeachers'), value: stats.totalTeachers ?? 0 },
          { label: t(lang, 'attendanceRate'), value: `${stats.attendanceRate ?? 0}%` },
          { label: t(lang, 'pendingFees'), value: `₹${(stats.totalPendingFees ?? 0).toLocaleString()}` },
        ]
      : user?.role === 'teacher'
        ? [
            { label: 'Assigned Classes', value: assignedClasses.length },
            { label: t(lang, 'totalStudents'), value: stats.totalStudents ?? 0 },
            { label: t(lang, 'attendanceRate'), value: `${stats.attendanceRate ?? 0}%` },
            { label: t(lang, 'avgAcademic'), value: `${stats.avgAcademicScore ?? 0}%` },
          ]
        : user?.role === 'parent'
          ? [
              { label: 'Linked Children', value: linkedStudents.length },
              { label: t(lang, 'attendanceRate'), value: `${stats.attendanceRate ?? 0}%` },
              { label: t(lang, 'avgAcademic'), value: `${stats.avgAcademicScore ?? 0}%` },
              { label: t(lang, 'pendingFees'), value: `₹${(stats.totalPendingFees ?? 0).toLocaleString()}` },
            ]
          : [
              { label: 'My Attendance Rate', value: `${pa?.attendanceBreakdown?.rate ?? stats.attendanceRate ?? 0}%` },
              { label: 'My Exam Average', value: `${pa?.exams?.avgScore ?? stats.avgAcademicScore ?? 0}%` },
              { label: 'Homework Completion', value: `${pa?.homework?.completionRate ?? stats.homeworkCompletionRate ?? 0}%` },
              { label: 'Syllabus Progress', value: `${pa?.syllabus?.completionPct ?? stats.syllabusCompletionPct ?? 0}%` },
            ];

  const todayAtt = (childReport?.attendance || []).find((a: any) => a.date === reportDate);
  const todayNamaz = (childReport?.namaz || []).find((n: any) => n.date === reportDate);
  const todayActivity = (childReport?.activities || []).find((a: any) => a.date === reportDate);
  const latestHealth = (childReport?.health || [])[0];
  const pendingHwCount = (childReport?.homework || []).filter((h: any) => !h.assignment).length;
  const completedHwCount = (childReport?.homework || []).filter((h: any) => Boolean(h.assignment)).length;

  return (
    <div className="space-y-6">
      {/* Welcome Banner */}
      <div className="bg-white border border-emerald-900/12 rounded-2xl p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <p className="text-xs font-semibold text-amber-700 mb-1">
            {user?.institutionName || t(lang, 'brandName')} ·{' '}
            {user?.role === 'super_admin'
              ? t(lang, 'roleSuperAdmin')
              : t(lang, `role${(user?.role || 'parent').charAt(0).toUpperCase() + (user?.role || 'parent').slice(1)}`)}
            {user?.isDemo ? ' · Sample Demonstration Mode' : ''}
          </p>
          <h1 className="font-display text-2xl font-bold text-slate-950">
            Assalamu Alaikum, {pa?.studentProfile?.fullName || user?.name}
          </h1>
          <p className="text-sm text-slate-600 mt-1">
            {isStudent
              ? pa?.studentProfile
                ? `Student ID: ${pa.studentProfile.admissionNo} · ${pa.studentProfile.className} (Section ${pa.studentProfile.section}) · Session ${pa.studentProfile.academicSession}`
                : 'Your personal student record is not linked yet. Ask your Maktab Admin to link your admission profile.'
              : user?.role === 'parent' && linkedStudents.length > 0
                ? `Monitoring: ${linkedStudents.map((s) => s.fullName).join(', ')}`
                : user?.role === 'teacher' && assignedClasses.length > 0
                  ? `Assigned Classes: ${assignedClasses.map((c) => c.name).join(', ')}`
                  : (stats.totalStudents ?? 0) === 0 && (stats.totalClasses ?? 0) === 0
                    ? 'Fresh isolated institution workspace ready. Start by creating classes, subjects, teachers, and enrolling students.'
                    : 'Centralized Maktab operations, Namaz monitoring, and student care.'}
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          {isStudent ? (
            <>
              <button
                type="button"
                onClick={() => onNavigate('academics')}
                className="px-4 py-2 text-xs font-semibold rounded-xl bg-emerald-800 hover:bg-emerald-900 text-white cursor-pointer whitespace-nowrap"
              >
                My Academics & Tests
              </button>
              <button
                type="button"
                onClick={() => onNavigate('attendance-namaz')}
                className="px-4 py-2 text-xs font-semibold rounded-xl border border-emerald-900/20 hover:bg-emerald-50 text-emerald-900 cursor-pointer whitespace-nowrap"
              >
                My Attendance & Namaz
              </button>
            </>
          ) : (
            <>
              <button
                type="button"
                onClick={() => onNavigate('attendance-namaz')}
                className="px-4 py-2 text-xs font-semibold rounded-xl bg-emerald-800 hover:bg-emerald-900 text-white cursor-pointer whitespace-nowrap"
              >
                {t(lang, 'menuAttendanceNamaz')}
              </button>
              <button
                type="button"
                onClick={() => onNavigate('notifications')}
                className="px-4 py-2 text-xs font-semibold rounded-xl border border-emerald-900/20 hover:bg-emerald-50 text-emerald-900 cursor-pointer whitespace-nowrap"
              >
                {t(lang, 'menuNotifications')}
              </button>
              {(user?.role === 'admin' || user?.role === 'teacher' || user?.role === 'parent') && (
                <button
                  type="button"
                  onClick={() => onNavigate('reports')}
                  className="px-4 py-2 text-xs font-semibold rounded-xl border border-emerald-900/20 hover:bg-emerald-50 text-emerald-900 cursor-pointer whitespace-nowrap"
                >
                  {t(lang, 'menuReports')}
                </button>
              )}
            </>
          )}
        </div>
      </div>

      {/* KPI Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {kpis.map((kpi) => (
          <div key={kpi.label} className="bg-white border border-emerald-900/10 rounded-xl p-5">
            <div className="text-xs font-medium text-slate-500">{kpi.label}</div>
            <div className="font-mono-num text-2xl font-bold text-emerald-900 mt-1.5">{kpi.value}</div>
          </div>
        ))}
      </div>

      {/* Student Personal Analytics Summary Cards */}
      {isStudent && pa && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-7 bg-white border border-emerald-900/10 rounded-2xl p-6 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <h2 className="font-display text-lg font-bold text-slate-950">My Exam & Subject Score Analytics (%)</h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Your personal exam results across enrolled subjects (Best: {pa.exams?.bestScore ?? 0}% · Exams Taken: {pa.exams?.totalTaken ?? 0})
                </p>
              </div>
              <button
                type="button"
                onClick={() => onNavigate('academics')}
                className="text-xs font-semibold text-emerald-800 hover:underline cursor-pointer"
              >
                View Report Card
              </button>
            </div>
            {(pa.exams?.trend || []).length === 0 ? (
              <div className="h-56 flex items-center justify-center text-xs text-slate-500 border border-dashed border-slate-200 rounded-xl">
                No exam marks published for your account yet.
              </div>
            ) : (
              <div className="h-56 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={pa.exams.trend} margin={{ top: 10, right: 10, left: -15, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
                    <XAxis dataKey="subjectName" tick={{ fontSize: 11 }} />
                    <YAxis domain={[0, 100]} tick={{ fontSize: 12 }} />
                    <Tooltip />
                    <Bar dataKey="percentage" name="My Score %" fill="#047857" radius={[6, 6, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            )}
          </div>

          <div className="lg:col-span-5 bg-white border border-emerald-900/10 rounded-2xl p-6 space-y-4">
            <div>
              <h2 className="font-display text-lg font-bold text-slate-950">My Attendance & Homework Summary</h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Personal counts across {pa.attendanceBreakdown?.totalDays ?? 0} recorded school day(s)
              </p>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-2 gap-2.5 text-xs">
              <div className="p-3 rounded-xl bg-emerald-50/70 border border-emerald-200">
                <div className="text-slate-600">{t(lang, 'present')}</div>
                <div className="font-mono-num text-lg font-bold text-emerald-800 mt-0.5">
                  {pa.attendanceBreakdown?.present ?? 0}
                </div>
              </div>
              <div className="p-3 rounded-xl bg-amber-50/70 border border-amber-200">
                <div className="text-slate-600">{t(lang, 'late')}</div>
                <div className="font-mono-num text-lg font-bold text-amber-800 mt-0.5">
                  {pa.attendanceBreakdown?.late ?? 0}
                </div>
              </div>
              <div className="p-3 rounded-xl bg-red-50/70 border border-red-200">
                <div className="text-slate-600">{t(lang, 'absent')}</div>
                <div className="font-mono-num text-lg font-bold text-red-700 mt-0.5">
                  {pa.attendanceBreakdown?.absent ?? 0}
                </div>
              </div>
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                <div className="text-slate-600">{t(lang, 'leave')}</div>
                <div className="font-mono-num text-lg font-bold text-slate-700 mt-0.5">
                  {pa.attendanceBreakdown?.leave ?? 0}
                </div>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-[#FAFBF9] border border-emerald-900/10 space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-slate-800">My Homework Completion</span>
                <span className="font-mono-num font-bold text-emerald-900">
                  {pa.homework?.completed ?? 0} / {pa.homework?.total ?? 0} ({pa.homework?.completionRate ?? 0}%)
                </span>
              </div>
              <div className="h-2 rounded-full bg-slate-200 overflow-hidden">
                <div
                  className="h-full bg-emerald-700 rounded-full"
                  style={{ width: `${pa.homework?.completionRate ?? 0}%` }}
                />
              </div>
              <div className="flex items-center justify-between text-[11px] text-slate-500">
                <span>{pa.homework?.pending ?? 0} pending assignment(s)</span>
                <button
                  type="button"
                  onClick={() => onNavigate('academics')}
                  className="font-semibold text-emerald-800 hover:underline cursor-pointer"
                >
                  Open Homework
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Parent Child Monitoring Report Workspace */}
      {user?.role === 'parent' && linkedStudents.length > 0 && (
        <div className="bg-white border border-emerald-900/12 rounded-2xl p-6 space-y-5">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-100 pb-4">
            <div>
              <h2 className="font-display text-lg font-bold text-slate-950 flex items-center gap-2">
                <UserCheck className="h-4 w-4 text-emerald-800" />
                <span>{t(lang, 'parentDashboard')}</span>
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Unified Daily, Weekly & Monthly summary across Attendance, Namaz, 5 Meals, Health, Homework, Syllabus & Messages.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              {linkedStudents.length > 1 && (
                <div className="inline-flex items-center gap-1 p-1 bg-[#FAFBF9] border border-emerald-900/10 rounded-xl">
                  {linkedStudents.map((child) => (
                    <button
                      key={child.id}
                      type="button"
                      onClick={() => setSelectedChildId(child.id)}
                      className={`px-3 py-1.5 text-xs font-semibold rounded-lg cursor-pointer whitespace-nowrap ${
                        selectedChildId === child.id
                          ? 'bg-emerald-800 text-white'
                          : 'text-slate-600 hover:text-emerald-900'
                      }`}
                    >
                      {child.fullName}
                    </button>
                  ))}
                </div>
              )}

              <input
                type="date"
                value={reportDate}
                onChange={(e) => setReportDate(e.target.value)}
                className="rounded-xl border border-slate-200 px-3 py-1.5 text-xs font-mono-num bg-white"
              />

              <div className="inline-flex items-center gap-1 p-1 bg-[#FAFBF9] border border-emerald-900/10 rounded-xl">
                {(['daily', 'weekly', 'monthly'] as const).map((rm) => (
                  <button
                    key={rm}
                    type="button"
                    onClick={() => setReportRange(rm)}
                    className={`px-2.5 py-1 text-xs font-medium rounded-lg capitalize cursor-pointer ${
                      reportRange === rm ? 'bg-emerald-800 text-white' : 'text-slate-600'
                    }`}
                  >
                    {rm}
                  </button>
                ))}
              </div>

              <button
                type="button"
                onClick={handleExportConsolidatedPdf}
                disabled={!childReport}
                className="px-3.5 py-1.5 rounded-xl bg-emerald-800 hover:bg-emerald-900 text-white text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
              >
                <Download className="h-3.5 w-3.5" />
                <span>{t(lang, 'exportPdf')}</span>
              </button>
            </div>
          </div>

          {loadingReport ? (
            <div className="py-8 text-center text-xs text-slate-500">{t(lang, 'loading')}</div>
          ) : childReport ? (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
                <div className="p-4 rounded-xl bg-[#FAFBF9] border border-slate-200">
                  <div className="text-slate-500 font-medium">Attendance ({reportDate})</div>
                  <div className="text-base font-bold text-slate-950 mt-1">
                    {todayAtt ? t(lang, todayAtt.status) : t(lang, 'not_recorded')}
                  </div>
                  <div className="text-[11px] text-slate-500 mt-0.5">
                    {childReport.attendance?.length || 0} log(s) in {reportRange} window
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-[#FAFBF9] border border-slate-200">
                  <div className="text-slate-500 font-medium">Homework Status</div>
                  <div className="text-base font-bold text-emerald-900 mt-1 font-mono-num">
                    {completedHwCount} Submitted · {pendingHwCount} Pending
                  </div>
                  <button
                    type="button"
                    onClick={() => onNavigate('academics')}
                    className="text-[11px] font-semibold text-emerald-800 hover:underline mt-0.5 cursor-pointer"
                  >
                    View Homework & Marks
                  </button>
                </div>

                <div className="p-4 rounded-xl bg-[#FAFBF9] border border-slate-200">
                  <div className="text-slate-500 font-medium">5-Time Meals ({reportDate})</div>
                  {todayActivity ? (
                    <div className="text-[11px] text-slate-700 mt-1 space-y-0.5">
                      <div>Breakfast: <strong>{t(lang, todayActivity.breakfastStatus)}</strong> · Lunch: <strong>{t(lang, todayActivity.lunchStatus)}</strong></div>
                      <div>Evening: <strong>{t(lang, todayActivity.eveningMealStatus || 'not_recorded')}</strong> · Dinner: <strong>{t(lang, todayActivity.dinnerStatus)}</strong></div>
                    </div>
                  ) : (
                    <div className="text-sm font-semibold text-slate-500 mt-1">{t(lang, 'not_recorded')}</div>
                  )}
                </div>

                <div className="p-4 rounded-xl bg-[#FAFBF9] border border-slate-200">
                  <div className="text-slate-500 font-medium">Latest Health Note</div>
                  <div className="text-sm font-bold text-slate-900 mt-1">
                    {latestHealth ? t(lang, latestHealth.healthStatus) : 'No Concerns Logged'}
                  </div>
                  {latestHealth?.urgentAlertSent && (
                    <div className="text-[11px] font-semibold text-red-700 mt-0.5 flex items-center gap-1">
                      <ShieldAlert className="h-3 w-3" />
                      <span>Urgent Contact Requested</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Prayer Summary inside Child Report */}
              {childReport.policy?.prayerTrackingEnabled &&
                (user.role !== 'parent' || childReport.policy?.prayerShowToParents) && (
                  <div className="p-4 rounded-xl border border-emerald-900/10 bg-emerald-50/30 space-y-2 text-xs">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <span className="font-semibold text-emerald-950">
                        {t(lang, 'namazOverview')} ({reportDate})
                      </span>
                      <span className="text-[11px] text-slate-600">{childReport.policy?.prayerPolicyNote}</span>
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                      {(['fajr', 'zuhr', 'asr', 'maghrib', 'isha'] as const).map((p) => {
                        const state = todayNamaz?.[p] || 'not_recorded';
                        return (
                          <div key={p} className="p-2.5 rounded-lg bg-white border border-slate-200">
                            <div className="text-[11px] text-slate-500">{t(lang, p)}</div>
                            <div
                              className={`font-semibold mt-0.5 ${
                                state === 'performed'
                                  ? 'text-emerald-700'
                                  : state === 'not_performed'
                                    ? 'text-red-600'
                                    : 'text-slate-500'
                              }`}
                            >
                              {t(lang, state)}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

              {/* Recent Teacher Messages */}
              {(childReport.recentMessages || []).length > 0 && (
                <div className="p-4 rounded-xl border border-slate-200 bg-white space-y-2 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-slate-900 flex items-center gap-1.5">
                      <MessageSquare className="h-3.5 w-3.5 text-emerald-800" />
                      <span>Recent Teacher–Parent Notes</span>
                    </span>
                    <button
                      type="button"
                      onClick={() => onNavigate('notifications')}
                      className="text-[11px] font-semibold text-emerald-800 hover:underline cursor-pointer"
                    >
                      Open Messaging
                    </button>
                  </div>
                  <div className="space-y-1.5">
                    {childReport.recentMessages.slice(0, 3).map((m: any) => (
                      <div key={m.id} className="text-slate-700 bg-[#FAFBF9] px-3 py-2 rounded-lg border border-slate-100">
                        <span className="font-semibold uppercase text-emerald-800 text-[10px] me-2">
                          {m.senderRole}:
                        </span>
                        {m.message}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="py-6 text-center text-xs text-slate-500">{t(lang, 'noRecords')}</div>
          )}
        </div>
      )}

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Five-Times Namaz Chart */}
        <div className="bg-white border border-emerald-900/10 rounded-2xl p-6">
          <div className="mb-4">
            <h2 className="font-display text-lg font-bold text-slate-950">
              {isStudent ? 'My Five-Times Namaz Summary' : t(lang, 'namazOverview')}
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">{t(lang, 'namazNotice')}</p>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data?.namazChartData || []} margin={{ top: 10, right: 10, left: -15, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
                <XAxis dataKey="prayer" tick={{ fontSize: 12 }} />
                <YAxis allowDecimals={false} tick={{ fontSize: 12 }} />
                <Tooltip />
                <Legend wrapperStyle={{ fontSize: '12px' }} />
                <Bar dataKey="performed" name={t(lang, 'performed')} fill="#047857" radius={[4, 4, 0, 0]} />
                <Bar dataKey="notPerformed" name={t(lang, 'not_performed')} fill="#DC2626" radius={[4, 4, 0, 0]} />
                <Bar dataKey="notRecorded" name={t(lang, 'not_recorded')} fill="#CBD5E1" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Attendance Trend Chart */}
        <div className="bg-white border border-emerald-900/10 rounded-2xl p-6">
          <div className="mb-4">
            <h2 className="font-display text-lg font-bold text-slate-950">
              {isStudent ? 'My Attendance Trend' : t(lang, 'attendanceTrend')}
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              {isStudent ? 'Your personal daily attendance record' : 'Daily recorded presence across authorized cohorts'}
            </p>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data?.attendanceTrend || []} margin={{ top: 10, right: 10, left: -15, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
                <XAxis dataKey="date" tick={{ fontSize: 11 }} />
                <YAxis allowDecimals={false} tick={{ fontSize: 12 }} />
                <Tooltip />
                <Legend wrapperStyle={{ fontSize: '12px' }} />
                <Area type="monotone" dataKey="present" name={t(lang, 'present')} stroke="#047857" fill="#D1FAE5" />
                <Area type="monotone" dataKey="late" name={t(lang, 'late')} stroke="#D97706" fill="#FEF3C7" />
                <Area type="monotone" dataKey="absent" name={t(lang, 'absent')} stroke="#DC2626" fill="#FEE2E2" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Syllabus Progress & Notifications */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-5 bg-white border border-emerald-900/10 rounded-2xl p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-display text-lg font-bold text-slate-950">
              {isStudent ? 'My Subject Syllabus Progress' : t(lang, 'syllabusTracking')}
            </h2>
            <button
              type="button"
              onClick={() => onNavigate('students')}
              className="text-xs font-semibold text-emerald-800 hover:underline cursor-pointer"
            >
              Details
            </button>
          </div>
          <div className="space-y-4">
            {subjects.length === 0 ? (
              <div className="text-xs text-slate-500 py-4">{t(lang, 'noRecords')}</div>
            ) : (
              subjects.slice(0, 6).map((sub) => {
                const pct =
                  sub.syllabusTotalUnits > 0
                    ? Math.min(100, Math.round((sub.syllabusCompletedUnits / sub.syllabusTotalUnits) * 100))
                    : 0;
                return (
                  <div key={sub.id}>
                    <div className="flex justify-between text-xs mb-1">
                      <span className="font-medium text-slate-800">{sub.name}</span>
                      <span className="font-mono-num text-slate-500">
                        {sub.syllabusCompletedUnits}/{sub.syllabusTotalUnits} ({pct}%)
                      </span>
                    </div>
                    <div className="h-2 rounded-full bg-slate-100 overflow-hidden">
                      <div className="h-full bg-emerald-700 rounded-full" style={{ width: `${pct}%` }} />
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        <div className="lg:col-span-7 bg-white border border-emerald-900/10 rounded-2xl p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-display text-lg font-bold text-slate-950 flex items-center gap-2">
              <Bell className="h-4 w-4 text-amber-700" />
              <span>{t(lang, 'recentNotices')}</span>
            </h2>
            <button
              type="button"
              onClick={() => onNavigate('notifications')}
              className="text-xs font-semibold text-emerald-800 hover:underline cursor-pointer"
            >
              View All
            </button>
          </div>

          {(user?.role === 'admin' || user?.role === 'teacher') && (
            <form onSubmit={handleSendNotification} className="mb-5 p-4 rounded-xl bg-[#FAFBF9] border border-emerald-900/10 space-y-2.5">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                <input
                  type="text"
                  required
                  placeholder="Notification title..."
                  value={notifTitle}
                  onChange={(e) => setNotifTitle(e.target.value)}
                  className="sm:col-span-2 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs"
                />
                <select
                  value={notifTarget}
                  onChange={(e) => setNotifTarget(e.target.value)}
                  className="rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs"
                >
                  <option value="all">All Users</option>
                  <option value="parent">Parents</option>
                  <option value="student">Students</option>
                  <option value="teacher">Teachers</option>
                </select>
              </div>
              <div className="flex gap-2">
                <input
                  type="text"
                  required
                  placeholder="Write announcement or parent update..."
                  value={notifMsg}
                  onChange={(e) => setNotifMsg(e.target.value)}
                  className="flex-1 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs"
                />
                <button
                  type="submit"
                  disabled={sending}
                  className="px-3.5 py-1.5 rounded-lg bg-emerald-800 text-white text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer shrink-0"
                >
                  <Send className="h-3 w-3" />
                  <span>Send</span>
                </button>
              </div>
            </form>
          )}

          <div className="space-y-2.5 max-h-72 overflow-y-auto">
            {(data?.notifications || []).map((n: any) => (
              <div
                key={n.id}
                className={`p-3.5 rounded-xl border text-sm flex items-start justify-between gap-3 ${
                  n.isRead ? 'border-slate-100 bg-slate-50/50' : 'border-emerald-900/15 bg-emerald-50/35'
                }`}
              >
                <div>
                  <div className="flex items-center gap-2 text-[11px] text-slate-500 mb-0.5">
                    <span className="font-semibold text-emerald-800 uppercase">{n.type}</span>
                    <span>·</span>
                    <span className="font-mono-num">{new Date(n.createdAt).toLocaleDateString()}</span>
                  </div>
                  <div className="font-semibold text-slate-900 text-xs">{n.title}</div>
                  <div className="text-xs text-slate-600 mt-0.5">{n.message}</div>
                </div>
                {!n.isRead && (
                  <button
                    type="button"
                    onClick={() => handleMarkRead(n.id)}
                    className="text-xs text-emerald-800 hover:text-emerald-950 shrink-0 cursor-pointer"
                    title="Mark as read"
                  >
                    <CheckCircle2 className="h-4 w-4" />
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
