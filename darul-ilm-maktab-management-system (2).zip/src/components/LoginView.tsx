import React, { useEffect, useState } from 'react';
import { ArrowLeft, Building2, CheckCircle2, Clock, Eye, EyeOff, Lock, Mail, ShieldCheck } from 'lucide-react';
import { useAuth } from '../context/AuthContext.tsx';
import { t } from '../i18n/translations.ts';
import { LanguageSwitcher } from './LanguageSwitcher.tsx';

interface LoginViewProps {
  onBack: () => void;
  onSuccess: () => void;
}

interface PublicInstitution {
  id: number;
  name: string;
  slug: string;
  code: string;
  city?: string | null;
}

export const LoginView: React.FC<LoginViewProps> = ({ onBack, onSuccess }) => {
  const { lang, loginWithPassword, registerAccount, loginWithGoogle } = useAuth();
  const [mode, setMode] = useState<'login' | 'register' | 'apply'>('login');
  const [institutions, setInstitutions] = useState<PublicInstitution[]>([]);

  // Sign-in / Register state
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [studentName, setStudentName] = useState('');
  const [admissionNo, setAdmissionNo] = useState('');
  const [phone, setPhone] = useState('');
  const [regRole, setRegRole] = useState<'parent' | 'student'>('parent');
  const [regInstitutionId, setRegInstitutionId] = useState<number>(1);

  // New Maktab onboarding application state (requires Super Admin approval)
  const [instForm, setInstForm] = useState({
    name: '',
    city: '',
    contactPhone: '',
    address: '',
    adminName: '',
    adminEmail: '',
    adminPassword: '',
  });
  const [applySuccess, setApplySuccess] = useState<string | null>(null);
  const [submittedMaktab, setSubmittedMaktab] = useState<{
    name: string;
    adminEmail: string;
    status: string;
  } | null>(null);
  const [checkingStatus, setCheckingStatus] = useState(false);

  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showLoginPass, setShowLoginPass] = useState(false);
  const [showAdminPass, setShowAdminPass] = useState(false);

  useEffect(() => {
    fetch('/api/public/institutions')
      .then((r) => r.json())
      .then((rows) => {
        if (Array.isArray(rows) && rows.length > 0) {
          setInstitutions(rows);
          setRegInstitutionId(rows[0].id);
        }
      })
      .catch(() => {});
  }, []);

  const handleCheckApplicationStatus = async () => {
    if (!submittedMaktab?.adminEmail) return;
    setCheckingStatus(true);
    setError(null);
    try {
      const res = await fetch(
        `/api/public/institution-status?email=${encodeURIComponent(submittedMaktab.adminEmail)}`
      );
      const data = await res.json().catch(() => ({}));
      if (data.found && data.institution) {
        const nextStatus = data.institution.status;
        setSubmittedMaktab({
          name: data.institution.name,
          adminEmail: submittedMaktab.adminEmail,
          status: nextStatus,
        });
        if (nextStatus === 'approved') {
          setApplySuccess(
            `"${data.institution.name}" is now APPROVED by the Super Admin! Registration is complete — click "Go to Sign In" below to log in with ${submittedMaktab.adminEmail}.`
          );
        } else if (nextStatus === 'pending') {
          setApplySuccess(
            `"${data.institution.name}" is still pending Super Admin approval. Your Maktab registration will be completed only after the Super Admin approves it.`
          );
        } else {
          setError(`Application for "${data.institution.name}" was ${nextStatus}.`);
        }
      }
    } catch {
      setError('Could not check application status right now.');
    } finally {
      setCheckingStatus(false);
    }
  };

  const handleGoToAdminLogin = (targetEmail?: string) => {
    setMode('login');
    if (targetEmail) {
      setEmail(targetEmail);
      setPassword('');
    }
    setError(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setApplySuccess(null);
    setSubmitting(true);
    try {
      if (mode === 'login') {
        await loginWithPassword(email, password);
        onSuccess();
      } else if (mode === 'register') {
        const enrolledName = studentName.trim();
        await registerAccount({
          name: regRole === 'student' ? enrolledName : name.trim(),
          studentName: enrolledName,
          admissionNo: admissionNo.trim() || undefined,
          email,
          password,
          phone,
          role: regRole,
          institutionId: regInstitutionId,
        });
        onSuccess();
      } else {
        const submittedEmail = instForm.adminEmail.trim().toLowerCase();
        const res = await fetch('/api/public/institution-application', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(instForm),
        });
        const data = await res.json().catch(() => ({}));
        if (!res.ok) {
          throw new Error(data.error || 'Failed to submit institution application');
        }
        setSubmittedMaktab({
          name: data.name,
          adminEmail: data.adminEmail || submittedEmail,
          status: data.status || 'pending',
        });
        setApplySuccess(
          `Request sent for "${data.name}". Your Maktab registration will be completed only after Super Admin approval. Once approved, ${data.adminEmail || submittedEmail} can sign in.`
        );
        setInstForm({
          name: '',
          city: '',
          contactPhone: '',
          address: '',
          adminName: '',
          adminEmail: '',
          adminPassword: '',
        });
      }
    } catch (err: any) {
      setError(err.message || 'Authentication failed');
    } finally {
      setSubmitting(false);
    }
  };

  const handleGoogleSignIn = async () => {
    setError(null);
    setSubmitting(true);
    try {
      await loginWithGoogle();
      onSuccess();
    } catch (err: any) {
      setError(err.message || 'Google Sign-In was cancelled or failed');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#FAFBF9] islamic-lattice flex flex-col">
      <header className="border-b border-emerald-900/10 bg-white/95 backdrop-blur px-6 py-4">
        <div className="max-w-4xl mx-auto flex items-center justify-between gap-4">
          <button
            type="button"
            onClick={onBack}
            className="inline-flex items-center gap-2 text-sm font-medium text-emerald-900 hover:text-emerald-700 cursor-pointer whitespace-nowrap"
          >
            <ArrowLeft className="h-4 w-4 rtl:rotate-180" />
            <span>{t(lang, 'backToWebsite')}</span>
          </button>
          <span className="font-display text-lg font-bold text-emerald-950 whitespace-nowrap">
            {t(lang, 'brandName')}
          </span>
          <LanguageSwitcher compact />
        </div>
      </header>

      <main className="flex-1 flex items-center justify-center p-4 sm:p-6">
        <div className="w-full max-w-2xl">
          {/* Unified Auth Card */}
          <div className="bg-white border border-emerald-900/12 rounded-2xl p-6 sm:p-8 flex flex-col justify-between shadow-xs">
            <div>
              <div className="flex items-center justify-between gap-4 mb-6">
                <div>
                  <p className="text-xs font-medium text-amber-700 tracking-wide mb-1">
                    {t(lang, 'heroBadge')}
                  </p>
                  <h1 className="font-display text-2xl font-bold text-slate-900">
                    {t(lang, 'loginTitle')}
                  </h1>
                </div>
                <div className="h-10 w-10 rounded-xl bg-emerald-50 border border-emerald-900/10 flex items-center justify-center text-emerald-800 shrink-0">
                  <Lock className="h-5 w-5" />
                </div>
              </div>

              <p className="text-sm text-slate-600 mb-6">{t(lang, 'loginSubtitle')}</p>

              {/* Segmented Auth Mode Switch */}
              <div className="grid grid-cols-3 gap-1 p-1 bg-slate-100 rounded-xl mb-6">
                <button
                  type="button"
                  onClick={() => {
                    setMode('login');
                    setError(null);
                    setApplySuccess(null);
                  }}
                  className={`py-2 px-3 text-xs sm:text-sm font-medium rounded-lg transition-colors cursor-pointer ${
                    mode === 'login' ? 'bg-white text-emerald-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {t(lang, 'loginTab')}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setMode('register');
                    setError(null);
                    setApplySuccess(null);
                  }}
                  className={`py-2 px-3 text-xs sm:text-sm font-medium rounded-lg transition-colors cursor-pointer ${
                    mode === 'register' ? 'bg-white text-emerald-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {t(lang, 'registerTab')}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setMode('apply');
                    setError(null);
                    setApplySuccess(null);
                  }}
                  className={`py-2 px-3 text-xs sm:text-sm font-medium rounded-lg transition-colors cursor-pointer ${
                    mode === 'apply' ? 'bg-white text-emerald-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  New Maktab
                </button>
              </div>

              {error && (
                <div className="mb-4 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800">
                  {error}
                </div>
              )}

              {applySuccess && (
                <div
                  className={`mb-4 rounded-xl border px-4 py-3 text-sm space-y-3 ${
                    submittedMaktab?.status === 'approved'
                      ? 'border-emerald-200 bg-emerald-50 text-emerald-900'
                      : 'border-amber-300 bg-amber-50 text-amber-950'
                  }`}
                >
                  <div className="flex items-start gap-2.5">
                    {submittedMaktab?.status === 'approved' ? (
                      <CheckCircle2 className="h-4 w-4 text-emerald-700 mt-0.5 shrink-0" />
                    ) : (
                      <Clock className="h-4 w-4 text-amber-700 mt-0.5 shrink-0" />
                    )}
                    <span>{applySuccess}</span>
                  </div>
                  {submittedMaktab && (
                    <div className="flex flex-wrap items-center gap-2 ps-6">
                      <button
                        type="button"
                        onClick={handleCheckApplicationStatus}
                        disabled={checkingStatus}
                        className="px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-xs font-semibold text-slate-900 hover:bg-slate-50 cursor-pointer disabled:opacity-60"
                      >
                        {checkingStatus
                          ? 'Checking...'
                          : `Check Status (${submittedMaktab.status.toUpperCase()})`}
                      </button>
                      {submittedMaktab.status === 'approved' && (
                        <button
                          type="button"
                          onClick={() => handleGoToAdminLogin(submittedMaktab.adminEmail)}
                          className="px-3 py-1.5 rounded-lg bg-emerald-800 hover:bg-emerald-900 text-xs font-semibold text-white cursor-pointer"
                        >
                          Go to Sign In
                        </button>
                      )}
                    </div>
                  )}
                </div>
              )}

              {mode === 'apply' ? (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="rounded-xl border border-emerald-900/15 bg-emerald-950 text-white p-4 space-y-1.5">
                    <div className="flex items-center gap-2">
                      <Building2 className="h-4 w-4 text-amber-300 shrink-0" />
                      <span className="font-display font-bold text-sm">New Maktab Registration</span>
                    </div>
                    <p className="text-[11px] text-emerald-100/85">
                      Submit your Maktab details below. Your application goes directly to the Super Admin and your Maktab workspace &amp; Admin login activate once approved.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1.5">Institution Name *</label>
                      <input
                        type="text"
                        required
                        value={instForm.name}
                        onChange={(e) => setInstForm({ ...instForm, name: e.target.value })}
                        placeholder="e.g. Madrasa Al-Falah"
                        className="w-full rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm focus:outline-none focus:border-emerald-700"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1.5">City</label>
                      <input
                        type="text"
                        value={instForm.city}
                        onChange={(e) => setInstForm({ ...instForm, city: e.target.value })}
                        placeholder="e.g. Lucknow"
                        className="w-full rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm focus:outline-none focus:border-emerald-700"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1.5">Principal / Admin Name *</label>
                      <input
                        type="text"
                        required
                        value={instForm.adminName}
                        onChange={(e) => setInstForm({ ...instForm, adminName: e.target.value })}
                        placeholder="e.g. Maulana Ahmad"
                        className="w-full rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm focus:outline-none focus:border-emerald-700"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1.5">Contact Phone</label>
                      <input
                        type="tel"
                        value={instForm.contactPhone}
                        onChange={(e) => setInstForm({ ...instForm, contactPhone: e.target.value })}
                        placeholder="+91 98110 00000"
                        className="w-full rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm focus:outline-none focus:border-emerald-700"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1.5">Campus Address</label>
                    <input
                      type="text"
                      value={instForm.address}
                      onChange={(e) => setInstForm({ ...instForm, address: e.target.value })}
                      placeholder="Full street address"
                      className="w-full rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm focus:outline-none focus:border-emerald-700"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1.5">Admin Login Email *</label>
                      <input
                        type="email"
                        required
                        value={instForm.adminEmail}
                        onChange={(e) => setInstForm({ ...instForm, adminEmail: e.target.value })}
                        placeholder="principal@maktab.edu"
                        className="w-full rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm focus:outline-none focus:border-emerald-700"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1.5">Admin Password *</label>
                      <div className="relative">
                        <input
                          type={showAdminPass ? 'text' : 'password'}
                          required
                          minLength={6}
                          value={instForm.adminPassword}
                          onChange={(e) => setInstForm({ ...instForm, adminPassword: e.target.value })}
                          placeholder="Min 6 characters"
                          className="w-full rounded-xl border border-slate-200 px-3.5 pe-10 py-2.5 text-sm focus:outline-none focus:border-emerald-700"
                        />
                        <button
                          type="button"
                          onClick={() => setShowAdminPass((prev) => !prev)}
                          aria-label={showAdminPass ? 'Hide password' : 'Show password'}
                          className="absolute inset-y-0 end-0 px-3 flex items-center text-slate-500 hover:text-slate-800 cursor-pointer"
                        >
                          {showAdminPass ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                        </button>
                      </div>
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={submitting}
                    className="w-full rounded-xl bg-emerald-800 hover:bg-emerald-900 text-white font-semibold py-2.5 px-4 text-sm transition-colors disabled:opacity-60 cursor-pointer"
                  >
                    {submitting ? t(lang, 'loading') : 'Submit Maktab Registration'}
                  </button>
                </form>
              ) : (
                <>
                  <form onSubmit={handleSubmit} className="space-y-4">
                    {mode === 'register' && (
                      <>
                        <div className="rounded-xl border border-amber-200 bg-amber-50/70 px-3.5 py-2.5 text-xs text-amber-950">
                          Only students and parents whose student name is actively enrolled in the selected Maktab can register and log in. Choosing the wrong Maktab will be blocked.
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <div>
                            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                              Select Approved Maktab *
                            </label>
                            <select
                              required
                              value={regInstitutionId}
                              onChange={(e) => setRegInstitutionId(Number(e.target.value))}
                              className="w-full rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm bg-white focus:outline-none focus:border-emerald-700"
                            >
                              {institutions.map((inst) => (
                                <option key={inst.id} value={inst.id}>
                                  {inst.name} {inst.city ? `— ${inst.city}` : ''}
                                </option>
                              ))}
                            </select>
                          </div>
                          <div>
                            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                              Account Role *
                            </label>
                            <select
                              value={regRole}
                              onChange={(e) => setRegRole(e.target.value as 'parent' | 'student')}
                              className="w-full rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm bg-white focus:outline-none focus:border-emerald-700"
                            >
                              <option value="parent">Parent / Guardian</option>
                              <option value="student">Student</option>
                            </select>
                          </div>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          {regRole === 'parent' && (
                            <div>
                              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                                Parent / Guardian Full Name *
                              </label>
                              <input
                                type="text"
                                required
                                value={name}
                                onChange={(e) => setName(e.target.value)}
                                placeholder="e.g. Tariq Siddiqui"
                                className="w-full rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm focus:outline-none focus:border-emerald-700"
                              />
                            </div>
                          )}
                          <div className={regRole === 'student' ? 'sm:col-span-1' : ''}>
                            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                              Enrolled Student Full Name *
                            </label>
                            <input
                              type="text"
                              required
                              value={studentName}
                              onChange={(e) => setStudentName(e.target.value)}
                              placeholder="Exact enrolled student name"
                              className="w-full rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm focus:outline-none focus:border-emerald-700"
                            />
                          </div>
                          <div>
                            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                              Admission No (Optional)
                            </label>
                            <input
                              type="text"
                              value={admissionNo}
                              onChange={(e) => setAdmissionNo(e.target.value)}
                              placeholder="e.g. DI-2026-001"
                              className="w-full rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm font-mono-num focus:outline-none focus:border-emerald-700"
                            />
                          </div>
                        </div>
                      </>
                    )}

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                        {t(lang, 'email')}
                      </label>
                      <div className="relative">
                        <Mail className="h-4 w-4 text-slate-400 absolute top-3 start-3.5" />
                        <input
                          type={mode === 'login' ? 'text' : 'email'}
                          required
                          autoComplete={mode === 'login' ? 'username' : 'email'}
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          placeholder={mode === 'login' ? 'name@maktab.edu or username' : 'name@maktab.edu'}
                          className="w-full rounded-xl border border-slate-200 ps-10 pe-4 py-2.5 text-sm focus:outline-none focus:border-emerald-700"
                        />
                      </div>
                    </div>

                    {mode === 'register' && (
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1.5">Phone Number</label>
                        <input
                          type="tel"
                          value={phone}
                          onChange={(e) => setPhone(e.target.value)}
                          placeholder="+91 98110 00000"
                          className="w-full rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm focus:outline-none focus:border-emerald-700"
                        />
                      </div>
                    )}

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                        {t(lang, 'password')}
                      </label>
                      <div className="relative">
                        <input
                          type={showLoginPass ? 'text' : 'password'}
                          required
                          minLength={6}
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          className="w-full rounded-xl border border-slate-200 px-3.5 pe-10 py-2.5 text-sm focus:outline-none focus:border-emerald-700"
                        />
                        <button
                          type="button"
                          onClick={() => setShowLoginPass((prev) => !prev)}
                          aria-label={showLoginPass ? 'Hide password' : 'Show password'}
                          className="absolute inset-y-0 end-0 px-3 flex items-center text-slate-500 hover:text-slate-800 cursor-pointer"
                        >
                          {showLoginPass ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                        </button>
                      </div>
                    </div>

                    <button
                      type="submit"
                      disabled={submitting}
                      className="w-full rounded-xl bg-emerald-800 hover:bg-emerald-900 text-white font-semibold py-2.5 px-4 text-sm transition-colors disabled:opacity-60 cursor-pointer"
                    >
                      {submitting ? t(lang, 'loading') : mode === 'login' ? t(lang, 'signIn') : t(lang, 'registerTab')}
                    </button>
                  </form>

                  <div className="relative my-5">
                    <div className="absolute inset-0 flex items-center">
                      <div className="w-full border-t border-slate-200" />
                    </div>
                    <div className="relative flex justify-center text-xs">
                      <span className="bg-white px-3 text-slate-500">or</span>
                    </div>
                  </div>

                  <button
                    type="button"
                    disabled={submitting}
                    onClick={handleGoogleSignIn}
                    className="w-full rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-800 font-medium py-2.5 px-4 text-sm inline-flex items-center justify-center gap-2.5 transition-colors cursor-pointer"
                  >
                    <ShieldCheck className="h-4 w-4 text-emerald-700" />
                    <span>{t(lang, 'signInGoogle')}</span>
                  </button>
                </>
              )}
            </div>

            <div className="mt-6 pt-4 border-t border-slate-100 flex items-center gap-2 text-xs text-slate-500">
              <CheckCircle2 className="h-3.5 w-3.5 text-emerald-700 shrink-0" />
              <span>Strict Tenant Isolation · Server-Verified Role Access · Encrypted Sessions</span>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};
