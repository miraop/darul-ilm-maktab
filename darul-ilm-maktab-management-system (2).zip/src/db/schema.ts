import { relations } from 'drizzle-orm';
import {
  boolean,
  index,
  integer,
  jsonb,
  numeric,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from 'drizzle-orm/pg-core';

export const institutions = pgTable(
  'institutions',
  {
    id: serial('id').primaryKey(),
    name: text('name').notNull(),
    slug: text('slug').notNull().unique(),
    code: text('code').notNull().unique(),
    city: text('city'),
    contactEmail: text('contact_email'),
    contactPhone: text('contact_phone'),
    address: text('address'),
    status: text('status').notNull().default('pending'), // 'pending' | 'approved' | 'suspended' | 'rejected'
    requestedAdminName: text('requested_admin_name'),
    requestedAdminEmail: text('requested_admin_email'),
    requestedAdminPasswordHash: text('requested_admin_password_hash'),
    approvedBy: integer('approved_by'),
    approvedAt: timestamp('approved_at'),
    subscriptionPlan: text('subscription_plan').notNull().default('maktab_399'),
    subscriptionAmount: integer('subscription_amount').notNull().default(399),
    subscriptionStatus: text('subscription_status').notNull().default('pending_payment'), // 'pending_payment' | 'active' | 'expired'
    subscriptionExpiresAt: timestamp('subscription_expires_at'),
    lastPaymentRef: text('last_payment_ref'),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => [index('institutions_status_idx').on(table.status)]
);

export const institutionSubscriptions = pgTable(
  'institution_subscriptions',
  {
    id: serial('id').primaryKey(),
    institutionId: integer('institution_id')
      .references(() => institutions.id, { onDelete: 'cascade' })
      .notNull(),
    planCode: text('plan_code').notNull().default('maktab_399'),
    planName: text('plan_name').notNull().default('Maktab Standard SaaS Plan'),
    amount: integer('amount').notNull().default(399),
    currency: text('currency').notNull().default('INR'),
    billingCycle: text('billing_cycle').notNull().default('monthly'),
    paymentMethod: text('payment_method').notNull().default('upi'),
    transactionRef: text('transaction_ref').notNull(),
    status: text('status').notNull().default('paid'),
    periodStart: timestamp('period_start').defaultNow().notNull(),
    periodEnd: timestamp('period_end').notNull(),
    paidByEmail: text('paid_by_email'),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => [index('inst_subs_inst_idx').on(table.institutionId)]
);

export const institutionPolicies = pgTable('institution_policies', {
  id: serial('id').primaryKey(),
  institutionId: integer('institution_id')
    .references(() => institutions.id, { onDelete: 'cascade' })
    .notNull()
    .unique(),
  prayerTrackingEnabled: boolean('prayer_tracking_enabled').notNull().default(true),
  prayerShowToParents: boolean('prayer_show_to_parents').notNull().default(true),
  prayerStaffRoles: jsonb('prayer_staff_roles').$type<string[]>().notNull().default(['admin', 'teacher']),
  prayerPolicyNote: text('prayer_policy_note')
    .notNull()
    .default(
      'Prayer records are private devotional guidance logs. Unmarked entries remain Not Recorded, never ranked publicly, and never used for punitive labeling.'
    ),
  customActivities: jsonb('custom_activities')
    .$type<string[]>()
    .notNull()
    .default([
      'Quran Reading',
      'Quran Memorization',
      'Revision',
      'Homework Completion',
      'Class Participation',
      'Reading Practice',
      'Sports and Physical Activities',
      'Personal Discipline',
    ]),
  urgentHealthProtocol: text('urgent_health_protocol')
    .notNull()
    .default('Notify parent/guardian immediately by phone and in-app urgent alert when fever or unwell concern is logged.'),
  teacherPermissions: jsonb('teacher_permissions')
    .$type<Record<string, boolean>>()
    .notNull()
    .default({
      canRecordAttendance: true,
      canRecordNamaz: true,
      canRecordMeals: true,
      canRecordHealth: true,
      canManageOnlineTests: true,
      canMessageParents: true,
    }),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

export const roles = pgTable('roles', {
  id: serial('id').primaryKey(),
  name: text('name').notNull().unique(), // 'super_admin' | 'admin' | 'teacher' | 'student' | 'parent'
  displayName: text('display_name').notNull(),
  permissions: jsonb('permissions').$type<string[]>().notNull().default([]),
  description: text('description'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const users = pgTable(
  'users',
  {
    id: serial('id').primaryKey(),
    uid: text('uid').notNull().unique(),
    email: text('email').notNull().unique(),
    passwordHash: text('password_hash'),
    name: text('name').notNull(),
    role: text('role').notNull().default('parent'), // 'super_admin' | 'admin' | 'teacher' | 'student' | 'parent'
    institutionId: integer('institution_id').references(() => institutions.id, { onDelete: 'cascade' }), // null ONLY for super_admin
    phone: text('phone'),
    preferredLang: text('preferred_lang').notNull().default('en'), // 'en' | 'hi' | 'ur'
    specialization: text('specialization'),
    qualification: text('qualification'),
    isActive: boolean('is_active').notNull().default(true),
    isDemo: boolean('is_demo').notNull().default(false),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => [
    index('users_role_idx').on(table.role),
    index('users_email_idx').on(table.email),
    index('users_inst_idx').on(table.institutionId),
  ]
);

export const classes = pgTable(
  'classes',
  {
    id: serial('id').primaryKey(),
    institutionId: integer('institution_id').references(() => institutions.id, { onDelete: 'cascade' }),
    name: text('name').notNull(),
    gradeLevel: text('grade_level').notNull(),
    section: text('section').notNull().default('A'),
    roomNumber: text('room_number'),
    capacity: integer('capacity').notNull().default(30),
    academicYear: text('academic_year').notNull().default('2026-2027'),
    teacherId: integer('teacher_id').references(() => users.id, { onDelete: 'set null' }),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => [index('classes_inst_idx').on(table.institutionId)]
);

export const subjects = pgTable(
  'subjects',
  {
    id: serial('id').primaryKey(),
    institutionId: integer('institution_id').references(() => institutions.id, { onDelete: 'cascade' }),
    name: text('name').notNull(),
    code: text('code').notNull(),
    category: text('category').notNull().default('Deeni'), // 'Deeni' | 'General' | 'Language'
    classId: integer('class_id')
      .references(() => classes.id, { onDelete: 'cascade' })
      .notNull(),
    teacherId: integer('teacher_id').references(() => users.id, { onDelete: 'set null' }),
    syllabusTotalUnits: integer('syllabus_total_units').notNull().default(12),
    syllabusCompletedUnits: integer('syllabus_completed_units').notNull().default(0),
    description: text('description'),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => [
    index('subjects_class_idx').on(table.classId),
    index('subjects_inst_idx').on(table.institutionId),
  ]
);

export const syllabusTopics = pgTable(
  'syllabus_topics',
  {
    id: serial('id').primaryKey(),
    institutionId: integer('institution_id')
      .references(() => institutions.id, { onDelete: 'cascade' })
      .notNull(),
    classId: integer('class_id')
      .references(() => classes.id, { onDelete: 'cascade' })
      .notNull(),
    subjectId: integer('subject_id')
      .references(() => subjects.id, { onDelete: 'cascade' })
      .notNull(),
    academicSession: text('academic_session').notNull().default('2026-2027'),
    bookName: text('book_name').notNull(),
    chapter: text('chapter').notNull(),
    lesson: text('lesson').notNull(),
    totalTopics: integer('total_topics').notNull().default(10),
    completedTopics: integer('completed_topics').notNull().default(0),
    status: text('status').notNull().default('in_progress'), // 'pending' | 'in_progress' | 'completed'
    completionDate: text('completion_date'),
    teacherRemarks: text('teacher_remarks'),
    updatedBy: integer('updated_by').references(() => users.id, { onDelete: 'set null' }),
    createdAt: timestamp('created_at').defaultNow().notNull(),
    updatedAt: timestamp('updated_at').defaultNow().notNull(),
  },
  (table) => [
    index('syllabus_inst_idx').on(table.institutionId),
    index('syllabus_subject_idx').on(table.subjectId),
    index('syllabus_class_idx').on(table.classId),
  ]
);

export const students = pgTable(
  'students',
  {
    id: serial('id').primaryKey(),
    institutionId: integer('institution_id').references(() => institutions.id, { onDelete: 'cascade' }),
    userId: integer('user_id').references(() => users.id, { onDelete: 'set null' }),
    admissionNo: text('admission_no').notNull(),
    fullName: text('full_name').notNull(),
    photoUrl: text('photo_url'),
    fatherName: text('father_name'),
    motherName: text('mother_name'),
    dob: text('dob').notNull(),
    gender: text('gender').notNull().default('Male'),
    classId: integer('class_id').references(() => classes.id, { onDelete: 'set null' }),
    academicSession: text('academic_session').notNull().default('2026-2027'),
    parentId: integer('parent_id').references(() => users.id, { onDelete: 'set null' }),
    guardianName: text('guardian_name').notNull(),
    guardianPhone: text('guardian_phone').notNull(),
    emergencyContact: text('emergency_contact'),
    address: text('address'),
    bloodGroup: text('blood_group'),
    allergies: text('allergies'),
    medicalNotes: text('medical_notes'),
    parentalConsent: boolean('parental_consent').notNull().default(true),
    status: text('status').notNull().default('active'), // 'active' | 'inactive'
    admissionDate: text('admission_date').notNull(),
    isDemo: boolean('is_demo').notNull().default(false),
    createdAt: timestamp('created_at').defaultNow().notNull(),
    updatedAt: timestamp('updated_at').defaultNow().notNull(),
  },
  (table) => [
    uniqueIndex('students_inst_admission_uidx').on(table.institutionId, table.admissionNo),
    index('students_class_idx').on(table.classId),
    index('students_parent_idx').on(table.parentId),
    index('students_inst_idx').on(table.institutionId),
  ]
);

export const enrollments = pgTable(
  'enrollments',
  {
    id: serial('id').primaryKey(),
    institutionId: integer('institution_id').references(() => institutions.id, { onDelete: 'cascade' }),
    studentId: integer('student_id')
      .references(() => students.id, { onDelete: 'cascade' })
      .notNull(),
    classId: integer('class_id')
      .references(() => classes.id, { onDelete: 'cascade' })
      .notNull(),
    academicYear: text('academic_year').notNull().default('2026-2027'),
    status: text('status').notNull().default('enrolled'),
    enrolledAt: timestamp('enrolled_at').defaultNow().notNull(),
  },
  (table) => [
    index('enrollments_student_idx').on(table.studentId),
    index('enrollments_inst_idx').on(table.institutionId),
  ]
);

export const attendance = pgTable(
  'attendance',
  {
    id: serial('id').primaryKey(),
    institutionId: integer('institution_id').references(() => institutions.id, { onDelete: 'cascade' }),
    studentId: integer('student_id')
      .references(() => students.id, { onDelete: 'cascade' })
      .notNull(),
    classId: integer('class_id')
      .references(() => classes.id, { onDelete: 'cascade' })
      .notNull(),
    date: text('date').notNull(), // YYYY-MM-DD
    status: text('status').notNull().default('present'), // 'present' | 'absent' | 'late' | 'leave' | 'excused'
    remarks: text('remarks'),
    recordedBy: integer('recorded_by').references(() => users.id, { onDelete: 'set null' }),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => [
    uniqueIndex('attendance_student_date_uidx').on(table.studentId, table.date),
    index('attendance_date_idx').on(table.date),
    index('attendance_inst_idx').on(table.institutionId),
  ]
);

export const teacherAttendance = pgTable(
  'teacher_attendance',
  {
    id: serial('id').primaryKey(),
    institutionId: integer('institution_id')
      .references(() => institutions.id, { onDelete: 'cascade' })
      .notNull(),
    teacherId: integer('teacher_id')
      .references(() => users.id, { onDelete: 'cascade' })
      .notNull(),
    date: text('date').notNull(),
    status: text('status').notNull().default('present'), // 'present' | 'absent' | 'late' | 'leave'
    remarks: text('remarks'),
    recordedBy: integer('recorded_by').references(() => users.id, { onDelete: 'set null' }),
    createdAt: timestamp('created_at').defaultNow().notNull(),
    updatedAt: timestamp('updated_at').defaultNow().notNull(),
  },
  (table) => [
    uniqueIndex('teacher_att_inst_teacher_date_uidx').on(table.institutionId, table.teacherId, table.date),
    index('teacher_att_inst_idx').on(table.institutionId),
  ]
);

export const namazRecords = pgTable(
  'namaz_records',
  {
    id: serial('id').primaryKey(),
    institutionId: integer('institution_id').references(() => institutions.id, { onDelete: 'cascade' }),
    studentId: integer('student_id')
      .references(() => students.id, { onDelete: 'cascade' })
      .notNull(),
    date: text('date').notNull(), // YYYY-MM-DD
    fajr: text('fajr').notNull().default('not_recorded'), // 'performed' | 'not_performed' | 'not_recorded'
    zuhr: text('zuhr').notNull().default('not_recorded'),
    asr: text('asr').notNull().default('not_recorded'),
    maghrib: text('maghrib').notNull().default('not_recorded'),
    isha: text('isha').notNull().default('not_recorded'),
    notes: text('notes'),
    remarks: text('remarks'),
    recordedBy: integer('recorded_by').references(() => users.id, { onDelete: 'set null' }),
    createdAt: timestamp('created_at').defaultNow().notNull(),
    updatedAt: timestamp('updated_at').defaultNow().notNull(),
  },
  (table) => [
    uniqueIndex('namaz_student_date_uidx').on(table.studentId, table.date),
    index('namaz_date_idx').on(table.date),
    index('namaz_inst_idx').on(table.institutionId),
  ]
);

export const healthRecords = pgTable(
  'health_records',
  {
    id: serial('id').primaryKey(),
    institutionId: integer('institution_id').references(() => institutions.id, { onDelete: 'cascade' }),
    studentId: integer('student_id')
      .references(() => students.id, { onDelete: 'cascade' })
      .notNull(),
    recordDate: text('record_date').notNull(),
    heightCm: numeric('height_cm'),
    weightKg: numeric('weight_kg'),
    temperatureC: numeric('temperature_c'),
    healthStatus: text('health_status').notNull().default('feeling_well'), // 'feeling_well' | 'feeling_unwell' | 'fever_reported' | 'other_concern' | 'healthy' | 'under_observation' | 'ill' | 'recovering'
    illnessInfo: text('illness_info'),
    medicationNotes: text('medication_notes'),
    followUpStatus: text('follow_up_status').notNull().default('none'), // 'none' | 'monitoring' | 'parent_notified' | 'urgent_contact_requested' | 'resolved'
    submittedByRole: text('submitted_by_role').notNull().default('staff'), // 'staff' | 'parent'
    parentUpdateNotes: text('parent_update_notes'),
    urgentAlertSent: boolean('urgent_alert_sent').notNull().default(false),
    restrictedAccess: boolean('restricted_access').notNull().default(true),
    recordedBy: integer('recorded_by').references(() => users.id, { onDelete: 'set null' }),
    createdAt: timestamp('created_at').defaultNow().notNull(),
    updatedAt: timestamp('updated_at').defaultNow().notNull(),
  },
  (table) => [
    index('health_student_idx').on(table.studentId),
    index('health_inst_idx').on(table.institutionId),
  ]
);

export const dailyActivities = pgTable(
  'daily_activities',
  {
    id: serial('id').primaryKey(),
    institutionId: integer('institution_id').references(() => institutions.id, { onDelete: 'cascade' }),
    studentId: integer('student_id')
      .references(() => students.id, { onDelete: 'cascade' })
      .notNull(),
    date: text('date').notNull(), // YYYY-MM-DD
    breakfastStatus: text('breakfast_status').notNull().default('not_recorded'), // 'taken' | 'not_taken' | 'not_applicable' | 'not_recorded' | 'partial' | 'skipped'
    lunchStatus: text('lunch_status').notNull().default('not_recorded'),
    eveningMealStatus: text('evening_meal_status').notNull().default('not_recorded'),
    dinnerStatus: text('dinner_status').notNull().default('not_recorded'),
    otherMealStatus: text('other_meal_status').notNull().default('not_recorded'),
    mealRemarks: text('meal_remarks'),
    homeworkCompleted: boolean('homework_completed').notNull().default(false),
    disciplineRating: integer('discipline_rating').notNull().default(5),
    deeniActivities: text('deeni_activities'),
    activityLogs: jsonb('activity_logs')
      .$type<Array<{ name: string; status: string; remarks?: string }>>()
      .notNull()
      .default([]),
    teacherRemarks: text('teacher_remarks'),
    parentRemarks: text('parent_remarks'),
    recordedBy: integer('recorded_by').references(() => users.id, { onDelete: 'set null' }),
    createdAt: timestamp('created_at').defaultNow().notNull(),
    updatedAt: timestamp('updated_at').defaultNow().notNull(),
  },
  (table) => [
    uniqueIndex('daily_activity_student_date_uidx').on(table.studentId, table.date),
    index('daily_activity_date_idx').on(table.date),
    index('daily_activity_inst_idx').on(table.institutionId),
  ]
);

export const homework = pgTable(
  'homework',
  {
    id: serial('id').primaryKey(),
    institutionId: integer('institution_id').references(() => institutions.id, { onDelete: 'cascade' }),
    title: text('title').notNull(),
    description: text('description').notNull(),
    classId: integer('class_id')
      .references(() => classes.id, { onDelete: 'cascade' })
      .notNull(),
    subjectId: integer('subject_id')
      .references(() => subjects.id, { onDelete: 'cascade' })
      .notNull(),
    teacherId: integer('teacher_id').references(() => users.id, { onDelete: 'set null' }),
    dueDate: text('due_date').notNull(),
    attachmentUrl: text('attachment_url'),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => [
    index('homework_class_idx').on(table.classId),
    index('homework_inst_idx').on(table.institutionId),
  ]
);

export const assignments = pgTable(
  'assignments',
  {
    id: serial('id').primaryKey(),
    institutionId: integer('institution_id').references(() => institutions.id, { onDelete: 'cascade' }),
    homeworkId: integer('homework_id')
      .references(() => homework.id, { onDelete: 'cascade' })
      .notNull(),
    studentId: integer('student_id')
      .references(() => students.id, { onDelete: 'cascade' })
      .notNull(),
    status: text('status').notNull().default('pending'), // 'pending' | 'submitted' | 'graded'
    submissionText: text('submission_text'),
    submittedAt: timestamp('submitted_at'),
    score: integer('score'),
    feedback: text('feedback'),
  },
  (table) => [
    uniqueIndex('assignment_hw_student_uidx').on(table.homeworkId, table.studentId),
    index('assignments_inst_idx').on(table.institutionId),
  ]
);

export interface ExamQuestionItem {
  id: string;
  type?: 'mcq' | 'true_false' | 'short_answer' | 'long_answer';
  question: string;
  options?: string[];
  correctIndex?: number;
  correctAnswerText?: string;
  marks: number;
}

export const exams = pgTable(
  'exams',
  {
    id: serial('id').primaryKey(),
    institutionId: integer('institution_id').references(() => institutions.id, { onDelete: 'cascade' }),
    title: text('title').notNull(),
    examType: text('exam_type').notNull().default('unit'), // 'unit' | 'midterm' | 'final' | 'online_quiz'
    classId: integer('class_id')
      .references(() => classes.id, { onDelete: 'cascade' })
      .notNull(),
    subjectId: integer('subject_id')
      .references(() => subjects.id, { onDelete: 'cascade' })
      .notNull(),
    examDate: text('exam_date').notNull(),
    startDate: text('start_date'),
    endDate: text('end_date'),
    totalMarks: integer('total_marks').notNull().default(100),
    passingMarks: integer('passing_marks').notNull().default(40),
    durationMinutes: integer('duration_minutes').notNull().default(60),
    isOnline: boolean('is_online').notNull().default(false),
    questionsJson: jsonb('questions_json').$type<ExamQuestionItem[]>().default([]),
    createdBy: integer('created_by').references(() => users.id, { onDelete: 'set null' }),
    createdAt: timestamp('created_at').defaultNow().notNull(),
    updatedAt: timestamp('updated_at').defaultNow().notNull(),
  },
  (table) => [
    index('exams_class_idx').on(table.classId),
    index('exams_inst_idx').on(table.institutionId),
  ]
);

export const testAttempts = pgTable(
  'test_attempts',
  {
    id: serial('id').primaryKey(),
    institutionId: integer('institution_id')
      .references(() => institutions.id, { onDelete: 'cascade' })
      .notNull(),
    examId: integer('exam_id')
      .references(() => exams.id, { onDelete: 'cascade' })
      .notNull(),
    studentId: integer('student_id')
      .references(() => students.id, { onDelete: 'cascade' })
      .notNull(),
    answersJson: jsonb('answers_json').$type<Record<string, any>>().notNull().default({}),
    questionScoresJson: jsonb('question_scores_json').$type<Record<string, number>>().notNull().default({}),
    objectiveScore: integer('objective_score').notNull().default(0),
    subjectiveScore: integer('subjective_score').notNull().default(0),
    totalScore: integer('total_score').notNull().default(0),
    status: text('status').notNull().default('evaluated'), // 'submitted_pending_review' | 'evaluated'
    teacherRemarks: text('teacher_remarks'),
    submittedAt: timestamp('submitted_at').defaultNow().notNull(),
    evaluatedBy: integer('evaluated_by').references(() => users.id, { onDelete: 'set null' }),
    evaluatedAt: timestamp('evaluated_at'),
  },
  (table) => [
    uniqueIndex('attempt_exam_student_uidx').on(table.examId, table.studentId),
    index('attempt_inst_idx').on(table.institutionId),
  ]
);

export const marks = pgTable(
  'marks',
  {
    id: serial('id').primaryKey(),
    institutionId: integer('institution_id').references(() => institutions.id, { onDelete: 'cascade' }),
    examId: integer('exam_id')
      .references(() => exams.id, { onDelete: 'cascade' })
      .notNull(),
    studentId: integer('student_id')
      .references(() => students.id, { onDelete: 'cascade' })
      .notNull(),
    obtainedMarks: integer('obtained_marks').notNull(),
    totalMarks: integer('total_marks').notNull(),
    grade: text('grade').notNull(),
    remarks: text('remarks'),
    gradedBy: integer('graded_by').references(() => users.id, { onDelete: 'set null' }),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => [
    uniqueIndex('marks_exam_student_uidx').on(table.examId, table.studentId),
    index('marks_inst_idx').on(table.institutionId),
  ]
);

export const fees = pgTable(
  'fees',
  {
    id: serial('id').primaryKey(),
    institutionId: integer('institution_id').references(() => institutions.id, { onDelete: 'cascade' }),
    studentId: integer('student_id')
      .references(() => students.id, { onDelete: 'cascade' })
      .notNull(),
    monthYear: text('month_year').notNull(), // e.g. '2026-11'
    title: text('title').notNull(),
    amount: integer('amount').notNull(),
    dueDate: text('due_date').notNull(),
    status: text('status').notNull().default('pending'), // 'paid' | 'pending' | 'overdue'
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => [
    index('fees_student_idx').on(table.studentId),
    index('fees_inst_idx').on(table.institutionId),
  ]
);

export const payments = pgTable(
  'payments',
  {
    id: serial('id').primaryKey(),
    institutionId: integer('institution_id').references(() => institutions.id, { onDelete: 'cascade' }),
    feeId: integer('fee_id')
      .references(() => fees.id, { onDelete: 'cascade' })
      .notNull(),
    studentId: integer('student_id')
      .references(() => students.id, { onDelete: 'cascade' })
      .notNull(),
    amountPaid: integer('amount_paid').notNull(),
    paymentMethod: text('payment_method').notNull().default('upi'), // 'upi' | 'card' | 'cash' | 'bank_transfer'
    transactionRef: text('transaction_ref').notNull(),
    receiptNo: text('receipt_no').notNull(),
    paidAt: timestamp('paid_at').defaultNow().notNull(),
    recordedBy: integer('recorded_by').references(() => users.id, { onDelete: 'set null' }),
  },
  (table) => [
    uniqueIndex('payments_inst_receipt_uidx').on(table.institutionId, table.receiptNo),
    index('payments_student_idx').on(table.studentId),
    index('payments_inst_idx').on(table.institutionId),
  ]
);

export const notifications = pgTable(
  'notifications',
  {
    id: serial('id').primaryKey(),
    institutionId: integer('institution_id').references(() => institutions.id, { onDelete: 'cascade' }),
    title: text('title').notNull(),
    message: text('message').notNull(),
    type: text('type').notNull().default('announcement'), // 'attendance' | 'homework' | 'exam' | 'namaz' | 'fee' | 'announcement' | 'health' | 'food' | 'live_class' | 'lesson' | 'message'
    targetRole: text('target_role').notNull().default('all'), // 'all' | 'admin' | 'teacher' | 'student' | 'parent'
    targetUserId: integer('target_user_id').references(() => users.id, { onDelete: 'cascade' }),
    isRead: boolean('is_read').notNull().default(false),
    createdBy: integer('created_by').references(() => users.id, { onDelete: 'set null' }),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => [
    index('notifications_role_idx').on(table.targetRole),
    index('notifications_inst_idx').on(table.institutionId),
  ]
);

export const notificationPreferences = pgTable(
  'notification_preferences',
  {
    id: serial('id').primaryKey(),
    institutionId: integer('institution_id')
      .references(() => institutions.id, { onDelete: 'cascade' })
      .notNull(),
    userId: integer('user_id')
      .references(() => users.id, { onDelete: 'cascade' })
      .notNull()
      .unique(),
    absentAlerts: boolean('absent_alerts').notNull().default(true),
    attendanceUpdates: boolean('attendance_updates').notNull().default(true),
    homeworkAlerts: boolean('homework_alerts').notNull().default(true),
    examAlerts: boolean('exam_alerts').notNull().default(true),
    liveClassAlerts: boolean('live_class_alerts').notNull().default(true),
    prayerUpdates: boolean('prayer_updates').notNull().default(true),
    foodUpdates: boolean('food_updates').notNull().default(true),
    healthAlerts: boolean('health_alerts').notNull().default(true),
    teacherMessages: boolean('teacher_messages').notNull().default(true),
    fcmConsentGranted: boolean('fcm_consent_granted').notNull().default(false),
    fcmToken: text('fcm_token'),
    deliveryStatus: text('delivery_status').notNull().default('in_app_only'), // 'in_app_only' | 'browser_granted' | 'fcm_registered' | 'permission_denied'
    updatedAt: timestamp('updated_at').defaultNow().notNull(),
  },
  (table) => [index('notif_pref_inst_idx').on(table.institutionId)]
);

export const teacherMessages = pgTable(
  'teacher_messages',
  {
    id: serial('id').primaryKey(),
    institutionId: integer('institution_id')
      .references(() => institutions.id, { onDelete: 'cascade' })
      .notNull(),
    studentId: integer('student_id')
      .references(() => students.id, { onDelete: 'cascade' })
      .notNull(),
    senderId: integer('sender_id')
      .references(() => users.id, { onDelete: 'cascade' })
      .notNull(),
    recipientId: integer('recipient_id').references(() => users.id, { onDelete: 'set null' }),
    senderRole: text('sender_role').notNull(),
    message: text('message').notNull(),
    isRead: boolean('is_read').notNull().default(false),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => [
    index('teacher_msg_inst_idx').on(table.institutionId),
    index('teacher_msg_student_idx').on(table.studentId),
  ]
);

export const studyMaterials = pgTable(
  'study_materials',
  {
    id: serial('id').primaryKey(),
    institutionId: integer('institution_id').references(() => institutions.id, { onDelete: 'cascade' }),
    title: text('title').notNull(),
    description: text('description'),
    classId: integer('class_id')
      .references(() => classes.id, { onDelete: 'cascade' })
      .notNull(),
    subjectId: integer('subject_id')
      .references(() => subjects.id, { onDelete: 'cascade' })
      .notNull(),
    materialType: text('material_type').notNull().default('pdf'), // 'pdf' | 'notes' | 'worksheet' | 'book'
    resourceUrl: text('resource_url').notNull(),
    uploadedBy: integer('uploaded_by').references(() => users.id, { onDelete: 'set null' }),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => [
    index('materials_class_idx').on(table.classId),
    index('materials_inst_idx').on(table.institutionId),
  ]
);

export const recordedLessons = pgTable(
  'recorded_lessons',
  {
    id: serial('id').primaryKey(),
    institutionId: integer('institution_id').references(() => institutions.id, { onDelete: 'cascade' }),
    title: text('title').notNull(),
    description: text('description'),
    chapter: text('chapter'),
    thumbnailUrl: text('thumbnail_url'),
    classId: integer('class_id')
      .references(() => classes.id, { onDelete: 'cascade' })
      .notNull(),
    subjectId: integer('subject_id')
      .references(() => subjects.id, { onDelete: 'cascade' })
      .notNull(),
    teacherId: integer('teacher_id').references(() => users.id, { onDelete: 'set null' }),
    lessonType: text('lesson_type').notNull().default('recorded'), // 'live' | 'recorded'
    provider: text('provider').notNull().default('jitsi_external'), // 'jitsi_external' | 'zoom_external' | 'google_meet_external' | 'secure_storage'
    accessScope: text('access_scope').notNull().default('enrolled_class'), // 'enrolled_class' | 'institution_all'
    videoUrl: text('video_url'),
    meetingLink: text('meeting_link'),
    scheduledAt: text('scheduled_at'),
    durationMinutes: integer('duration_minutes').notNull().default(40),
    createdAt: timestamp('created_at').defaultNow().notNull(),
    updatedAt: timestamp('updated_at').defaultNow().notNull(),
  },
  (table) => [
    index('lessons_class_idx').on(table.classId),
    index('lessons_inst_idx').on(table.institutionId),
  ]
);

export const liveClassAttendance = pgTable(
  'live_class_attendance',
  {
    id: serial('id').primaryKey(),
    institutionId: integer('institution_id')
      .references(() => institutions.id, { onDelete: 'cascade' })
      .notNull(),
    lessonId: integer('lesson_id')
      .references(() => recordedLessons.id, { onDelete: 'cascade' })
      .notNull(),
    studentId: integer('student_id')
      .references(() => students.id, { onDelete: 'cascade' })
      .notNull(),
    status: text('status').notNull().default('present'), // 'present' | 'absent' | 'joined'
    joinedAt: timestamp('joined_at').defaultNow().notNull(),
  },
  (table) => [
    uniqueIndex('live_att_lesson_student_uidx').on(table.lessonId, table.studentId),
    index('live_att_inst_idx').on(table.institutionId),
  ]
);

export const timetable = pgTable(
  'timetable',
  {
    id: serial('id').primaryKey(),
    institutionId: integer('institution_id').references(() => institutions.id, { onDelete: 'cascade' }),
    classId: integer('class_id')
      .references(() => classes.id, { onDelete: 'cascade' })
      .notNull(),
    dayOfWeek: text('day_of_week').notNull(), // 'Monday' .. 'Saturday'
    startTime: text('start_time').notNull(),
    endTime: text('end_time').notNull(),
    subjectId: integer('subject_id')
      .references(() => subjects.id, { onDelete: 'cascade' })
      .notNull(),
    teacherId: integer('teacher_id').references(() => users.id, { onDelete: 'set null' }),
    room: text('room'),
  },
  (table) => [
    index('timetable_class_idx').on(table.classId),
    index('timetable_inst_idx').on(table.institutionId),
  ]
);

export const admissions = pgTable(
  'admissions',
  {
    id: serial('id').primaryKey(),
    institutionId: integer('institution_id').references(() => institutions.id, { onDelete: 'cascade' }),
    applicantName: text('applicant_name').notNull(),
    dob: text('dob').notNull(),
    gender: text('gender').notNull().default('Male'),
    guardianName: text('guardian_name').notNull(),
    guardianPhone: text('guardian_phone').notNull(),
    guardianEmail: text('guardian_email'),
    desiredClass: text('desired_class').notNull(),
    previousEducation: text('previous_education'),
    address: text('address').notNull(),
    status: text('status').notNull().default('pending'), // 'pending' | 'reviewed' | 'accepted' | 'rejected'
    submittedAt: timestamp('submitted_at').defaultNow().notNull(),
  },
  (table) => [index('admissions_inst_idx').on(table.institutionId)]
);

export const notices = pgTable(
  'notices',
  {
    id: serial('id').primaryKey(),
    institutionId: integer('institution_id').references(() => institutions.id, { onDelete: 'cascade' }),
    title: text('title').notNull(),
    content: text('content').notNull(),
    category: text('category').notNull().default('General'),
    isPinned: boolean('is_pinned').notNull().default(false),
    authorId: integer('author_id').references(() => users.id, { onDelete: 'set null' }),
    publishedAt: timestamp('published_at').defaultNow().notNull(),
  },
  (table) => [index('notices_inst_idx').on(table.institutionId)]
);

export const websiteSettings = pgTable(
  'website_settings',
  {
    id: serial('id').primaryKey(),
    institutionId: integer('institution_id').references(() => institutions.id, { onDelete: 'cascade' }),
    key: text('key').notNull(),
    value: text('value').notNull(),
    updatedAt: timestamp('updated_at').defaultNow().notNull(),
  },
  (table) => [uniqueIndex('settings_inst_key_uidx').on(table.institutionId, table.key)]
);

export const auditLogs = pgTable(
  'audit_logs',
  {
    id: serial('id').primaryKey(),
    institutionId: integer('institution_id').references(() => institutions.id, { onDelete: 'cascade' }),
    userId: integer('user_id').references(() => users.id, { onDelete: 'set null' }),
    userEmail: text('user_email'),
    action: text('action').notNull(),
    entityType: text('entity_type').notNull(),
    entityId: text('entity_id'),
    details: text('details'),
    ipAddress: text('ip_address'),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => [
    index('audit_created_idx').on(table.createdAt),
    index('audit_inst_idx').on(table.institutionId),
  ]
);

// Relations
export const institutionsRelations = relations(institutions, ({ many, one }) => ({
  policy: one(institutionPolicies, { fields: [institutions.id], references: [institutionPolicies.institutionId] }),
  subscriptions: many(institutionSubscriptions),
  users: many(users),
  classes: many(classes),
  students: many(students),
}));

export const classesRelations = relations(classes, ({ one, many }) => ({
  institution: one(institutions, { fields: [classes.institutionId], references: [institutions.id] }),
  teacher: one(users, { fields: [classes.teacherId], references: [users.id] }),
  subjects: many(subjects),
  students: many(students),
}));

export const studentsRelations = relations(students, ({ one, many }) => ({
  institution: one(institutions, { fields: [students.institutionId], references: [institutions.id] }),
  user: one(users, { fields: [students.userId], references: [users.id] }),
  parent: one(users, { fields: [students.parentId], references: [users.id] }),
  classRoom: one(classes, { fields: [students.classId], references: [classes.id] }),
  attendance: many(attendance),
  namazRecords: many(namazRecords),
  healthRecords: many(healthRecords),
  dailyActivities: many(dailyActivities),
  marks: many(marks),
  fees: many(fees),
}));
