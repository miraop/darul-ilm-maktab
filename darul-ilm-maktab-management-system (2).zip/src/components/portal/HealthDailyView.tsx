import React, { useEffect, useState } from 'react';
import { Download, HeartPulse, ShieldAlert } from 'lucide-react';
import { useAuth } from '../../context/AuthContext.tsx';
import { t } from '../../i18n/translations.ts';
import { exportToExcel, exportToPdf } from '../../utils/exports.ts';

const MEAL_STATES = ['taken', 'not_taken', 'not_applicable', 'not_recorded'] as const;

export const HealthDailyView: React.FC = () => {
  const { user, lang, apiFetch } = useAuth();
  const [tab, setTab] = useState<'daily' | 'health'>('daily');
  const [students, setStudents] = useState<any[]>([]);
  const [dailyRows, setDailyRows] = useState<any[]>([]);
  const [healthRows, setHealthRows] = useState<any[]>([]);
  const [policy, setPolicy] = useState<any>(null);
  const [rangeMode, setRangeMode] = useState<'daily' | 'weekly' | 'monthly'>('daily');
  const [filterDate, setFilterDate] = useState(new Date().toISOString().slice(0, 10));
  const [notice, setNotice] = useState<string | null>(null);

  const canEdit = user?.role === 'admin' || user?.role === 'teacher';

  const [dailyForm, setDailyForm] = useState({
    studentId: '',
    date: new Date().toISOString().slice(0, 10),
    breakfastStatus: 'taken',
    lunchStatus: 'taken',
    eveningMealStatus: 'not_recorded',
    dinnerStatus: 'not_recorded',
    otherMealStatus: 'not_recorded',
    mealRemarks: '',
    homeworkCompleted: true,
    disciplineRating: 5,
    deeniActivities: '',
    teacherRemarks: '',
  });
  const [activityCheck, setActivityCheck] = useState<Record<string, { status: string; remarks: string }>>({});
  const [parentRemarkInputs, setParentRemarkInputs] = useState<Record<number, string>>({});

  const [healthForm, setHealthForm] = useState({
    studentId: '',
    recordDate: new Date().toISOString().slice(0, 10),
    heightCm: '',
    weightKg: '',
    temperatureC: '36.7',
    healthStatus: 'feeling_well',
    illnessInfo: '',
    medicationNotes: '',
    followUpStatus: 'monitoring',
    parentUpdateNotes: '',
    urgentAlertSent: false,
  });

  const loadAll = async () => {
    const [st, da, hl, pol] = await Promise.all([
      apiFetch('/api/students'),
      apiFetch('/api/daily-activities'),
      apiFetch('/api/health'),
      apiFetch('/api/institution-policy'),
    ]);
    setStudents(st || []);
    setDailyRows(da || []);
    setHealthRows(hl || []);
    setPolicy(pol || null);

    if ((st || []).length > 0 && !dailyForm.studentId) {
      setDailyForm((p) => ({ ...p, studentId: String(st[0].id) }));
      setHealthForm((p) => ({ ...p, studentId: String(st[0].id) }));
    }

    const customList: string[] = Array.isArray(pol?.customActivities) ? pol.customActivities : [];
    const initChecks: Record<string, { status: string; remarks: string }> = {};
    for (const act of customList) {
      initChecks[act] = { status: 'completed', remarks: '' };
    }
    setActivityCheck(initChecks);
  };

  useEffect(() => {
    loadAll();
  }, []);

  const studentMap = new Map(students.map((s) => [s.id, s]));

  const handleSaveDaily = async (e: React.FormEvent) => {
    e.preventDefault();
    const activityLogs = Object.entries(activityCheck).map(([name, val]) => ({
      name,
      status: val.status,
      remarks: val.remarks || undefined,
    }));

    const saved = await apiFetch('/api/daily-activities', {
      method: 'POST',
      body: JSON.stringify({
        ...dailyForm,
        activityLogs,
      }),
    });
    setDailyRows((prev) => [
      saved,
      ...prev.filter((r) => !(r.studentId === saved.studentId && r.date === saved.date)),
    ]);
    setNotice('5-Time Meal & Daily Activity record saved.');
  };

  const handleSaveParentRemark = async (recordId: number) => {
    const text = parentRemarkInputs[recordId] ?? '';
    const updated = await apiFetch(`/api/daily-activities/${recordId}/parent-remark`, {
      method: 'PATCH',
      body: JSON.stringify({ parentRemarks: text }),
    });
    setDailyRows((prev) => prev.map((r) => (r.id === recordId ? updated : r)));
    setNotice('Parent remark saved cleanly.');
  };

  const handleSaveHealth = async (e: React.FormEvent) => {
    e.preventDefault();
    const saved = await apiFetch('/api/health', {
      method: 'POST',
      body: JSON.stringify(healthForm),
    });
    setHealthRows((prev) => [saved, ...prev]);
    setHealthForm((p) => ({
      ...p,
      illnessInfo: '',
      medicationNotes: '',
      parentUpdateNotes: '',
      urgentAlertSent: false,
    }));
    setNotice(
      user?.role === 'parent'
        ? 'Parent health note submitted securely to Maktab administration.'
        : saved.urgentAlertSent
          ? 'Restricted health record saved & urgent parent contact notification sent.'
          : 'Restricted health record logged securely.'
    );
  };

  const handleEscalateUrgent = async (rec: any) => {
    const updated = await apiFetch(`/api/health/${rec.id}`, {
      method: 'PATCH',
      body: JSON.stringify({
        urgentAlertSent: true,
        followUpStatus: 'urgent_parent_contacted',
      }),
    });
    setHealthRows((prev) => prev.map((r) => (r.id === rec.id ? updated : r)));
    setNotice('Urgent parent contact notification dispatched and audit-logged.');
  };

  const handleToggleConsent = async (student: any) => {
    const updated = await apiFetch(`/api/students/${student.id}`, {
      method: 'PATCH',
      body: JSON.stringify({ parentalConsent: !student.parentalConsent }),
    });
    setStudents((prev) => prev.map((s) => (s.id === student.id ? updated : s)));
  };

  const filterByRange = (dateStr: string) => {
    if (rangeMode === 'daily') return dateStr === filterDate;
    const target = new Date(filterDate).getTime();
    const rowT = new Date(dateStr).getTime();
    const diffDays = (target - rowT) / 86400000;
    if (rangeMode === 'weekly') return diffDays >= 0 && diffDays <= 7;
    return dateStr.slice(0, 7) === filterDate.slice(0, 7);
  };

  const filteredDaily = dailyRows.filter((d) => filterByRange(d.date));

  const handleExportMeals = (format: 'pdf' | 'excel') => {
    const headers = ['Date', 'Student', 'Breakfast', 'Lunch', 'Evening', 'Dinner', 'Other', 'Remarks'];
    const rows = filteredDaily.map((d) => [
      d.date,
      studentMap.get(d.studentId)?.fullName || `#${d.studentId}`,
      t(lang, d.breakfastStatus),
      t(lang, d.lunchStatus),
      t(lang, d.eveningMealStatus || 'not_recorded'),
      t(lang, d.dinnerStatus),
      t(lang, d.otherMealStatus || 'not_recorded'),
      d.mealRemarks || d.teacherRemarks || '—',
    ]);
    if (format === 'pdf') {
      exportToPdf({ title: `5-Meal & Daily Care Report (${rangeMode.toUpperCase()})`, headers, rows, filename: `meals-${filterDate}` });
    } else {
      exportToExcel({ sheetName: 'Meals & Activities', headers, rows, filename: `meals-${filterDate}` });
    }
  };

  const customActivities: string[] = Array.isArray(policy?.customActivities) ? policy.customActivities : [];

  return (
    <div className="space-y-6">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div className="flex items-center gap-1 p-1 bg-white border border-emerald-900/10 rounded-xl self-start inline-flex">
          <button
            type="button"
            onClick={() => setTab('daily')}
            className={`px-4 py-2 text-xs font-semibold rounded-lg cursor-pointer whitespace-nowrap ${
              tab === 'daily' ? 'bg-emerald-800 text-white' : 'text-slate-600 hover:text-emerald-900'
            }`}
          >
            Daily Activities & 5-Time Meals
          </button>
          <button
            type="button"
            onClick={() => setTab('health')}
            className={`px-4 py-2 text-xs font-semibold rounded-lg cursor-pointer whitespace-nowrap ${
              tab === 'health' ? 'bg-emerald-800 text-white' : 'text-slate-600 hover:text-emerald-900'
            }`}
          >
            Restricted Health Monitoring
          </button>
        </div>

        {tab === 'daily' && (
          <div className="flex flex-wrap items-center gap-2">
            <input
              type="date"
              value={filterDate}
              onChange={(e) => setFilterDate(e.target.value)}
              className="rounded-xl border border-emerald-900/15 bg-white px-3 py-1.5 text-xs font-mono-num"
            />
            <div className="inline-flex items-center gap-1 bg-white border border-emerald-900/10 rounded-xl p-1">
              {(['daily', 'weekly', 'monthly'] as const).map((rm) => (
                <button
                  key={rm}
                  type="button"
                  onClick={() => setRangeMode(rm)}
                  className={`px-2.5 py-1 text-xs font-medium rounded-lg capitalize cursor-pointer ${
                    rangeMode === rm ? 'bg-emerald-800 text-white' : 'text-slate-600'
                  }`}
                >
                  {rm}
                </button>
              ))}
            </div>
            <button
              type="button"
              onClick={() => handleExportMeals('pdf')}
              className="px-3 py-1.5 text-xs font-semibold rounded-xl border border-emerald-800 text-emerald-900 hover:bg-emerald-50 inline-flex items-center gap-1 cursor-pointer"
            >
              <Download className="h-3.5 w-3.5" />
              <span>{t(lang, 'exportPdf')}</span>
            </button>
            <button
              type="button"
              onClick={() => handleExportMeals('excel')}
              className="px-3 py-1.5 text-xs font-semibold rounded-xl border border-slate-200 bg-white text-slate-700 hover:bg-slate-50 inline-flex items-center gap-1 cursor-pointer"
            >
              <Download className="h-3.5 w-3.5" />
              <span>{t(lang, 'exportExcel')}</span>
            </button>
          </div>
        )}
      </div>

      {notice && (
        <div className="rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-2.5 text-xs text-emerald-900">
          {notice}
        </div>
      )}

      {tab === 'daily' ? (
        <div className="space-y-6">
          {canEdit && (
            <form onSubmit={handleSaveDaily} className="bg-white border border-emerald-900/10 rounded-2xl p-6 space-y-4 text-xs">
              <h2 className="font-display text-lg font-bold text-slate-950">Log 5-Time Meals & Daily Activities</h2>
              <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-7 gap-3">
                <select
                  value={dailyForm.studentId}
                  onChange={(e) => setDailyForm({ ...dailyForm, studentId: e.target.value })}
                  className="sm:col-span-2 rounded-xl border border-slate-200 px-3 py-2 bg-white"
                >
                  {students.map((s) => (
                    <option key={s.id} value={s.id}>{s.fullName}</option>
                  ))}
                </select>
                <input
                  type="date"
                  value={dailyForm.date}
                  onChange={(e) => setDailyForm({ ...dailyForm, date: e.target.value })}
                  className="rounded-xl border border-slate-200 px-3 py-2 font-mono-num"
                />
                <select
                  value={dailyForm.breakfastStatus}
                  onChange={(e) => setDailyForm({ ...dailyForm, breakfastStatus: e.target.value })}
                  className="rounded-xl border border-slate-200 px-3 py-2 bg-white"
                >
                  {MEAL_STATES.map((m) => <option key={m} value={m}>{t(lang, 'breakfast')}: {t(lang, m)}</option>)}
                </select>
                <select
                  value={dailyForm.lunchStatus}
                  onChange={(e) => setDailyForm({ ...dailyForm, lunchStatus: e.target.value })}
                  className="rounded-xl border border-slate-200 px-3 py-2 bg-white"
                >
                  {MEAL_STATES.map((m) => <option key={m} value={m}>{t(lang, 'lunch')}: {t(lang, m)}</option>)}
                </select>
                <select
                  value={dailyForm.eveningMealStatus}
                  onChange={(e) => setDailyForm({ ...dailyForm, eveningMealStatus: e.target.value })}
                  className="rounded-xl border border-slate-200 px-3 py-2 bg-white"
                >
                  {MEAL_STATES.map((m) => <option key={m} value={m}>{t(lang, 'eveningMeal')}: {t(lang, m)}</option>)}
                </select>
                <select
                  value={dailyForm.dinnerStatus}
                  onChange={(e) => setDailyForm({ ...dailyForm, dinnerStatus: e.target.value })}
                  className="rounded-xl border border-slate-200 px-3 py-2 bg-white"
                >
                  {MEAL_STATES.map((m) => <option key={m} value={m}>{t(lang, 'dinner')}: {t(lang, m)}</option>)}
                </select>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                <select
                  value={dailyForm.otherMealStatus}
                  onChange={(e) => setDailyForm({ ...dailyForm, otherMealStatus: e.target.value })}
                  className="rounded-xl border border-slate-200 px-3 py-2 bg-white"
                >
                  {MEAL_STATES.map((m) => <option key={m} value={m}>{t(lang, 'otherMeal')}: {t(lang, m)}</option>)}
                </select>
                <input
                  type="text"
                  placeholder="Meal Remarks (e.g. Appetite, Tiffin notes)"
                  value={dailyForm.mealRemarks}
                  onChange={(e) => setDailyForm({ ...dailyForm, mealRemarks: e.target.value })}
                  className="rounded-xl border border-slate-200 px-3 py-2"
                />
                <input
                  type="text"
                  placeholder="Deeni Activities (e.g. Morning Adhkar, Surah Mulk)"
                  value={dailyForm.deeniActivities}
                  onChange={(e) => setDailyForm({ ...dailyForm, deeniActivities: e.target.value })}
                  className="rounded-xl border border-slate-200 px-3 py-2"
                />
                <input
                  type="text"
                  placeholder={t(lang, 'teacherRemarks')}
                  value={dailyForm.teacherRemarks}
                  onChange={(e) => setDailyForm({ ...dailyForm, teacherRemarks: e.target.value })}
                  className="rounded-xl border border-slate-200 px-3 py-2"
                />
              </div>

              {customActivities.length > 0 && (
                <div className="p-3.5 rounded-xl bg-[#FAFBF9] border border-emerald-900/10 space-y-2">
                  <div className="font-semibold text-slate-900">Institution Daily Activity Checklist</div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                    {customActivities.map((act) => (
                      <div key={act} className="flex items-center gap-2 bg-white p-2 rounded-lg border border-slate-200">
                        <span className="font-medium text-slate-800 flex-1 truncate">{act}</span>
                        <select
                          value={activityCheck[act]?.status || 'completed'}
                          onChange={(e) =>
                            setActivityCheck({
                              ...activityCheck,
                              [act]: { status: e.target.value, remarks: activityCheck[act]?.remarks || '' },
                            })
                          }
                          className="border border-slate-200 rounded px-2 py-1 text-[11px] bg-white"
                        >
                          <option value="completed">Completed</option>
                          <option value="partial">Partial</option>
                          <option value="needs_practice">Needs Practice</option>
                          <option value="not_applicable">Not Applicable</option>
                        </select>
                        <input
                          type="text"
                          placeholder="Note..."
                          value={activityCheck[act]?.remarks || ''}
                          onChange={(e) =>
                            setActivityCheck({
                              ...activityCheck,
                              [act]: { status: activityCheck[act]?.status || 'completed', remarks: e.target.value },
                            })
                          }
                          className="border border-slate-200 rounded px-2 py-1 text-[11px] w-24"
                        />
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-4">
                  <label className="inline-flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={dailyForm.homeworkCompleted}
                      onChange={(e) => setDailyForm({ ...dailyForm, homeworkCompleted: e.target.checked })}
                    />
                    <span>{t(lang, 'homeworkDone')}</span>
                  </label>
                  <label className="inline-flex items-center gap-1.5">
                    <span>{t(lang, 'discipline')}:</span>
                    <select
                      value={dailyForm.disciplineRating}
                      onChange={(e) => setDailyForm({ ...dailyForm, disciplineRating: Number(e.target.value) })}
                      className="border border-slate-200 rounded px-2 py-1 bg-white"
                    >
                      {[5, 4, 3, 2, 1].map((n) => (
                        <option key={n} value={n}>{n}/5</option>
                      ))}
                    </select>
                  </label>
                </div>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-semibold rounded-xl bg-emerald-800 hover:bg-emerald-900 text-white cursor-pointer"
                >
                  {t(lang, 'save')}
                </button>
              </div>
            </form>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredDaily.length === 0 ? (
              <div className="md:col-span-2 bg-white border border-emerald-900/10 rounded-2xl p-8 text-center text-xs text-slate-500">
                {t(lang, 'noRecords')}
              </div>
            ) : (
              filteredDaily.map((d) => (
                <div key={d.id} className="bg-white border border-emerald-900/10 rounded-2xl p-5 space-y-2.5 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-950 text-sm">
                      {studentMap.get(d.studentId)?.fullName || `Student #${d.studentId}`}
                    </span>
                    <span className="font-mono-num text-slate-500">{d.date}</span>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 bg-[#FAFBF9] p-2.5 rounded-xl border border-slate-100">
                    <div>{t(lang, 'breakfast')}: <strong>{t(lang, d.breakfastStatus)}</strong></div>
                    <div>{t(lang, 'lunch')}: <strong>{t(lang, d.lunchStatus)}</strong></div>
                    <div>{t(lang, 'eveningMeal')}: <strong>{t(lang, d.eveningMealStatus || 'not_recorded')}</strong></div>
                    <div>{t(lang, 'dinner')}: <strong>{t(lang, d.dinnerStatus)}</strong></div>
                    <div>{t(lang, 'otherMeal')}: <strong>{t(lang, d.otherMealStatus || 'not_recorded')}</strong></div>
                  </div>
                  {d.mealRemarks && <div className="text-slate-600"><strong>Meal Remarks:</strong> {d.mealRemarks}</div>}
                  <div className="flex items-center gap-3 text-emerald-800 font-medium">
                    <span>{t(lang, 'homeworkDone')}: {d.homeworkCompleted ? 'Yes' : 'Pending'}</span>
                    <span>·</span>
                    <span className="font-mono-num">{t(lang, 'discipline')}: {d.disciplineRating}/5</span>
                  </div>
                  {Array.isArray(d.activityLogs) && d.activityLogs.length > 0 && (
                    <div className="space-y-1 pt-1">
                      {d.activityLogs.map((al: any, idx: number) => (
                        <div key={idx} className="flex justify-between text-[11px] bg-slate-50 px-2.5 py-1.5 rounded-lg">
                          <span className="font-medium text-slate-800">{al.name}</span>
                          <span className="font-semibold text-emerald-800 uppercase">{al.status}{al.remarks ? ` · ${al.remarks}` : ''}</span>
                        </div>
                      ))}
                    </div>
                  )}
                  {d.deeniActivities && (
                    <p className="text-slate-700 bg-[#FAFBF9] p-2.5 rounded-lg border border-slate-100">
                      <strong>{t(lang, 'deeniActivities')}:</strong> {d.deeniActivities}
                    </p>
                  )}
                  {d.teacherRemarks && (
                    <p className="text-slate-600">
                      <strong>{t(lang, 'teacherRemarks')}:</strong> {d.teacherRemarks}
                    </p>
                  )}
                  {d.parentRemarks && (
                    <p className="text-emerald-900 bg-emerald-50/50 p-2 rounded-lg border border-emerald-200/70">
                      <strong>{t(lang, 'parentRemarks')}:</strong> {d.parentRemarks}
                    </p>
                  )}
                  {user?.role === 'parent' && (
                    <div className="flex gap-2 pt-1">
                      <input
                        type="text"
                        placeholder="Add parent reply or observation..."
                        value={parentRemarkInputs[d.id] ?? d.parentRemarks ?? ''}
                        onChange={(e) => setParentRemarkInputs({ ...parentRemarkInputs, [d.id]: e.target.value })}
                        className="flex-1 rounded-lg border border-slate-200 px-2.5 py-1.5 text-xs"
                      />
                      <button
                        type="button"
                        onClick={() => handleSaveParentRemark(d.id)}
                        className="px-3 py-1.5 rounded-lg bg-emerald-800 text-white font-semibold cursor-pointer"
                      >
                        Reply
                      </button>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        </div>
      ) : (
        <div className="space-y-6">
          <div className="rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-xs text-amber-950 space-y-1">
            <div className="flex items-center gap-2 font-semibold">
              <ShieldAlert className="h-4 w-4 text-amber-700 shrink-0" />
              <span>{t(lang, 'restrictedHealthNote')}</span>
            </div>
            {policy?.urgentHealthProtocol && (
              <div className="ps-6 text-[11px] text-amber-900">
                Urgent Protocol: {policy.urgentHealthProtocol}
              </div>
            )}
          </div>

          {user?.role === 'parent' && (
            <div className="bg-white border border-emerald-900/10 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3 text-xs">
              <span className="font-semibold text-slate-800">Parental Health & Privacy Consent Controls:</span>
              <div className="flex flex-wrap gap-3">
                {students.map((st) => (
                  <button
                    key={st.id}
                    type="button"
                    onClick={() => handleToggleConsent(st)}
                    className={`px-3 py-1.5 rounded-lg border font-medium cursor-pointer ${
                      st.parentalConsent
                        ? 'bg-emerald-50 border-emerald-300 text-emerald-900'
                        : 'bg-slate-50 border-slate-300 text-slate-600'
                    }`}
                  >
                    {st.fullName}: {st.parentalConsent ? 'Consent Active' : 'Consent Paused'}
                  </button>
                ))}
              </div>
            </div>
          )}

          {(canEdit || user?.role === 'parent') && (
            <form onSubmit={handleSaveHealth} className="bg-white border border-emerald-900/10 rounded-2xl p-6 space-y-4">
              <h2 className="font-display text-lg font-bold text-slate-950 flex items-center gap-2">
                <HeartPulse className="h-4 w-4 text-emerald-800" />
                <span>
                  {user?.role === 'parent' ? 'Submit Parent Health Update to Maktab' : 'Add Restricted Health Observation'}
                </span>
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-6 gap-3 text-xs">
                <select
                  value={healthForm.studentId}
                  onChange={(e) => setHealthForm({ ...healthForm, studentId: e.target.value })}
                  className="sm:col-span-2 rounded-xl border border-slate-200 px-3 py-2 bg-white"
                >
                  {students.map((s) => (
                    <option key={s.id} value={s.id}>{s.fullName}</option>
                  ))}
                </select>
                <input
                  type="date"
                  value={healthForm.recordDate}
                  onChange={(e) => setHealthForm({ ...healthForm, recordDate: e.target.value })}
                  className="rounded-xl border border-slate-200 px-3 py-2 font-mono-num"
                />
                <select
                  value={healthForm.healthStatus}
                  onChange={(e) => setHealthForm({ ...healthForm, healthStatus: e.target.value })}
                  className="rounded-xl border border-slate-200 px-3 py-2 bg-white"
                >
                  <option value="feeling_well">{t(lang, 'feeling_well')}</option>
                  <option value="feeling_unwell">{t(lang, 'feeling_unwell')}</option>
                  <option value="fever_reported">{t(lang, 'fever_reported')}</option>
                  <option value="other_concern">{t(lang, 'other_concern')}</option>
                </select>
                <input
                  type="number"
                  step="0.1"
                  placeholder="Temp (°C)"
                  value={healthForm.temperatureC}
                  onChange={(e) => setHealthForm({ ...healthForm, temperatureC: e.target.value })}
                  className="rounded-xl border border-slate-200 px-3 py-2"
                />
                <input
                  type="number"
                  step="0.1"
                  placeholder="Weight (kg)"
                  value={healthForm.weightKg}
                  onChange={(e) => setHealthForm({ ...healthForm, weightKg: e.target.value })}
                  className="rounded-xl border border-slate-200 px-3 py-2"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <input
                  type="text"
                  placeholder="Observation / Symptom / Allergy Note (not a medical diagnosis)"
                  value={healthForm.illnessInfo}
                  onChange={(e) => setHealthForm({ ...healthForm, illnessInfo: e.target.value })}
                  className="rounded-xl border border-slate-200 px-3 py-2"
                />
                {user?.role === 'parent' ? (
                  <input
                    type="text"
                    placeholder="Instructions for Ustads / Care Notes"
                    value={healthForm.parentUpdateNotes}
                    onChange={(e) => setHealthForm({ ...healthForm, parentUpdateNotes: e.target.value })}
                    className="rounded-xl border border-slate-200 px-3 py-2"
                  />
                ) : (
                  <input
                    type="text"
                    placeholder="Care & Rest Notes / Guardian Instructions"
                    value={healthForm.medicationNotes}
                    onChange={(e) => setHealthForm({ ...healthForm, medicationNotes: e.target.value })}
                    className="rounded-xl border border-slate-200 px-3 py-2"
                  />
                )}
              </div>

              <div className="flex flex-wrap items-center justify-between gap-3 text-xs">
                {canEdit && (
                  <label className="inline-flex items-center gap-2 text-red-700 font-semibold cursor-pointer">
                    <input
                      type="checkbox"
                      checked={healthForm.urgentAlertSent}
                      onChange={(e) => setHealthForm({ ...healthForm, urgentAlertSent: e.target.checked })}
                    />
                    <span>Send Urgent Parent Contact Escalation</span>
                  </label>
                )}
                <button type="submit" className="px-4 py-2 text-xs font-semibold rounded-xl bg-emerald-800 text-white cursor-pointer">
                  {t(lang, 'save')}
                </button>
              </div>
            </form>
          )}

          <div className="bg-white border border-emerald-900/10 rounded-2xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-start border-collapse text-xs">
                <thead>
                  <tr className="border-b border-slate-100 bg-slate-50/70 text-[11px] font-semibold text-slate-500">
                    <th className="py-3 px-4 text-start">Student</th>
                    <th className="py-3 px-4 text-start">Date & Source</th>
                    <th className="py-3 px-4 text-start">Vitals (W / Temp)</th>
                    <th className="py-3 px-4 text-start">{t(lang, 'healthStatus')}</th>
                    <th className="py-3 px-4 text-start">Observations & Follow-up</th>
                    {canEdit && <th className="py-3 px-4 text-end">Escalation</th>}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {healthRows.map((h) => (
                    <tr key={h.id}>
                      <td className="py-3 px-4 font-semibold text-slate-900">
                        {studentMap.get(h.studentId)?.fullName || `Student #${h.studentId}`}
                      </td>
                      <td className="py-3 px-4 text-slate-500">
                        <div className="font-mono-num">{h.recordDate}</div>
                        <div className="text-[10px] uppercase font-semibold text-slate-400">{h.submittedByRole || 'staff'}</div>
                      </td>
                      <td className="py-3 px-4 font-mono-num text-slate-700">
                        {h.weightKg || '—'} kg / {h.temperatureC || '—'} °C
                      </td>
                      <td className="py-3 px-4">
                        <span
                          className={`font-semibold ${
                            h.healthStatus === 'feeling_well' || h.healthStatus === 'healthy'
                              ? 'text-emerald-700'
                              : h.healthStatus === 'fever_reported' || h.healthStatus === 'ill'
                                ? 'text-red-600'
                                : 'text-amber-700'
                          }`}
                        >
                          {t(lang, h.healthStatus)}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-slate-600">
                        <div>{h.illnessInfo || 'No concern reported'}</div>
                        {h.medicationNotes && <div className="text-[11px] text-slate-500 mt-0.5">{h.medicationNotes}</div>}
                        {h.parentUpdateNotes && (
                          <div className="text-[11px] text-emerald-800 mt-0.5">Parent Note: {h.parentUpdateNotes}</div>
                        )}
                        <div className="text-[10px] text-slate-400 mt-0.5">
                          Follow-up: {h.followUpStatus || 'monitoring'}
                        </div>
                      </td>
                      {canEdit && (
                        <td className="py-3 px-4 text-end">
                          {h.urgentAlertSent ? (
                            <span className="text-[11px] font-semibold text-red-700">Urgent Alert Sent</span>
                          ) : (
                            <button
                              type="button"
                              onClick={() => handleEscalateUrgent(h)}
                              className="px-2.5 py-1 rounded-lg border border-red-200 text-red-700 hover:bg-red-50 text-[11px] font-semibold cursor-pointer whitespace-nowrap"
                            >
                              {t(lang, 'urgentContact')}
                            </button>
                          )}
                        </td>
                      )}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
