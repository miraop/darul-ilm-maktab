import bcrypt from 'bcryptjs';
import { and, count, eq, isNull, notInArray } from 'drizzle-orm';
import { db } from './index.ts';
import {
  admissions,
  assignments,
  attendance,
  auditLogs,
  classes,
  dailyActivities,
  enrollments,
  exams,
  fees,
  healthRecords,
  homework,
  institutionPolicies,
  institutions,
  marks,
  namazRecords,
  notices,
  notifications,
  payments,
  recordedLessons,
  roles,
  students,
  studyMaterials,
  subjects,
  syllabusTopics,
  teacherAttendance,
  teacherMessages,
  timetable,
  users,
  websiteSettings,
} from './schema.ts';
import { PLATFORM_OWNER_EMAIL, PLATFORM_OWNER_EMAILS } from '../middleware/auth.ts';

let seedPromise: Promise<void> | null = null;

export async function ensureSeeded(): Promise<void> {
  if (!seedPromise) {
    seedPromise = seedAndReconcileMultiTenant().catch((err) => {
      seedPromise = null;
      console.error('Seed/migration failed:', err);
    });
  }
  return seedPromise;
}

async function ensureDefaultRoles(): Promise<void> {
  const roleDefs = [
    {
      name: 'super_admin',
      displayName: 'Platform Owner / Super Admin',
      permissions: [
        'approve_institutions',
        'suspend_institutions',
        'provision_institution_admin',
        'view_platform_metrics',
        'view_platform_audit_logs',
        'enforce_tenant_isolation',
      ],
      description: 'Exclusive Platform Owner authority for approving institutions and governing multi-tenant security.',
    },
    {
      name: 'admin',
      displayName: 'Institution Admin / Principal',
      permissions: [
        'manage_users',
        'manage_classes',
        'manage_students',
        'manage_teachers',
        'manage_attendance',
        'manage_namaz',
        'view_health',
        'edit_health',
        'manage_fees',
        'manage_exams',
        'manage_settings',
        'view_audit_logs',
        'export_reports',
      ],
      description: 'Full institutional authority strictly scoped to their own approved Maktab workspace.',
    },
    {
      name: 'teacher',
      displayName: 'Ustad / Teacher',
      permissions: [
        'view_assigned_classes',
        'mark_attendance',
        'record_namaz',
        'update_syllabus',
        'assign_homework',
        'enter_marks',
        'update_daily_activity',
        'update_health_assigned',
        'send_parent_notifications',
      ],
      description: 'Scoped exclusively to assigned classes, subjects, and enrolled students within their institution.',
    },
    {
      name: 'student',
      displayName: 'Talib-e-Ilm / Student',
      permissions: [
        'view_own_profile',
        'view_own_attendance',
        'view_timetable',
        'submit_homework',
        'access_materials',
        'join_live_classes',
        'take_online_exams',
        'view_own_results',
      ],
      description: 'Student learning portal for classes, homework, live/recorded lessons, and online quizzes.',
    },
    {
      name: 'parent',
      displayName: 'Wali / Parent',
      permissions: [
        'view_linked_children',
        'view_child_attendance',
        'view_child_namaz',
        'view_child_academics',
        'view_child_health',
        'view_child_daily_activities',
        'pay_fees',
        'download_reports',
      ],
      description: 'Guardian portal strictly scoped to linked children and parental consent records.',
    },
  ];

  for (const r of roleDefs) {
    await db
      .insert(roles)
      .values(r)
      .onConflictDoUpdate({
        target: roles.name,
        set: {
          displayName: r.displayName,
          permissions: r.permissions,
          description: r.description,
        },
      });
  }
}

export async function provisionInstitutionSettings(institutionId: number, opts: {
  name: string;
  contactEmail?: string | null;
  contactPhone?: string | null;
  address?: string | null;
  tagline?: string;
}) {
  const defaults = [
    { key: 'maktab_name', value: opts.name },
    { key: 'tagline', value: opts.tagline || 'Harmonizing Deeni Taleem, Character Building, and Modern Academic Excellence' },
    { key: 'contact_phone', value: opts.contactPhone || '+91 11 2698 4410' },
    { key: 'contact_email', value: opts.contactEmail || 'office@maktab.edu' },
    { key: 'address', value: opts.address || 'Main Maktab Campus' },
    { key: 'academic_session', value: '2026-2027' },
  ];

  for (const d of defaults) {
    await db
      .insert(websiteSettings)
      .values({ institutionId, key: d.key, value: d.value, updatedAt: new Date() })
      .onConflictDoNothing();
  }
}

export async function provisionInstitutionPolicy(institutionId: number) {
  await db
    .insert(institutionPolicies)
    .values({
      institutionId,
      prayerTrackingEnabled: true,
      prayerShowToParents: true,
      prayerStaffRoles: ['admin', 'teacher'],
      prayerPolicyNote:
        'Prayer records are private devotional guidance logs. Unmarked entries remain Not Recorded, never ranked publicly, and never used for punitive labeling.',
      customActivities: [
        'Quran Reading',
        'Quran Memorization',
        'Revision',
        'Homework Completion',
        'Class Participation',
        'Reading Practice',
        'Sports and Physical Activities',
        'Personal Discipline',
      ],
      urgentHealthProtocol:
        'Notify parent/guardian immediately by phone and in-app urgent alert when fever or unwell concern is logged.',
      teacherPermissions: {
        canRecordAttendance: true,
        canRecordNamaz: true,
        canRecordMeals: true,
        canRecordHealth: true,
        canManageOnlineTests: true,
        canMessageParents: true,
      },
      updatedAt: new Date(),
    })
    .onConflictDoNothing();
}

async function seedAndReconcileMultiTenant(): Promise<void> {
  await ensureDefaultRoles();

  // 1. Ensure Platform Owner (Super Admin) exists & no other account holds super_admin
  const ownerHash = await bcrypt.hash('Sukura', 10);
  const existingOwner = await db
    .select()
    .from(users)
    .where(eq(users.email, PLATFORM_OWNER_EMAIL))
    .limit(1);

  let ownerId: number;
  if (existingOwner.length === 0) {
    const [createdOwner] = await db
      .insert(users)
      .values({
        uid: 'platform-owner-super-admin',
        email: PLATFORM_OWNER_EMAIL,
        passwordHash: ownerHash,
        name: 'Platform Owner (Super Admin)',
        role: 'super_admin',
        institutionId: null,
        phone: '+91 98110 00001',
        preferredLang: 'en',
        isActive: true,
        isDemo: false,
      })
      .onConflictDoUpdate({
        target: users.uid,
        set: {
          email: PLATFORM_OWNER_EMAIL,
          passwordHash: ownerHash,
          name: 'Platform Owner (Super Admin)',
          role: 'super_admin',
          institutionId: null,
          isActive: true,
          isDemo: false,
        },
      })
      .returning();
    ownerId = createdOwner.id;
  } else {
    const [updatedOwner] = await db
      .update(users)
      .set({
        role: 'super_admin',
        institutionId: null,
        isActive: true,
        ...(existingOwner[0].passwordHash ? {} : { passwordHash: ownerHash }),
      })
      .where(eq(users.id, existingOwner[0].id))
      .returning();
    ownerId = updatedOwner.id;
  }

  // Ensure secondary Platform Owner / Super Admin (kabeersuperadmin) exists
  const kabeerHash = await bcrypt.hash('kabeeradmin', 10);
  const existingKabeer = await db
    .select()
    .from(users)
    .where(eq(users.email, 'kabeersuperadmin'))
    .limit(1);

  if (existingKabeer.length === 0) {
    await db
      .insert(users)
      .values({
        uid: 'platform-owner-kabeer-super-admin',
        email: 'kabeersuperadmin',
        passwordHash: kabeerHash,
        name: 'Kabeer Super Admin',
        role: 'super_admin',
        institutionId: null,
        phone: '+91 98110 00001',
        preferredLang: 'en',
        isActive: true,
        isDemo: false,
      })
      .onConflictDoUpdate({
        target: users.uid,
        set: {
          email: 'kabeersuperadmin',
          passwordHash: kabeerHash,
          name: 'Kabeer Super Admin',
          role: 'super_admin',
          institutionId: null,
          isActive: true,
          isDemo: false,
        },
      });
  } else {
    await db
      .update(users)
      .set({
        role: 'super_admin',
        institutionId: null,
        isActive: true,
        passwordHash: kabeerHash,
      })
      .where(eq(users.id, existingKabeer[0].id));
  }

  // 2. Ensure Maktab A (Kabeer Sb Maktab & Academy) exists
  let maktabA = (await db.select().from(institutions).where(eq(institutions.slug, 'darul-ilm')).limit(1))[0];
  if (!maktabA) {
    const [createdA] = await db
      .insert(institutions)
      .values({
        name: 'Kabeer Sb Maktab & Academy',
        slug: 'darul-ilm',
        code: 'DI-001',
        city: 'New Delhi',
        contactEmail: 'admissions@darulilm.edu',
        contactPhone: '+91 11 2698 4410',
        address: 'Lane 4, Jamia Nagar Educational Campus, New Delhi 110025',
        status: 'approved',
        requestedAdminName: 'Maulana Abdul Kareem Nadwi',
        requestedAdminEmail: 'admin@darulilm.edu',
        approvedBy: ownerId,
        approvedAt: new Date(),
        subscriptionPlan: 'maktab_399',
        subscriptionAmount: 399,
        subscriptionStatus: 'active',
        subscriptionExpiresAt: new Date(Date.now() + 30 * 86400 * 1000),
      })
      .returning();
    maktabA = createdA;
  }

  // Strip super_admin from ALL non-owner customer accounts and assign them to Maktab A if unassigned
  await db
    .update(users)
    .set({ role: 'admin' })
    .where(and(eq(users.role, 'super_admin'), notInArray(users.email, [...PLATFORM_OWNER_EMAILS])));

  await db
    .update(users)
    .set({ institutionId: maktabA.id })
    .where(and(isNull(users.institutionId), notInArray(users.email, [...PLATFORM_OWNER_EMAILS])));

  // Backfill any pre-existing Maktab A rows where institutionId is NULL
  await Promise.all([
    db.update(classes).set({ institutionId: maktabA.id }).where(isNull(classes.institutionId)),
    db.update(subjects).set({ institutionId: maktabA.id }).where(isNull(subjects.institutionId)),
    db.update(students).set({ institutionId: maktabA.id }).where(isNull(students.institutionId)),
    db.update(enrollments).set({ institutionId: maktabA.id }).where(isNull(enrollments.institutionId)),
    db.update(attendance).set({ institutionId: maktabA.id }).where(isNull(attendance.institutionId)),
    db.update(namazRecords).set({ institutionId: maktabA.id }).where(isNull(namazRecords.institutionId)),
    db.update(healthRecords).set({ institutionId: maktabA.id }).where(isNull(healthRecords.institutionId)),
    db.update(dailyActivities).set({ institutionId: maktabA.id }).where(isNull(dailyActivities.institutionId)),
    db.update(homework).set({ institutionId: maktabA.id }).where(isNull(homework.institutionId)),
    db.update(assignments).set({ institutionId: maktabA.id }).where(isNull(assignments.institutionId)),
    db.update(exams).set({ institutionId: maktabA.id }).where(isNull(exams.institutionId)),
    db.update(marks).set({ institutionId: maktabA.id }).where(isNull(marks.institutionId)),
    db.update(fees).set({ institutionId: maktabA.id }).where(isNull(fees.institutionId)),
    db.update(payments).set({ institutionId: maktabA.id }).where(isNull(payments.institutionId)),
    db.update(notifications).set({ institutionId: maktabA.id }).where(isNull(notifications.institutionId)),
    db.update(studyMaterials).set({ institutionId: maktabA.id }).where(isNull(studyMaterials.institutionId)),
    db.update(recordedLessons).set({ institutionId: maktabA.id }).where(isNull(recordedLessons.institutionId)),
    db.update(timetable).set({ institutionId: maktabA.id }).where(isNull(timetable.institutionId)),
    db.update(admissions).set({ institutionId: maktabA.id }).where(isNull(admissions.institutionId)),
    db.update(notices).set({ institutionId: maktabA.id }).where(isNull(notices.institutionId)),
    db.update(websiteSettings).set({ institutionId: maktabA.id }).where(isNull(websiteSettings.institutionId)),
    db.update(auditLogs).set({ institutionId: maktabA.id }).where(isNull(auditLogs.institutionId)),
  ]);

  // 3. Seed Maktab A sample data ONLY if Maktab A has zero students
  const maktabAStudents = await db
    .select({ value: count() })
    .from(students)
    .where(eq(students.institutionId, maktabA.id));

  if ((maktabAStudents[0]?.value ?? 0) === 0) {
    await seedMaktabAData(maktabA.id);
  }
  await ensureMaktabAExtendedData(maktabA.id);

  const deletedInstLogs = await db
    .select({ id: auditLogs.id })
    .from(auditLogs)
    .where(eq(auditLogs.action, 'DELETE_INSTITUTION'))
    .limit(1);
  const allowDemoInstSeed = deletedInstLogs.length === 0;

  // 4. Ensure Maktab B (Al-Noor Maktab & Islamic Academy) exists with a FRESH, EMPTY workspace & separate Institution Admin
  let maktabB = (await db.select().from(institutions).where(eq(institutions.slug, 'al-noor')).limit(1))[0];
  if (!maktabB && allowDemoInstSeed) {
    const [createdB] = await db
      .insert(institutions)
      .values({
        name: 'Al-Noor Maktab & Islamic Academy',
        slug: 'al-noor',
        code: 'AN-002',
        city: 'Lucknow',
        contactEmail: 'admin@alnoor.edu',
        contactPhone: '+91 522 401 8820',
        address: 'Sector 7, Gomti Nagar, Lucknow 226010',
        status: 'approved',
        requestedAdminName: 'Ustaz Salman Farooqi',
        requestedAdminEmail: 'admin@alnoor.edu',
        approvedBy: ownerId,
        approvedAt: new Date(),
        subscriptionPlan: 'maktab_399',
        subscriptionAmount: 399,
        subscriptionStatus: 'active',
        subscriptionExpiresAt: new Date(Date.now() + 30 * 86400 * 1000),
      })
      .returning();
    maktabB = createdB;

    await provisionInstitutionSettings(maktabB.id, {
      name: maktabB.name,
      contactEmail: maktabB.contactEmail,
      contactPhone: maktabB.contactPhone,
      address: maktabB.address,
      tagline: 'Fresh Approved Maktab Workspace · Ready for Admissions & Classes',
    });
  }
  await provisionInstitutionPolicy(maktabA.id);
  if (maktabB) {
    await provisionInstitutionPolicy(maktabB.id);

    // Ensure Maktab B's Institution Admin account exists (role: 'admin', institutionId: maktabB.id)
    const existingAdminB = await db
      .select()
      .from(users)
      .where(eq(users.email, 'admin@alnoor.edu'))
      .limit(1);

    if (existingAdminB.length === 0) {
      const alNoorHash = await bcrypt.hash('AlNoorAdmin@2026', 10);
      await db.insert(users).values({
        uid: 'inst-admin-alnoor-001',
        email: 'admin@alnoor.edu',
        passwordHash: alNoorHash,
        name: 'Ustaz Salman Farooqi',
        role: 'admin',
        institutionId: maktabB.id,
        phone: '+91 98390 11220',
        preferredLang: 'en',
        specialization: 'Maktab Administration & Tajweed',
        qualification: 'Alimiyat & B.Ed',
        isActive: true,
        isDemo: false,
      });
    }
  }

  // 5. Ensure a sample pending institution onboarding request exists for Platform Owner approval workflow
  const pendingCheck = await db.select().from(institutions).where(eq(institutions.slug, 'al-huda')).limit(1);
  if (pendingCheck.length === 0 && allowDemoInstSeed) {
    const alHudaHash = await bcrypt.hash('AlHudaAdmin@2026', 10);
    await db.insert(institutions).values({
      name: 'Madrasa Al-Huda & Model Maktab',
      slug: 'al-huda',
      code: 'AH-003',
      city: 'Hyderabad',
      contactEmail: 'admin@alhuda.edu',
      contactPhone: '+91 40 2451 7790',
      address: 'Toli Chowki Educational Enclave, Hyderabad 500008',
      status: 'pending',
      requestedAdminName: 'Maulana Yusuf Siddiqui',
      requestedAdminEmail: 'admin@alhuda.edu',
      requestedAdminPasswordHash: alHudaHash,
    });
  }
}

async function seedMaktabAData(institutionId: number): Promise<void> {
  const adminHash = await bcrypt.hash('MaktabAdmin@2026', 10);
  const teacherHash = await bcrypt.hash('Teacher@2026', 10);
  const studentHash = await bcrypt.hash('Student@2026', 10);
  const parentHash = await bcrypt.hash('Parent@2026', 10);

  const insertedUsers = await db
    .insert(users)
    .values([
      {
        uid: 'demo-admin-001',
        email: 'admin@darulilm.edu',
        passwordHash: adminHash,
        name: 'Maulana Abdul Kareem Nadwi',
        role: 'admin',
        institutionId,
        phone: '+91 98110 24501',
        preferredLang: 'en',
        specialization: 'Educational Leadership & Fiqh',
        qualification: 'Fazilat & M.A. Islamic Studies',
        isActive: true,
        isDemo: true,
      },
      {
        uid: 'demo-teacher-001',
        email: 'teacher@darulilm.edu',
        passwordHash: teacherHash,
        name: 'Qari Tariq Mahmood',
        role: 'teacher',
        institutionId,
        phone: '+91 98110 24502',
        preferredLang: 'en',
        specialization: 'Tajweed, Hifz & Arabic',
        qualification: 'Qari Sabaa & B.Ed',
        isActive: true,
        isDemo: true,
      },
      {
        uid: 'demo-teacher-002',
        email: 'aisha.teacher@darulilm.edu',
        passwordHash: teacherHash,
        name: 'Ustaza Aisha Siddiqui',
        role: 'teacher',
        institutionId,
        phone: '+91 98110 24503',
        preferredLang: 'en',
        specialization: 'Mathematics, Science & Urdu',
        qualification: 'M.Sc. Mathematics & Alimah',
        isActive: true,
        isDemo: true,
      },
      {
        uid: 'demo-parent-001',
        email: 'parent@darulilm.edu',
        passwordHash: parentHash,
        name: 'Amina Begum',
        role: 'parent',
        institutionId,
        phone: '+91 98110 24504',
        preferredLang: 'en',
        isActive: true,
        isDemo: true,
      },
      {
        uid: 'demo-parent-002',
        email: 'imran.parent@darulilm.edu',
        passwordHash: parentHash,
        name: 'Imran Qureshi',
        role: 'parent',
        institutionId,
        phone: '+91 98110 24505',
        preferredLang: 'en',
        isActive: true,
        isDemo: true,
      },
      {
        uid: 'demo-student-001',
        email: 'student@darulilm.edu',
        passwordHash: studentHash,
        name: 'Zayd Ahmed',
        role: 'student',
        institutionId,
        phone: '+91 98110 24504',
        preferredLang: 'en',
        isActive: true,
        isDemo: true,
      },
      {
        uid: 'demo-student-002',
        email: 'fatima.student@darulilm.edu',
        passwordHash: studentHash,
        name: 'Fatima Zahra',
        role: 'student',
        institutionId,
        phone: '+91 98110 24504',
        preferredLang: 'en',
        isActive: true,
        isDemo: true,
      },
    ])
    .onConflictDoNothing()
    .returning();

  if (insertedUsers.length < 7) return;

  const [adminUser, teacher1, teacher2, parent1, parent2, studentUser1, studentUser2] = insertedUsers;

  const insertedClasses = await db
    .insert(classes)
    .values([
      {
        institutionId,
        name: 'Hifz & Nazra — Level 1',
        gradeLevel: 'Level 1',
        section: 'A',
        roomNumber: 'Hall 101',
        capacity: 25,
        academicYear: '2026-2027',
        teacherId: teacher1.id,
      },
      {
        institutionId,
        name: 'Primary Deeni & General — Grade 4',
        gradeLevel: 'Grade 4',
        section: 'B',
        roomNumber: 'Room 204',
        capacity: 30,
        academicYear: '2026-2027',
        teacherId: teacher2.id,
      },
      {
        institutionId,
        name: 'Middle Taleem — Grade 6',
        gradeLevel: 'Grade 6',
        section: 'A',
        roomNumber: 'Room 302',
        capacity: 30,
        academicYear: '2026-2027',
        teacherId: teacher1.id,
      },
    ])
    .returning();

  const [class1, class2, class3] = insertedClasses;

  const insertedSubjects = await db
    .insert(subjects)
    .values([
      {
        institutionId,
        name: 'Quran Tajweed & Hifz',
        code: 'QTJ-101',
        category: 'Deeni',
        classId: class1.id,
        teacherId: teacher1.id,
        syllabusTotalUnits: 30,
        syllabusCompletedUnits: 18,
        description: 'Makharij, rules of Noon Sakinah, and Juz Amma memorization.',
      },
      {
        institutionId,
        name: 'Fiqh, Seerah & Akhlaq',
        code: 'FQA-102',
        category: 'Deeni',
        classId: class1.id,
        teacherId: teacher1.id,
        syllabusTotalUnits: 16,
        syllabusCompletedUnits: 11,
        description: 'Essential rulings of Wudu, Salah, Prophetic biography, and Islamic manners.',
      },
      {
        institutionId,
        name: 'Urdu & Arabic Primer',
        code: 'UAP-103',
        category: 'Language',
        classId: class1.id,
        teacherId: teacher1.id,
        syllabusTotalUnits: 20,
        syllabusCompletedUnits: 14,
        description: 'Reading, Nastaliq writing, and foundational Arabic vocabulary.',
      },
      {
        institutionId,
        name: 'Mathematics',
        code: 'MTH-401',
        category: 'General',
        classId: class2.id,
        teacherId: teacher2.id,
        syllabusTotalUnits: 14,
        syllabusCompletedUnits: 9,
        description: 'Arithmetic, fractions, geometry, and problem solving.',
      },
      {
        institutionId,
        name: 'General Science & Hindi',
        code: 'SCH-402',
        category: 'General',
        classId: class2.id,
        teacherId: teacher2.id,
        syllabusTotalUnits: 12,
        syllabusCompletedUnits: 8,
        description: 'Natural sciences, hygiene, and Hindi comprehension.',
      },
      {
        institutionId,
        name: 'Deeniyaat & Tarjuma',
        code: 'DNY-601',
        category: 'Deeni',
        classId: class3.id,
        teacherId: teacher1.id,
        syllabusTotalUnits: 24,
        syllabusCompletedUnits: 15,
        description: 'Selected Surahs translation and Hadith sciences.',
      },
    ])
    .returning();

  const insertedStudents = await db
    .insert(students)
    .values([
      {
        institutionId,
        userId: studentUser1.id,
        admissionNo: 'DI-2026-001',
        fullName: 'Zayd Ahmed',
        dob: '2016-04-12',
        gender: 'Male',
        classId: class1.id,
        parentId: parent1.id,
        guardianName: 'Amina Begum',
        guardianPhone: '+91 98110 24504',
        address: '14 Jamia Nagar, Okhla, New Delhi',
        bloodGroup: 'B+',
        allergies: 'None',
        parentalConsent: true,
        status: 'active',
        admissionDate: '2026-04-01',
        isDemo: true,
      },
      {
        institutionId,
        userId: studentUser2.id,
        admissionNo: 'DI-2026-002',
        fullName: 'Fatima Zahra',
        dob: '2015-08-21',
        gender: 'Female',
        classId: class2.id,
        parentId: parent1.id,
        guardianName: 'Amina Begum',
        guardianPhone: '+91 98110 24504',
        address: '14 Jamia Nagar, Okhla, New Delhi',
        bloodGroup: 'O+',
        allergies: 'Mild dust sensitivity',
        parentalConsent: true,
        status: 'active',
        admissionDate: '2026-04-01',
        isDemo: true,
      },
      {
        institutionId,
        admissionNo: 'DI-2026-003',
        fullName: 'Hamza Qureshi',
        dob: '2016-01-15',
        gender: 'Male',
        classId: class1.id,
        parentId: parent2.id,
        guardianName: 'Imran Qureshi',
        guardianPhone: '+91 98110 24505',
        address: '28 Zakir Nagar, New Delhi',
        bloodGroup: 'A+',
        allergies: 'Peanuts',
        parentalConsent: true,
        status: 'active',
        admissionDate: '2026-04-03',
        isDemo: true,
      },
      {
        institutionId,
        admissionNo: 'DI-2026-004',
        fullName: 'Yusuf Ansari',
        dob: '2014-11-05',
        gender: 'Male',
        classId: class3.id,
        parentId: parent2.id,
        guardianName: 'Imran Qureshi',
        guardianPhone: '+91 98110 24505',
        address: '28 Zakir Nagar, New Delhi',
        bloodGroup: 'AB+',
        allergies: 'None',
        parentalConsent: true,
        status: 'active',
        admissionDate: '2026-04-05',
        isDemo: true,
      },
      {
        institutionId,
        admissionNo: 'DI-2026-005',
        fullName: 'Maryam Khan',
        dob: '2016-06-19',
        gender: 'Female',
        classId: class1.id,
        parentId: parent2.id,
        guardianName: 'Imran Qureshi',
        guardianPhone: '+91 98110 24505',
        address: '42 Abul Fazal Enclave, New Delhi',
        bloodGroup: 'O+',
        allergies: 'None',
        parentalConsent: true,
        status: 'active',
        admissionDate: '2026-04-10',
        isDemo: true,
      },
    ])
    .returning();

  const [st1, st2, st3, st4, st5] = insertedStudents;

  await db.insert(enrollments).values(
    insertedStudents.map((s) => ({
      institutionId,
      studentId: s.id,
      classId: s.classId!,
      academicYear: '2026-2027',
      status: 'enrolled',
    }))
  );

  const today = new Date().toISOString().slice(0, 10);
  const d1 = new Date(Date.now() - 86400000).toISOString().slice(0, 10);
  const d2 = new Date(Date.now() - 2 * 86400000).toISOString().slice(0, 10);
  const d3 = new Date(Date.now() - 3 * 86400000).toISOString().slice(0, 10);

  await db.insert(attendance).values([
    { institutionId, studentId: st1.id, classId: class1.id, date: today, status: 'present', remarks: 'On time for Fajr revision', recordedBy: teacher1.id },
    { institutionId, studentId: st3.id, classId: class1.id, date: today, status: 'present', remarks: 'Good participation', recordedBy: teacher1.id },
    { institutionId, studentId: st5.id, classId: class1.id, date: today, status: 'late', remarks: 'Arrived 10 mins late', recordedBy: teacher1.id },
    { institutionId, studentId: st2.id, classId: class2.id, date: today, status: 'present', remarks: 'Active in Math quiz', recordedBy: teacher2.id },
    { institutionId, studentId: st4.id, classId: class3.id, date: today, status: 'present', remarks: 'Present', recordedBy: teacher1.id },
    { institutionId, studentId: st1.id, classId: class1.id, date: d1, status: 'present', recordedBy: teacher1.id },
    { institutionId, studentId: st1.id, classId: class1.id, date: d2, status: 'present', recordedBy: teacher1.id },
    { institutionId, studentId: st1.id, classId: class1.id, date: d3, status: 'excused', remarks: 'Family medical visit', recordedBy: teacher1.id },
    { institutionId, studentId: st2.id, classId: class2.id, date: d1, status: 'present', recordedBy: teacher2.id },
    { institutionId, studentId: st2.id, classId: class2.id, date: d2, status: 'present', recordedBy: teacher2.id },
  ]);

  await db.insert(namazRecords).values([
    { institutionId, studentId: st1.id, date: today, fajr: 'performed', zuhr: 'performed', asr: 'performed', maghrib: 'not_recorded', isha: 'not_recorded', notes: 'Led Sunnah posture demonstration in Zuhr', recordedBy: teacher1.id },
    { institutionId, studentId: st1.id, date: d1, fajr: 'performed', zuhr: 'performed', asr: 'performed', maghrib: 'performed', isha: 'performed', notes: 'Consistent all five prayers', recordedBy: teacher1.id },
    { institutionId, studentId: st1.id, date: d2, fajr: 'not_performed', zuhr: 'performed', asr: 'performed', maghrib: 'performed', isha: 'not_recorded', notes: 'Woke slightly after Fajr', recordedBy: teacher1.id },
    { institutionId, studentId: st2.id, date: today, fajr: 'performed', zuhr: 'performed', asr: 'not_recorded', maghrib: 'not_recorded', isha: 'not_recorded', notes: 'Afternoon shift pending', recordedBy: teacher2.id },
    { institutionId, studentId: st3.id, date: today, fajr: 'performed', zuhr: 'performed', asr: 'performed', maghrib: 'not_recorded', isha: 'not_recorded', recordedBy: teacher1.id },
  ]);

  await db.insert(healthRecords).values([
    { institutionId, studentId: st1.id, recordDate: today, heightCm: '136', weightKg: '31.5', temperatureC: '36.7', healthStatus: 'healthy', illnessInfo: 'No active illness', medicationNotes: 'Routine seasonal wellness check completed.', restrictedAccess: true, recordedBy: teacher1.id },
    { institutionId, studentId: st2.id, recordDate: d1, heightCm: '142', weightKg: '34.0', temperatureC: '37.1', healthStatus: 'recovering', illnessInfo: 'Mild seasonal cold — recovering well', medicationNotes: 'Warm honey water & rest advised; parent informed.', restrictedAccess: true, recordedBy: teacher2.id },
    { institutionId, studentId: st3.id, recordDate: d2, heightCm: '134', weightKg: '30.2', temperatureC: '36.6', healthStatus: 'healthy', illnessInfo: 'Peanut allergy documented in kitchen card', medicationNotes: 'Strict nut-free meal tray protocol.', restrictedAccess: true, recordedBy: teacher1.id },
  ]);

  await db.insert(dailyActivities).values([
    { institutionId, studentId: st1.id, date: today, breakfastStatus: 'taken', lunchStatus: 'taken', dinnerStatus: 'not_recorded', homeworkCompleted: true, disciplineRating: 5, deeniActivities: 'Completed Surah Al-Mulk verses 1–15 revision & morning Adhkar', teacherRemarks: 'Respectful demeanor with peers; strong Tajweed clarity.', recordedBy: teacher1.id },
    { institutionId, studentId: st1.id, date: d1, breakfastStatus: 'taken', lunchStatus: 'partial', dinnerStatus: 'taken', homeworkCompleted: true, disciplineRating: 5, deeniActivities: 'Practiced Wudu Sunan steps and Dua after Adhan', teacherRemarks: 'Very attentive throughout both Deeni and Urdu sessions.', recordedBy: teacher1.id },
    { institutionId, studentId: st2.id, date: today, breakfastStatus: 'taken', lunchStatus: 'taken', dinnerStatus: 'not_recorded', homeworkCompleted: true, disciplineRating: 5, deeniActivities: 'Memorized 2 short Hadith on kindness to parents', teacherRemarks: 'Helpful in classroom organization.', recordedBy: teacher2.id },
  ]);

  const insertedHw = await db
    .insert(homework)
    .values([
      { institutionId, title: 'Surah Al-Mulk (Ayah 1–15) Tajweed Practice', description: 'Recite slowly applying Idgham and Ikhfa rules; submit brief audio reflection or written notes on Makharij.', classId: class1.id, subjectId: insertedSubjects[0].id, teacherId: teacher1.id, dueDate: new Date(Date.now() + 2 * 86400000).toISOString().slice(0, 10) },
      { institutionId, title: 'Five Pillars & Wudu Faraid Worksheet', description: 'List the 4 Faraid of Wudu and write 3 Sunnah etiquettes of entering the Masjid in Urdu or English.', classId: class1.id, subjectId: insertedSubjects[1].id, teacherId: teacher1.id, dueDate: new Date(Date.now() + 4 * 86400000).toISOString().slice(0, 10) },
      { institutionId, title: 'Fractions & Equivalent Ratios Exercise 4.2', description: 'Solve questions 1 to 10 from textbook chapter 4 with full working steps.', classId: class2.id, subjectId: insertedSubjects[3].id, teacherId: teacher2.id, dueDate: new Date(Date.now() + 3 * 86400000).toISOString().slice(0, 10) },
    ])
    .returning();

  await db.insert(assignments).values([
    { institutionId, homeworkId: insertedHw[0].id, studentId: st1.id, status: 'submitted', submissionText: 'Practiced verses 1-15 thrice with father after Maghrib. Focused on Ghunnah elongation.', submittedAt: new Date() },
    { institutionId, homeworkId: insertedHw[1].id, studentId: st1.id, status: 'pending' },
    { institutionId, homeworkId: insertedHw[2].id, studentId: st2.id, status: 'graded', submissionText: 'All 10 fraction problems solved and verified.', submittedAt: new Date(Date.now() - 86400000), score: 95, feedback: 'MashaAllah, neat and accurate steps!' },
  ]);

  const insertedExams = await db
    .insert(exams)
    .values([
      { institutionId, title: 'First Term Tajweed & Makharij Assessment', examType: 'midterm', classId: class1.id, subjectId: insertedSubjects[0].id, examDate: d3, totalMarks: 100, durationMinutes: 60, isOnline: false, createdBy: teacher1.id },
      {
        institutionId,
        title: 'Interactive Fiqh & Seerah MCQ Quiz',
        examType: 'online_quiz',
        classId: class1.id,
        subjectId: insertedSubjects[1].id,
        examDate: today,
        totalMarks: 20,
        durationMinutes: 15,
        isOnline: true,
        questionsJson: [
          { id: 'q1', question: 'How many obligatory (Fard) acts are there in Wudu according to standard Maktab Fiqh?', options: ['Three', 'Four', 'Five', 'Six'], correctIndex: 1, marks: 5 },
          { id: 'q2', question: 'Which prayer is performed immediately after sunset?', options: ['Asr', 'Zuhr', 'Maghrib', 'Isha'], correctIndex: 2, marks: 5 },
          { id: 'q3', question: 'What is the first revealed word of the Noble Quran?', options: ['Alhamdulillah', 'Iqra (Read)', 'Bismillah', 'SubhanAllah'], correctIndex: 1, marks: 5 },
          { id: 'q4', question: 'Which Surah is known as the heart of the Quran?', options: ['Surah Al-Fatihah', 'Surah Al-Ikhlas', 'Surah Yasin', 'Surah Al-Mulk'], correctIndex: 2, marks: 5 },
        ],
        createdBy: teacher1.id,
      },
      { institutionId, title: 'Grade 4 Mathematics Unit Test', examType: 'unit', classId: class2.id, subjectId: insertedSubjects[3].id, examDate: d2, totalMarks: 50, durationMinutes: 45, isOnline: false, createdBy: teacher2.id },
    ])
    .returning();

  await db.insert(marks).values([
    { institutionId, examId: insertedExams[0].id, studentId: st1.id, obtainedMarks: 92, totalMarks: 100, grade: 'A+', remarks: 'Excellent articulation of throat letters and calm recitation.', gradedBy: teacher1.id },
    { institutionId, examId: insertedExams[0].id, studentId: st3.id, obtainedMarks: 84, totalMarks: 100, grade: 'A', remarks: 'Very steady progress in Madd rules.', gradedBy: teacher1.id },
    { institutionId, examId: insertedExams[2].id, studentId: st2.id, obtainedMarks: 47, totalMarks: 50, grade: 'A+', remarks: 'Outstanding analytical clarity.', gradedBy: teacher2.id },
  ]);

  const insertedFees = await db
    .insert(fees)
    .values([
      { institutionId, studentId: st1.id, monthYear: '2026-10', title: 'October Tuition & Deeni Kit Fee', amount: 2200, dueDate: '2026-10-10', status: 'paid' },
      { institutionId, studentId: st1.id, monthYear: '2026-11', title: 'November Monthly Maktab Tuition', amount: 1800, dueDate: '2026-11-15', status: 'pending' },
      { institutionId, studentId: st2.id, monthYear: '2026-11', title: 'November Monthly Maktab & Science Lab Fee', amount: 2000, dueDate: '2026-11-15', status: 'paid' },
      { institutionId, studentId: st3.id, monthYear: '2026-11', title: 'November Monthly Maktab Tuition', amount: 1800, dueDate: '2026-11-15', status: 'pending' },
    ])
    .returning();

  await db.insert(payments).values([
    { institutionId, feeId: insertedFees[0].id, studentId: st1.id, amountPaid: 2200, paymentMethod: 'upi', transactionRef: 'UPI-20261008-9941', receiptNo: 'RCPT-2026-0001', recordedBy: parent1.id },
    { institutionId, feeId: insertedFees[2].id, studentId: st2.id, amountPaid: 2000, paymentMethod: 'card', transactionRef: 'CARD-20261104-4412', receiptNo: 'RCPT-2026-0002', recordedBy: parent1.id },
  ]);

  await db.insert(studyMaterials).values([
    { institutionId, title: 'Noorani Qaida & Tajweed Rules Compendium (PDF)', description: 'Illustrated guide to Makharij, Madd, and Noon Sakinah rules in Urdu and English.', classId: class1.id, subjectId: insertedSubjects[0].id, materialType: 'pdf', resourceUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf', uploadedBy: teacher1.id },
    { institutionId, title: 'Daily Masnoon Duas & Adab Workbook', description: 'Printable bilingual booklet with Arabic text, Hindi transliteration, and Urdu translation.', classId: class1.id, subjectId: insertedSubjects[1].id, materialType: 'book', resourceUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf', uploadedBy: teacher1.id },
    { institutionId, title: 'Grade 4 Fractions Practice Packet', description: 'Visual fraction worksheets and solved examples.', classId: class2.id, subjectId: insertedSubjects[3].id, materialType: 'worksheet', resourceUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf', uploadedBy: teacher2.id },
  ]);

  await db.insert(recordedLessons).values([
    { institutionId, title: 'Live Morning Hifz & Tajweed Revision Circle', description: 'Interactive live recitation review with Qari Tariq Mahmood.', classId: class1.id, subjectId: insertedSubjects[0].id, teacherId: teacher1.id, lessonType: 'live', meetingLink: 'https://meet.jit.si/darul-ilm-tajweed-level1', scheduledAt: `${today} 08:30`, durationMinutes: 45 },
    { institutionId, title: 'Lesson 04: Rules of Meem Sakinah & Practical Recitation', description: 'Recorded video lecture covering Ikhfa Shafawi, Idgham Shafawi, and Izhar Shafawi.', classId: class1.id, subjectId: insertedSubjects[0].id, teacherId: teacher1.id, lessonType: 'recorded', videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4', durationMinutes: 28 },
    { institutionId, title: 'Lesson 07: Understanding Equivalent Fractions', description: 'Step-by-step whiteboard lesson for Grade 4 Mathematics.', classId: class2.id, subjectId: insertedSubjects[3].id, teacherId: teacher2.id, lessonType: 'recorded', videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4', durationMinutes: 35 },
  ]);

  await db.insert(timetable).values([
    { institutionId, classId: class1.id, dayOfWeek: 'Monday', startTime: '08:00', endTime: '09:00', subjectId: insertedSubjects[0].id, teacherId: teacher1.id, room: 'Hall 101' },
    { institutionId, classId: class1.id, dayOfWeek: 'Monday', startTime: '09:15', endTime: '10:00', subjectId: insertedSubjects[1].id, teacherId: teacher1.id, room: 'Hall 101' },
    { institutionId, classId: class1.id, dayOfWeek: 'Tuesday', startTime: '08:00', endTime: '09:00', subjectId: insertedSubjects[2].id, teacherId: teacher1.id, room: 'Hall 101' },
    { institutionId, classId: class1.id, dayOfWeek: 'Wednesday', startTime: '08:00', endTime: '09:00', subjectId: insertedSubjects[0].id, teacherId: teacher1.id, room: 'Hall 101' },
    { institutionId, classId: class2.id, dayOfWeek: 'Monday', startTime: '08:00', endTime: '09:00', subjectId: insertedSubjects[3].id, teacherId: teacher2.id, room: 'Room 204' },
    { institutionId, classId: class2.id, dayOfWeek: 'Tuesday', startTime: '09:15', endTime: '10:15', subjectId: insertedSubjects[4].id, teacherId: teacher2.id, room: 'Room 204' },
  ]);

  await db.insert(notices).values([
    { institutionId, title: 'Admissions Open for Academic Session 2026–2027', content: 'Applications are invited for Nazra, Hifz-ul-Quran, and Primary Deeni & General Education streams. Parent orientation takes place every Saturday at 10:00 AM.', category: 'Admission', isPinned: true, authorId: adminUser.id },
    { institutionId, title: 'Winter Timetable & Fajr Revision Adjustment', content: 'Effective Monday, morning assembly begins at 7:45 AM. Please ensure students arrive comfortably with warm attire.', category: 'Schedule', isPinned: true, authorId: adminUser.id },
    { institutionId, title: 'Annual Qiraat & Seerah Quiz Competition', content: 'All students from Level 1 to Grade 6 are encouraged to register through their class Ustad before November 28.', category: 'Event', isPinned: false, authorId: adminUser.id },
  ]);

  await db.insert(notifications).values([
    { institutionId, title: 'November Fee Reminder', message: 'Monthly tuition for November 2026 is due by November 15. Instant digital receipts are available in the Parent Portal.', type: 'fee', targetRole: 'parent', createdBy: adminUser.id },
    { institutionId, title: 'New Tajweed Homework Assigned', message: 'Surah Al-Mulk (Ayah 1–15) Tajweed practice has been assigned for Hifz & Nazra Level 1.', type: 'homework', targetRole: 'student', createdBy: teacher1.id },
    { institutionId, title: 'Monthly Namaz & Daily Activity Summary Ready', message: 'Parents can now review five-times Namaz logs, meal records, and download monthly PDF progress reports.', type: 'namaz', targetRole: 'all', createdBy: adminUser.id },
  ]);

  await provisionInstitutionSettings(institutionId, {
    name: 'Kabeer Sb Maktab & Academy',
    contactPhone: '+91 11 2698 4410',
    contactEmail: 'admissions@darulilm.edu',
    address: 'Lane 4, Jamia Nagar Educational Campus, New Delhi 110025',
  });

  await db.insert(auditLogs).values([
    { institutionId, userId: adminUser.id, userEmail: adminUser.email, action: 'SYSTEM_SEED', entityType: 'database', details: 'Initialized demonstration Maktab A dataset (clearly tagged isDemo=true).' },
  ]);
}

async function ensureMaktabAExtendedData(institutionId: number): Promise<void> {
  const maktabStudents = await db.select().from(students).where(eq(students.institutionId, institutionId));
  const maktabSubjects = await db.select().from(subjects).where(eq(subjects.institutionId, institutionId));
  const maktabTeachers = await db
    .select()
    .from(users)
    .where(and(eq(users.institutionId, institutionId), eq(users.role, 'teacher')));
  const maktabAdmin = (
    await db
      .select()
      .from(users)
      .where(and(eq(users.institutionId, institutionId), eq(users.role, 'admin')))
      .limit(1)
  )[0];

  const today = new Date().toISOString().slice(0, 10);
  const d1 = new Date(Date.now() - 86400000).toISOString().slice(0, 10);

  // Enrich Maktab A student profile details where null
  const enrichMap: Record<string, { father: string; mother: string; emergency: string; medical?: string }> = {
    'DI-2026-001': {
      father: 'Tariq Ahmed',
      mother: 'Amina Begum',
      emergency: '+91 98110 24599',
      medical: 'No chronic conditions; routine vision check normal.',
    },
    'DI-2026-002': {
      father: 'Tariq Ahmed',
      mother: 'Amina Begum',
      emergency: '+91 98110 24599',
      medical: 'Mild dust sensitivity during dry weather.',
    },
    'DI-2026-003': {
      father: 'Imran Qureshi',
      mother: 'Zainab Qureshi',
      emergency: '+91 98110 24588',
      medical: 'Documented peanut allergy (epipen protocol on file).',
    },
    'DI-2026-004': {
      father: 'Imran Qureshi',
      mother: 'Zainab Qureshi',
      emergency: '+91 98110 24588',
    },
    'DI-2026-005': {
      father: 'Imran Qureshi',
      mother: 'Zainab Qureshi',
      emergency: '+91 98110 24588',
    },
  };

  for (const st of maktabStudents) {
    const info = enrichMap[st.admissionNo];
    if (info && (!st.fatherName || !st.motherName || !st.emergencyContact)) {
      await db
        .update(students)
        .set({
          fatherName: st.fatherName || info.father,
          motherName: st.motherName || info.mother,
          emergencyContact: st.emergencyContact || info.emergency,
          medicalNotes: st.medicalNotes || info.medical || null,
          updatedAt: new Date(),
        })
        .where(eq(students.id, st.id));
    }
  }

  // Seed detailed syllabusTopics for Maktab A if empty
  const existingSyllabus = await db
    .select({ value: count() })
    .from(syllabusTopics)
    .where(eq(syllabusTopics.institutionId, institutionId));
  if ((existingSyllabus[0]?.value ?? 0) === 0 && maktabSubjects.length > 0) {
    const findSub = (code: string) => maktabSubjects.find((s) => s.code === code);
    const qtj = findSub('QTJ-101');
    const fqa = findSub('FQA-102');
    const uap = findSub('UAP-103');
    const mth = findSub('MTH-401');
    const topicRows: any[] = [];

    if (qtj) {
      topicRows.push(
        {
          institutionId,
          classId: qtj.classId,
          subjectId: qtj.id,
          academicSession: '2026-2027',
          bookName: 'Noorani Qaida & Tajweed Primer',
          chapter: 'Chapter 1: Makharij-ul-Huruf',
          lesson: 'Throat, Tongue & Lip Articulation Points',
          totalTopics: 10,
          completedTopics: 10,
          status: 'completed',
          completionDate: d1,
          teacherRemarks: 'All students practiced articulation letters accurately.',
          updatedBy: qtj.teacherId,
        },
        {
          institutionId,
          classId: qtj.classId,
          subjectId: qtj.id,
          academicSession: '2026-2027',
          bookName: 'Tuhfat-ul-Atfal & Juz Amma',
          chapter: 'Chapter 2: Rules of Noon Sakinah & Tanween',
          lesson: 'Izhar, Idgham, Iqlab & Ikhfa Exercises',
          totalTopics: 20,
          completedTopics: 8,
          status: 'in_progress',
          teacherRemarks: 'Currently practicing Ikhfa elongation on Surah Al-Mulk.',
          updatedBy: qtj.teacherId,
        }
      );
    }
    if (fqa) {
      topicRows.push({
        institutionId,
        classId: fqa.classId,
        subjectId: fqa.id,
        academicSession: '2026-2027',
        bookName: 'Talim-ul-Islam Part 2',
        chapter: 'Chapter 3: Cleanliness & Five Daily Salah',
        lesson: 'Faraid & Sunan of Wudu and Salah Postures',
        totalTopics: 16,
        completedTopics: 11,
        status: 'in_progress',
        teacherRemarks: 'Practical Wudu assessment completed for Level 1.',
        updatedBy: fqa.teacherId,
      });
    }
    if (uap) {
      topicRows.push({
        institutionId,
        classId: uap.classId,
        subjectId: uap.id,
        academicSession: '2026-2027',
        bookName: 'Jadeed Urdu & Arabic Reader I',
        chapter: 'Chapter 4: Compound Letters & Vocabulary',
        lesson: 'Daily Home & Classroom Dialogue Phrases',
        totalTopics: 20,
        completedTopics: 14,
        status: 'in_progress',
        teacherRemarks: 'Good handwriting progress.',
        updatedBy: uap.teacherId,
      });
    }
    if (mth) {
      topicRows.push({
        institutionId,
        classId: mth.classId,
        subjectId: mth.id,
        academicSession: '2026-2027',
        bookName: 'Primary Mathematics Grade 4',
        chapter: 'Chapter 4: Equivalent Fractions & Ratios',
        lesson: 'Addition and Simplification of Mixed Fractions',
        totalTopics: 14,
        completedTopics: 9,
        status: 'in_progress',
        teacherRemarks: 'Class scored strongly in Exercise 4.1.',
        updatedBy: mth.teacherId,
      });
    }
    if (topicRows.length > 0) {
      await db.insert(syllabusTopics).values(topicRows);
    }
  }

  // Seed teacherAttendance if empty
  const existingTeacherAtt = await db
    .select({ value: count() })
    .from(teacherAttendance)
    .where(eq(teacherAttendance.institutionId, institutionId));
  if ((existingTeacherAtt[0]?.value ?? 0) === 0 && maktabTeachers.length > 0) {
    await db
      .insert(teacherAttendance)
      .values(
        maktabTeachers.map((t) => ({
          institutionId,
          teacherId: t.id,
          date: today,
          status: 'present',
          remarks: 'Morning assembly check-in verified',
          recordedBy: maktabAdmin?.id ?? t.id,
        }))
      )
      .onConflictDoNothing();
  }

  // Seed sample teacherMessages if empty
  const existingMsgs = await db
    .select({ value: count() })
    .from(teacherMessages)
    .where(eq(teacherMessages.institutionId, institutionId));
  const zayd = maktabStudents.find((s) => s.admissionNo === 'DI-2026-001');
  if ((existingMsgs[0]?.value ?? 0) === 0 && zayd && zayd.parentId && maktabTeachers.length > 0) {
    await db.insert(teacherMessages).values([
      {
        institutionId,
        studentId: zayd.id,
        senderId: maktabTeachers[0].id,
        recipientId: zayd.parentId,
        senderRole: 'teacher',
        message: 'Assalamu Alaikum! Zayd recited Surah Al-Mulk verses 1–15 with calm Makharij today. Please encourage 10 minutes of revision after Maghrib.',
        isRead: false,
      },
      {
        institutionId,
        studentId: zayd.id,
        senderId: zayd.parentId,
        recipientId: maktabTeachers[0].id,
        senderRole: 'parent',
        message: 'Wa Alaikum Assalam Ustad! JazakAllahu Khairan for the update, we will practice together tonight.',
        isRead: true,
      },
    ]);
  }

  // Backfill recordedLessons chapter metadata where null
  const lessons = await db.select().from(recordedLessons).where(eq(recordedLessons.institutionId, institutionId));
  for (const l of lessons) {
    if (!l.chapter) {
      await db
        .update(recordedLessons)
        .set({
          chapter: l.lessonType === 'live' ? 'Live Revision Circle' : 'Chapter 2: Core Concepts',
          provider: l.lessonType === 'live' ? 'jitsi_external' : 'secure_storage',
          accessScope: 'enrolled_class',
        })
        .where(eq(recordedLessons.id, l.id));
    }
  }
}
