import React, { useEffect, useState } from 'react';
import { Calendar, Download, Shield } from 'lucide-react';
import { useAuth } from '../../context/AuthContext.tsx';
import { t } from '../../i18n/translations.ts';
import { exportToExcel, exportToPdf } from '../../utils/exports.ts';

const PRAYERS = ['fajr', 'zuhr', 'asr', 'maghrib', 'isha'] as const;
type NamazState = 'performed' | 'not_performed' | 'not_recorded';

export const AttendanceNamazView: React.FC = () => {
  const { user, lang, apiFetch } = useAuth();
  const [subTab, setSubTab] = useState<'namaz' | 'attendance' | 'calendar' | 'teacher_attendance'>('namaz');
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().slice(0, 10));
  const [selectedMonth, setSelectedMonth] = useState(new Date().toISOString().slice(0, 7));
  const [rangeMode, setRangeMode] = useState<'daily' | 'weekly' | 'monthly'>('daily');
  const [classFilter, setClassFilter] = useState<string>('all');

  const [classes, setClasses] = useState<any[]>([]);
  const [students, setStudents] = useState<any[]>([]);
  const [attendanceRows, setAttendanceRows] = useState<any[]>([]);
  const [namazRows, setNamazRows] = useState<any[]>([]);
  const [policy, setPolicy] = useState<any>(null);
  const [calendarStudentId, setCalendarStudentId] = useState<string>('');

  // Teacher attendance state
  const [teachersRoster, setTeachersRoster] = useState<any[]>([]);
  const [teacherAttRows, setTeacherAttRows] = useState<any[]>([]);

  // Inline remarks state
  const [attRemarks, setAttRemarks] = useState<Record<number, string>>({});
  const [namazRemarks, setNamazRemarks] = useState<Record<number, string>>({});
  const [teacherRemarks, setTeacherRemarks] = useState<Record<number, string>>({});

  const [savingId, setSavingId] = useState<number | null>(null);
  const [feedback, setFeedback] = useState<string | null>(null);

  const isStudent = user?.role === 'student';
  const canEdit = user?.role === 'admin' || user?.role === 'teacher';
  const showTeacherTab = user?.role === 'admin' || user?.role === 'teacher';

  const loadData = async () => {
    const reqs: Promise<any>[] = [
      apiFetch('/api/classes'),
      apiFetch('/api/students'),
      apiFetch('/api/attendance'),
      apiFetch('/api/namaz'),
      apiFetch('/api/institution-policy'),
    ];
    if (showTeacherTab) {
      reqs.push(apiFetch('/api/teacher-attendance'));
    }
    const [cl, st, att, nmz, pol, trAtt] = await Promise.all(reqs);
    setClasses(cl || []);
    setStudents(st || []);
    setAttendanceRows(att || []);
    setNamazRows(nmz || []);
    setPolicy(pol || null);
    if ((st || []).length > 0 && !calendarStudentId) {
      setCalendarStudentId(String(st[0].id));
    }
    if (trAtt) {
      setTeachersRoster(trAtt.teachers || []);
      setTeacherAttRows(trAtt.records || []);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const filteredStudents =
    classFilter === 'all' ? students : students.filter((s) => String(s.classId) === classFilter);
  const studentMap = new Map(students.map((s) => [s.id, s]));
  const classMap = new Map(classes.map((c) => [c.id, c.name]));

  const getAttendanceFor = (studentId: number) =>
    attendanceRows.find((a) => a.studentId === studentId && a.date === selectedDate);

  const getNamazFor = (studentId: number) =>
    namazRows.find((n) => n.studentId === studentId && n.date === selectedDate) || {
      fajr: 'not_recorded',
      zuhr: 'not_recorded',
      asr: 'not_recorded',
      maghrib: 'not_recorded',
      isha: 'not_recorded',
      remarks: '',
    };

  const handleSaveAttendance = async (student: any, status: string) => {
    if (!canEdit) return;
    setSavingId(student.id);
    try {
      const saved = await apiFetch('/api/attendance', {
        method: 'POST',
        body: JSON.stringify({
          studentId: student.id,
          classId: student.classId,
          date: selectedDate,
          status,
          remarks: attRemarks[student.id] || getAttendanceFor(student.id)?.remarks || '',
        }),
      });
      setAttendanceRows((prev) => [
        saved,
        ...prev.filter((r) => !(r.studentId === student.id && r.date === selectedDate)),
      ]);
      setFeedback(`Attendance saved for ${student.fullName} (${t(lang, status)})`);
    } catch (err: any) {
      setFeedback(err.message);
    } finally {
      setSavingId(null);
    }
  };

  const handleUpdatePrayer = async (
    student: any,
    prayer: (typeof PRAYERS)[number] | 'remarks',
    state?: NamazState
  ) => {
    if (!canEdit) return;
    setSavingId(student.id);
    const current = getNamazFor(student.id);
    const payload = {
      studentId: student.id,
      date: selectedDate,
      fajr: prayer === 'fajr' && state ? state : current.fajr,
      zuhr: prayer === 'zuhr' && state ? state : current.zuhr,
      asr: prayer === 'asr' && state ? state : current.asr,
      maghrib: prayer === 'maghrib' && state ? state : current.maghrib,
      isha: prayer === 'isha' && state ? state : current.isha,
      remarks: namazRemarks[student.id] ?? current.remarks ?? '',
    };
    try {
      const saved = await apiFetch('/api/namaz', {
        method: 'POST',
        body: JSON.stringify(payload),
      });
      setNamazRows((prev) => [
        saved,
        ...prev.filter((r) => !(r.studentId === student.id && r.date === selectedDate)),
      ]);
      setFeedback(
        prayer === 'remarks'
          ? `Prayer note updated for ${student.fullName}`
          : `Updated ${prayer.toUpperCase()} for ${student.fullName}`
      );
    } catch (err: any) {
      setFeedback(err.message);
    } finally {
      setSavingId(null);
    }
  };

  const handleSaveTeacherAttendance = async (teacherId: number, status: 'present' | 'late' | 'absent' | 'leave') => {
    setSavingId(teacherId);
    try {
      const saved = await apiFetch('/api/teacher-attendance', {
        method: 'POST',
        body: JSON.stringify({
          teacherId,
          date: selectedDate,
          status,
          remarks: teacherRemarks[teacherId] || '',
        }),
      });
      setTeacherAttRows((prev) => [
        saved,
        ...prev.filter((r) => !(r.teacherId === teacherId && r.date === selectedDate)),
      ]);
      setFeedback(`Teacher attendance saved (${t(lang, status)})`);
    } catch (err: any) {
      setFeedback(err.message);
    } finally {
      setSavingId(null);
    }
  };

  // Range filtering
  const filterByRange = (dateStr: string) => {
    if (rangeMode === 'daily') return dateStr === selectedDate;
    const target = new Date(selectedDate).getTime();
    const rowT = new Date(dateStr).getTime();
    const diffDays = (target - rowT) / 86400000;
    if (rangeMode === 'weekly') return diffDays >= 0 && diffDays <= 7;
    return dateStr.slice(0, 7) === selectedDate.slice(0, 7);
  };

  const filteredNamazHistory = namazRows.filter(
    (r) =>
      filterByRange(r.date) &&
      (classFilter === 'all' || String(studentMap.get(r.studentId)?.classId) === classFilter)
  );

  const handleExport = (format: 'pdf' | 'excel') => {
    if (subTab === 'attendance' || subTab === 'calendar') {
      const attSlice = attendanceRows.filter(
        (r) =>
          filterByRange(r.date) &&
          (classFilter === 'all' || String(studentMap.get(r.studentId)?.classId) === classFilter)
      );
      const headers = ['Date', 'Student', 'Class', 'Status', 'Remarks'];
      const rows = attSlice.map((a) => [
        a.date,
        studentMap.get(a.studentId)?.fullName || `#${a.studentId}`,
        classMap.get(a.classId) || '—',
        t(lang, a.status),
        a.remarks || '—',
      ]);
      if (format === 'pdf') {
        exportToPdf({ title: `Attendance Report (${rangeMode.toUpperCase()})`, headers, rows, filename: `attendance-${selectedDate}` });
      } else {
        exportToExcel({ sheetName: 'Attendance', headers, rows, filename: `attendance-${selectedDate}` });
      }
      return;
    }

    const headers = ['Date', 'Student', 'Fajr', 'Zuhr', 'Asr', 'Maghrib', 'Isha', 'Remarks'];
    const rows = filteredNamazHistory.map((r) => [
      r.date,
      studentMap.get(r.studentId)?.fullName || `Student #${r.studentId}`,
      t(lang, r.fajr),
      t(lang, r.zuhr),
      t(lang, r.asr),
      t(lang, r.maghrib),
      t(lang, r.isha),
      r.remarks || r.notes || '',
    ]);
    if (format === 'pdf') {
      exportToPdf({
        title: `Five-Times Namaz Guidance Report (${rangeMode.toUpperCase()})`,
        subtitle: `Reference Date: ${selectedDate} · ${policy?.prayerPolicyNote || t(lang, 'namazNotice')}`,
        headers,
        rows,
        filename: `namaz-report-${selectedDate}`,
      });
    } else {
      exportToExcel({
        sheetName: 'Namaz Monitoring',
        headers,
        rows,
        filename: `namaz-report-${selectedDate}`,
      });
    }
  };

  const stateButtonStyle = (current: string, target: NamazState) => {
    const active = current === target;
    if (!active) return 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100';
    if (target === 'performed') return 'bg-emerald-700 text-white border-emerald-700';
    if (target === 'not_performed') return 'bg-red-600 text-white border-red-600';
    return 'bg-slate-600 text-white border-slate-600';
  };

  // Monthly Attendance Calendar Computations
  const monthDaysCount = (() => {
    const [yr, mo] = selectedMonth.split('-').map(Number);
    if (!yr || !mo) return 30;
    return new Date(yr, mo, 0).getDate();
  })();
  const calendarAttRows = attendanceRows.filter(
    (a) => String(a.studentId) === calendarStudentId && a.date.startsWith(selectedMonth)
  );
  const calendarAttMap = new Map(calendarAttRows.map((a) => [a.date, a]));
  const calPresent = calendarAttRows.filter((a) => a.status === 'present').length;
  const calLate = calendarAttRows.filter((a) => a.status === 'late').length;
  const calAbsent = calendarAttRows.filter((a) => a.status === 'absent').length;
  const calLeave = calendarAttRows.filter((a) => a.status === 'leave' || a.status === 'excused').length;
  const calTotal = calendarAttRows.length;
  const calRate = calTotal > 0 ? Math.round(((calPresent + calLate) / calTotal) * 100) : 0;

  return (
    <div className="space-y-6">
      <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-1 p-1 bg-white border border-emerald-900/10 rounded-xl self-start">
          <button
            type="button"
            onClick={() => setSubTab('namaz')}
            className={`px-3.5 py-2 text-xs font-semibold rounded-lg cursor-pointer whitespace-nowrap ${
              subTab === 'namaz' ? 'bg-emerald-800 text-white' : 'text-slate-600 hover:text-emerald-900'
            }`}
          >
            Five-Times Namaz
          </button>
          <button
            type="button"
            onClick={() => setSubTab('attendance')}
            className={`px-3.5 py-2 text-xs font-semibold rounded-lg cursor-pointer whitespace-nowrap ${
              subTab === 'attendance' ? 'bg-emerald-800 text-white' : 'text-slate-600 hover:text-emerald-900'
            }`}
          >
            Daily Attendance
          </button>
          <button
            type="button"
            onClick={() => setSubTab('calendar')}
            className={`px-3.5 py-2 text-xs font-semibold rounded-lg cursor-pointer whitespace-nowrap ${
              subTab === 'calendar' ? 'bg-emerald-800 text-white' : 'text-slate-600 hover:text-emerald-900'
            }`}
          >
            Monthly Calendar
          </button>
          {showTeacherTab && (
            <button
              type="button"
              onClick={() => setSubTab('teacher_attendance')}
              className={`px-3.5 py-2 text-xs font-semibold rounded-lg cursor-pointer whitespace-nowrap ${
                subTab === 'teacher_attendance' ? 'bg-emerald-800 text-white' : 'text-slate-600 hover:text-emerald-900'
              }`}
            >
              {t(lang, 'teacherAttendance')}
            </button>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {!isStudent && (
            <select
              value={classFilter}
              onChange={(e) => setClassFilter(e.target.value)}
              className="rounded-xl border border-emerald-900/15 bg-white px-3 py-1.5 text-xs"
            >
              <option value="all">{t(lang, 'all')} Classes</option>
              {classes.map((c) => (
                <option key={c.id} value={String(c.id)}>{c.name}</option>
              ))}
            </select>
          )}

          <div className="inline-flex items-center gap-2 bg-white border border-emerald-900/15 rounded-xl px-3 py-1.5">
            <Calendar className="h-4 w-4 text-emerald-800" />
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="text-xs font-mono-num focus:outline-none"
            />
          </div>
          <div className="inline-flex items-center gap-1 bg-white border border-emerald-900/10 rounded-xl p-1">
            {(['daily', 'weekly', 'monthly'] as const).map((rm) => (
              <button
                key={rm}
                type="button"
                onClick={() => setRangeMode(rm)}
                className={`px-2.5 py-1 text-xs font-medium rounded-lg capitalize cursor-pointer ${
                  rangeMode === rm ? 'bg-emerald-800 text-white' : 'text-slate-600'
                }`}
              >
                {rm}
              </button>
            ))}
          </div>
          <button
            type="button"
            onClick={() => handleExport('pdf')}
            className="px-3 py-2 text-xs font-semibold rounded-xl border border-emerald-800 text-emerald-900 hover:bg-emerald-50 inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
          >
            <Download className="h-3.5 w-3.5" />
            <span>{t(lang, 'exportPdf')}</span>
          </button>
          {!isStudent && (
            <button
              type="button"
              onClick={() => handleExport('excel')}
              className="px-3 py-2 text-xs font-semibold rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
            >
              <Download className="h-3.5 w-3.5" />
              <span>{t(lang, 'exportExcel')}</span>
            </button>
          )}
        </div>
      </div>

      {feedback && (
        <div className="rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-2.5 text-xs text-emerald-900">
          {feedback}
        </div>
      )}

      {subTab === 'namaz' && (
        <div className="space-y-4">
          <div className="rounded-xl border border-amber-200 bg-amber-50/70 px-4 py-3 text-xs text-amber-950 flex items-start gap-2.5">
            <Shield className="h-4 w-4 text-amber-700 shrink-0 mt-0.5" />
            <div>
              <div className="font-semibold">Institution Prayer Privacy Policy</div>
              <div>{policy?.prayerPolicyNote || t(lang, 'namazNotice')}</div>
            </div>
          </div>

          {!policy?.prayerTrackingEnabled ? (
            <div className="bg-white border border-emerald-900/10 rounded-2xl p-8 text-center text-xs text-slate-500">
              Prayer tracking is currently paused by your institution administrator.
            </div>
          ) : user?.role === 'parent' && !policy?.prayerShowToParents ? (
            <div className="bg-white border border-emerald-900/10 rounded-2xl p-8 text-center text-xs text-slate-500">
              Parent visibility for individual prayer logs is restricted by your institution policy.
            </div>
          ) : (
            <>
              <div className="bg-white border border-emerald-900/10 rounded-2xl overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-start border-collapse">
                    <thead>
                      <tr className="border-b border-slate-100 bg-slate-50/70 text-[11px] font-semibold text-slate-600">
                        <th className="py-3 px-4 text-start">Student ({selectedDate})</th>
                        {PRAYERS.map((p) => (
                          <th key={p} className="py-3 px-3 text-start">{t(lang, p)}</th>
                        ))}
                        <th className="py-3 px-3 text-start">Guidance Remarks</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-xs">
                      {filteredStudents.map((st) => {
                        const rec = getNamazFor(st.id);
                        return (
                          <tr key={st.id} className="hover:bg-emerald-50/20">
                            <td className="py-3.5 px-4">
                              <div className="font-semibold text-slate-900">{st.fullName}</div>
                              <div className="text-[11px] font-mono-num text-slate-500">{st.admissionNo}</div>
                            </td>
                            {PRAYERS.map((p) => {
                              const val: NamazState = rec[p] || 'not_recorded';
                              return (
                                <td key={p} className="py-3.5 px-3">
                                  {canEdit ? (
                                    <div className="flex flex-col gap-1 min-w-[112px]">
                                      <button
                                        type="button"
                                        disabled={savingId === st.id}
                                        onClick={() => handleUpdatePrayer(st, p, 'performed')}
                                        className={`px-2 py-1 text-[11px] font-medium rounded-md border text-start cursor-pointer ${stateButtonStyle(val, 'performed')}`}
                                      >
                                        {t(lang, 'performed')}
                                      </button>
                                      <button
                                        type="button"
                                        disabled={savingId === st.id}
                                        onClick={() => handleUpdatePrayer(st, p, 'not_performed')}
                                        className={`px-2 py-1 text-[11px] font-medium rounded-md border text-start cursor-pointer ${stateButtonStyle(val, 'not_performed')}`}
                                      >
                                        {t(lang, 'not_performed')}
                                      </button>
                                      <button
                                        type="button"
                                        disabled={savingId === st.id}
                                        onClick={() => handleUpdatePrayer(st, p, 'not_recorded')}
                                        className={`px-2 py-1 text-[11px] font-medium rounded-md border text-start cursor-pointer ${stateButtonStyle(val, 'not_recorded')}`}
                                      >
                                        {t(lang, 'not_recorded')}
                                      </button>
                                    </div>
                                  ) : (
                                    <span
                                      className={`font-semibold ${
                                        val === 'performed' ? 'text-emerald-700' : val === 'not_performed' ? 'text-red-600' : 'text-slate-500'
                                      }`}
                                    >
                                      {t(lang, val)}
                                    </span>
                                  )}
                                </td>
                              );
                            })}
                            <td className="py-3.5 px-3 min-w-[180px]">
                              {canEdit ? (
                                <div className="flex gap-1.5">
                                  <input
                                    type="text"
                                    placeholder="Optional note..."
                                    value={namazRemarks[st.id] ?? rec.remarks ?? ''}
                                    onChange={(e) => setNamazRemarks({ ...namazRemarks, [st.id]: e.target.value })}
                                    className="w-full rounded-lg border border-slate-200 px-2 py-1 text-[11px]"
                                  />
                                  <button
                                    type="button"
                                    onClick={() => handleUpdatePrayer(st, 'remarks')}
                                    className="px-2 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-[11px] font-medium cursor-pointer"
                                  >
                                    Save
                                  </button>
                                </div>
                              ) : (
                                <span className="text-slate-600">{rec.remarks || rec.notes || '—'}</span>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Privacy-Safe Range Summary (No leaderboards or public scores) */}
              <div className="bg-white border border-emerald-900/10 rounded-2xl p-5">
                <h3 className="font-display text-base font-bold text-slate-950 mb-3">
                  {rangeMode.charAt(0).toUpperCase() + rangeMode.slice(1)} Private Prayer Log ({filteredNamazHistory.length} entries)
                </h3>
                <div className="overflow-x-auto">
                  <table className="w-full text-xs text-start">
                    <thead>
                      <tr className="border-b border-slate-100 text-slate-500">
                        <th className="py-2 px-3 text-start">Date</th>
                        <th className="py-2 px-3 text-start">Student</th>
                        {PRAYERS.map((p) => (
                          <th key={p} className="py-2 px-3 text-start">{t(lang, p)}</th>
                        ))}
                        <th className="py-2 px-3 text-start">Remarks</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {filteredNamazHistory.map((r) => (
                        <tr key={r.id}>
                          <td className="py-2 px-3 font-mono-num text-slate-600">{r.date}</td>
                          <td className="py-2 px-3 font-medium text-slate-900">
                            {studentMap.get(r.studentId)?.fullName || `#${r.studentId}`}
                          </td>
                          {PRAYERS.map((p) => (
                            <td
                              key={p}
                              className={`py-2 px-3 font-medium ${
                                r[p] === 'performed' ? 'text-emerald-700' : r[p] === 'not_performed' ? 'text-red-600' : 'text-slate-400'
                              }`}
                            >
                              {t(lang, r[p])}
                            </td>
                          ))}
                          <td className="py-2 px-3 text-slate-500">{r.remarks || r.notes || '—'}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </>
          )}
        </div>
      )}

      {subTab === 'attendance' && (
        <div className="bg-white border border-emerald-900/10 rounded-2xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-start border-collapse">
              <thead>
                <tr className="border-b border-slate-100 bg-slate-50/70 text-[11px] font-semibold text-slate-600">
                  <th className="py-3 px-4 text-start">Student</th>
                  <th className="py-3 px-4 text-start">Class</th>
                  <th className="py-3 px-4 text-start">Date</th>
                  <th className="py-3 px-4 text-start">Status</th>
                  {canEdit && <th className="py-3 px-4 text-start">Remarks</th>}
                  {canEdit && <th className="py-3 px-4 text-end">Mark Attendance</th>}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-xs">
                {filteredStudents.map((st) => {
                  const rec = getAttendanceFor(st.id);
                  const currentStatus = rec?.status || 'not_recorded';
                  return (
                    <tr key={st.id}>
                      <td className="py-3.5 px-4">
                        <div className="font-semibold text-slate-900">{st.fullName}</div>
                        <div className="text-[11px] font-mono-num text-slate-500">{st.admissionNo}</div>
                      </td>
                      <td className="py-3.5 px-4 text-slate-600">{classMap.get(st.classId) || '—'}</td>
                      <td className="py-3.5 px-4 font-mono-num text-slate-600">{selectedDate}</td>
                      <td className="py-3.5 px-4">
                        <span
                          className={`font-semibold ${
                            currentStatus === 'present'
                              ? 'text-emerald-700'
                              : currentStatus === 'absent'
                                ? 'text-red-600'
                                : currentStatus === 'late'
                                  ? 'text-amber-700'
                                  : 'text-slate-600'
                          }`}
                        >
                          {t(lang, currentStatus)}
                        </span>
                      </td>
                      {canEdit && (
                        <td className="py-3.5 px-4">
                          <input
                            type="text"
                            placeholder="Note..."
                            value={attRemarks[st.id] ?? rec?.remarks ?? ''}
                            onChange={(e) => setAttRemarks({ ...attRemarks, [st.id]: e.target.value })}
                            className="rounded-lg border border-slate-200 px-2.5 py-1 text-xs w-36"
                          />
                        </td>
                      )}
                      {canEdit && (
                        <td className="py-3.5 px-4 text-end">
                          <div className="inline-flex flex-wrap gap-1.5 justify-end">
                            {(['present', 'late', 'absent', 'leave'] as const).map((status) => (
                              <button
                                key={status}
                                type="button"
                                disabled={savingId === st.id}
                                onClick={() => handleSaveAttendance(st, status)}
                                className={`px-2.5 py-1 rounded-lg text-[11px] font-medium border cursor-pointer ${
                                  currentStatus === status || (status === 'leave' && currentStatus === 'excused')
                                    ? 'bg-emerald-800 text-white border-emerald-800'
                                    : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                                }`}
                              >
                                {t(lang, status)}
                              </button>
                            ))}
                          </div>
                        </td>
                      )}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {subTab === 'calendar' && (
        <div className="bg-white border border-emerald-900/10 rounded-2xl p-6 space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
            <div>
              <h2 className="font-display text-lg font-bold text-slate-950">Monthly Student Attendance Calendar</h2>
              <p className="text-xs text-slate-500">Color-coded monthly log preventing unmarked dates from showing as absent.</p>
            </div>
            <div className="flex flex-wrap gap-2.5 text-xs items-center">
              {!isStudent ? (
                <select
                  value={calendarStudentId}
                  onChange={(e) => setCalendarStudentId(e.target.value)}
                  className="rounded-xl border border-slate-200 px-3 py-1.5 bg-white"
                >
                  {students.map((s) => (
                    <option key={s.id} value={String(s.id)}>{s.fullName} ({s.admissionNo})</option>
                  ))}
                </select>
              ) : (
                students[0] && (
                  <span className="px-3 py-1.5 rounded-xl bg-emerald-50 border border-emerald-200 font-semibold text-emerald-900">
                    {students[0].fullName} ({students[0].admissionNo})
                  </span>
                )
              )}
              <input
                type="month"
                value={selectedMonth}
                onChange={(e) => setSelectedMonth(e.target.value)}
                className="rounded-xl border border-slate-200 px-3 py-1.5 font-mono-num"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 text-xs">
            <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200">
              <div className="text-slate-500">Attendance Rate</div>
              <div className="font-mono-num text-xl font-bold text-emerald-900 mt-0.5">{calRate}%</div>
            </div>
            <div className="p-3.5 rounded-xl border border-slate-200">
              <div className="text-slate-500">{t(lang, 'present')}</div>
              <div className="font-mono-num text-xl font-bold text-emerald-700 mt-0.5">{calPresent}</div>
            </div>
            <div className="p-3.5 rounded-xl border border-slate-200">
              <div className="text-slate-500">{t(lang, 'late')}</div>
              <div className="font-mono-num text-xl font-bold text-amber-700 mt-0.5">{calLate}</div>
            </div>
            <div className="p-3.5 rounded-xl border border-slate-200">
              <div className="text-slate-500">{t(lang, 'absent')}</div>
              <div className="font-mono-num text-xl font-bold text-red-600 mt-0.5">{calAbsent}</div>
            </div>
            <div className="p-3.5 rounded-xl border border-slate-200">
              <div className="text-slate-500">{t(lang, 'leave')}</div>
              <div className="font-mono-num text-xl font-bold text-slate-700 mt-0.5">{calLeave}</div>
            </div>
          </div>

          <div className="grid grid-cols-4 sm:grid-cols-7 gap-2 text-xs">
            {Array.from({ length: monthDaysCount }, (_, idx) => {
              const dayStr = String(idx + 1).padStart(2, '0');
              const fullDate = `${selectedMonth}-${dayStr}`;
              const rec = calendarAttMap.get(fullDate);
              const status = rec?.status;
              const style =
                status === 'present'
                  ? 'bg-emerald-50 border-emerald-300 text-emerald-900'
                  : status === 'late'
                    ? 'bg-amber-50 border-amber-300 text-amber-900'
                    : status === 'absent'
                      ? 'bg-red-50 border-red-300 text-red-900'
                      : status === 'leave' || status === 'excused'
                        ? 'bg-slate-100 border-slate-300 text-slate-800'
                        : 'bg-[#FAFBF9] border-slate-200 text-slate-400';
              return (
                <div key={fullDate} className={`p-2.5 rounded-xl border ${style}`}>
                  <div className="font-mono-num font-bold text-[11px]">{dayStr}</div>
                  <div className="text-[10px] font-semibold mt-1 truncate">
                    {status ? t(lang, status) : 'Unmarked'}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {subTab === 'teacher_attendance' && showTeacherTab && (
        <div className="bg-white border border-emerald-900/10 rounded-2xl overflow-hidden">
          <div className="p-4 border-b border-slate-100 flex items-center justify-between">
            <div>
              <h2 className="font-display text-base font-bold text-slate-950">{t(lang, 'teacherAttendance')} ({selectedDate})</h2>
              <p className="text-xs text-slate-500">Duplicate check-ins on the same day update safely in place.</p>
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-start border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-100 bg-slate-50/70 text-[11px] font-semibold text-slate-600">
                  <th className="py-3 px-4 text-start">Teacher / Ustad</th>
                  <th className="py-3 px-4 text-start">Specialization</th>
                  <th className="py-3 px-4 text-start">Status</th>
                  <th className="py-3 px-4 text-start">Remarks</th>
                  <th className="py-3 px-4 text-end">Record</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {teachersRoster.map((tr) => {
                  const rec = teacherAttRows.find((r) => r.teacherId === tr.id && r.date === selectedDate);
                  const currentStatus = rec?.status || 'not_recorded';
                  return (
                    <tr key={tr.id}>
                      <td className="py-3 px-4 font-semibold text-slate-900">{tr.name}</td>
                      <td className="py-3 px-4 text-slate-600">{tr.specialization || 'Faculty'}</td>
                      <td className="py-3 px-4 font-semibold text-emerald-800">{t(lang, currentStatus)}</td>
                      <td className="py-3 px-4">
                        <input
                          type="text"
                          placeholder="Duty / Leave note..."
                          value={teacherRemarks[tr.id] ?? rec?.remarks ?? ''}
                          onChange={(e) => setTeacherRemarks({ ...teacherRemarks, [tr.id]: e.target.value })}
                          className="rounded-lg border border-slate-200 px-2.5 py-1 text-xs w-40"
                        />
                      </td>
                      <td className="py-3 px-4 text-end">
                        <div className="inline-flex gap-1.5">
                          {(['present', 'late', 'absent', 'leave'] as const).map((status) => (
                            <button
                              key={status}
                              type="button"
                              disabled={savingId === tr.id}
                              onClick={() => handleSaveTeacherAttendance(tr.id, status)}
                              className={`px-2.5 py-1 rounded-lg text-[11px] font-medium border cursor-pointer ${
                                currentStatus === status
                                  ? 'bg-emerald-800 text-white border-emerald-800'
                                  : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                              }`}
                            >
                              {t(lang, status)}
                            </button>
                          ))}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
