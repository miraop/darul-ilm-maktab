import React, { useEffect, useState } from 'react';
import { BookOpen, CheckCircle2, ExternalLink, Play, Users, Video, X } from 'lucide-react';
import { useAuth } from '../../context/AuthContext.tsx';
import { t } from '../../i18n/translations.ts';

export const OnlineEducationView: React.FC = () => {
  const { user, lang, apiFetch } = useAuth();
  const [classes, setClasses] = useState<any[]>([]);
  const [subjects, setSubjects] = useState<any[]>([]);
  const [teachers, setTeachers] = useState<any[]>([]);
  const [students, setStudents] = useState<any[]>([]);
  const [materials, setMaterials] = useState<any[]>([]);
  const [lessons, setLessons] = useState<any[]>([]);
  const [timetable, setTimetable] = useState<any[]>([]);
  const [liveAttendance, setLiveAttendance] = useState<any[]>([]);
  const [playingLesson, setPlayingLesson] = useState<any | null>(null);
  const [rosterLesson, setRosterLesson] = useState<any | null>(null);
  const [rosterEntries, setRosterEntries] = useState<any[]>([]);
  const [tab, setTab] = useState<'lessons' | 'materials' | 'timetable'>('lessons');
  const [feedback, setFeedback] = useState<string | null>(null);

  // Filters for recorded & live library
  const [filterClass, setFilterClass] = useState<string>('all');
  const [filterSubject, setFilterSubject] = useState<string>('all');
  const [filterTeacher, setFilterTeacher] = useState<string>('all');
  const [filterChapter, setFilterChapter] = useState<string>('');

  const isStudent = user?.role === 'student';
  const canEdit = user?.role === 'admin' || user?.role === 'teacher';

  const [lessonForm, setLessonForm] = useState({
    title: '',
    description: '',
    chapter: '',
    thumbnailUrl: '',
    classId: '',
    subjectId: '',
    lessonType: 'live',
    provider: 'jitsi_external',
    accessScope: 'enrolled_class',
    meetingLink: 'https://meet.jit.si/darul-ilm-live',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
    scheduledAt: '',
    durationMinutes: 40,
  });

  const [materialForm, setMaterialForm] = useState({
    title: '',
    description: '',
    classId: '',
    subjectId: '',
    materialType: 'pdf',
    resourceUrl: '',
  });

  const loadAll = async () => {
    const [cl, sb, us, st, edu] = await Promise.all([
      apiFetch('/api/classes'),
      apiFetch('/api/subjects'),
      apiFetch('/api/users'),
      apiFetch('/api/students'),
      apiFetch('/api/online-education'),
    ]);
    setClasses(cl || []);
    setSubjects(sb || []);
    setTeachers((us || []).filter((u: any) => u.role === 'teacher'));
    setStudents(st || []);
    setMaterials(edu.materials || []);
    setLessons(edu.lessons || []);
    setTimetable(edu.timetable || []);
    setLiveAttendance(edu.liveAttendance || []);

    if ((cl || []).length > 0 && !lessonForm.classId) {
      setLessonForm((p) => ({ ...p, classId: String(cl[0].id) }));
      setMaterialForm((p) => ({ ...p, classId: String(cl[0].id) }));
    }
    if ((sb || []).length > 0 && !lessonForm.subjectId) {
      setLessonForm((p) => ({ ...p, subjectId: String(sb[0].id) }));
      setMaterialForm((p) => ({ ...p, subjectId: String(sb[0].id) }));
    }
  };

  useEffect(() => {
    loadAll();
  }, []);

  const classMap = new Map(classes.map((c) => [c.id, c.name]));
  const subjectMap = new Map(subjects.map((s) => [s.id, s.name]));
  const teacherMap = new Map(teachers.map((tr) => [tr.id, tr.name]));
  const studentMap = new Map(students.map((st) => [st.id, st]));

  const handleAddLesson = async (e: React.FormEvent) => {
    e.preventDefault();
    const created = await apiFetch('/api/lessons', { method: 'POST', body: JSON.stringify(lessonForm) });
    setLessons((prev) => [created, ...prev]);
    setLessonForm({ ...lessonForm, title: '', description: '', chapter: '', thumbnailUrl: '' });
    setFeedback(
      created.lessonType === 'live'
        ? 'Live class scheduled and external room link published.'
        : 'Recorded lesson added to library.'
    );
  };

  const handleAddMaterial = async (e: React.FormEvent) => {
    e.preventDefault();
    const created = await apiFetch('/api/materials', { method: 'POST', body: JSON.stringify(materialForm) });
    setMaterials((prev) => [created, ...prev]);
    setMaterialForm({ ...materialForm, title: '', description: '', resourceUrl: '' });
    setFeedback('Digital study material uploaded.');
  };

  const handleCheckInLiveClass = async (lessonId: number, studentId?: number, status = 'joined') => {
    const saved = await apiFetch(`/api/lessons/${lessonId}/attendance`, {
      method: 'POST',
      body: JSON.stringify({ studentId, status }),
    });
    setLiveAttendance((prev) => [
      saved,
      ...prev.filter((r) => !(r.lessonId === lessonId && r.studentId === saved.studentId)),
    ]);
    if (rosterLesson?.id === lessonId) {
      setRosterEntries((prev) => [
        saved,
        ...prev.filter((r) => r.studentId !== saved.studentId),
      ]);
    }
    setFeedback('Live class check-in recorded cleanly.');
  };

  const openRosterModal = async (lesson: any) => {
    setRosterLesson(lesson);
    const rows = await apiFetch(`/api/lessons/${lesson.id}/attendance`);
    setRosterEntries(rows || []);
  };

  const filteredLessons = lessons.filter((l) => {
    if (filterClass !== 'all' && String(l.classId) !== filterClass) return false;
    if (filterSubject !== 'all' && String(l.subjectId) !== filterSubject) return false;
    if (filterTeacher !== 'all' && String(l.teacherId) !== filterTeacher) return false;
    if (filterChapter.trim() && !(l.chapter || '').toLowerCase().includes(filterChapter.toLowerCase())) return false;
    return true;
  });

  const providerLabel = (p: string) =>
    p === 'zoom_external'
      ? 'Zoom (External Room)'
      : p === 'google_meet_external'
        ? 'Google Meet (External Room)'
        : p === 'jitsi_external'
          ? 'Jitsi Meet (External Room)'
          : 'Hosted Lesson Replay';

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-1 p-1 bg-white border border-emerald-900/10 rounded-xl self-start inline-flex">
        <button
          type="button"
          onClick={() => setTab('lessons')}
          className={`px-4 py-2 text-xs font-semibold rounded-lg cursor-pointer whitespace-nowrap ${
            tab === 'lessons' ? 'bg-emerald-800 text-white' : 'text-slate-600'
          }`}
        >
          Live & Recorded Classes
        </button>
        <button
          type="button"
          onClick={() => setTab('materials')}
          className={`px-4 py-2 text-xs font-semibold rounded-lg cursor-pointer whitespace-nowrap ${
            tab === 'materials' ? 'bg-emerald-800 text-white' : 'text-slate-600'
          }`}
        >
          Digital Study Materials
        </button>
        <button
          type="button"
          onClick={() => setTab('timetable')}
          className={`px-4 py-2 text-xs font-semibold rounded-lg cursor-pointer whitespace-nowrap ${
            tab === 'timetable' ? 'bg-emerald-800 text-white' : 'text-slate-600'
          }`}
        >
          Class Timetable
        </button>
      </div>

      {feedback && (
        <div className="rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-2.5 text-xs text-emerald-900">
          {feedback}
        </div>
      )}

      {tab === 'lessons' && (
        <div className="space-y-6">
          <div className="rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-xs text-slate-600">
            Live sessions open through configured external meeting links (Jitsi, Zoom, or Google Meet), while check-in and class attendance are recorded inside the Maktab portal.
          </div>

          {canEdit && (
            <form onSubmit={handleAddLesson} className="bg-white border border-emerald-900/10 rounded-2xl p-6 space-y-3 text-xs">
              <h2 className="font-display text-base font-bold text-slate-950">Schedule Live Class or Upload Recorded Lesson</h2>
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                <input
                  type="text"
                  required
                  placeholder="Lesson Title *"
                  value={lessonForm.title}
                  onChange={(e) => setLessonForm({ ...lessonForm, title: e.target.value })}
                  className="sm:col-span-2 rounded-xl border border-slate-200 px-3 py-2"
                />
                <select
                  value={lessonForm.lessonType}
                  onChange={(e) =>
                    setLessonForm({
                      ...lessonForm,
                      lessonType: e.target.value,
                      provider: e.target.value === 'live' ? 'jitsi_external' : 'secure_storage',
                    })
                  }
                  className="rounded-xl border border-slate-200 px-3 py-2 bg-white"
                >
                  <option value="live">Live Video Class</option>
                  <option value="recorded">Recorded Lesson Replay</option>
                </select>
                <select
                  value={lessonForm.classId}
                  onChange={(e) => setLessonForm({ ...lessonForm, classId: e.target.value })}
                  className="rounded-xl border border-slate-200 px-3 py-2 bg-white"
                >
                  {classes.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                <select
                  value={lessonForm.subjectId}
                  onChange={(e) => setLessonForm({ ...lessonForm, subjectId: e.target.value })}
                  className="rounded-xl border border-slate-200 px-3 py-2 bg-white"
                >
                  {subjects.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
                </select>
                <input
                  type="text"
                  placeholder="Chapter / Topic"
                  value={lessonForm.chapter}
                  onChange={(e) => setLessonForm({ ...lessonForm, chapter: e.target.value })}
                  className="rounded-xl border border-slate-200 px-3 py-2"
                />
                <select
                  value={lessonForm.provider}
                  onChange={(e) => setLessonForm({ ...lessonForm, provider: e.target.value })}
                  className="rounded-xl border border-slate-200 px-3 py-2 bg-white"
                >
                  {lessonForm.lessonType === 'live' ? (
                    <>
                      <option value="jitsi_external">Jitsi External Link</option>
                      <option value="zoom_external">Zoom External Link</option>
                      <option value="google_meet_external">Google Meet Link</option>
                    </>
                  ) : (
                    <option value="secure_storage">Video Replay URL</option>
                  )}
                </select>
                <select
                  value={lessonForm.accessScope}
                  onChange={(e) => setLessonForm({ ...lessonForm, accessScope: e.target.value })}
                  className="rounded-xl border border-slate-200 px-3 py-2 bg-white"
                >
                  <option value="enrolled_class">Enrolled Class Only</option>
                  <option value="institution_all">All Institution Students</option>
                </select>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                <input
                  type="url"
                  placeholder={lessonForm.lessonType === 'live' ? 'Meeting Link (Jitsi/Zoom/Meet)' : 'MP4 Video URL'}
                  value={lessonForm.lessonType === 'live' ? lessonForm.meetingLink : lessonForm.videoUrl}
                  onChange={(e) =>
                    setLessonForm(
                      lessonForm.lessonType === 'live'
                        ? { ...lessonForm, meetingLink: e.target.value }
                        : { ...lessonForm, videoUrl: e.target.value }
                    )
                  }
                  className="sm:col-span-2 rounded-xl border border-slate-200 px-3 py-2"
                />
                <input
                  type="text"
                  placeholder="Schedule Date/Time (e.g. Tomorrow 9:00 AM)"
                  value={lessonForm.scheduledAt}
                  onChange={(e) => setLessonForm({ ...lessonForm, scheduledAt: e.target.value })}
                  className="rounded-xl border border-slate-200 px-3 py-2"
                />
                <input
                  type="number"
                  min={10}
                  placeholder="Duration (min)"
                  value={lessonForm.durationMinutes}
                  onChange={(e) => setLessonForm({ ...lessonForm, durationMinutes: Number(e.target.value) })}
                  className="rounded-xl border border-slate-200 px-3 py-2"
                />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <input
                  type="text"
                  placeholder="Short summary / learning goals..."
                  value={lessonForm.description}
                  onChange={(e) => setLessonForm({ ...lessonForm, description: e.target.value })}
                  className="sm:col-span-2 rounded-xl border border-slate-200 px-3 py-2"
                />
                <button type="submit" className="px-4 py-2 rounded-xl bg-emerald-800 hover:bg-emerald-900 text-white font-semibold cursor-pointer">
                  Publish Lesson
                </button>
              </div>
            </form>
          )}

          {/* Filter Bar */}
          <div className={`bg-white border border-emerald-900/10 rounded-2xl p-4 grid grid-cols-1 ${isStudent ? 'sm:grid-cols-3' : 'sm:grid-cols-4'} gap-3 text-xs`}>
            {!isStudent && (
              <select value={filterClass} onChange={(e) => setFilterClass(e.target.value)} className="rounded-xl border border-slate-200 px-3 py-2 bg-white">
                <option value="all">{t(lang, 'all')} Classes</option>
                {classes.map((c) => <option key={c.id} value={String(c.id)}>{c.name}</option>)}
              </select>
            )}
            <select value={filterSubject} onChange={(e) => setFilterSubject(e.target.value)} className="rounded-xl border border-slate-200 px-3 py-2 bg-white">
              <option value="all">{t(lang, 'all')} Subjects</option>
              {subjects.map((s) => <option key={s.id} value={String(s.id)}>{s.name}</option>)}
            </select>
            <select value={filterTeacher} onChange={(e) => setFilterTeacher(e.target.value)} className="rounded-xl border border-slate-200 px-3 py-2 bg-white">
              <option value="all">{t(lang, 'all')} Teachers</option>
              {teachers.map((tr) => <option key={tr.id} value={String(tr.id)}>{tr.name}</option>)}
            </select>
            <input
              type="text"
              placeholder="Filter by chapter..."
              value={filterChapter}
              onChange={(e) => setFilterChapter(e.target.value)}
              className="rounded-xl border border-slate-200 px-3 py-2"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredLessons.length === 0 ? (
              <div className="md:col-span-3 bg-white border border-emerald-900/10 rounded-2xl p-8 text-center text-xs text-slate-500">
                {t(lang, 'noRecords')}
              </div>
            ) : (
              filteredLessons.map((l) => {
                const checkedIn = liveAttendance.some((a) => a.lessonId === l.id);
                return (
                  <div key={l.id} className="bg-white border border-emerald-900/10 rounded-2xl p-5 flex flex-col justify-between gap-4">
                    <div>
                      <div className="flex items-center justify-between text-[11px] text-slate-500 mb-1.5">
                        <span className="font-semibold text-amber-700 uppercase">{l.lessonType}</span>
                        <span className="font-mono-num">{l.durationMinutes} min</span>
                      </div>
                      <h3 className="font-display font-bold text-slate-950 text-base">{l.title}</h3>
                      <p className="text-xs text-slate-500 mt-1">
                        {classMap.get(l.classId)} · {subjectMap.get(l.subjectId)}
                        {l.chapter ? ` · ${l.chapter}` : ''}
                      </p>
                      <div className="text-[11px] text-slate-500 mt-1">
                        {teacherMap.get(l.teacherId) ? `Ustad: ${teacherMap.get(l.teacherId)} · ` : ''}
                        {providerLabel(l.provider)}
                      </div>
                      {l.scheduledAt && (
                        <div className="text-[11px] font-mono-num text-emerald-800 mt-1 font-medium">
                          Schedule: {l.scheduledAt}
                        </div>
                      )}
                      {l.description && <p className="text-xs text-slate-600 mt-2">{l.description}</p>}
                    </div>

                    <div className="space-y-2">
                      {l.lessonType === 'live' && l.meetingLink ? (
                        <div className="flex flex-col gap-2">
                          <a
                            href={l.meetingLink}
                            target="_blank"
                            rel="noreferrer"
                            onClick={() => {
                              if (user?.role === 'student') handleCheckInLiveClass(l.id, undefined, 'joined');
                            }}
                            className="px-4 py-2 rounded-xl bg-emerald-800 hover:bg-emerald-900 text-white text-xs font-semibold inline-flex items-center justify-center gap-1.5"
                          >
                            <Video className="h-3.5 w-3.5" />
                            <span>Open External Meeting Room</span>
                            <ExternalLink className="h-3 w-3" />
                          </a>
                          {user?.role === 'student' && (
                            <button
                              type="button"
                              onClick={() => handleCheckInLiveClass(l.id, undefined, 'joined')}
                              className="px-3 py-1.5 rounded-xl border border-emerald-800/30 text-emerald-900 text-xs font-semibold inline-flex items-center justify-center gap-1.5 cursor-pointer"
                            >
                              <CheckCircle2 className="h-3.5 w-3.5" />
                              <span>{checkedIn ? 'Attendance Checked In' : 'Mark Live Attendance'}</span>
                            </button>
                          )}
                          {canEdit && (
                            <button
                              type="button"
                              onClick={() => openRosterModal(l)}
                              className="px-3 py-1.5 rounded-xl border border-slate-200 text-slate-700 hover:bg-slate-50 text-xs font-semibold inline-flex items-center justify-center gap-1.5 cursor-pointer"
                            >
                              <Users className="h-3.5 w-3.5" />
                              <span>Live Class Roster</span>
                            </button>
                          )}
                        </div>
                      ) : (
                        <button
                          type="button"
                          onClick={() => setPlayingLesson(l)}
                          className="w-full px-4 py-2 rounded-xl border border-emerald-800 text-emerald-900 hover:bg-emerald-50 text-xs font-semibold inline-flex items-center justify-center gap-1.5 cursor-pointer"
                        >
                          <Play className="h-3.5 w-3.5" />
                          <span>Watch Lesson Replay</span>
                        </button>
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {tab === 'materials' && (
        <div className="space-y-6">
          {canEdit && (
            <form onSubmit={handleAddMaterial} className="bg-white border border-emerald-900/10 rounded-2xl p-6 space-y-3 text-xs">
              <h2 className="font-display text-base font-bold text-slate-950">Add Digital Study Material</h2>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <input
                  type="text"
                  required
                  placeholder="Document Title *"
                  value={materialForm.title}
                  onChange={(e) => setMaterialForm({ ...materialForm, title: e.target.value })}
                  className="rounded-xl border border-slate-200 px-3 py-2"
                />
                <select
                  value={materialForm.classId}
                  onChange={(e) => setMaterialForm({ ...materialForm, classId: e.target.value })}
                  className="rounded-xl border border-slate-200 px-3 py-2 bg-white"
                >
                  {classes.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
                <select
                  value={materialForm.subjectId}
                  onChange={(e) => setMaterialForm({ ...materialForm, subjectId: e.target.value })}
                  className="rounded-xl border border-slate-200 px-3 py-2 bg-white"
                >
                  {subjects.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
                </select>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <input
                  type="url"
                  required
                  placeholder="PDF / Resource URL *"
                  value={materialForm.resourceUrl}
                  onChange={(e) => setMaterialForm({ ...materialForm, resourceUrl: e.target.value })}
                  className="sm:col-span-2 rounded-xl border border-slate-200 px-3 py-2"
                />
                <button type="submit" className="px-4 py-2 rounded-xl bg-emerald-800 text-white font-semibold cursor-pointer">
                  Upload Material
                </button>
              </div>
            </form>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {materials.map((m) => (
              <div key={m.id} className="bg-white border border-emerald-900/10 rounded-2xl p-5 flex items-start justify-between gap-4">
                <div>
                  <div className="text-[11px] font-semibold text-emerald-800 uppercase mb-1">
                    {m.materialType} · {classMap.get(m.classId)}
                  </div>
                  <h3 className="font-semibold text-slate-950 text-sm">{m.title}</h3>
                  <p className="text-xs text-slate-600 mt-1">{m.description}</p>
                </div>
                <a
                  href={m.resourceUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="px-3 py-1.5 rounded-lg border border-emerald-800 text-emerald-900 text-xs font-semibold inline-flex items-center gap-1 shrink-0"
                >
                  <BookOpen className="h-3.5 w-3.5" />
                  <span>Open</span>
                </a>
              </div>
            ))}
          </div>
        </div>
      )}

      {tab === 'timetable' && (
        <div className="bg-white border border-emerald-900/10 rounded-2xl overflow-hidden">
          <table className="w-full text-start border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-100 bg-slate-50/70 text-[11px] font-semibold text-slate-500">
                <th className="py-3 px-4 text-start">Day</th>
                <th className="py-3 px-4 text-start">Time</th>
                <th className="py-3 px-4 text-start">Class</th>
                <th className="py-3 px-4 text-start">Subject</th>
                <th className="py-3 px-4 text-start">Room</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {timetable.map((slot) => (
                <tr key={slot.id}>
                  <td className="py-3 px-4 font-semibold text-emerald-900">{slot.dayOfWeek}</td>
                  <td className="py-3 px-4 font-mono-num text-slate-600">
                    {slot.startTime} – {slot.endTime}
                  </td>
                  <td className="py-3 px-4 text-slate-700">{classMap.get(slot.classId)}</td>
                  <td className="py-3 px-4 font-medium text-slate-900">{subjectMap.get(slot.subjectId)}</td>
                  <td className="py-3 px-4 text-slate-500">{slot.room || 'Hall'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Recorded Video Player Modal */}
      {playingLesson && (
        <div className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4" onClick={() => setPlayingLesson(null)}>
          <div className="bg-white rounded-2xl max-w-3xl w-full overflow-hidden" onClick={(e) => e.stopPropagation()}>
            <div className="px-5 py-3.5 border-b border-slate-100 flex items-center justify-between">
              <h3 className="font-display font-bold text-slate-950 text-base">{playingLesson.title}</h3>
              <button type="button" onClick={() => setPlayingLesson(null)} className="p-1 cursor-pointer">
                <X className="h-5 w-5" />
              </button>
            </div>
            <video src={playingLesson.videoUrl} controls autoPlay className="w-full max-h-[65vh] bg-black" />
            <div className="p-4 text-xs text-slate-600">{playingLesson.description}</div>
          </div>
        </div>
      )}

      {/* Live Class Attendance Roster Modal */}
      {rosterLesson && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4" onClick={() => setRosterLesson(null)}>
          <div className="bg-white rounded-2xl max-w-xl w-full p-6 space-y-4 text-xs" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h3 className="font-display font-bold text-base text-slate-950">Live Class Roster — {rosterLesson.title}</h3>
                <p className="text-slate-500">{classMap.get(rosterLesson.classId)}</p>
              </div>
              <button type="button" onClick={() => setRosterLesson(null)} className="p-1 cursor-pointer">
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="divide-y divide-slate-100 max-h-72 overflow-y-auto">
              {students
                .filter((s) => s.classId === rosterLesson.classId || rosterLesson.accessScope === 'institution_all')
                .map((st) => {
                  const rec = rosterEntries.find((r) => r.studentId === st.id);
                  return (
                    <div key={st.id} className="py-2.5 flex items-center justify-between gap-3">
                      <div>
                        <div className="font-semibold text-slate-900">{st.fullName}</div>
                        <div className="text-[11px] font-mono-num text-slate-500">{st.admissionNo}</div>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <span className="font-semibold text-emerald-800 me-2 uppercase">
                          {rec ? rec.status : 'Not Joined'}
                        </span>
                        <button
                          type="button"
                          onClick={() => handleCheckInLiveClass(rosterLesson.id, st.id, 'present')}
                          className="px-2.5 py-1 rounded bg-emerald-800 text-white cursor-pointer"
                        >
                          Present
                        </button>
                        <button
                          type="button"
                          onClick={() => handleCheckInLiveClass(rosterLesson.id, st.id, 'absent')}
                          className="px-2.5 py-1 rounded border border-red-200 text-red-700 cursor-pointer"
                        >
                          Absent
                        </button>
                      </div>
                    </div>
                  );
                })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
