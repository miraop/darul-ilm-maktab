import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import * as XLSX from 'xlsx';

export function exportToPdf(params: {
  title: string;
  subtitle?: string;
  headers: string[];
  rows: Array<Array<string | number>>;
  filename: string;
}) {
  const doc = new jsPDF({ orientation: 'portrait', unit: 'pt', format: 'a4' });

  // Emerald header band
  doc.setFillColor(6, 95, 70); // #065F46
  doc.rect(0, 0, doc.internal.pageSize.getWidth(), 78, 'F');

  // Gold accent rule
  doc.setFillColor(212, 175, 55);
  doc.rect(0, 78, doc.internal.pageSize.getWidth(), 3, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFontSize(17);
  doc.text('Kabeer Sb Maktab & Academy', 40, 36);
  doc.setFontSize(11);
  doc.text(params.title, 40, 58);

  if (params.subtitle) {
    doc.setTextColor(71, 85, 105);
    doc.setFontSize(9.5);
    doc.text(params.subtitle, 40, 102);
  }

  autoTable(doc, {
    startY: params.subtitle ? 118 : 102,
    head: [params.headers],
    body: params.rows.map((r) => r.map((c) => String(c ?? ''))),
    styles: {
      fontSize: 9,
      cellPadding: 6,
    },
    headStyles: {
      fillColor: [6, 95, 70],
      textColor: [255, 255, 255],
      fontStyle: 'bold',
    },
    alternateRowStyles: {
      fillColor: [248, 250, 249],
    },
  });

  const pageHeight = doc.internal.pageSize.getHeight();
  doc.setFontSize(8);
  doc.setTextColor(100, 116, 139);
  doc.text(`Generated on ${new Date().toLocaleString()} · Kabeer Sb Maktab Management System`, 40, pageHeight - 24);

  doc.save(params.filename.endsWith('.pdf') ? params.filename : `${params.filename}.pdf`);
}

export function exportToExcel(params: {
  sheetName: string;
  headers: string[];
  rows: Array<Array<string | number | boolean>>;
  filename: string;
}) {
  const worksheetData = [params.headers, ...params.rows];
  const ws = XLSX.utils.aoa_to_sheet(worksheetData);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, params.sheetName.slice(0, 31));
  XLSX.writeFile(wb, params.filename.endsWith('.xlsx') ? params.filename : `${params.filename}.xlsx`);
}

export function exportFeeReceiptPdf(params: {
  receiptNo: string;
  studentName: string;
  admissionNo: string;
  feeTitle: string;
  monthYear: string;
  amount: number;
  paymentMethod: string;
  transactionRef: string;
  paidAt: string;
}) {
  const doc = new jsPDF({ orientation: 'portrait', unit: 'pt', format: 'a5' });

  doc.setFillColor(6, 95, 70);
  doc.rect(0, 0, doc.internal.pageSize.getWidth(), 70, 'F');
  doc.setFillColor(212, 175, 55);
  doc.rect(0, 70, doc.internal.pageSize.getWidth(), 3, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFontSize(15);
  doc.text('Kabeer Sb Maktab', 30, 32);
  doc.setFontSize(10);
  doc.text('Official Fee Payment Receipt', 30, 52);

  autoTable(doc, {
    startY: 94,
    theme: 'grid',
    head: [['Receipt Field', 'Details']],
    body: [
      ['Receipt Number', params.receiptNo],
      ['Student Name', params.studentName],
      ['Admission No', params.admissionNo],
      ['Fee Description', params.feeTitle],
      ['Billing Month', params.monthYear],
      ['Amount Paid', `INR ${params.amount.toLocaleString()}`],
      ['Payment Method', params.paymentMethod.toUpperCase()],
      ['Transaction Ref', params.transactionRef],
      ['Payment Date', new Date(params.paidAt).toLocaleString()],
      ['Status', 'PAID & VERIFIED'],
    ],
    headStyles: {
      fillColor: [6, 95, 70],
      textColor: [255, 255, 255],
    },
    styles: {
      fontSize: 9.5,
      cellPadding: 7,
    },
  });

  doc.save(`${params.receiptNo}.pdf`);
}
