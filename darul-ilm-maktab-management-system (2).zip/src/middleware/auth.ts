import crypto from 'node:crypto';
import { Request, Response, NextFunction } from 'express';
import { and, eq, isNull } from 'drizzle-orm';
import { adminAuth } from '../lib/firebase-admin.ts';
import { db } from '../db/index.ts';
import { auditLogs, institutions, students, users } from '../db/schema.ts';

export const PLATFORM_OWNER_EMAIL = 'monkeyaisa@gmail.com';
export const PLATFORM_OWNER_EMAILS = ['monkeyaisa@gmail.com', 'kabeersuperadmin'] as const;

export function isPlatformOwnerEmail(email?: string | null): boolean {
  return PLATFORM_OWNER_EMAILS.includes(String(email || '').trim().toLowerCase() as any);
}

const SESSION_SECRET =
  process.env.SESSION_SECRET ||
  crypto.createHash('sha256').update(process.env.SQL_PASSWORD || 'darul-ilm-maktab-secret-2026').digest('hex');

export interface DbUser {
  id: number;
  uid: string;
  email: string;
  name: string;
  role: string; // 'super_admin' | 'admin' | 'teacher' | 'student' | 'parent'
  institutionId: number | null;
  institutionName?: string | null;
  institutionSlug?: string | null;
  institutionStatus?: string | null;
  phone: string | null;
  preferredLang: string;
  specialization: string | null;
  qualification: string | null;
  isActive: boolean;
  isDemo: boolean;
}

export interface AuthRequest extends Request {
  dbUser?: DbUser;
}

export function signSessionToken(payload: {
  userId: number;
  uid: string;
  role: string;
  institutionId: number | null;
  email: string;
}): string {
  const exp = Date.now() + 1000 * 60 * 60 * 24 * 7; // 7 days
  const data = Buffer.from(JSON.stringify({ ...payload, exp })).toString('base64url');
  const sig = crypto.createHmac('sha256', SESSION_SECRET).update(data).digest('base64url');
  return `mkt.${data}.${sig}`;
}

export function verifySessionToken(token: string): {
  userId: number;
  uid: string;
  role: string;
  institutionId: number | null;
  email: string;
  exp: number;
} | null {
  try {
    const parts = token.split('.');
    if (parts.length !== 3 || parts[0] !== 'mkt') return null;
    const [, data, sig] = parts;
    const expected = crypto.createHmac('sha256', SESSION_SECRET).update(data).digest('base64url');
    if (!crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return null;
    const parsed = JSON.parse(Buffer.from(data, 'base64url').toString('utf8'));
    if (!parsed.exp || Date.now() > parsed.exp) return null;
    return parsed;
  } catch {
    return null;
  }
}

async function hydrateDbUser(u: typeof users.$inferSelect): Promise<DbUser> {
  const isOwner = isPlatformOwnerEmail(u.email);
  let effectiveRole = u.role;
  let effectiveInstId = u.institutionId;

  // Enforce strict Platform Owner exclusivity
  if (isOwner) {
    effectiveRole = 'super_admin';
    effectiveInstId = null;
  } else if (effectiveRole === 'super_admin') {
    effectiveRole = 'parent';
  }

  let institutionName: string | null = null;
  let institutionSlug: string | null = null;
  let institutionStatus: string | null = null;

  if (effectiveInstId) {
    const instRows = await db.select().from(institutions).where(eq(institutions.id, effectiveInstId)).limit(1);
    if (instRows[0]) {
      institutionName = instRows[0].name;
      institutionSlug = instRows[0].slug;
      institutionStatus = instRows[0].status;
    }
  }

  return {
    id: u.id,
    uid: u.uid,
    email: u.email,
    name: u.name,
    role: effectiveRole,
    institutionId: effectiveInstId,
    institutionName,
    institutionSlug,
    institutionStatus,
    phone: u.phone,
    preferredLang: u.preferredLang,
    specialization: u.specialization,
    qualification: u.qualification,
    isActive: u.isActive,
    isDemo: u.isDemo,
  };
}

export class PendingInstitutionError extends Error {
  statusCode = 403;
  constructor(message: string) {
    super(message);
    this.name = 'PendingInstitutionError';
  }
}

export function normalizePersonName(val?: string | null): string {
  return String(val || '').trim().replace(/\s+/g, ' ').toLowerCase();
}

function normalizePhoneTail(val?: string | null): string {
  return String(val || '').replace(/\D/g, '').slice(-10);
}

export async function verifyAndEnsureStudentParentEnrollment(user: {
  id: number;
  name: string;
  phone: string | null;
  role: string;
  institutionId: number | null;
}): Promise<{ ok: boolean; reason?: string; linkedCount: number }> {
  if (user.role !== 'student' && user.role !== 'parent') {
    return { ok: true, linkedCount: 0 };
  }
  if (!user.institutionId) {
    return {
      ok: false,
      reason: 'Access denied: Account is not linked to an approved Maktab.',
      linkedCount: 0,
    };
  }

  const instStudents = await db
    .select()
    .from(students)
    .where(and(eq(students.institutionId, user.institutionId), eq(students.status, 'active')));

  if (user.role === 'student') {
    const linked = instStudents.filter((s) => s.userId === user.id);
    if (linked.length > 0) {
      return { ok: true, linkedCount: linked.length };
    }

    const userNorm = normalizePersonName(user.name);
    const unlinkedMatches = instStudents.filter(
      (s) => s.userId === null && userNorm.length > 0 && normalizePersonName(s.fullName) === userNorm
    );
    if (unlinkedMatches.length === 1) {
      const target = unlinkedMatches[0];
      const [claimed] = await db
        .update(students)
        .set({ userId: user.id })
        .where(and(eq(students.id, target.id), isNull(students.userId)))
        .returning({ id: students.id });
      if (claimed) {
        return { ok: true, linkedCount: 1 };
      }
    }

    return {
      ok: false,
      reason:
        'Access denied: No active enrolled student record matching your name was found in this Maktab.',
      linkedCount: 0,
    };
  }

  // role === 'parent'
  const linkedChildren = instStudents.filter((s) => s.parentId === user.id);
  if (linkedChildren.length > 0) {
    return { ok: true, linkedCount: linkedChildren.length };
  }

  const parentNorm = normalizePersonName(user.name);
  const parentPhone = normalizePhoneTail(user.phone);
  const unlinkedChildren = instStudents.filter((s) => {
    if (s.parentId !== null) return false;
    const nameMatches =
      parentNorm.length > 0 &&
      (normalizePersonName(s.guardianName) === parentNorm ||
        normalizePersonName(s.fatherName) === parentNorm ||
        normalizePersonName(s.motherName) === parentNorm);
    if (!nameMatches) return false;
    if (parentPhone && s.guardianPhone) {
      return normalizePhoneTail(s.guardianPhone) === parentPhone;
    }
    return true;
  });

  if (unlinkedChildren.length > 0) {
    let linkedCount = 0;
    for (const child of unlinkedChildren) {
      const [claimed] = await db
        .update(students)
        .set({ parentId: user.id })
        .where(and(eq(students.id, child.id), isNull(students.parentId)))
        .returning({ id: students.id });
      if (claimed) linkedCount += 1;
    }
    if (linkedCount > 0) {
      return { ok: true, linkedCount };
    }
  }

  return {
    ok: false,
    reason:
      'Access denied: Only parents or guardians of an active enrolled student in this Maktab can sign in.',
    linkedCount: 0,
  };
}

export async function getOrCreateFirebaseUser(uid: string, email: string, name?: string): Promise<DbUser> {
  const lowerEmail = email.toLowerCase();
  const isOwner = isPlatformOwnerEmail(lowerEmail);

  const existing = await db.select().from(users).where(eq(users.uid, uid)).limit(1);
  if (existing.length > 0) {
    const u = existing[0];
    if (isOwner && (u.role !== 'super_admin' || u.institutionId !== null)) {
      const [promoted] = await db
        .update(users)
        .set({ role: 'super_admin', institutionId: null })
        .where(eq(users.id, u.id))
        .returning();
      return hydrateDbUser(promoted);
    }
    return hydrateDbUser(u);
  }

  // Also check if email already exists (e.g., pre-registered owner / admin / teacher / parent)
  const byEmail = await db.select().from(users).where(eq(users.email, lowerEmail)).limit(1);
  if (byEmail.length > 0) {
    const updatePatch: any = { uid };
    if (isOwner) {
      updatePatch.role = 'super_admin';
      updatePatch.institutionId = null;
    }
    const [updated] = await db
      .update(users)
      .set(updatePatch)
      .where(eq(users.id, byEmail[0].id))
      .returning();
    return hydrateDbUser(updated);
  }

  // Check if this email belongs to a Maktab institution application before defaulting to parent
  if (!isOwner) {
    const appInst = await db
      .select()
      .from(institutions)
      .where(eq(institutions.requestedAdminEmail, lowerEmail))
      .limit(1);
    if (appInst.length > 0) {
      const inst = appInst[0];
      if (inst.status === 'pending') {
        throw new PendingInstitutionError(
          `Your New Maktab application for "${inst.name}" is awaiting Super Admin approval. Once approved, you can sign in to your dashboard.`
        );
      }
      if (inst.status === 'rejected' || inst.status === 'suspended') {
        throw new PendingInstitutionError(
          `Your institution "${inst.name}" is currently ${inst.status}. Please contact the Platform Owner.`
        );
      }
      if (inst.status === 'approved') {
        const [createdAdmin] = await db
          .insert(users)
          .values({
            uid,
            email: lowerEmail,
            passwordHash: inst.requestedAdminPasswordHash,
            name: inst.requestedAdminName || name || email.split('@')[0],
            role: 'admin',
            institutionId: inst.id,
            phone: inst.contactPhone,
            preferredLang: 'en',
            isActive: true,
            isDemo: false,
          })
          .onConflictDoUpdate({
            target: users.uid,
            set: { email: lowerEmail },
          })
          .returning();
        return hydrateDbUser(createdAdmin);
      }
    }
  }

  if (isOwner) {
    const [inserted] = await db
      .insert(users)
      .values({
        uid,
        email: lowerEmail,
        name: name || email.split('@')[0],
        role: 'super_admin',
        institutionId: null,
        preferredLang: 'en',
        isActive: true,
        isDemo: false,
      })
      .onConflictDoUpdate({
        target: users.uid,
        set: { email: lowerEmail },
      })
      .returning();

    return hydrateDbUser(inserted);
  }

  // Never blindly auto-create unverified Google accounts as parents in Maktab #1.
  throw new PendingInstitutionError(
    'No enrolled student or staff account is linked to this Google email. Please register first under "Register Parent / Student" with your Maktab and enrolled student name.'
  );
}

export const requireAuth = async (req: AuthRequest, res: Response, next: NextFunction) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Unauthorized: Missing authentication token' });
  }

  const token = authHeader.split('Bearer ')[1];

  // 1. Check signed local session token
  if (token.startsWith('mkt.')) {
    const decoded = verifySessionToken(token);
    if (!decoded) {
      return res.status(401).json({ error: 'Unauthorized: Session expired or invalid' });
    }
    try {
      const rows = await db.select().from(users).where(eq(users.id, decoded.userId)).limit(1);
      if (rows.length === 0 || !rows[0].isActive) {
        return res.status(401).json({ error: 'Unauthorized: Account disabled or missing' });
      }
      const hydrated = await hydrateDbUser(rows[0]);
      if (hydrated.role !== 'super_admin' && hydrated.institutionId && hydrated.institutionStatus !== 'approved') {
        return res.status(403).json({ error: 'Institution workspace is suspended or pending approval.' });
      }
      if (hydrated.role === 'student' || hydrated.role === 'parent') {
        const enrollmentCheck = await verifyAndEnsureStudentParentEnrollment(hydrated);
        if (!enrollmentCheck.ok) {
          return res.status(403).json({ error: enrollmentCheck.reason });
        }
      }
      req.dbUser = hydrated;
      return next();
    } catch (err) {
      console.error('Auth lookup error:', err);
      return res.status(500).json({ error: 'Authentication verification failed' });
    }
  }

  // 2. Verify Firebase ID Token
  try {
    const decodedToken = await adminAuth.verifyIdToken(token);
    const email = decodedToken.email || `${decodedToken.uid}@firebase.local`;
    const dbUser = await getOrCreateFirebaseUser(decodedToken.uid, email, decodedToken.name);
    if (!dbUser.isActive) {
      return res.status(403).json({ error: 'Account is deactivated' });
    }
    if (dbUser.role !== 'super_admin' && dbUser.institutionId && dbUser.institutionStatus !== 'approved') {
      return res.status(403).json({ error: 'Institution workspace is suspended or pending approval.' });
    }
    if (dbUser.role === 'student' || dbUser.role === 'parent') {
      const enrollmentCheck = await verifyAndEnsureStudentParentEnrollment(dbUser);
      if (!enrollmentCheck.ok) {
        return res.status(403).json({ error: enrollmentCheck.reason });
      }
    }
    req.dbUser = dbUser;
    return next();
  } catch (error: any) {
    if (error instanceof PendingInstitutionError) {
      return res.status(403).json({ error: error.message });
    }
    console.error('Error verifying token:', error);
    return res.status(401).json({ error: 'Unauthorized: Invalid token' });
  }
};

export const requireRole = (...allowedRoles: string[]) => {
  return (req: AuthRequest, res: Response, next: NextFunction) => {
    if (!req.dbUser) {
      return res.status(401).json({ error: 'Unauthorized' });
    }
    if (!allowedRoles.includes(req.dbUser.role)) {
      return res.status(403).json({ error: 'Forbidden: Insufficient permissions for this portal' });
    }
    next();
  };
};

// Strictly ensures request belongs to a verified institution tenant (never leaks cross-tenant data)
export const requireTenant = (req: AuthRequest, res: Response, next: NextFunction) => {
  if (!req.dbUser) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  if (req.dbUser.role === 'super_admin') {
    return res.status(403).json({ error: 'Forbidden: Super Admin manages institutions via the Platform Owner Console.' });
  }
  if (!req.dbUser.institutionId) {
    return res.status(403).json({ error: 'Forbidden: User is not assigned to an approved institution.' });
  }
  if (req.dbUser.institutionStatus !== 'approved') {
    return res.status(403).json({ error: 'Forbidden: Institution workspace is not approved or is suspended.' });
  }
  next();
};

// Simple in-memory sliding-window rate limiter
const rateBuckets = new Map<string, { count: number; resetAt: number }>();

export function rateLimit(maxRequests: number, windowMs: number) {
  return (req: Request, res: Response, next: NextFunction) => {
    const key = `${req.ip || 'unknown'}:${req.baseUrl}${req.path}`;
    const now = Date.now();
    const bucket = rateBuckets.get(key);
    if (!bucket || now > bucket.resetAt) {
      rateBuckets.set(key, { count: 1, resetAt: now + windowMs });
      return next();
    }
    if (bucket.count >= maxRequests) {
      return res.status(429).json({ error: 'Too many requests. Please wait a moment and try again.' });
    }
    bucket.count += 1;
    return next();
  };
}

export async function logAudit(params: {
  institutionId?: number | null;
  userId?: number | null;
  userEmail?: string | null;
  action: string;
  entityType: string;
  entityId?: string | number | null;
  details?: string;
  ipAddress?: string;
}) {
  try {
    await db.insert(auditLogs).values({
      institutionId: params.institutionId ?? null,
      userId: params.userId ?? null,
      userEmail: params.userEmail ?? 'system',
      action: params.action,
      entityType: params.entityType,
      entityId: params.entityId !== undefined && params.entityId !== null ? String(params.entityId) : null,
      details: params.details ?? null,
      ipAddress: params.ipAddress ?? 'server',
    });
  } catch (err) {
    console.error('Failed to write audit log:', err);
  }
}
