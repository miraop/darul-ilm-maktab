import bcrypt from 'bcryptjs';
import { and, desc, eq, inArray, isNull, or, sql } from 'drizzle-orm';
import { Router } from 'express';
import { db } from '../db/index.ts';
import {
  admissions,
  assignments,
  attendance,
  auditLogs,
  classes,
  dailyActivities,
  enrollments,
  exams,
  fees,
  healthRecords,
  homework,
  institutionPolicies,
  institutions,
  institutionSubscriptions,
  liveClassAttendance,
  marks,
  namazRecords,
  notices,
  notificationPreferences,
  notifications,
  payments,
  recordedLessons,
  roles,
  students,
  studyMaterials,
  subjects,
  syllabusTopics,
  teacherAttendance,
  teacherMessages,
  testAttempts,
  timetable,
  users,
  websiteSettings,
} from '../db/schema.ts';
import { ensureSeeded, provisionInstitutionPolicy, provisionInstitutionSettings } from '../db/seed.ts';
import {
  AuthRequest,
  isPlatformOwnerEmail,
  logAudit,
  normalizePersonName,
  PLATFORM_OWNER_EMAIL,
  rateLimit,
  requireAuth,
  requireRole,
  requireTenant,
  signSessionToken,
  verifyAndEnsureStudentParentEnrollment,
} from '../middleware/auth.ts';

const router = Router();

const MAKTAB_SUBSCRIPTION_PLAN = {
  code: 'maktab_399',
  name: 'Maktab Standard SaaS Plan',
  priceInr: 399,
  currency: 'INR',
  billingCycle: 'monthly',
  durationDays: 30,
  features: [
    'Dedicated Isolated Maktab Workspace & Admin Portal',
    'Unlimited Teacher, Parent & Student Portals',
    'Attendance, 5-Times Namaz, Meals & Health Records',
    'Exams, Online Tests, Homework & Syllabus Tracking',
    'Fee Collection, Receipts & PDF/Excel Reports',
    'Multilingual Support (English, Hindi, Urdu RTL)',
  ],
};

// Helper: get class IDs assigned to a teacher strictly within their institution
async function getTeacherClassIds(teacherId: number, institutionId: number): Promise<number[]> {
  const assignedClasses = await db
    .select({ id: classes.id })
    .from(classes)
    .where(and(eq(classes.teacherId, teacherId), eq(classes.institutionId, institutionId)));
  const subjectClasses = await db
    .select({ classId: subjects.classId })
    .from(subjects)
    .where(and(eq(subjects.teacherId, teacherId), eq(subjects.institutionId, institutionId)));
  const ids = new Set<number>([
    ...assignedClasses.map((c) => c.id),
    ...subjectClasses.map((s) => s.classId),
  ]);
  return Array.from(ids);
}

// Helper: get student IDs authorized for current tenant user
async function getScopedStudentIds(req: AuthRequest): Promise<number[] | null> {
  const user = req.dbUser!;
  const instId = user.institutionId;
  if (!instId) return [];

  if (user.role === 'admin') return null; // unrestricted within user's OWN institutionId only
  if (user.role === 'teacher') {
    const classIds = await getTeacherClassIds(user.id, instId);
    if (classIds.length === 0) return [];
    const rows = await db
      .select({ id: students.id })
      .from(students)
      .where(and(eq(students.institutionId, instId), inArray(students.classId, classIds)));
    return rows.map((r) => r.id);
  }
  if (user.role === 'parent') {
    const rows = await db
      .select({ id: students.id })
      .from(students)
      .where(and(eq(students.institutionId, instId), eq(students.parentId, user.id)));
    return rows.map((r) => r.id);
  }
  if (user.role === 'student') {
    const rows = await db
      .select({ id: students.id })
      .from(students)
      .where(and(eq(students.institutionId, instId), eq(students.userId, user.id)));
    return rows.map((r) => r.id);
  }
  return [];
}

async function resolveApprovedInstitution(slugOrId?: string | number | null) {
  if (slugOrId) {
    const bySlug =
      typeof slugOrId === 'string' && Number.isNaN(Number(slugOrId))
        ? await db
            .select()
            .from(institutions)
            .where(and(eq(institutions.slug, slugOrId), eq(institutions.status, 'approved')))
            .limit(1)
        : await db
            .select()
            .from(institutions)
            .where(and(eq(institutions.id, Number(slugOrId)), eq(institutions.status, 'approved')))
            .limit(1);
    if (bySlug[0]) return bySlug[0];
  }
  const firstApproved = await db
    .select()
    .from(institutions)
    .where(eq(institutions.status, 'approved'))
    .orderBy(institutions.id)
    .limit(1);
  return firstApproved[0] || null;
}

function computeGrade(obtained: number, total: number): string {
  if (total <= 0) return 'N/A';
  const pct = (obtained / total) * 100;
  if (pct >= 90) return 'A+';
  if (pct >= 80) return 'A';
  if (pct >= 70) return 'B+';
  if (pct >= 60) return 'B';
  if (pct >= 50) return 'C';
  if (pct >= 40) return 'D';
  return 'Needs Support';
}

async function getInstitutionPolicy(institutionId: number) {
  await provisionInstitutionPolicy(institutionId);
  const rows = await db
    .select()
    .from(institutionPolicies)
    .where(eq(institutionPolicies.institutionId, institutionId))
    .limit(1);
  return rows[0];
}

async function shouldNotifyPreference(
  institutionId: number,
  targetUserId: number | null | undefined,
  prefKey:
    | 'absentAlerts'
    | 'attendanceUpdates'
    | 'homeworkAlerts'
    | 'examAlerts'
    | 'liveClassAlerts'
    | 'prayerUpdates'
    | 'foodUpdates'
    | 'healthAlerts'
    | 'teacherMessages'
): Promise<boolean> {
  if (!targetUserId) return false;
  const rows = await db
    .select()
    .from(notificationPreferences)
    .where(and(eq(notificationPreferences.institutionId, institutionId), eq(notificationPreferences.userId, targetUserId)))
    .limit(1);
  if (rows.length === 0) return true;
  return Boolean(rows[0][prefKey]);
}

async function syncSubjectSyllabusTotals(subjectId: number, institutionId: number) {
  const topics = await db
    .select()
    .from(syllabusTopics)
    .where(and(eq(syllabusTopics.subjectId, subjectId), eq(syllabusTopics.institutionId, institutionId)));
  if (topics.length === 0) return;
  const sumTotal = topics.reduce((acc, t) => acc + Math.max(0, Number(t.totalTopics) || 0), 0);
  const sumCompleted = topics.reduce(
    (acc, t) => acc + Math.min(Math.max(0, Number(t.completedTopics) || 0), Math.max(0, Number(t.totalTopics) || 0)),
    0
  );
  await db
    .update(subjects)
    .set({
      syllabusTotalUnits: Math.max(1, sumTotal),
      syllabusCompletedUnits: sumCompleted,
    })
    .where(and(eq(subjects.id, subjectId), eq(subjects.institutionId, institutionId)));
}

async function ensureInstitutionAdminAccount(
  inst: typeof institutions.$inferSelect,
  overrides?: { adminName?: string; adminEmail?: string; adminPassword?: string }
): Promise<{ admin?: any; error?: string; status?: number }> {
  const targetEmail = (overrides?.adminEmail || inst.requestedAdminEmail || inst.contactEmail || '')
    .trim()
    .toLowerCase();
  if (!targetEmail) {
    return { error: 'No Institution Admin email is configured for this Maktab.', status: 400 };
  }
  if (isPlatformOwnerEmail(targetEmail)) {
    return { error: 'Platform Owner email cannot be assigned as an Institution Admin.', status: 400 };
  }

  const targetName = (overrides?.adminName || inst.requestedAdminName || `${inst.name} Principal`).trim();
  const hasNewPassword = Boolean(overrides?.adminPassword && String(overrides.adminPassword).trim().length >= 6);
  const newPasswordHash = hasNewPassword
    ? await bcrypt.hash(String(overrides!.adminPassword).trim(), 10)
    : null;

  const existingRows = await db.select().from(users).where(eq(users.email, targetEmail)).limit(1);

  if (existingRows.length === 0) {
    const hash =
      newPasswordHash ||
      inst.requestedAdminPasswordHash ||
      (await bcrypt.hash('MaktabAdmin@2026', 10));

    const [created] = await db
      .insert(users)
      .values({
        uid: `inst-admin-${inst.id}-${Date.now()}`,
        email: targetEmail,
        passwordHash: hash,
        name: targetName,
        role: 'admin',
        institutionId: inst.id,
        phone: inst.contactPhone,
        preferredLang: 'en',
        isActive: true,
        isDemo: false,
      })
      .returning();

    const { passwordHash: _ph, ...safe } = created;
    return { admin: safe };
  }

  const existingUser = existingRows[0];
  if (
    existingUser.role === 'admin' &&
    existingUser.institutionId &&
    existingUser.institutionId !== inst.id
  ) {
    return {
      error: `${targetEmail} is already the Institution Admin for another Maktab (Tenant #${existingUser.institutionId}). Assign a different email for this institution.`,
      status: 409,
    };
  }

  const resolvedHash =
    newPasswordHash ||
    inst.requestedAdminPasswordHash ||
    existingUser.passwordHash ||
    (await bcrypt.hash('MaktabAdmin@2026', 10));

  const [updated] = await db
    .update(users)
    .set({
      role: 'admin',
      institutionId: inst.id,
      isActive: true,
      name: targetName || existingUser.name,
      passwordHash: resolvedHash,
    })
    .where(eq(users.id, existingUser.id))
    .returning();

  if (
    targetEmail !== (inst.requestedAdminEmail || '').toLowerCase() ||
    targetName !== (inst.requestedAdminName || '') ||
    newPasswordHash
  ) {
    await db
      .update(institutions)
      .set({
        requestedAdminEmail: targetEmail,
        requestedAdminName: targetName,
        ...(newPasswordHash ? { requestedAdminPasswordHash: newPasswordHash } : {}),
      })
      .where(eq(institutions.id, inst.id));
  }

  const { passwordHash: _ph, ...safe } = updated;
  return { admin: safe };
}

// ==================== PUBLIC ENDPOINTS ====================

router.get('/public/institutions', async (_req, res) => {
  try {
    await ensureSeeded();
    const rows = await db
      .select({
        id: institutions.id,
        name: institutions.name,
        slug: institutions.slug,
        code: institutions.code,
        city: institutions.city,
      })
      .from(institutions)
      .where(eq(institutions.status, 'approved'))
      .orderBy(institutions.id);
    res.json(rows);
  } catch (err) {
    console.error('Public institutions error:', err);
    res.status(500).json({ error: 'Failed to load institutions directory' });
  }
});

router.get('/public/subscription-plans', (_req, res) => {
  res.json({ plans: [MAKTAB_SUBSCRIPTION_PLAN], defaultPlan: MAKTAB_SUBSCRIPTION_PLAN });
});

router.get('/public/institution-status', rateLimit(20, 60000), async (req, res) => {
  try {
    await ensureSeeded();
    const email = String(req.query.email || '').trim().toLowerCase();
    if (!email) {
      return res.status(400).json({ error: 'Admin email is required.' });
    }
    const rows = await db
      .select({
        id: institutions.id,
        name: institutions.name,
        slug: institutions.slug,
        status: institutions.status,
        subscriptionPlan: institutions.subscriptionPlan,
        subscriptionAmount: institutions.subscriptionAmount,
        subscriptionStatus: institutions.subscriptionStatus,
        subscriptionExpiresAt: institutions.subscriptionExpiresAt,
        lastPaymentRef: institutions.lastPaymentRef,
      })
      .from(institutions)
      .where(eq(institutions.requestedAdminEmail, email))
      .orderBy(desc(institutions.id))
      .limit(1);

    if (rows.length === 0) {
      return res.json({ found: false });
    }
    res.json({ found: true, institution: rows[0] });
  } catch (err) {
    console.error('Institution status lookup error:', err);
    res.status(500).json({ error: 'Failed to check institution application status' });
  }
});

router.post('/public/institution-application', rateLimit(10, 60000), async (req, res) => {
  try {
    await ensureSeeded();
    const {
      name,
      city,
      contactEmail,
      contactPhone,
      address,
      adminName,
      adminEmail,
      adminPassword,
      paySubscriptionNow,
      paymentMethod,
      paymentReference,
    } = req.body;
    if (!name || !adminName || !adminEmail || !adminPassword || String(adminPassword).length < 6) {
      return res
        .status(400)
        .json({ error: 'Institution name, admin name, valid email, and password (min 6 chars) are required.' });
    }
    const normalizedAdminEmail = String(adminEmail).trim().toLowerCase();
    if (isPlatformOwnerEmail(normalizedAdminEmail)) {
      return res.status(403).json({ error: 'Platform Owner email cannot be used to register a Maktab.' });
    }

    const existingUser = await db.select().from(users).where(eq(users.email, normalizedAdminEmail)).limit(1);
    if (existingUser.length > 0) {
      return res.status(409).json({ error: 'An account with this admin email already exists.' });
    }

    const existingApp = await db
      .select()
      .from(institutions)
      .where(eq(institutions.requestedAdminEmail, normalizedAdminEmail))
      .orderBy(desc(institutions.id))
      .limit(1);
    if (existingApp.length > 0) {
      if (existingApp[0].status === 'pending') {
        return res.status(409).json({
          error: `An application for "${existingApp[0].name}" with this admin email is already awaiting Super Admin approval.`,
        });
      }
      if (existingApp[0].status === 'approved') {
        return res.status(409).json({
          error: `An approved Maktab ("${existingApp[0].name}") already uses this admin email. Please sign in on the Sign In tab.`,
        });
      }
    }

    const baseSlug = String(name)
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-|-$/g, '')
      .slice(0, 32);
    const slug = `${baseSlug || 'maktab'}-${Math.floor(100 + Math.random() * 900)}`;
    const code = `MK-${Math.floor(1000 + Math.random() * 9000)}`;
    const trimmedAdminPass = String(adminPassword).trim();
    if (trimmedAdminPass.length < 6) {
      return res.status(400).json({ error: 'Admin password must be at least 6 characters.' });
    }
    const passwordHash = await bcrypt.hash(trimmedAdminPass, 10);

    const [created] = await db
      .insert(institutions)
      .values({
        name: String(name).trim(),
        slug,
        code,
        city: city ? String(city).trim() : null,
        contactEmail: contactEmail ? String(contactEmail).trim() : normalizedAdminEmail,
        contactPhone: contactPhone ? String(contactPhone).trim() : null,
        address: address ? String(address).trim() : null,
        status: 'pending',
        requestedAdminName: String(adminName).trim(),
        requestedAdminEmail: normalizedAdminEmail,
        requestedAdminPasswordHash: passwordHash,
        subscriptionPlan: 'standard',
        subscriptionAmount: 0,
        subscriptionStatus: 'active',
        subscriptionExpiresAt: null,
        lastPaymentRef: null,
      })
      .returning();

    await logAudit({
      institutionId: created.id,
      userEmail: normalizedAdminEmail,
      action: 'SUBMIT_INSTITUTION_APPLICATION',
      entityType: 'institutions',
      entityId: created.id,
      details: `New Maktab registration submitted: ${created.name} (${normalizedAdminEmail}) — awaiting Super Admin approval`,
      ipAddress: req.ip,
    });

    res.status(201).json({
      id: created.id,
      name: created.name,
      slug: created.slug,
      status: created.status,
      adminEmail: normalizedAdminEmail,
      message: 'Maktab registration submitted and awaiting Super Admin approval. Your account activates once approved.',
    });
  } catch (err) {
    console.error('Institution application error:', err);
    res.status(500).json({ error: 'Failed to submit institution application' });
  }
});

router.get('/public/overview', async (req, res) => {
  try {
    await ensureSeeded();
    const slugParam = req.query.slug ? String(req.query.slug) : null;
    const inst = await resolveApprovedInstitution(slugParam);
    if (!inst) {
      return res.json({
        institution: null,
        settings: {},
        notices: [],
        teachers: [],
        classes: [],
        subjects: [],
        stats: { totalStudents: 0, totalTeachers: 0, totalClasses: 0, totalSubjects: 0 },
      });
    }

    const [settingsRows, noticeRows, teacherRows, classRows, subjectRows, studentCount] = await Promise.all([
      db.select().from(websiteSettings).where(eq(websiteSettings.institutionId, inst.id)),
      db
        .select()
        .from(notices)
        .where(eq(notices.institutionId, inst.id))
        .orderBy(desc(notices.isPinned), desc(notices.publishedAt))
        .limit(12),
      db
        .select({
          id: users.id,
          name: users.name,
          specialization: users.specialization,
          qualification: users.qualification,
        })
        .from(users)
        .where(and(eq(users.institutionId, inst.id), eq(users.role, 'teacher'), eq(users.isActive, true))),
      db.select().from(classes).where(eq(classes.institutionId, inst.id)),
      db.select().from(subjects).where(eq(subjects.institutionId, inst.id)),
      db
        .select({ count: sql<number>`count(*)::int` })
        .from(students)
        .where(eq(students.institutionId, inst.id)),
    ]);

    const settings: Record<string, string> = {};
    for (const row of settingsRows) {
      settings[row.key] = row.value;
    }

    res.json({
      institution: { id: inst.id, name: inst.name, slug: inst.slug, code: inst.code, city: inst.city },
      settings,
      notices: noticeRows,
      teachers: teacherRows,
      classes: classRows,
      subjects: subjectRows,
      stats: {
        totalStudents: studentCount[0]?.count ?? 0,
        totalTeachers: teacherRows.length,
        totalClasses: classRows.length,
        totalSubjects: subjectRows.length,
      },
    });
  } catch (err) {
    console.error('Public overview error:', err);
    res.status(500).json({ error: 'Failed to load Maktab overview' });
  }
});

router.post('/public/admission', rateLimit(15, 60000), async (req, res) => {
  try {
    await ensureSeeded();
    const {
      institutionId,
      institutionSlug,
      applicantName,
      dob,
      gender,
      guardianName,
      guardianPhone,
      guardianEmail,
      desiredClass,
      previousEducation,
      address,
    } = req.body;

    if (!applicantName || !dob || !guardianName || !guardianPhone || !desiredClass || !address) {
      return res.status(400).json({ error: 'Please complete all required admission fields.' });
    }

    const inst = await resolveApprovedInstitution(institutionSlug || institutionId);
    if (!inst) {
      return res.status(400).json({ error: 'Selected institution was not found or is not active.' });
    }

    const [created] = await db
      .insert(admissions)
      .values({
        institutionId: inst.id,
        applicantName: String(applicantName).trim(),
        dob: String(dob),
        gender: gender ? String(gender) : 'Male',
        guardianName: String(guardianName).trim(),
        guardianPhone: String(guardianPhone).trim(),
        guardianEmail: guardianEmail ? String(guardianEmail).trim() : null,
        desiredClass: String(desiredClass),
        previousEducation: previousEducation ? String(previousEducation).trim() : null,
        address: String(address).trim(),
        status: 'pending',
      })
      .returning();

    await db.insert(notifications).values({
      institutionId: inst.id,
      title: 'New Admission Application Received',
      message: `${created.applicantName} applied for ${created.desiredClass} (Guardian: ${created.guardianName}).`,
      type: 'announcement',
      targetRole: 'admin',
    });

    await logAudit({
      institutionId: inst.id,
      userEmail: guardianEmail || guardianPhone,
      action: 'SUBMIT_ADMISSION',
      entityType: 'admissions',
      entityId: created.id,
      details: `Online admission submitted for ${created.applicantName} at ${inst.name}`,
      ipAddress: req.ip,
    });

    res.status(201).json(created);
  } catch (err) {
    console.error('Admission submit error:', err);
    res.status(500).json({ error: 'Failed to submit admission application' });
  }
});

router.post('/public/contact', rateLimit(15, 60000), async (req, res) => {
  try {
    await ensureSeeded();
    const { institutionId, institutionSlug, name, email, phone, subject, message } = req.body;
    if (!name || !message) {
      return res.status(400).json({ error: 'Name and message are required.' });
    }

    const inst = await resolveApprovedInstitution(institutionSlug || institutionId);
    if (!inst) {
      return res.status(400).json({ error: 'Institution not found.' });
    }

    const [notif] = await db
      .insert(notifications)
      .values({
        institutionId: inst.id,
        title: `Contact Inquiry: ${subject || 'General'}`,
        message: `From ${name} (${email || phone || 'No contact'}): ${message}`,
        type: 'announcement',
        targetRole: 'admin',
      })
      .returning();

    res.status(201).json({ success: true, id: notif.id });
  } catch (err) {
    console.error('Contact form error:', err);
    res.status(500).json({ error: 'Failed to submit contact inquiry' });
  }
});

// ==================== AUTH ENDPOINTS ====================

router.post('/auth/login', rateLimit(20, 60000), async (req, res) => {
  try {
    await ensureSeeded();
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required.' });
    }

    const normalizedLoginEmail = String(email).trim().toLowerCase();
    let rows = await db
      .select()
      .from(users)
      .where(eq(users.email, normalizedLoginEmail))
      .limit(1);

    if (rows.length === 0) {
      // Check if this email submitted a New Maktab application so we give a clear status message (or self-heal approved ones)
      const appRows = await db
        .select()
        .from(institutions)
        .where(eq(institutions.requestedAdminEmail, normalizedLoginEmail))
        .orderBy(desc(institutions.id))
        .limit(1);

      if (appRows.length > 0) {
        const appInst = appRows[0];
        if (appInst.status === 'pending') {
          return res.status(403).json({
            error: `Your New Maktab application for "${appInst.name}" is still pending Super Admin approval. Once approved, you can sign in here.`,
          });
        }
        if (appInst.status === 'rejected') {
          return res.status(403).json({
            error: `Your New Maktab application for "${appInst.name}" was rejected. Please contact the Platform Owner.`,
          });
        }
        if (appInst.status === 'suspended') {
          return res.status(403).json({
            error: `Your institution "${appInst.name}" is currently suspended. Please contact the Platform Owner.`,
          });
        }
        if (appInst.status === 'approved' && appInst.requestedAdminPasswordHash) {
          const validAppPass = await bcrypt.compare(String(password), appInst.requestedAdminPasswordHash);
          if (!validAppPass) {
            return res.status(401).json({ error: 'Invalid email or password.' });
          }
          const provisioned = await ensureInstitutionAdminAccount(appInst);
          if (provisioned.admin) {
            rows = await db
              .select()
              .from(users)
              .where(eq(users.email, normalizedLoginEmail))
              .limit(1);
          }
        }
      }
    }

    if (rows.length === 0 || !rows[0].passwordHash) {
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    const user = rows[0];
    if (!user.isActive || !user.passwordHash) {
      return res.status(403).json({ error: 'Account is deactivated or password login is not enabled.' });
    }

    const rawPass = String(password);
    const trimmedPass = rawPass.trim();
    let valid =
      (await bcrypt.compare(rawPass, user.passwordHash)) ||
      (trimmedPass !== rawPass && (await bcrypt.compare(trimmedPass, user.passwordHash)));

    if (!valid && user.role === 'admin' && user.institutionId) {
      const ownInstRows = await db
        .select()
        .from(institutions)
        .where(eq(institutions.id, user.institutionId))
        .limit(1);
      const reqHash = ownInstRows[0]?.requestedAdminPasswordHash;
      if (
        reqHash &&
        ((await bcrypt.compare(rawPass, reqHash)) ||
          (trimmedPass !== rawPass && (await bcrypt.compare(trimmedPass, reqHash))))
      ) {
        await db.update(users).set({ passwordHash: reqHash }).where(eq(users.id, user.id));
        valid = true;
      }
    }

    if (!valid) {
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    const isOwner = isPlatformOwnerEmail(user.email);
    const effectiveRole = isOwner ? 'super_admin' : user.role === 'super_admin' ? 'parent' : user.role;
    const effectiveInstitutionId = isOwner ? null : user.institutionId;

    let institutionMeta: { name: string; slug: string; status: string } | null = null;
    if (effectiveInstitutionId) {
      const instRows = await db
        .select()
        .from(institutions)
        .where(eq(institutions.id, effectiveInstitutionId))
        .limit(1);
      if (!instRows[0] || instRows[0].status !== 'approved') {
        const instStatus = instRows[0]?.status || 'pending';
        const instName = instRows[0]?.name || 'Your institution';
        return res.status(403).json({
          error: `${instName} workspace is currently ${instStatus}. Please wait for Super Admin approval or contact the Platform Owner.`,
        });
      }
      institutionMeta = { name: instRows[0].name, slug: instRows[0].slug, status: instRows[0].status };
    } else if (effectiveRole !== 'super_admin') {
      return res.status(403).json({ error: 'Account is not linked to an approved institution.' });
    }

    if (effectiveRole === 'student' || effectiveRole === 'parent') {
      const enrollmentCheck = await verifyAndEnsureStudentParentEnrollment({
        id: user.id,
        name: user.name,
        phone: user.phone,
        role: effectiveRole,
        institutionId: effectiveInstitutionId,
      });
      if (!enrollmentCheck.ok) {
        await logAudit({
          institutionId: effectiveInstitutionId,
          userId: user.id,
          userEmail: user.email,
          action: 'LOGIN_BLOCKED_UNLINKED_STUDENT',
          entityType: 'users',
          entityId: user.id,
          details: `Blocked ${effectiveRole} login for ${user.email}: no matching active student in institution #${effectiveInstitutionId}`,
          ipAddress: req.ip,
        });
        return res.status(403).json({
          error:
            enrollmentCheck.reason ||
            'Access denied: Only students or parents of active enrolled students in this Maktab can sign in.',
        });
      }
    }

    const token = signSessionToken({
      userId: user.id,
      uid: user.uid,
      role: effectiveRole,
      institutionId: effectiveInstitutionId,
      email: user.email,
    });

    await logAudit({
      institutionId: effectiveInstitutionId,
      userId: user.id,
      userEmail: user.email,
      action: 'LOGIN',
      entityType: 'users',
      entityId: user.id,
      details: `Signed in via password to ${effectiveRole} portal`,
      ipAddress: req.ip,
    });

    res.json({
      token,
      user: {
        id: user.id,
        uid: user.uid,
        email: user.email,
        name: user.name,
        role: effectiveRole,
        institutionId: effectiveInstitutionId,
        institutionName: institutionMeta?.name ?? null,
        institutionSlug: institutionMeta?.slug ?? null,
        institutionStatus: institutionMeta?.status ?? null,
        phone: user.phone,
        preferredLang: user.preferredLang,
        specialization: user.specialization,
        qualification: user.qualification,
        isDemo: user.isDemo,
      },
    });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ error: 'Login failed. Please try again.' });
  }
});

router.post('/auth/register', rateLimit(10, 60000), async (req, res) => {
  try {
    await ensureSeeded();
    const {
      name,
      email,
      password,
      phone,
      role,
      institutionId,
      institutionSlug,
      studentName,
      admissionNo,
    } = req.body;

    // Security: Client can NEVER self-assign 'super_admin', 'admin', or 'teacher'
    const allowedSelfRoles = ['parent', 'student'];
    const assignedRole: 'parent' | 'student' = allowedSelfRoles.includes(role) ? role : 'parent';
    const targetStudentName = String(studentName || (assignedRole === 'student' ? name || '' : '')).trim();
    const applicantName = String(name || (assignedRole === 'student' ? targetStudentName : '')).trim();

    if (!applicantName || !targetStudentName || !email || !password || String(password).length < 6) {
      return res.status(400).json({
        error:
          'Full name, enrolled student full name, valid email, and password (min 6 chars) are required.',
      });
    }

    const normalizedEmail = String(email).trim().toLowerCase();

    if (isPlatformOwnerEmail(normalizedEmail)) {
      return res.status(403).json({ error: 'Reserved platform owner email.' });
    }

    const pendingMaktab = await db
      .select()
      .from(institutions)
      .where(eq(institutions.requestedAdminEmail, normalizedEmail))
      .orderBy(desc(institutions.id))
      .limit(1);
    if (pendingMaktab.length > 0 && (pendingMaktab[0].status === 'pending' || pendingMaktab[0].status === 'approved')) {
      return res.status(409).json({
        error: `This email is reserved for the Institution Admin of "${pendingMaktab[0].name}" (${pendingMaktab[0].status}). Please use the Sign In tab instead, or register with a different email.`,
      });
    }

    // Strictly resolve the exact selected institution (NEVER fall back to another Maktab)
    const instIdentifier = institutionSlug || institutionId;
    if (!instIdentifier) {
      return res.status(400).json({ error: 'Please select the Maktab where the student is enrolled.' });
    }

    const instRows =
      typeof instIdentifier === 'string' && Number.isNaN(Number(instIdentifier))
        ? await db.select().from(institutions).where(eq(institutions.slug, instIdentifier)).limit(1)
        : await db.select().from(institutions).where(eq(institutions.id, Number(instIdentifier))).limit(1);

    const inst = instRows[0];
    if (!inst) {
      return res.status(400).json({ error: 'Selected Maktab was not found.' });
    }
    if (inst.status !== 'approved') {
      return res.status(403).json({
        error: `"${inst.name}" is currently ${inst.status} and is not open for student or parent registration.`,
      });
    }

    const existing = await db.select().from(users).where(eq(users.email, normalizedEmail)).limit(1);
    if (existing.length > 0) {
      return res.status(409).json({ error: 'An account with this email already exists.' });
    }

    // Verify the student is actively enrolled in THIS exact Maktab
    const instStudents = await db
      .select()
      .from(students)
      .where(and(eq(students.institutionId, inst.id), eq(students.status, 'active')));

    const normalizedTargetStudent = normalizePersonName(targetStudentName);
    const normalizedAdm = admissionNo ? String(admissionNo).trim().toLowerCase() : '';

    const matchedStudents = instStudents.filter((s) => {
      if (normalizePersonName(s.fullName) !== normalizedTargetStudent) return false;
      if (normalizedAdm) {
        return String(s.admissionNo || '').trim().toLowerCase() === normalizedAdm;
      }
      return true;
    });

    if (matchedStudents.length === 0) {
      await logAudit({
        institutionId: inst.id,
        userEmail: normalizedEmail,
        action: 'REGISTER_BLOCKED_WRONG_MAKTAB',
        entityType: 'students',
        details: `Blocked ${assignedRole} registration at ${inst.name}: no active student named "${targetStudentName}"${admissionNo ? ` (${admissionNo})` : ''}`,
        ipAddress: req.ip,
      });
      return res.status(403).json({
        error: `Registration blocked: No enrolled student named "${targetStudentName}"${admissionNo ? ` (Admission No: ${String(admissionNo).trim()})` : ''} was found in ${inst.name}. Please make sure you selected the correct Maktab and spelled the student's enrolled name accurately.`,
      });
    }

    if (matchedStudents.length > 1) {
      return res.status(409).json({
        error: `Multiple students named "${targetStudentName}" are enrolled in ${inst.name}. Please enter the Admission No to verify the exact student.`,
      });
    }

    const matchedStudent = matchedStudents[0];

    if (assignedRole === 'student') {
      if (normalizePersonName(applicantName) !== normalizePersonName(matchedStudent.fullName)) {
        return res.status(403).json({
          error: `Student name must match the enrolled record "${matchedStudent.fullName}" in ${inst.name}.`,
        });
      }
      if (matchedStudent.userId !== null) {
        return res.status(409).json({
          error: `A student login account is already registered for ${matchedStudent.fullName} (${matchedStudent.admissionNo}). Please sign in instead.`,
        });
      }
    } else if (matchedStudent.parentId !== null) {
      return res.status(409).json({
        error: `${matchedStudent.fullName} (${matchedStudent.admissionNo}) is already linked to a registered parent account. Please sign in or contact ${inst.name} Admin.`,
      });
    }

    const passwordHash = await bcrypt.hash(String(password), 10);
    const uid = `usr-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

    const [created] = await db
      .insert(users)
      .values({
        uid,
        email: normalizedEmail,
        passwordHash,
        name: assignedRole === 'student' ? matchedStudent.fullName : applicantName,
        role: assignedRole,
        institutionId: inst.id,
        phone: phone ? String(phone).trim() : null,
        preferredLang: 'en',
        isActive: true,
        isDemo: false,
      })
      .returning();

    // Atomically link student/parent account to the verified enrolled student record
    if (assignedRole === 'student') {
      const [linked] = await db
        .update(students)
        .set({ userId: created.id })
        .where(and(eq(students.id, matchedStudent.id), isNull(students.userId)))
        .returning({ id: students.id });
      if (!linked) {
        await db.delete(users).where(eq(users.id, created.id));
        return res.status(409).json({
          error: `This student record was just claimed by another account. Please sign in instead.`,
        });
      }
    } else {
      const [linked] = await db
        .update(students)
        .set({ parentId: created.id })
        .where(and(eq(students.id, matchedStudent.id), isNull(students.parentId)))
        .returning({ id: students.id });
      if (!linked) {
        await db.delete(users).where(eq(users.id, created.id));
        return res.status(409).json({
          error: `This student record was just linked to another parent account. Please sign in or contact your Maktab Admin.`,
        });
      }
    }

    const token = signSessionToken({
      userId: created.id,
      uid: created.uid,
      role: created.role,
      institutionId: created.institutionId,
      email: created.email,
    });

    await logAudit({
      institutionId: inst.id,
      userId: created.id,
      userEmail: created.email,
      action: 'REGISTER',
      entityType: 'users',
      entityId: created.id,
      details: `Registered & linked ${created.role} account for student ${matchedStudent.fullName} (${matchedStudent.admissionNo}) at ${inst.name}`,
      ipAddress: req.ip,
    });

    res.status(201).json({
      token,
      user: {
        id: created.id,
        uid: created.uid,
        email: created.email,
        name: created.name,
        role: created.role,
        institutionId: created.institutionId,
        institutionName: inst.name,
        institutionSlug: inst.slug,
        institutionStatus: inst.status,
        phone: created.phone,
        preferredLang: created.preferredLang,
        isDemo: created.isDemo,
      },
    });
  } catch (err) {
    console.error('Register error:', err);
    res.status(500).json({ error: 'Registration failed.' });
  }
});

router.get('/auth/me', requireAuth, async (req: AuthRequest, res) => {
  try {
    const user = req.dbUser!;
    let linkedStudents: any[] = [];
    let assignedClasses: any[] = [];

    if (user.institutionId) {
      if (user.role === 'parent') {
        linkedStudents = await db
          .select()
          .from(students)
          .where(and(eq(students.institutionId, user.institutionId), eq(students.parentId, user.id)));
      } else if (user.role === 'student') {
        linkedStudents = await db
          .select()
          .from(students)
          .where(and(eq(students.institutionId, user.institutionId), eq(students.userId, user.id)));
      } else if (user.role === 'teacher') {
        const classIds = await getTeacherClassIds(user.id, user.institutionId);
        if (classIds.length > 0) {
          assignedClasses = await db
            .select()
            .from(classes)
            .where(and(eq(classes.institutionId, user.institutionId), inArray(classes.id, classIds)));
        }
      }
    }

    res.json({ user, linkedStudents, assignedClasses });
  } catch (err) {
    console.error('Auth me error:', err);
    res.status(500).json({ error: 'Failed to load profile' });
  }
});

router.patch('/auth/preferences', requireAuth, async (req: AuthRequest, res) => {
  try {
    const { preferredLang } = req.body;
    if (!['en', 'hi', 'ur'].includes(preferredLang)) {
      return res.status(400).json({ error: 'Invalid language code' });
    }
    const [updated] = await db
      .update(users)
      .set({ preferredLang })
      .where(eq(users.id, req.dbUser!.id))
      .returning();
    res.json({ preferredLang: updated.preferredLang });
  } catch (err) {
    console.error('Preferences error:', err);
    res.status(500).json({ error: 'Failed to update preference' });
  }
});

// ==================== PLATFORM OWNER / SUPER ADMIN CONSOLE ====================

router.get('/super-admin/overview', requireAuth, requireRole('super_admin'), async (req: AuthRequest, res) => {
  try {
    if (!isPlatformOwnerEmail(req.dbUser!.email)) {
      return res.status(403).json({ error: 'Forbidden: Only the verified Platform Owner may access this console.' });
    }

    const [instRows, userRows, studentCounts, classCounts, logsRows, roleRows, subRows] = await Promise.all([
      db.select().from(institutions).orderBy(institutions.id),
      db
        .select({
          id: users.id,
          name: users.name,
          email: users.email,
          role: users.role,
          institutionId: users.institutionId,
          isActive: users.isActive,
          isDemo: users.isDemo,
          createdAt: users.createdAt,
        })
        .from(users)
        .orderBy(users.id),
      db
        .select({ institutionId: students.institutionId, count: sql<number>`count(*)::int` })
        .from(students)
        .groupBy(students.institutionId),
      db
        .select({ institutionId: classes.institutionId, count: sql<number>`count(*)::int` })
        .from(classes)
        .groupBy(classes.institutionId),
      db.select().from(auditLogs).orderBy(desc(auditLogs.createdAt)).limit(40),
      db.select().from(roles).orderBy(roles.id),
      db.select().from(institutionSubscriptions).orderBy(desc(institutionSubscriptions.createdAt)).limit(100),
    ]);

    const studentMap = new Map(studentCounts.map((s) => [s.institutionId, s.count]));
    const classMap = new Map(classCounts.map((c) => [c.institutionId, c.count]));
    const instNameMap = new Map(instRows.map((i) => [i.id, i.name]));

    const institutionsSummary = instRows.map(({ requestedAdminPasswordHash: _ph, ...inst }) => {
      const instUsers = userRows.filter((u) => u.institutionId === inst.id);
      const admins = instUsers.filter((u) => u.role === 'admin');
      return {
        ...inst,
        adminCount: admins.length,
        admins,
        userCount: instUsers.length,
        studentCount: studentMap.get(inst.id) ?? 0,
        classCount: classMap.get(inst.id) ?? 0,
      };
    });

    const activeSubscriptions = instRows.filter((i) => i.subscriptionStatus === 'active').length;
    const pendingSubscriptionPayments = subRows.filter((s) => s.status === 'pending_approval').length;
    const totalCollectedSubscriptionRevenue = subRows
      .filter((s) => s.status === 'paid')
      .reduce((acc, s) => acc + (s.amount || 0), 0);

    res.json({
      stats: {
        totalInstitutions: instRows.length,
        approvedInstitutions: instRows.filter((i) => i.status === 'approved').length,
        pendingInstitutions: instRows.filter((i) => i.status === 'pending').length,
        suspendedInstitutions: instRows.filter((i) => i.status === 'suspended').length,
        totalUsers: userRows.length,
        superAdminCount: userRows.filter((u) => u.role === 'super_admin').length,
        activeSubscriptions,
        pendingSubscriptionPayments,
        monthlySubscriptionRevenue: activeSubscriptions * MAKTAB_SUBSCRIPTION_PLAN.priceInr,
        totalCollectedSubscriptionRevenue,
      },
      subscriptionPlan: MAKTAB_SUBSCRIPTION_PLAN,
      institutions: institutionsSummary,
      subscriptions: subRows.map((s) => ({
        ...s,
        institutionName: instNameMap.get(s.institutionId) || `Institution #${s.institutionId}`,
      })),
      platformUsers: userRows,
      roles: roleRows,
      auditLogs: logsRows,
    });
  } catch (err) {
    console.error('Super Admin overview error:', err);
    res.status(500).json({ error: 'Failed to load Platform Owner console' });
  }
});

router.post('/super-admin/institutions', requireAuth, requireRole('super_admin'), async (req: AuthRequest, res) => {
  try {
    if (!isPlatformOwnerEmail(req.dbUser!.email)) {
      return res.status(403).json({ error: 'Forbidden' });
    }
    const {
      name,
      slug,
      code,
      city,
      contactEmail,
      contactPhone,
      address,
      adminName,
      adminEmail,
      adminPassword,
      activateSubscription = true,
    } = req.body;
    if (!name || !adminName || !adminEmail || !adminPassword || String(adminPassword).length < 6) {
      return res.status(400).json({ error: 'Institution name and admin details (min 6 char password) are required.' });
    }

    const normalizedAdminEmail = String(adminEmail).trim().toLowerCase();
    if (isPlatformOwnerEmail(normalizedAdminEmail)) {
      return res.status(400).json({ error: 'Platform Owner email cannot be used as an Institution Admin.' });
    }

    const existingUser = await db.select().from(users).where(eq(users.email, normalizedAdminEmail)).limit(1);
    if (existingUser.length > 0) {
      return res.status(409).json({ error: 'An account with this Institution Admin email already exists.' });
    }

    const cleanSlug =
      (slug ? String(slug) : String(name))
        .trim()
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/^-|-$/g, '') || `maktab-${Date.now()}`;
    const cleanCode = code ? String(code).trim().toUpperCase() : `MK-${Math.floor(1000 + Math.random() * 9000)}`;

    const now = new Date();

    const [createdInst] = await db
      .insert(institutions)
      .values({
        name: String(name).trim(),
        slug: cleanSlug,
        code: cleanCode,
        city: city ? String(city).trim() : null,
        contactEmail: contactEmail ? String(contactEmail).trim() : normalizedAdminEmail,
        contactPhone: contactPhone ? String(contactPhone).trim() : null,
        address: address ? String(address).trim() : null,
        status: 'approved',
        requestedAdminName: String(adminName).trim(),
        requestedAdminEmail: normalizedAdminEmail,
        approvedBy: req.dbUser!.id,
        approvedAt: now,
        subscriptionPlan: 'standard',
        subscriptionAmount: 0,
        subscriptionStatus: 'active',
        subscriptionExpiresAt: null,
        lastPaymentRef: null,
      })
      .returning();

    const adminHash = await bcrypt.hash(String(adminPassword), 10);
    const [createdAdmin] = await db
      .insert(users)
      .values({
        uid: `inst-admin-${createdInst.id}-${Date.now()}`,
        email: normalizedAdminEmail,
        passwordHash: adminHash,
        name: String(adminName).trim(),
        role: 'admin',
        institutionId: createdInst.id,
        phone: contactPhone ? String(contactPhone).trim() : null,
        preferredLang: 'en',
        isActive: true,
        isDemo: false,
      })
      .returning();

    // Fresh empty workspace: ONLY default website settings & policies, zero sample students/classes/fees
    await provisionInstitutionSettings(createdInst.id, {
      name: createdInst.name,
      contactEmail: createdInst.contactEmail,
      contactPhone: createdInst.contactPhone,
      address: createdInst.address,
    });
    await provisionInstitutionPolicy(createdInst.id);

    await logAudit({
      institutionId: createdInst.id,
      userId: req.dbUser!.id,
      userEmail: req.dbUser!.email,
      action: 'CREATE_APPROVED_INSTITUTION',
      entityType: 'institutions',
      entityId: createdInst.id,
      details: `Created & approved fresh workspace for ${createdInst.name} with Institution Admin ${createdAdmin.email} (Plan ₹399/mo: ${createdInst.subscriptionStatus})`,
    });

    const { passwordHash: _ph, ...safeAdmin } = createdAdmin;
    res.status(201).json({ institution: createdInst, admin: safeAdmin });
  } catch (err) {
    console.error('Create institution error:', err);
    res.status(500).json({ error: 'Failed to provision institution workspace' });
  }
});

router.patch('/super-admin/institutions/:id/approve', requireAuth, requireRole('super_admin'), async (req: AuthRequest, res) => {
  try {
    if (!isPlatformOwnerEmail(req.dbUser!.email)) {
      return res.status(403).json({ error: 'Forbidden' });
    }
    const instId = Number(req.params.id);
    const instRows = await db.select().from(institutions).where(eq(institutions.id, instId)).limit(1);
    if (instRows.length === 0) return res.status(404).json({ error: 'Institution not found' });

    const inst = instRows[0];
    const adminResult = await ensureInstitutionAdminAccount(inst, {
      adminName: req.body?.adminName,
      adminEmail: req.body?.adminEmail,
      adminPassword: req.body?.adminPassword,
    });
    if (adminResult.error) {
      return res.status(adminResult.status || 400).json({ error: adminResult.error });
    }

    const [approvedInst] = await db
      .update(institutions)
      .set({ status: 'approved', approvedBy: req.dbUser!.id, approvedAt: new Date() })
      .where(eq(institutions.id, instId))
      .returning();

    await provisionInstitutionSettings(inst.id, {
      name: approvedInst.name,
      contactEmail: approvedInst.contactEmail,
      contactPhone: approvedInst.contactPhone,
      address: approvedInst.address,
    });
    await provisionInstitutionPolicy(inst.id);

    await logAudit({
      institutionId: inst.id,
      userId: req.dbUser!.id,
      userEmail: req.dbUser!.email,
      action: 'APPROVE_INSTITUTION',
      entityType: 'institutions',
      entityId: inst.id,
      details: `Approved ${approvedInst.name}, activated Institution Admin (${adminResult.admin?.email}), and provisioned fresh empty workspace`,
    });

    res.json({ institution: approvedInst, admin: adminResult.admin });
  } catch (err) {
    console.error('Approve institution error:', err);
    res.status(500).json({ error: 'Failed to approve institution' });
  }
});

router.patch('/super-admin/institutions/:id/admin-credentials', requireAuth, requireRole('super_admin'), async (req: AuthRequest, res) => {
  try {
    if (!isPlatformOwnerEmail(req.dbUser!.email)) {
      return res.status(403).json({ error: 'Forbidden' });
    }
    const instId = Number(req.params.id);
    const { adminName, adminEmail, adminPassword } = req.body;
    if (adminPassword && String(adminPassword).trim().length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters.' });
    }

    const instRows = await db.select().from(institutions).where(eq(institutions.id, instId)).limit(1);
    if (instRows.length === 0) return res.status(404).json({ error: 'Institution not found' });

    const inst = instRows[0];
    const adminResult = await ensureInstitutionAdminAccount(inst, {
      adminName,
      adminEmail,
      adminPassword,
    });
    if (adminResult.error) {
      return res.status(adminResult.status || 400).json({ error: adminResult.error });
    }

    await logAudit({
      institutionId: inst.id,
      userId: req.dbUser!.id,
      userEmail: req.dbUser!.email,
      action: 'UPDATE_INSTITUTION_ADMIN_CREDENTIALS',
      entityType: 'institutions',
      entityId: inst.id,
      details: `Updated/activated Institution Admin login (${adminResult.admin?.email}) for ${inst.name}`,
    });

    res.json({ institution: inst, admin: adminResult.admin });
  } catch (err) {
    console.error('Admin credentials update error:', err);
    res.status(500).json({ error: 'Failed to update institution admin credentials' });
  }
});

router.patch('/super-admin/institutions/:id/status', requireAuth, requireRole('super_admin'), async (req: AuthRequest, res) => {
  try {
    if (!isPlatformOwnerEmail(req.dbUser!.email)) {
      return res.status(403).json({ error: 'Forbidden' });
    }
    const instId = Number(req.params.id);
    const { status } = req.body;
    if (!['approved', 'suspended', 'rejected'].includes(status)) {
      return res.status(400).json({ error: 'Invalid status' });
    }

    const existingRows = await db.select().from(institutions).where(eq(institutions.id, instId)).limit(1);
    if (existingRows.length === 0) return res.status(404).json({ error: 'Institution not found' });

    let provisionedAdmin: any = null;
    if (status === 'approved') {
      const adminResult = await ensureInstitutionAdminAccount(existingRows[0]);
      if (adminResult.error) {
        return res.status(adminResult.status || 400).json({ error: adminResult.error });
      }
      provisionedAdmin = adminResult.admin;
    }

    const [updated] = await db
      .update(institutions)
      .set({
        status,
        ...(status === 'approved' ? { approvedBy: req.dbUser!.id, approvedAt: new Date() } : {}),
      })
      .where(eq(institutions.id, instId))
      .returning();

    if (status === 'approved') {
      await provisionInstitutionSettings(instId, {
        name: updated.name,
        contactEmail: updated.contactEmail,
        contactPhone: updated.contactPhone,
        address: updated.address,
      });
      await provisionInstitutionPolicy(instId);
    }

    await logAudit({
      institutionId: instId,
      userId: req.dbUser!.id,
      userEmail: req.dbUser!.email,
      action: 'UPDATE_INSTITUTION_STATUS',
      entityType: 'institutions',
      entityId: instId,
      details: `Changed ${updated.name} status to ${status}`,
    });

    res.json({ ...updated, admin: provisionedAdmin });
  } catch (err) {
    console.error('Institution status error:', err);
    res.status(500).json({ error: 'Failed to update institution status' });
  }
});

router.patch('/super-admin/institutions/:id/subscription', requireAuth, requireRole('super_admin'), async (req: AuthRequest, res) => {
  try {
    if (!isPlatformOwnerEmail(req.dbUser!.email)) {
      return res.status(403).json({ error: 'Forbidden' });
    }
    const instId = Number(req.params.id);
    const { action = 'activate_30_days', paymentMethod = 'manual_super_admin', transactionRef } = req.body;
    const instRows = await db.select().from(institutions).where(eq(institutions.id, instId)).limit(1);
    if (instRows.length === 0) return res.status(404).json({ error: 'Institution not found' });

    const inst = instRows[0];
    if (action === 'activate_30_days') {
      const now = new Date();
      const baseStart =
        inst.subscriptionExpiresAt && new Date(inst.subscriptionExpiresAt).getTime() > now.getTime()
          ? new Date(inst.subscriptionExpiresAt)
          : now;
      const nextExpiry = new Date(baseStart.getTime() + MAKTAB_SUBSCRIPTION_PLAN.durationDays * 86400 * 1000);
      const txRef =
        (transactionRef && String(transactionRef).trim()) ||
        `SUB399-SA-${Date.now().toString().slice(-6)}`;

      const [updatedInst] = await db
        .update(institutions)
        .set({
          subscriptionPlan: MAKTAB_SUBSCRIPTION_PLAN.code,
          subscriptionAmount: MAKTAB_SUBSCRIPTION_PLAN.priceInr,
          subscriptionStatus: 'active',
          subscriptionExpiresAt: nextExpiry,
          lastPaymentRef: txRef,
        })
        .where(eq(institutions.id, instId))
        .returning();

      const [subEntry] = await db
        .insert(institutionSubscriptions)
        .values({
          institutionId: instId,
          planCode: MAKTAB_SUBSCRIPTION_PLAN.code,
          planName: MAKTAB_SUBSCRIPTION_PLAN.name,
          amount: MAKTAB_SUBSCRIPTION_PLAN.priceInr,
          currency: MAKTAB_SUBSCRIPTION_PLAN.currency,
          billingCycle: MAKTAB_SUBSCRIPTION_PLAN.billingCycle,
          paymentMethod: String(paymentMethod),
          transactionRef: txRef,
          status: 'paid',
          periodStart: baseStart,
          periodEnd: nextExpiry,
          paidByEmail: req.dbUser!.email,
        })
        .returning();

      await logAudit({
        institutionId: instId,
        userId: req.dbUser!.id,
        userEmail: req.dbUser!.email,
        action: 'ACTIVATE_MAKTAB_SUBSCRIPTION',
        entityType: 'institution_subscriptions',
        entityId: subEntry.id,
        details: `Activated/extended ₹399/mo subscription for ${inst.name} until ${nextExpiry.toISOString().slice(0, 10)} (Ref: ${txRef})`,
      });

      return res.json({ institution: updatedInst, subscription: subEntry });
    }

    if (action === 'mark_expired' || action === 'mark_pending_payment') {
      const nextStatus = action === 'mark_expired' ? 'expired' : 'pending_payment';
      const [updatedInst] = await db
        .update(institutions)
        .set({ subscriptionStatus: nextStatus })
        .where(eq(institutions.id, instId))
        .returning();

      await logAudit({
        institutionId: instId,
        userId: req.dbUser!.id,
        userEmail: req.dbUser!.email,
        action: 'UPDATE_MAKTAB_SUBSCRIPTION_STATUS',
        entityType: 'institutions',
        entityId: instId,
        details: `Set ${inst.name} ₹399 subscription status to ${nextStatus}`,
      });

      return res.json({ institution: updatedInst });
    }

    res.status(400).json({ error: 'Invalid subscription action' });
  } catch (err) {
    console.error('Super Admin subscription update error:', err);
    res.status(500).json({ error: 'Failed to update institution subscription' });
  }
});

router.patch('/super-admin/subscriptions/:subId/decision', requireAuth, requireRole('super_admin'), async (req: AuthRequest, res) => {
  try {
    if (!isPlatformOwnerEmail(req.dbUser!.email)) {
      return res.status(403).json({ error: 'Forbidden' });
    }
    const subId = Number(req.params.subId);
    const { decision } = req.body || {};
    if (decision !== 'approve' && decision !== 'cancel') {
      return res.status(400).json({ error: 'Decision must be approve or cancel.' });
    }

    const subRows = await db
      .select()
      .from(institutionSubscriptions)
      .where(eq(institutionSubscriptions.id, subId))
      .limit(1);
    if (subRows.length === 0) {
      return res.status(404).json({ error: 'Subscription payment record not found' });
    }
    const sub = subRows[0];

    const instRows = await db.select().from(institutions).where(eq(institutions.id, sub.institutionId)).limit(1);
    if (instRows.length === 0) {
      return res.status(404).json({ error: 'Institution not found' });
    }
    const inst = instRows[0];

    if (decision === 'approve') {
      if (sub.status === 'paid') {
        return res.status(400).json({ error: 'Payment is already approved.' });
      }
      const now = new Date();
      const baseStart =
        inst.subscriptionExpiresAt && new Date(inst.subscriptionExpiresAt).getTime() > now.getTime()
          ? new Date(inst.subscriptionExpiresAt)
          : now;
      const nextExpiry = new Date(baseStart.getTime() + MAKTAB_SUBSCRIPTION_PLAN.durationDays * 86400 * 1000);

      const [updatedSub] = await db
        .update(institutionSubscriptions)
        .set({
          status: 'paid',
          periodStart: baseStart,
          periodEnd: nextExpiry,
        })
        .where(eq(institutionSubscriptions.id, subId))
        .returning();

      const [updatedInst] = await db
        .update(institutions)
        .set({
          subscriptionPlan: MAKTAB_SUBSCRIPTION_PLAN.code,
          subscriptionAmount: MAKTAB_SUBSCRIPTION_PLAN.priceInr,
          subscriptionStatus: 'active',
          subscriptionExpiresAt: nextExpiry,
          lastPaymentRef: sub.transactionRef,
        })
        .where(eq(institutions.id, inst.id))
        .returning();

      await db.insert(notifications).values({
        institutionId: inst.id,
        title: `₹${MAKTAB_SUBSCRIPTION_PLAN.priceInr} Subscription Approved`,
        message: `Super Admin approved your ₹${MAKTAB_SUBSCRIPTION_PLAN.priceInr} payment (Ref: ${sub.transactionRef}). Active until ${nextExpiry.toISOString().slice(0, 10)}.`,
        type: 'fee',
        targetRole: 'admin',
        createdBy: req.dbUser!.id,
      });

      await logAudit({
        institutionId: inst.id,
        userId: req.dbUser!.id,
        userEmail: req.dbUser!.email,
        action: 'APPROVE_MAKTAB_SUBSCRIPTION_PAYMENT',
        entityType: 'institution_subscriptions',
        entityId: subId,
        details: `Approved ₹${sub.amount} payment (Ref: ${sub.transactionRef}) for ${inst.name}. Active until ${nextExpiry.toISOString().slice(0, 10)}.`,
      });

      return res.json({ subscription: updatedSub, institution: updatedInst });
    }

    // decision === 'cancel'
    if (sub.status === 'cancelled') {
      return res.status(400).json({ error: 'Payment is already cancelled.' });
    }

    const [updatedSub] = await db
      .update(institutionSubscriptions)
      .set({ status: 'cancelled' })
      .where(eq(institutionSubscriptions.id, subId))
      .returning();

    const remainingPaid = await db
      .select()
      .from(institutionSubscriptions)
      .where(and(eq(institutionSubscriptions.institutionId, inst.id), eq(institutionSubscriptions.status, 'paid')))
      .orderBy(desc(institutionSubscriptions.periodEnd));

    const latestActivePaid = remainingPaid.find(
      (r) => r.periodEnd && new Date(r.periodEnd).getTime() > Date.now()
    );
    const hasRemainingPending =
      (
        await db
          .select({ id: institutionSubscriptions.id })
          .from(institutionSubscriptions)
          .where(
            and(
              eq(institutionSubscriptions.institutionId, inst.id),
              eq(institutionSubscriptions.status, 'pending_approval')
            )
          )
          .limit(1)
      ).length > 0;

    const nextInstSubStatus = latestActivePaid
      ? 'active'
      : hasRemainingPending
        ? 'pending_approval'
        : 'pending_payment';

    const [updatedInst] = await db
      .update(institutions)
      .set({
        subscriptionStatus: nextInstSubStatus,
        subscriptionExpiresAt: latestActivePaid ? latestActivePaid.periodEnd : null,
      })
      .where(eq(institutions.id, inst.id))
      .returning();

    await db.insert(notifications).values({
      institutionId: inst.id,
      title: `₹${MAKTAB_SUBSCRIPTION_PLAN.priceInr} Payment Cancelled`,
      message: `Your submitted ₹${MAKTAB_SUBSCRIPTION_PLAN.priceInr} payment (Ref: ${sub.transactionRef}) was cancelled by Super Admin. Please send a valid WhatsApp payment screenshot (+91 99448 86960) and resubmit.`,
      type: 'fee',
      targetRole: 'admin',
      createdBy: req.dbUser!.id,
    });

    await logAudit({
      institutionId: inst.id,
      userId: req.dbUser!.id,
      userEmail: req.dbUser!.email,
      action: 'CANCEL_MAKTAB_SUBSCRIPTION_PAYMENT',
      entityType: 'institution_subscriptions',
      entityId: subId,
      details: `Cancelled ₹${sub.amount} payment (Ref: ${sub.transactionRef}) for ${inst.name}.`,
    });

    return res.json({ subscription: updatedSub, institution: updatedInst });
  } catch (err) {
    console.error('Super Admin subscription payment decision error:', err);
    res.status(500).json({ error: 'Failed to process payment decision' });
  }
});

router.delete('/super-admin/subscriptions/:subId', requireAuth, requireRole('super_admin'), async (req: AuthRequest, res) => {
  try {
    if (!isPlatformOwnerEmail(req.dbUser!.email)) {
      return res.status(403).json({ error: 'Forbidden' });
    }
    const subId = Number(req.params.subId);
    const subRows = await db
      .select()
      .from(institutionSubscriptions)
      .where(eq(institutionSubscriptions.id, subId))
      .limit(1);
    if (subRows.length === 0) {
      return res.status(404).json({ error: 'Subscription record not found' });
    }
    const sub = subRows[0];
    if (sub.status !== 'cancelled') {
      return res.status(400).json({
        error: 'Only cancelled subscription records can be removed. Please cancel this entry first.',
      });
    }

    await db.delete(institutionSubscriptions).where(eq(institutionSubscriptions.id, subId));

    const instRows = await db.select().from(institutions).where(eq(institutions.id, sub.institutionId)).limit(1);
    if (instRows[0] && instRows[0].lastPaymentRef === sub.transactionRef) {
      const remaining = await db
        .select()
        .from(institutionSubscriptions)
        .where(eq(institutionSubscriptions.institutionId, sub.institutionId))
        .orderBy(desc(institutionSubscriptions.id))
        .limit(1);
      await db
        .update(institutions)
        .set({ lastPaymentRef: remaining[0]?.transactionRef ?? null })
        .where(eq(institutions.id, sub.institutionId));
    }

    await logAudit({
      institutionId: sub.institutionId,
      userId: req.dbUser!.id,
      userEmail: req.dbUser!.email,
      action: 'DELETE_CANCELLED_SUBSCRIPTION',
      entityType: 'institution_subscriptions',
      entityId: subId,
      details: `Removed cancelled ₹${sub.amount} subscription record (UTR: ${sub.transactionRef}).`,
    });

    res.json({ deletedId: subId });
  } catch (err) {
    console.error('Super Admin delete subscription error:', err);
    res.status(500).json({ error: 'Failed to remove subscription record' });
  }
});

router.delete('/super-admin/institutions/:id', requireAuth, requireRole('super_admin'), async (req: AuthRequest, res) => {
  try {
    if (!isPlatformOwnerEmail(req.dbUser!.email)) {
      return res.status(403).json({ error: 'Forbidden' });
    }
    const instId = Number(req.params.id);
    const instRows = await db.select().from(institutions).where(eq(institutions.id, instId)).limit(1);
    if (instRows.length === 0) {
      return res.status(404).json({ error: 'Maktab / Institution not found' });
    }
    const inst = instRows[0];

    await db.delete(institutions).where(eq(institutions.id, instId));

    await logAudit({
      institutionId: null,
      userId: req.dbUser!.id,
      userEmail: req.dbUser!.email,
      action: 'DELETE_INSTITUTION',
      entityType: 'institutions',
      entityId: instId,
      details: `Permanently removed Maktab "${inst.name}" (${inst.code}) and its workspace records.`,
    });

    res.json({ deletedId: instId, name: inst.name });
  } catch (err) {
    console.error('Super Admin delete institution error:', err);
    res.status(500).json({ error: 'Failed to remove Maktab institution' });
  }
});

// ==================== INSTITUTION DASHBOARD OVERVIEW ====================

router.get('/dashboard', requireAuth, requireTenant, async (req: AuthRequest, res) => {
  try {
    await ensureSeeded();
    const user = req.dbUser!;
    const instId = user.institutionId!;
    const scopedIds = await getScopedStudentIds(req);

    let visibleStudents: any[] = [];
    if (scopedIds === null) {
      visibleStudents = await db.select().from(students).where(eq(students.institutionId, instId));
    } else if (scopedIds.length > 0) {
      visibleStudents = await db
        .select()
        .from(students)
        .where(and(eq(students.institutionId, instId), inArray(students.id, scopedIds)));
    }

    const visibleStudentIds = visibleStudents.map((s) => s.id);
    const enrolledClassIds = Array.from(
      new Set(visibleStudents.map((s) => s.classId).filter((id): id is number => Boolean(id)))
    );

    const [allClasses, allSubjects] = await Promise.all([
      user.role === 'student' || user.role === 'parent'
        ? enrolledClassIds.length > 0
          ? db.select().from(classes).where(and(eq(classes.institutionId, instId), inArray(classes.id, enrolledClassIds)))
          : Promise.resolve([])
        : db.select().from(classes).where(eq(classes.institutionId, instId)),
      user.role === 'student' || user.role === 'parent'
        ? enrolledClassIds.length > 0
          ? db.select().from(subjects).where(and(eq(subjects.institutionId, instId), inArray(subjects.classId, enrolledClassIds)))
          : Promise.resolve([])
        : db.select().from(subjects).where(eq(subjects.institutionId, instId)),
    ]);

    const [
      attendanceRows,
      namazRows,
      marksRows,
      examRows,
      homeworkRows,
      assignmentRows,
      feeRows,
      notifRows,
      teacherCountRow,
      parentCountRow,
    ] = await Promise.all([
      visibleStudentIds.length > 0
        ? db
            .select()
            .from(attendance)
            .where(and(eq(attendance.institutionId, instId), inArray(attendance.studentId, visibleStudentIds)))
        : Promise.resolve([]),
      visibleStudentIds.length > 0
        ? db
            .select()
            .from(namazRecords)
            .where(and(eq(namazRecords.institutionId, instId), inArray(namazRecords.studentId, visibleStudentIds)))
        : Promise.resolve([]),
      visibleStudentIds.length > 0
        ? db
            .select()
            .from(marks)
            .where(and(eq(marks.institutionId, instId), inArray(marks.studentId, visibleStudentIds)))
        : Promise.resolve([]),
      user.role === 'student'
        ? enrolledClassIds.length > 0
          ? db.select().from(exams).where(and(eq(exams.institutionId, instId), inArray(exams.classId, enrolledClassIds)))
          : Promise.resolve([])
        : Promise.resolve([]),
      user.role === 'student'
        ? enrolledClassIds.length > 0
          ? db.select().from(homework).where(and(eq(homework.institutionId, instId), inArray(homework.classId, enrolledClassIds)))
          : Promise.resolve([])
        : Promise.resolve([]),
      user.role === 'student' && visibleStudentIds.length > 0
        ? db
            .select()
            .from(assignments)
            .where(and(eq(assignments.institutionId, instId), inArray(assignments.studentId, visibleStudentIds)))
        : Promise.resolve([]),
      user.role !== 'student' && user.role !== 'teacher' && visibleStudentIds.length > 0
        ? db
            .select()
            .from(fees)
            .where(and(eq(fees.institutionId, instId), inArray(fees.studentId, visibleStudentIds)))
        : Promise.resolve([]),
      db
        .select()
        .from(notifications)
        .where(
          and(
            eq(notifications.institutionId, instId),
            or(
              eq(notifications.targetRole, 'all'),
              eq(notifications.targetRole, user.role),
              eq(notifications.targetUserId, user.id)
            )
          )
        )
        .orderBy(desc(notifications.createdAt))
        .limit(15),
      user.role === 'admin'
        ? db
            .select({ count: sql<number>`count(*)::int` })
            .from(users)
            .where(and(eq(users.institutionId, instId), eq(users.role, 'teacher')))
        : Promise.resolve([{ count: 0 }]),
      user.role === 'admin'
        ? db
            .select({ count: sql<number>`count(*)::int` })
            .from(users)
            .where(and(eq(users.institutionId, instId), eq(users.role, 'parent')))
        : Promise.resolve([{ count: 0 }]),
    ]);

    const presentOnly = attendanceRows.filter((a) => a.status === 'present').length;
    const lateOnly = attendanceRows.filter((a) => a.status === 'late').length;
    const absentOnly = attendanceRows.filter((a) => a.status === 'absent').length;
    const leaveOnly = attendanceRows.filter((a) => a.status === 'leave' || a.status === 'excused').length;
    const presentCount = presentOnly + lateOnly;
    const attendanceRate = attendanceRows.length > 0 ? Math.round((presentCount / attendanceRows.length) * 100) : 0;

    const prayers = ['fajr', 'zuhr', 'asr', 'maghrib', 'isha'] as const;
    const namazChartData = prayers.map((p) => {
      let performed = 0;
      let notPerformed = 0;
      let notRecorded = 0;
      for (const rec of namazRows) {
        const val = rec[p];
        if (val === 'performed') performed++;
        else if (val === 'not_performed') notPerformed++;
        else notRecorded++;
      }
      return {
        prayer: p.charAt(0).toUpperCase() + p.slice(1),
        performed,
        notPerformed,
        notRecorded,
      };
    });

    const dateMap = new Map<string, { date: string; present: number; absent: number; late: number }>();
    for (const a of attendanceRows) {
      const entry = dateMap.get(a.date) || { date: a.date, present: 0, absent: 0, late: 0 };
      if (a.status === 'present') entry.present++;
      else if (a.status === 'late') entry.late++;
      else entry.absent++;
      dateMap.set(a.date, entry);
    }
    const attendanceTrend = Array.from(dateMap.values()).sort((a, b) => a.date.localeCompare(b.date));

    const totalPaidFees = feeRows.filter((f) => f.status === 'paid').reduce((acc, f) => acc + f.amount, 0);
    const totalPendingFees = feeRows.filter((f) => f.status !== 'paid').reduce((acc, f) => acc + f.amount, 0);

    const avgScore =
      marksRows.length > 0
        ? Math.round(
            marksRows.reduce((acc, m) => acc + (m.totalMarks > 0 ? (m.obtainedMarks / m.totalMarks) * 100 : 0), 0) /
              marksRows.length
          )
        : 0;

    let personalAnalytics: any = undefined;
    if (user.role === 'student') {
      const exMap = new Map(examRows.map((e) => [e.id, e]));
      const subMap = new Map(allSubjects.map((s) => [s.id, s]));
      const examTrend = marksRows.map((m) => {
        const ex = exMap.get(m.examId);
        const sub = ex ? subMap.get(ex.subjectId) : null;
        const pct = m.totalMarks > 0 ? Math.round((m.obtainedMarks / m.totalMarks) * 100) : 0;
        return {
          examTitle: ex?.title || `Exam #${m.examId}`,
          subjectName: sub?.name || 'Subject',
          obtained: m.obtainedMarks,
          total: m.totalMarks,
          percentage: pct,
          grade: m.grade,
        };
      });
      const bestExamScore = examTrend.length > 0 ? Math.max(...examTrend.map((e) => e.percentage)) : 0;
      const hwTotal = homeworkRows.length;
      const hwCompleted = homeworkRows.filter((h) => assignmentRows.some((a) => a.homeworkId === h.id)).length;
      const hwCompletionRate = hwTotal > 0 ? Math.round((hwCompleted / hwTotal) * 100) : 0;
      const sylTotal = allSubjects.reduce((acc, s) => acc + (s.syllabusTotalUnits || 0), 0);
      const sylDone = allSubjects.reduce((acc, s) => acc + (s.syllabusCompletedUnits || 0), 0);
      const sylPct = sylTotal > 0 ? Math.min(100, Math.round((sylDone / sylTotal) * 100)) : 0;

      personalAnalytics = {
        studentProfile: visibleStudents[0]
          ? {
              id: visibleStudents[0].id,
              fullName: visibleStudents[0].fullName,
              admissionNo: visibleStudents[0].admissionNo,
              className: allClasses[0]?.name || 'Assigned Class',
              section: allClasses[0]?.section || 'A',
              academicSession: visibleStudents[0].academicSession || '2026-2027',
            }
          : null,
        attendanceBreakdown: {
          present: presentOnly,
          late: lateOnly,
          absent: absentOnly,
          leave: leaveOnly,
          totalDays: attendanceRows.length,
          rate: attendanceRate,
        },
        exams: {
          avgScore,
          bestScore: bestExamScore,
          totalTaken: examTrend.length,
          trend: examTrend,
        },
        homework: {
          completed: hwCompleted,
          pending: Math.max(0, hwTotal - hwCompleted),
          total: hwTotal,
          completionRate: hwCompletionRate,
        },
        syllabus: {
          completedUnits: sylDone,
          totalUnits: sylTotal,
          completionPct: sylPct,
        },
      };
    }

    res.json({
      stats:
        user.role === 'student'
          ? {
              attendanceRate,
              avgAcademicScore: avgScore,
              homeworkCompletionRate: personalAnalytics?.homework?.completionRate ?? 0,
              syllabusCompletionPct: personalAnalytics?.syllabus?.completionPct ?? 0,
              totalSubjects: allSubjects.length,
            }
          : {
              totalStudents: visibleStudents.length,
              totalTeachers: user.role === 'admin' ? (teacherCountRow[0]?.count ?? 0) : 0,
              totalParents: user.role === 'admin' ? (parentCountRow[0]?.count ?? 0) : 0,
              totalClasses: allClasses.length,
              totalSubjects: allSubjects.length,
              attendanceRate,
              avgAcademicScore: avgScore,
              totalPaidFees,
              totalPendingFees,
            },
      personalAnalytics,
      institutionSubscription: null,
      namazChartData,
      attendanceTrend,
      notifications: notifRows,
    });
  } catch (err) {
    console.error('Dashboard error:', err);
    res.status(500).json({ error: 'Failed to load dashboard overview' });
  }
});

// ==================== USERS & ROLES (INSTITUTION ADMIN) ====================

router.get('/users', requireAuth, requireTenant, async (req: AuthRequest, res) => {
  try {
    const instId = req.dbUser!.institutionId!;
    const roleFilter = req.query.role ? String(req.query.role) : null;

    if (req.dbUser!.role !== 'admin') {
      const teacherList = await db
        .select({
          id: users.id,
          name: users.name,
          role: users.role,
          specialization: users.specialization,
          qualification: users.qualification,
        })
        .from(users)
        .where(and(eq(users.institutionId, instId), eq(users.role, 'teacher'), eq(users.isActive, true)));
      return res.json(teacherList);
    }

    const rows = roleFilter
      ? await db
          .select()
          .from(users)
          .where(and(eq(users.institutionId, instId), eq(users.role, roleFilter)))
          .orderBy(desc(users.createdAt))
      : await db
          .select()
          .from(users)
          .where(eq(users.institutionId, instId))
          .orderBy(desc(users.createdAt));

    res.json(rows.map(({ passwordHash: _ph, ...safe }) => safe));
  } catch (err) {
    console.error('Users list error:', err);
    res.status(500).json({ error: 'Failed to fetch users' });
  }
});

router.post('/users', requireAuth, requireTenant, requireRole('admin'), async (req: AuthRequest, res) => {
  try {
    const instId = req.dbUser!.institutionId!;
    const { name, email, password, role, phone, specialization, qualification } = req.body;
    if (!name || !email || !role) {
      return res.status(400).json({ error: 'Name, email, and role are required.' });
    }
    const allowedTenantRoles = ['admin', 'teacher', 'student', 'parent'];
    if (!allowedTenantRoles.includes(String(role))) {
      return res.status(403).json({ error: 'Forbidden: Cannot assign Super Admin or unsupported role.' });
    }

    const normalizedEmail = String(email).trim().toLowerCase();
    const existing = await db.select().from(users).where(eq(users.email, normalizedEmail)).limit(1);
    if (existing.length > 0) {
      return res.status(409).json({ error: 'Email already registered.' });
    }

    const passwordHash = await bcrypt.hash(password || 'Maktab@2026', 10);
    const uid = `usr-${instId}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;

    const [created] = await db
      .insert(users)
      .values({
        uid,
        email: normalizedEmail,
        passwordHash,
        name: String(name).trim(),
        role: String(role),
        institutionId: instId, // strictly bound to caller's institutionId
        phone: phone ? String(phone).trim() : null,
        specialization: specialization ? String(specialization).trim() : null,
        qualification: qualification ? String(qualification).trim() : null,
        isActive: true,
        isDemo: false,
      })
      .returning();

    await logAudit({
      institutionId: instId,
      userId: req.dbUser!.id,
      userEmail: req.dbUser!.email,
      action: 'CREATE_USER',
      entityType: 'users',
      entityId: created.id,
      details: `Created ${created.role}: ${created.email}`,
    });

    const { passwordHash: _ph, ...safe } = created;
    res.status(201).json(safe);
  } catch (err) {
    console.error('Create user error:', err);
    res.status(500).json({ error: 'Failed to create user' });
  }
});

router.patch('/users/:id', requireAuth, requireTenant, requireRole('admin'), async (req: AuthRequest, res) => {
  try {
    const id = Number(req.params.id);
    const instId = req.dbUser!.institutionId!;
    const { name, role, phone, specialization, qualification, isActive } = req.body;

    if (role !== undefined && !['admin', 'teacher', 'student', 'parent'].includes(String(role))) {
      return res.status(403).json({ error: 'Forbidden: Cannot escalate to Super Admin role.' });
    }

    // Tenant authorization check: only update users inside caller's institution
    const [updated] = await db
      .update(users)
      .set({
        ...(name !== undefined ? { name: String(name).trim() } : {}),
        ...(role !== undefined ? { role: String(role) } : {}),
        ...(phone !== undefined ? { phone: phone ? String(phone) : null } : {}),
        ...(specialization !== undefined ? { specialization } : {}),
        ...(qualification !== undefined ? { qualification } : {}),
        ...(isActive !== undefined ? { isActive: Boolean(isActive) } : {}),
      })
      .where(and(eq(users.id, id), eq(users.institutionId, instId)))
      .returning();

    if (!updated) return res.status(404).json({ error: 'User not found in your institution' });

    await logAudit({
      institutionId: instId,
      userId: req.dbUser!.id,
      userEmail: req.dbUser!.email,
      action: 'UPDATE_USER',
      entityType: 'users',
      entityId: id,
      details: `Updated user ${updated.email} (role: ${updated.role}, active: ${updated.isActive})`,
    });

    const { passwordHash: _ph, ...safe } = updated;
    res.json(safe);
  } catch (err) {
    console.error('Update user error:', err);
    res.status(500).json({ error: 'Failed to update user' });
  }
});

router.delete('/users/:id', requireAuth, requireTenant, requireRole('admin'), async (req: AuthRequest, res) => {
  try {
    const id = Number(req.params.id);
    const instId = req.dbUser!.institutionId!;
    if (id === req.dbUser!.id) {
      return res.status(400).json({ error: 'Cannot delete your own active admin account.' });
    }
    const deleted = await db
      .delete(users)
      .where(and(eq(users.id, id), eq(users.institutionId, instId)))
      .returning();
    if (deleted.length === 0) {
      return res.status(404).json({ error: 'User not found in your institution' });
    }
    await logAudit({
      institutionId: instId,
      userId: req.dbUser!.id,
      userEmail: req.dbUser!.email,
      action: 'DELETE_USER',
      entityType: 'users',
      entityId: id,
    });
    res.json({ success: true });
  } catch (err) {
    console.error('Delete user error:', err);
    res.status(500).json({ error: 'Failed to delete user' });
  }
});

router.get('/roles', requireAuth, requireRole('admin', 'super_admin'), async (_req, res) => {
  try {
    const rows = await db.select().from(roles).orderBy(roles.id);
    res.json(rows);
  } catch (err) {
    console.error('Roles fetch error:', err);
    res.status(500).json({ error: 'Failed to load roles' });
  }
});

router.patch('/roles/:id', requireAuth, requireRole('super_admin'), async (req: AuthRequest, res) => {
  try {
    const id = Number(req.params.id);
    const { permissions, description } = req.body;
    const [updated] = await db
      .update(roles)
      .set({
        ...(Array.isArray(permissions) ? { permissions } : {}),
        ...(description !== undefined ? { description } : {}),
      })
      .where(eq(roles.id, id))
      .returning();

    await logAudit({
      userId: req.dbUser!.id,
      userEmail: req.dbUser!.email,
      action: 'UPDATE_ROLE_PERMISSIONS',
      entityType: 'roles',
      entityId: id,
      details: `Updated permissions for role ${updated?.name}`,
    });

    res.json(updated);
  } catch (err) {
    console.error('Role update error:', err);
    res.status(500).json({ error: 'Failed to update role permissions' });
  }
});

// ==================== CLASSES & SUBJECTS ====================

router.get('/classes', requireAuth, requireTenant, async (req: AuthRequest, res) => {
  try {
    const user = req.dbUser!;
    const instId = user.institutionId!;
    let rows = await db.select().from(classes).where(eq(classes.institutionId, instId)).orderBy(classes.id);
    if (user.role === 'teacher') {
      const assignedIds = await getTeacherClassIds(user.id, instId);
      rows = rows.filter((c) => assignedIds.includes(c.id));
    } else if (user.role === 'student' || user.role === 'parent') {
      const scopedIds = await getScopedStudentIds(req);
      if (!scopedIds || scopedIds.length === 0) return res.json([]);
      const myStudents = await db
        .select({ classId: students.classId })
        .from(students)
        .where(and(eq(students.institutionId, instId), inArray(students.id, scopedIds)));
      const myClassIds = myStudents.map((s) => s.classId).filter((id): id is number => Boolean(id));
      rows = rows.filter((c) => myClassIds.includes(c.id));
    }
    res.json(rows);
  } catch (err) {
    console.error('Classes fetch error:', err);
    res.status(500).json({ error: 'Failed to load classes' });
  }
});

router.post('/classes', requireAuth, requireTenant, requireRole('admin'), async (req: AuthRequest, res) => {
  try {
    const instId = req.dbUser!.institutionId!;
    const { name, gradeLevel, section, roomNumber, capacity, academicYear, teacherId } = req.body;
    if (!name || !gradeLevel) {
      return res.status(400).json({ error: 'Class name and grade level are required.' });
    }
    if (teacherId) {
      const tr = await db
        .select()
        .from(users)
        .where(and(eq(users.id, Number(teacherId)), eq(users.institutionId, instId)))
        .limit(1);
      if (tr.length === 0) {
        return res.status(403).json({ error: 'Forbidden: Teacher does not belong to your institution.' });
      }
    }

    const [created] = await db
      .insert(classes)
      .values({
        institutionId: instId,
        name: String(name).trim(),
        gradeLevel: String(gradeLevel).trim(),
        section: section ? String(section).trim() : 'A',
        roomNumber: roomNumber ? String(roomNumber).trim() : null,
        capacity: Number(capacity) || 30,
        academicYear: academicYear || '2026-2027',
        teacherId: teacherId ? Number(teacherId) : null,
      })
      .returning();

    await logAudit({
      institutionId: instId,
      userId: req.dbUser!.id,
      userEmail: req.dbUser!.email,
      action: 'CREATE_CLASS',
      entityType: 'classes',
      entityId: created.id,
      details: created.name,
    });
    res.status(201).json(created);
  } catch (err) {
    console.error('Create class error:', err);
    res.status(500).json({ error: 'Failed to create class' });
  }
});

router.patch('/classes/:id', requireAuth, requireTenant, requireRole('admin'), async (req: AuthRequest, res) => {
  try {
    const id = Number(req.params.id);
    const instId = req.dbUser!.institutionId!;
    const { name, gradeLevel, section, roomNumber, capacity, teacherId } = req.body;
    const [updated] = await db
      .update(classes)
      .set({
        ...(name !== undefined ? { name } : {}),
        ...(gradeLevel !== undefined ? { gradeLevel } : {}),
        ...(section !== undefined ? { section } : {}),
        ...(roomNumber !== undefined ? { roomNumber } : {}),
        ...(capacity !== undefined ? { capacity: Number(capacity) } : {}),
        ...(teacherId !== undefined ? { teacherId: teacherId ? Number(teacherId) : null } : {}),
      })
      .where(and(eq(classes.id, id), eq(classes.institutionId, instId)))
      .returning();
    if (!updated) return res.status(404).json({ error: 'Class not found in your institution' });
    res.json(updated);
  } catch (err) {
    console.error('Update class error:', err);
    res.status(500).json({ error: 'Failed to update class' });
  }
});

router.delete('/classes/:id', requireAuth, requireTenant, requireRole('admin'), async (req: AuthRequest, res) => {
  try {
    const instId = req.dbUser!.institutionId!;
    const deleted = await db
      .delete(classes)
      .where(and(eq(classes.id, Number(req.params.id)), eq(classes.institutionId, instId)))
      .returning();
    if (deleted.length === 0) return res.status(404).json({ error: 'Class not found in your institution' });
    res.json({ success: true });
  } catch (err) {
    console.error('Delete class error:', err);
    res.status(500).json({ error: 'Failed to delete class' });
  }
});

router.get('/subjects', requireAuth, requireTenant, async (req: AuthRequest, res) => {
  try {
    const user = req.dbUser!;
    const instId = user.institutionId!;
    const rows = await db.select().from(subjects).where(eq(subjects.institutionId, instId)).orderBy(subjects.id);
    if (user.role === 'teacher') {
      const assignedIds = await getTeacherClassIds(user.id, instId);
      return res.json(rows.filter((s) => s.teacherId === user.id || assignedIds.includes(s.classId)));
    }
    if (user.role === 'student' || user.role === 'parent') {
      const scopedIds = await getScopedStudentIds(req);
      if (!scopedIds || scopedIds.length === 0) return res.json([]);
      const myStudents = await db
        .select({ classId: students.classId })
        .from(students)
        .where(and(eq(students.institutionId, instId), inArray(students.id, scopedIds)));
      const myClassIds = myStudents.map((s) => s.classId).filter((id): id is number => Boolean(id));
      return res.json(rows.filter((s) => myClassIds.includes(s.classId)));
    }
    res.json(rows);
  } catch (err) {
    console.error('Subjects error:', err);
    res.status(500).json({ error: 'Failed to load subjects' });
  }
});

router.post('/subjects', requireAuth, requireTenant, requireRole('admin'), async (req: AuthRequest, res) => {
  try {
    const instId = req.dbUser!.institutionId!;
    const { name, code, category, classId, teacherId, syllabusTotalUnits, description } = req.body;
    if (!name || !code || !classId) {
      return res.status(400).json({ error: 'Subject name, code, and class are required.' });
    }
    const cls = await db
      .select()
      .from(classes)
      .where(and(eq(classes.id, Number(classId)), eq(classes.institutionId, instId)))
      .limit(1);
    if (cls.length === 0) {
      return res.status(403).json({ error: 'Forbidden: Target class does not belong to your institution.' });
    }

    const [created] = await db
      .insert(subjects)
      .values({
        institutionId: instId,
        name: String(name).trim(),
        code: String(code).trim(),
        category: category || 'Deeni',
        classId: Number(classId),
        teacherId: teacherId ? Number(teacherId) : null,
        syllabusTotalUnits: Number(syllabusTotalUnits) || 12,
        syllabusCompletedUnits: 0,
        description: description || null,
      })
      .returning();
    res.status(201).json(created);
  } catch (err) {
    console.error('Create subject error:', err);
    res.status(500).json({ error: 'Failed to create subject' });
  }
});

router.patch('/subjects/:id', requireAuth, requireTenant, requireRole('admin', 'teacher'), async (req: AuthRequest, res) => {
  try {
    const id = Number(req.params.id);
    const instId = req.dbUser!.institutionId!;
    const existing = await db
      .select()
      .from(subjects)
      .where(and(eq(subjects.id, id), eq(subjects.institutionId, instId)))
      .limit(1);
    if (existing.length === 0) return res.status(404).json({ error: 'Subject not found in your institution' });

    if (req.dbUser!.role === 'teacher') {
      const classIds = await getTeacherClassIds(req.dbUser!.id, instId);
      if (existing[0].teacherId !== req.dbUser!.id && !classIds.includes(existing[0].classId)) {
        return res.status(403).json({ error: 'Forbidden: Not assigned to this subject' });
      }
    }

    const { syllabusCompletedUnits, syllabusTotalUnits, name, teacherId } = req.body;
    const [updated] = await db
      .update(subjects)
      .set({
        ...(syllabusCompletedUnits !== undefined
          ? { syllabusCompletedUnits: Math.max(0, Number(syllabusCompletedUnits)) }
          : {}),
        ...(syllabusTotalUnits !== undefined && req.dbUser!.role === 'admin'
          ? { syllabusTotalUnits: Math.max(1, Number(syllabusTotalUnits)) }
          : {}),
        ...(name !== undefined && req.dbUser!.role === 'admin' ? { name } : {}),
        ...(teacherId !== undefined && req.dbUser!.role === 'admin'
          ? { teacherId: teacherId ? Number(teacherId) : null }
          : {}),
      })
      .where(and(eq(subjects.id, id), eq(subjects.institutionId, instId)))
      .returning();
    res.json(updated);
  } catch (err) {
    console.error('Update subject error:', err);
    res.status(500).json({ error: 'Failed to update subject' });
  }
});

router.delete('/subjects/:id', requireAuth, requireTenant, requireRole('admin'), async (req: AuthRequest, res) => {
  try {
    const instId = req.dbUser!.institutionId!;
    const deleted = await db
      .delete(subjects)
      .where(and(eq(subjects.id, Number(req.params.id)), eq(subjects.institutionId, instId)))
      .returning();
    if (deleted.length === 0) return res.status(404).json({ error: 'Subject not found in your institution' });
    res.json({ success: true });
  } catch (err) {
    console.error('Delete subject error:', err);
    res.status(500).json({ error: 'Failed to delete subject' });
  }
});

// ==================== INSTITUTION POLICIES & SYLLABUS TOPICS ====================

router.get('/institution-policy', requireAuth, requireTenant, async (req: AuthRequest, res) => {
  try {
    const instId = req.dbUser!.institutionId!;
    const policy = await getInstitutionPolicy(instId);
    res.json(policy);
  } catch (err) {
    console.error('Institution policy fetch error:', err);
    res.status(500).json({ error: 'Failed to load institution policy' });
  }
});

router.put('/institution-policy', requireAuth, requireTenant, requireRole('admin'), async (req: AuthRequest, res) => {
  try {
    const instId = req.dbUser!.institutionId!;
    await getInstitutionPolicy(instId);
    const {
      prayerTrackingEnabled,
      prayerShowToParents,
      prayerStaffRoles,
      prayerPolicyNote,
      customActivities,
      urgentHealthProtocol,
      teacherPermissions,
    } = req.body;

    const [updated] = await db
      .update(institutionPolicies)
      .set({
        ...(prayerTrackingEnabled !== undefined ? { prayerTrackingEnabled: Boolean(prayerTrackingEnabled) } : {}),
        ...(prayerShowToParents !== undefined ? { prayerShowToParents: Boolean(prayerShowToParents) } : {}),
        ...(Array.isArray(prayerStaffRoles) ? { prayerStaffRoles: prayerStaffRoles.map(String) } : {}),
        ...(prayerPolicyNote !== undefined ? { prayerPolicyNote: String(prayerPolicyNote).trim() } : {}),
        ...(Array.isArray(customActivities)
          ? { customActivities: customActivities.map((x) => String(x).trim()).filter(Boolean) }
          : {}),
        ...(urgentHealthProtocol !== undefined ? { urgentHealthProtocol: String(urgentHealthProtocol).trim() } : {}),
        ...(teacherPermissions && typeof teacherPermissions === 'object' ? { teacherPermissions } : {}),
        updatedAt: new Date(),
      })
      .where(eq(institutionPolicies.institutionId, instId))
      .returning();

    await logAudit({
      institutionId: instId,
      userId: req.dbUser!.id,
      userEmail: req.dbUser!.email,
      action: 'UPDATE_INSTITUTION_POLICY',
      entityType: 'institution_policies',
      entityId: updated.id,
      details: 'Updated prayer privacy rules, customizable activities, and permission policies.',
    });

    res.json(updated);
  } catch (err) {
    console.error('Update institution policy error:', err);
    res.status(500).json({ error: 'Failed to update institution policy' });
  }
});

router.get('/syllabus-topics', requireAuth, requireTenant, async (req: AuthRequest, res) => {
  try {
    const user = req.dbUser!;
    const instId = user.institutionId!;
    let rows = await db
      .select()
      .from(syllabusTopics)
      .where(eq(syllabusTopics.institutionId, instId))
      .orderBy(syllabusTopics.id);

    if (user.role === 'teacher') {
      const assignedClassIds = await getTeacherClassIds(user.id, instId);
      const mySubjects = await db
        .select({ id: subjects.id })
        .from(subjects)
        .where(and(eq(subjects.institutionId, instId), eq(subjects.teacherId, user.id)));
      const mySubIds = mySubjects.map((s) => s.id);
      rows = rows.filter((t) => assignedClassIds.includes(t.classId) || mySubIds.includes(t.subjectId));
    } else if (user.role === 'parent' || user.role === 'student') {
      const scopedIds = await getScopedStudentIds(req);
      if (!scopedIds || scopedIds.length === 0) return res.json([]);
      const myStudents = await db
        .select({ classId: students.classId })
        .from(students)
        .where(and(eq(students.institutionId, instId), inArray(students.id, scopedIds)));
      const myClassIds = myStudents.map((s) => s.classId).filter(Boolean) as number[];
      rows = rows.filter((t) => myClassIds.includes(t.classId));
    }

    res.json(rows);
  } catch (err) {
    console.error('Syllabus topics fetch error:', err);
    res.status(500).json({ error: 'Failed to load syllabus topics' });
  }
});

router.post('/syllabus-topics', requireAuth, requireTenant, requireRole('admin', 'teacher'), async (req: AuthRequest, res) => {
  try {
    const user = req.dbUser!;
    const instId = user.institutionId!;
    const {
      classId,
      subjectId,
      academicSession,
      bookName,
      chapter,
      lesson,
      totalTopics,
      completedTopics,
      completionDate,
      teacherRemarks,
    } = req.body;

    if (!classId || !subjectId || !bookName || !chapter || !lesson) {
      return res.status(400).json({ error: 'Class, subject, book name, chapter, and lesson are required.' });
    }

    const [clsRows, subRows] = await Promise.all([
      db.select().from(classes).where(and(eq(classes.id, Number(classId)), eq(classes.institutionId, instId))).limit(1),
      db.select().from(subjects).where(and(eq(subjects.id, Number(subjectId)), eq(subjects.institutionId, instId))).limit(1),
    ]);
    if (clsRows.length === 0 || subRows.length === 0) {
      return res.status(403).json({ error: 'Forbidden: Class or subject does not belong to your institution.' });
    }

    if (user.role === 'teacher' && subRows[0].teacherId !== user.id && clsRows[0].teacherId !== user.id) {
      return res.status(403).json({ error: 'Forbidden: You are not assigned to this subject or class.' });
    }

    const totalNum = Math.max(1, Number(totalTopics) || 10);
    const completedNum = Math.min(totalNum, Math.max(0, Number(completedTopics) || 0));
    const computedStatus = completedNum >= totalNum ? 'completed' : completedNum === 0 ? 'pending' : 'in_progress';

    const [created] = await db
      .insert(syllabusTopics)
      .values({
        institutionId: instId,
        classId: Number(classId),
        subjectId: Number(subjectId),
        academicSession: academicSession ? String(academicSession).trim() : '2026-2027',
        bookName: String(bookName).trim(),
        chapter: String(chapter).trim(),
        lesson: String(lesson).trim(),
        totalTopics: totalNum,
        completedTopics: completedNum,
        status: computedStatus,
        completionDate: completionDate ? String(completionDate) : computedStatus === 'completed' ? new Date().toISOString().slice(0, 10) : null,
        teacherRemarks: teacherRemarks ? String(teacherRemarks).trim() : null,
        updatedBy: user.id,
      })
      .returning();

    await syncSubjectSyllabusTotals(Number(subjectId), instId);
    res.status(201).json(created);
  } catch (err) {
    console.error('Create syllabus topic error:', err);
    res.status(500).json({ error: 'Failed to create syllabus topic' });
  }
});

router.patch('/syllabus-topics/:id', requireAuth, requireTenant, requireRole('admin', 'teacher'), async (req: AuthRequest, res) => {
  try {
    const id = Number(req.params.id);
    const user = req.dbUser!;
    const instId = user.institutionId!;

    const existing = await db
      .select()
      .from(syllabusTopics)
      .where(and(eq(syllabusTopics.id, id), eq(syllabusTopics.institutionId, instId)))
      .limit(1);
    if (existing.length === 0) return res.status(404).json({ error: 'Syllabus topic not found in your institution.' });

    const topic = existing[0];
    if (user.role === 'teacher') {
      const [subRows, clsRows] = await Promise.all([
        db.select().from(subjects).where(and(eq(subjects.id, topic.subjectId), eq(subjects.institutionId, instId))).limit(1),
        db.select().from(classes).where(and(eq(classes.id, topic.classId), eq(classes.institutionId, instId))).limit(1),
      ]);
      if (subRows[0]?.teacherId !== user.id && clsRows[0]?.teacherId !== user.id) {
        return res.status(403).json({ error: 'Forbidden: Only assigned teachers may update this syllabus.' });
      }
    }

    const { bookName, chapter, lesson, totalTopics, completedTopics, completionDate, teacherRemarks, academicSession } = req.body;
    const nextTotal = totalTopics !== undefined ? Math.max(1, Number(totalTopics)) : topic.totalTopics;
    const nextCompleted =
      completedTopics !== undefined
        ? Math.min(nextTotal, Math.max(0, Number(completedTopics)))
        : Math.min(nextTotal, topic.completedTopics);
    const computedStatus = nextCompleted >= nextTotal ? 'completed' : nextCompleted === 0 ? 'pending' : 'in_progress';

    const [updated] = await db
      .update(syllabusTopics)
      .set({
        ...(academicSession !== undefined ? { academicSession: String(academicSession) } : {}),
        ...(bookName !== undefined ? { bookName: String(bookName).trim() } : {}),
        ...(chapter !== undefined ? { chapter: String(chapter).trim() } : {}),
        ...(lesson !== undefined ? { lesson: String(lesson).trim() } : {}),
        totalTopics: nextTotal,
        completedTopics: nextCompleted,
        status: computedStatus,
        completionDate:
          completionDate !== undefined
            ? completionDate || null
            : computedStatus === 'completed'
              ? topic.completionDate || new Date().toISOString().slice(0, 10)
              : null,
        ...(teacherRemarks !== undefined ? { teacherRemarks: teacherRemarks ? String(teacherRemarks) : null } : {}),
        updatedBy: user.id,
        updatedAt: new Date(),
      })
      .where(and(eq(syllabusTopics.id, id), eq(syllabusTopics.institutionId, instId)))
      .returning();

    await syncSubjectSyllabusTotals(topic.subjectId, instId);
    res.json(updated);
  } catch (err) {
    console.error('Update syllabus topic error:', err);
    res.status(500).json({ error: 'Failed to update syllabus topic' });
  }
});

router.delete('/syllabus-topics/:id', requireAuth, requireTenant, requireRole('admin', 'teacher'), async (req: AuthRequest, res) => {
  try {
    const id = Number(req.params.id);
    const user = req.dbUser!;
    const instId = user.institutionId!;
    const existing = await db
      .select()
      .from(syllabusTopics)
      .where(and(eq(syllabusTopics.id, id), eq(syllabusTopics.institutionId, instId)))
      .limit(1);
    if (existing.length === 0) return res.status(404).json({ error: 'Syllabus topic not found.' });

    if (user.role === 'teacher') {
      const subRows = await db
        .select()
        .from(subjects)
        .where(and(eq(subjects.id, existing[0].subjectId), eq(subjects.institutionId, instId)))
        .limit(1);
      const clsRows = await db
        .select()
        .from(classes)
        .where(and(eq(classes.id, existing[0].classId), eq(classes.institutionId, instId)))
        .limit(1);
      if (subRows[0]?.teacherId !== user.id && clsRows[0]?.teacherId !== user.id) {
        return res.status(403).json({ error: 'Forbidden: Not assigned to this syllabus item.' });
      }
    }

    await db.delete(syllabusTopics).where(and(eq(syllabusTopics.id, id), eq(syllabusTopics.institutionId, instId)));
    await syncSubjectSyllabusTotals(existing[0].subjectId, instId);
    res.json({ success: true });
  } catch (err) {
    console.error('Delete syllabus topic error:', err);
    res.status(500).json({ error: 'Failed to delete syllabus topic' });
  }
});

// ==================== STUDENTS & UNIFIED PROFILE ====================

router.get('/students', requireAuth, requireTenant, async (req: AuthRequest, res) => {
  try {
    const instId = req.dbUser!.institutionId!;
    const scopedIds = await getScopedStudentIds(req);
    if (scopedIds !== null && scopedIds.length === 0) {
      return res.json([]);
    }
    const rows =
      scopedIds === null
        ? await db.select().from(students).where(eq(students.institutionId, instId)).orderBy(students.id)
        : await db
            .select()
            .from(students)
            .where(and(eq(students.institutionId, instId), inArray(students.id, scopedIds)))
            .orderBy(students.id);
    res.json(rows);
  } catch (err) {
    console.error('Students fetch error:', err);
    res.status(500).json({ error: 'Failed to fetch students' });
  }
});

router.post('/students', requireAuth, requireTenant, requireRole('admin'), async (req: AuthRequest, res) => {
  try {
    const instId = req.dbUser!.institutionId!;
    const {
      admissionNo,
      fullName,
      photoUrl,
      fatherName,
      motherName,
      dob,
      gender,
      classId,
      academicSession,
      parentId,
      guardianName,
      guardianPhone,
      emergencyContact,
      address,
      bloodGroup,
      allergies,
      medicalNotes,
      admissionDate,
    } = req.body;

    if (!fullName || !dob || !guardianName || !guardianPhone) {
      return res.status(400).json({ error: 'Full name, DOB, guardian name and phone are required.' });
    }

    let resolvedClassId: number | null = null;
    if (classId !== undefined && classId !== null && String(classId).trim() !== '') {
      const numericClassId = Number(classId);
      const cls = await db
        .select()
        .from(classes)
        .where(and(eq(classes.id, numericClassId), eq(classes.institutionId, instId)))
        .limit(1);
      if (cls.length === 0) {
        return res.status(403).json({ error: 'Forbidden: Selected class does not belong to your institution.' });
      }
      resolvedClassId = numericClassId;
    }

    if (parentId) {
      const pr = await db
        .select()
        .from(users)
        .where(and(eq(users.id, Number(parentId)), eq(users.institutionId, instId)))
        .limit(1);
      if (pr.length === 0) {
        return res.status(403).json({ error: 'Forbidden: Selected parent does not belong to your institution.' });
      }
    }

    const code = admissionNo || `MK${instId}-${new Date().getFullYear()}-${Math.floor(100 + Math.random() * 900)}`;

    const [created] = await db
      .insert(students)
      .values({
        institutionId: instId,
        admissionNo: String(code).trim(),
        fullName: String(fullName).trim(),
        photoUrl: photoUrl ? String(photoUrl).trim() : null,
        fatherName: fatherName ? String(fatherName).trim() : null,
        motherName: motherName ? String(motherName).trim() : null,
        dob: String(dob),
        gender: gender || 'Male',
        classId: resolvedClassId,
        academicSession: academicSession ? String(academicSession).trim() : '2026-2027',
        parentId: parentId ? Number(parentId) : null,
        guardianName: String(guardianName).trim(),
        guardianPhone: String(guardianPhone).trim(),
        emergencyContact: emergencyContact ? String(emergencyContact).trim() : null,
        address: address || null,
        bloodGroup: bloodGroup || null,
        allergies: allergies || 'None',
        medicalNotes: medicalNotes ? String(medicalNotes).trim() : null,
        parentalConsent: true,
        status: 'active',
        admissionDate: admissionDate || new Date().toISOString().slice(0, 10),
        isDemo: false,
      })
      .returning();

    if (resolvedClassId) {
      await db.insert(enrollments).values({
        institutionId: instId,
        studentId: created.id,
        classId: resolvedClassId,
        academicYear: academicSession || '2026-2027',
        status: 'enrolled',
      });
    }

    await logAudit({
      institutionId: instId,
      userId: req.dbUser!.id,
      userEmail: req.dbUser!.email,
      action: 'REGISTER_STUDENT',
      entityType: 'students',
      entityId: created.id,
      details: `Registered ${created.fullName} (${created.admissionNo})`,
    });

    res.status(201).json(created);
  } catch (err) {
    console.error('Create student error:', err);
    res.status(500).json({ error: 'Failed to register student' });
  }
});

router.get('/students/:id/profile', requireAuth, requireTenant, async (req: AuthRequest, res) => {
  try {
    const id = Number(req.params.id);
    const user = req.dbUser!;
    const instId = user.institutionId!;

    const stRows = await db
      .select()
      .from(students)
      .where(and(eq(students.id, id), eq(students.institutionId, instId)))
      .limit(1);
    if (stRows.length === 0) return res.status(404).json({ error: 'Student not found in your institution' });

    const scopedIds = await getScopedStudentIds(req);
    if (scopedIds !== null && !scopedIds.includes(id)) {
      return res.status(403).json({ error: 'Forbidden: You are not authorized to access this student profile.' });
    }

    const student = stRows[0];
    const policy = await getInstitutionPolicy(instId);
    const canSeeMedical = user.role === 'admin' || user.role === 'parent' || student.parentalConsent;
    const canSeePrayer =
      policy.prayerTrackingEnabled && (user.role !== 'parent' || policy.prayerShowToParents);

    const [
      classRow,
      classSubjects,
      classSyllabus,
      attRows,
      namazRows,
      activityRows,
      healthRows,
      hwRows,
      assignRows,
      markRows,
      attemptRows,
      examRows,
      messageRows,
      feeRows,
    ] = await Promise.all([
      student.classId
        ? db.select().from(classes).where(and(eq(classes.id, student.classId), eq(classes.institutionId, instId))).limit(1)
        : Promise.resolve([]),
      student.classId
        ? db.select().from(subjects).where(and(eq(subjects.classId, student.classId), eq(subjects.institutionId, instId)))
        : Promise.resolve([]),
      student.classId
        ? db.select().from(syllabusTopics).where(and(eq(syllabusTopics.classId, student.classId), eq(syllabusTopics.institutionId, instId)))
        : Promise.resolve([]),
      db.select().from(attendance).where(and(eq(attendance.studentId, id), eq(attendance.institutionId, instId))).orderBy(desc(attendance.date)),
      canSeePrayer
        ? db.select().from(namazRecords).where(and(eq(namazRecords.studentId, id), eq(namazRecords.institutionId, instId))).orderBy(desc(namazRecords.date))
        : Promise.resolve([]),
      db.select().from(dailyActivities).where(and(eq(dailyActivities.studentId, id), eq(dailyActivities.institutionId, instId))).orderBy(desc(dailyActivities.date)),
      canSeeMedical
        ? db.select().from(healthRecords).where(and(eq(healthRecords.studentId, id), eq(healthRecords.institutionId, instId))).orderBy(desc(healthRecords.recordDate))
        : Promise.resolve([]),
      student.classId
        ? db.select().from(homework).where(and(eq(homework.classId, student.classId), eq(homework.institutionId, instId))).orderBy(desc(homework.createdAt))
        : Promise.resolve([]),
      db.select().from(assignments).where(and(eq(assignments.studentId, id), eq(assignments.institutionId, instId))),
      db.select().from(marks).where(and(eq(marks.studentId, id), eq(marks.institutionId, instId))),
      db.select().from(testAttempts).where(and(eq(testAttempts.studentId, id), eq(testAttempts.institutionId, instId))),
      student.classId
        ? db.select().from(exams).where(and(eq(exams.classId, student.classId), eq(exams.institutionId, instId)))
        : Promise.resolve([]),
      db.select().from(teacherMessages).where(and(eq(teacherMessages.studentId, id), eq(teacherMessages.institutionId, instId))).orderBy(desc(teacherMessages.createdAt)),
      db.select().from(fees).where(and(eq(fees.studentId, id), eq(fees.institutionId, instId))).orderBy(desc(fees.createdAt)),
    ]);

    await logAudit({
      institutionId: instId,
      userId: user.id,
      userEmail: user.email,
      action: 'VIEW_STUDENT_PROFILE',
      entityType: 'students',
      entityId: id,
      details: `Viewed unified profile for ${student.fullName}`,
    });

    const sanitizedStudent = canSeeMedical ? student : { ...student, medicalNotes: null, allergies: null };
    const totalAtt = attRows.length;
    const presentAtt = attRows.filter((a) => a.status === 'present' || a.status === 'late').length;

    res.json({
      student: sanitizedStudent,
      classInfo: classRow[0] || null,
      subjects: classSubjects,
      syllabusTopics: classSyllabus,
      attendance: attRows,
      attendanceStats: {
        total: totalAtt,
        present: attRows.filter((a) => a.status === 'present').length,
        absent: attRows.filter((a) => a.status === 'absent').length,
        late: attRows.filter((a) => a.status === 'late').length,
        leave: attRows.filter((a) => a.status === 'leave' || a.status === 'excused').length,
        rate: totalAtt > 0 ? Math.round((presentAtt / totalAtt) * 100) : 0,
      },
      namazRecords: namazRows,
      dailyActivities: activityRows,
      healthRecords: healthRows,
      homework: hwRows.map((h) => ({
        ...h,
        assignment: assignRows.find((a) => a.homeworkId === h.id) || null,
      })),
      marks: markRows.map((m) => ({
        ...m,
        exam: examRows.find((e) => e.id === m.examId) || null,
      })),
      testAttempts: attemptRows,
      teacherMessages: messageRows,
      fees: feeRows,
      policy: {
        prayerTrackingEnabled: policy.prayerTrackingEnabled,
        prayerShowToParents: policy.prayerShowToParents,
        prayerPolicyNote: policy.prayerPolicyNote,
      },
    });
  } catch (err) {
    console.error('Student profile error:', err);
    res.status(500).json({ error: 'Failed to load student profile' });
  }
});

router.patch('/students/:id', requireAuth, requireTenant, requireRole('admin', 'parent'), async (req: AuthRequest, res) => {
  try {
    const id = Number(req.params.id);
    const instId = req.dbUser!.institutionId!;
    const existing = await db
      .select()
      .from(students)
      .where(and(eq(students.id, id), eq(students.institutionId, instId)))
      .limit(1);
    if (existing.length === 0) return res.status(404).json({ error: 'Student not found in your institution' });

    if (req.dbUser!.role === 'parent' && existing[0].parentId !== req.dbUser!.id) {
      return res.status(403).json({ error: 'Forbidden: Not your linked child' });
    }

    const {
      fullName,
      photoUrl,
      fatherName,
      motherName,
      academicSession,
      classId,
      parentId,
      guardianName,
      guardianPhone,
      emergencyContact,
      address,
      bloodGroup,
      allergies,
      medicalNotes,
      parentalConsent,
      status,
    } = req.body;

    const updateFields: any = { updatedAt: new Date() };
    if (allergies !== undefined) updateFields.allergies = allergies;
    if (medicalNotes !== undefined) updateFields.medicalNotes = medicalNotes;
    if (emergencyContact !== undefined) updateFields.emergencyContact = emergencyContact;
    if (parentalConsent !== undefined) updateFields.parentalConsent = Boolean(parentalConsent);

    if (req.dbUser!.role === 'admin') {
      if (fullName !== undefined) updateFields.fullName = fullName;
      if (photoUrl !== undefined) updateFields.photoUrl = photoUrl;
      if (fatherName !== undefined) updateFields.fatherName = fatherName;
      if (motherName !== undefined) updateFields.motherName = motherName;
      if (academicSession !== undefined) updateFields.academicSession = academicSession;
      if (classId !== undefined) {
        if (classId === null || String(classId).trim() === '') {
          updateFields.classId = null;
        } else {
          const cls = await db
            .select()
            .from(classes)
            .where(and(eq(classes.id, Number(classId)), eq(classes.institutionId, instId)))
            .limit(1);
          if (cls.length === 0) return res.status(403).json({ error: 'Class does not belong to your institution.' });
          updateFields.classId = Number(classId);
        }
      }
      if (parentId !== undefined) updateFields.parentId = parentId ? Number(parentId) : null;
      if (guardianName !== undefined) updateFields.guardianName = guardianName;
      if (guardianPhone !== undefined) updateFields.guardianPhone = guardianPhone;
      if (address !== undefined) updateFields.address = address;
      if (bloodGroup !== undefined) updateFields.bloodGroup = bloodGroup;
      if (status !== undefined) updateFields.status = status;
    }

    const [updated] = await db
      .update(students)
      .set(updateFields)
      .where(and(eq(students.id, id), eq(students.institutionId, instId)))
      .returning();
    res.json(updated);
  } catch (err) {
    console.error('Update student error:', err);
    res.status(500).json({ error: 'Failed to update student' });
  }
});

router.delete('/students/:id', requireAuth, requireTenant, requireRole('admin'), async (req: AuthRequest, res) => {
  try {
    const id = Number(req.params.id);
    const instId = req.dbUser!.institutionId!;
    const deleted = await db
      .delete(students)
      .where(and(eq(students.id, id), eq(students.institutionId, instId)))
      .returning();
    if (deleted.length === 0) return res.status(404).json({ error: 'Student not found in your institution' });

    await logAudit({
      institutionId: instId,
      userId: req.dbUser!.id,
      userEmail: req.dbUser!.email,
      action: 'DELETE_STUDENT',
      entityType: 'students',
      entityId: id,
    });
    res.json({ success: true });
  } catch (err) {
    console.error('Delete student error:', err);
    res.status(500).json({ error: 'Failed to remove student' });
  }
});

// ==================== ATTENDANCE & TEACHER ATTENDANCE ====================

router.get('/attendance', requireAuth, requireTenant, async (req: AuthRequest, res) => {
  try {
    const instId = req.dbUser!.institutionId!;
    const scopedIds = await getScopedStudentIds(req);
    if (scopedIds !== null && scopedIds.length === 0) return res.json([]);
    const dateFilter = req.query.date ? String(req.query.date) : null;
    const conditions: any[] = [eq(attendance.institutionId, instId)];
    if (scopedIds !== null) conditions.push(inArray(attendance.studentId, scopedIds));
    if (dateFilter) conditions.push(eq(attendance.date, dateFilter));

    const rows = await db
      .select()
      .from(attendance)
      .where(and(...conditions))
      .orderBy(desc(attendance.date));
    res.json(rows);
  } catch (err) {
    console.error('Attendance fetch error:', err);
    res.status(500).json({ error: 'Failed to load attendance records' });
  }
});

router.post('/attendance', requireAuth, requireTenant, requireRole('admin', 'teacher'), async (req: AuthRequest, res) => {
  try {
    const instId = req.dbUser!.institutionId!;
    const { studentId, classId, date, status, remarks } = req.body;
    if (!studentId || !classId || !date || !status) {
      return res.status(400).json({ error: 'Student, class, date, and status are required.' });
    }

    const stRows = await db
      .select()
      .from(students)
      .where(and(eq(students.id, Number(studentId)), eq(students.institutionId, instId)))
      .limit(1);
    if (stRows.length === 0) {
      return res.status(403).json({ error: 'Forbidden: Student does not belong to your institution.' });
    }

    const clsRows = await db
      .select({ id: classes.id })
      .from(classes)
      .where(and(eq(classes.id, Number(classId)), eq(classes.institutionId, instId)))
      .limit(1);
    if (clsRows.length === 0) {
      return res.status(403).json({ error: 'Forbidden: Class does not belong to your institution.' });
    }

    const scopedIds = await getScopedStudentIds(req);
    if (scopedIds !== null && !scopedIds.includes(Number(studentId))) {
      return res.status(403).json({ error: 'Forbidden: Student is not in your assigned classes.' });
    }

    const allowedStatuses = ['present', 'absent', 'late', 'leave', 'excused'];
    const cleanStatus = allowedStatuses.includes(String(status)) ? String(status) : 'present';

    const [record] = await db
      .insert(attendance)
      .values({
        institutionId: instId,
        studentId: Number(studentId),
        classId: Number(classId),
        date: String(date),
        status: cleanStatus,
        remarks: remarks ? String(remarks) : null,
        recordedBy: req.dbUser!.id,
      })
      .onConflictDoUpdate({
        target: [attendance.studentId, attendance.date],
        set: {
          status: cleanStatus,
          remarks: remarks ? String(remarks) : null,
          recordedBy: req.dbUser!.id,
        },
      })
      .returning();

    if (stRows[0]?.parentId) {
      if (cleanStatus === 'absent') {
        const allowAbsent = await shouldNotifyPreference(instId, stRows[0].parentId, 'absentAlerts');
        if (allowAbsent) {
          await db.insert(notifications).values({
            institutionId: instId,
            title: `Attendance Alert: ${stRows[0].fullName}`,
            message: `${stRows[0].fullName} was marked absent on ${date}. ${remarks || ''}`,
            type: 'attendance',
            targetRole: 'parent',
            targetUserId: stRows[0].parentId,
            createdBy: req.dbUser!.id,
          });
        }
      } else {
        const allowUpdates = await shouldNotifyPreference(instId, stRows[0].parentId, 'attendanceUpdates');
        if (allowUpdates && (cleanStatus === 'late' || cleanStatus === 'leave')) {
          await db.insert(notifications).values({
            institutionId: instId,
            title: `Attendance Update: ${stRows[0].fullName}`,
            message: `${stRows[0].fullName} marked ${cleanStatus} on ${date}. ${remarks || ''}`,
            type: 'attendance',
            targetRole: 'parent',
            targetUserId: stRows[0].parentId,
            createdBy: req.dbUser!.id,
          });
        }
      }
    }

    res.status(201).json(record);
  } catch (err) {
    console.error('Attendance save error:', err);
    res.status(500).json({ error: 'Failed to save attendance' });
  }
});

router.get('/teacher-attendance', requireAuth, requireTenant, requireRole('admin', 'teacher'), async (req: AuthRequest, res) => {
  try {
    const user = req.dbUser!;
    const instId = user.institutionId!;
    const dateFilter = req.query.date ? String(req.query.date) : null;

    const teacherRows = await db
      .select({
        id: users.id,
        name: users.name,
        email: users.email,
        specialization: users.specialization,
      })
      .from(users)
      .where(and(eq(users.institutionId, instId), eq(users.role, 'teacher'), eq(users.isActive, true)));

    const conditions: any[] = [eq(teacherAttendance.institutionId, instId)];
    if (user.role === 'teacher') conditions.push(eq(teacherAttendance.teacherId, user.id));
    if (dateFilter) conditions.push(eq(teacherAttendance.date, dateFilter));

    const records = await db
      .select()
      .from(teacherAttendance)
      .where(and(...conditions))
      .orderBy(desc(teacherAttendance.date));

    res.json({
      teachers: user.role === 'admin' ? teacherRows : teacherRows.filter((t) => t.id === user.id),
      records,
    });
  } catch (err) {
    console.error('Teacher attendance fetch error:', err);
    res.status(500).json({ error: 'Failed to load teacher attendance' });
  }
});

router.post('/teacher-attendance', requireAuth, requireTenant, requireRole('admin', 'teacher'), async (req: AuthRequest, res) => {
  try {
    const user = req.dbUser!;
    const instId = user.institutionId!;
    const { teacherId, date, status, remarks } = req.body;
    const targetTeacherId = user.role === 'teacher' ? user.id : Number(teacherId);
    if (!targetTeacherId || !date || !status) {
      return res.status(400).json({ error: 'Teacher, date, and status are required.' });
    }
    if (!['present', 'absent', 'late', 'leave'].includes(String(status))) {
      return res.status(400).json({ error: 'Invalid attendance status.' });
    }

    const trCheck = await db
      .select({ id: users.id })
      .from(users)
      .where(and(eq(users.id, targetTeacherId), eq(users.institutionId, instId), eq(users.role, 'teacher')))
      .limit(1);
    if (trCheck.length === 0) {
      return res.status(403).json({ error: 'Forbidden: Teacher does not belong to your institution.' });
    }

    const [saved] = await db
      .insert(teacherAttendance)
      .values({
        institutionId: instId,
        teacherId: targetTeacherId,
        date: String(date),
        status: String(status),
        remarks: remarks ? String(remarks) : null,
        recordedBy: user.id,
        updatedAt: new Date(),
      })
      .onConflictDoUpdate({
        target: [teacherAttendance.institutionId, teacherAttendance.teacherId, teacherAttendance.date],
        set: {
          status: String(status),
          remarks: remarks ? String(remarks) : null,
          recordedBy: user.id,
          updatedAt: new Date(),
        },
      })
      .returning();

    res.status(201).json(saved);
  } catch (err) {
    console.error('Teacher attendance save error:', err);
    res.status(500).json({ error: 'Failed to save teacher attendance' });
  }
});

// ==================== FIVE TIMES NAMAZ MONITORING (PRIVACY-FIRST) ====================

router.get('/namaz', requireAuth, requireTenant, async (req: AuthRequest, res) => {
  try {
    const user = req.dbUser!;
    const instId = user.institutionId!;
    const policy = await getInstitutionPolicy(instId);

    if (!policy.prayerTrackingEnabled && user.role !== 'admin') {
      return res.json([]);
    }
    if (user.role === 'parent' && !policy.prayerShowToParents) {
      return res.json([]);
    }

    const scopedIds = await getScopedStudentIds(req);
    if (scopedIds !== null && scopedIds.length === 0) return res.json([]);
    const dateFilter = req.query.date ? String(req.query.date) : null;
    const conditions: any[] = [eq(namazRecords.institutionId, instId)];
    if (scopedIds !== null) conditions.push(inArray(namazRecords.studentId, scopedIds));
    if (dateFilter) conditions.push(eq(namazRecords.date, dateFilter));

    const rows = await db
      .select()
      .from(namazRecords)
      .where(and(...conditions))
      .orderBy(desc(namazRecords.date));
    res.json(rows);
  } catch (err) {
    console.error('Namaz fetch error:', err);
    res.status(500).json({ error: 'Failed to load Namaz records' });
  }
});

router.post('/namaz', requireAuth, requireTenant, requireRole('admin', 'teacher'), async (req: AuthRequest, res) => {
  try {
    const user = req.dbUser!;
    const instId = user.institutionId!;
    const policy = await getInstitutionPolicy(instId);
    if (!policy.prayerTrackingEnabled) {
      return res.status(403).json({ error: 'Prayer tracking is disabled by institution policy.' });
    }
    if (Array.isArray(policy.prayerStaffRoles) && !policy.prayerStaffRoles.includes(user.role)) {
      return res.status(403).json({ error: 'Forbidden: Your role is not authorized to record prayer logs by policy.' });
    }

    const { studentId, date, fajr, zuhr, asr, maghrib, isha, notes, remarks } = req.body;
    if (!studentId || !date) {
      return res.status(400).json({ error: 'Student and date are required.' });
    }
    const stRows = await db
      .select()
      .from(students)
      .where(and(eq(students.id, Number(studentId)), eq(students.institutionId, instId)))
      .limit(1);
    if (stRows.length === 0) {
      return res.status(403).json({ error: 'Forbidden: Student does not belong to your institution.' });
    }

    const validStates = ['performed', 'not_performed', 'not_recorded'];
    const sanitizeState = (v: any) => (validStates.includes(v) ? v : 'not_recorded');

    const scopedIds = await getScopedStudentIds(req);
    if (scopedIds !== null && !scopedIds.includes(Number(studentId))) {
      return res.status(403).json({ error: 'Forbidden: Student is not in your assigned classes.' });
    }

    const cleanRemarks = remarks !== undefined ? (remarks ? String(remarks) : null) : notes ? String(notes) : null;

    const [record] = await db
      .insert(namazRecords)
      .values({
        institutionId: instId,
        studentId: Number(studentId),
        date: String(date),
        fajr: sanitizeState(fajr),
        zuhr: sanitizeState(zuhr),
        asr: sanitizeState(asr),
        maghrib: sanitizeState(maghrib),
        isha: sanitizeState(isha),
        notes: cleanRemarks,
        remarks: cleanRemarks,
        recordedBy: user.id,
        updatedAt: new Date(),
      })
      .onConflictDoUpdate({
        target: [namazRecords.studentId, namazRecords.date],
        set: {
          fajr: sanitizeState(fajr),
          zuhr: sanitizeState(zuhr),
          asr: sanitizeState(asr),
          maghrib: sanitizeState(maghrib),
          isha: sanitizeState(isha),
          notes: cleanRemarks,
          remarks: cleanRemarks,
          recordedBy: user.id,
          updatedAt: new Date(),
        },
      })
      .returning();

    if (policy.prayerShowToParents && stRows[0]?.parentId) {
      const allowPrayer = await shouldNotifyPreference(instId, stRows[0].parentId, 'prayerUpdates');
      if (allowPrayer) {
        await db.insert(notifications).values({
          institutionId: instId,
          title: `Prayer Guidance Log Updated: ${stRows[0].fullName}`,
          message: `Daily devotional prayer log updated for ${date}.`,
          type: 'namaz',
          targetRole: 'parent',
          targetUserId: stRows[0].parentId,
          createdBy: user.id,
        });
      }
    }

    res.status(201).json(record);
  } catch (err) {
    console.error('Namaz save error:', err);
    res.status(500).json({ error: 'Failed to save Namaz record' });
  }
});

// ==================== HEALTH RECORDS (RESTRICTED) ====================

router.get('/health', requireAuth, requireTenant, async (req: AuthRequest, res) => {
  try {
    const user = req.dbUser!;
    const instId = user.institutionId!;
    const scopedIds = await getScopedStudentIds(req);
    if (scopedIds !== null && scopedIds.length === 0) return res.json([]);

    const rows =
      scopedIds === null
        ? await db
            .select()
            .from(healthRecords)
            .where(eq(healthRecords.institutionId, instId))
            .orderBy(desc(healthRecords.recordDate))
        : await db
            .select()
            .from(healthRecords)
            .where(and(eq(healthRecords.institutionId, instId), inArray(healthRecords.studentId, scopedIds)))
            .orderBy(desc(healthRecords.recordDate));

    if (user.role !== 'student') {
      await logAudit({
        institutionId: instId,
        userId: user.id,
        userEmail: user.email,
        action: 'VIEW_HEALTH_RECORDS',
        entityType: 'health_records',
        details: `Accessed ${rows.length} restricted health record(s)`,
      });
    }

    res.json(rows);
  } catch (err) {
    console.error('Health fetch error:', err);
    res.status(500).json({ error: 'Failed to load health records' });
  }
});

router.post('/health', requireAuth, requireTenant, requireRole('admin', 'teacher', 'parent'), async (req: AuthRequest, res) => {
  try {
    const user = req.dbUser!;
    const instId = user.institutionId!;
    const {
      studentId,
      recordDate,
      heightCm,
      weightKg,
      temperatureC,
      healthStatus,
      illnessInfo,
      medicationNotes,
      followUpStatus,
      parentUpdateNotes,
      urgentAlertSent,
    } = req.body;

    if (!studentId || !recordDate || !healthStatus) {
      return res.status(400).json({ error: 'Student, date, and health status are required.' });
    }

    const stRows = await db
      .select()
      .from(students)
      .where(and(eq(students.id, Number(studentId)), eq(students.institutionId, instId)))
      .limit(1);
    if (stRows.length === 0) {
      return res.status(403).json({ error: 'Forbidden: Student does not belong to your institution.' });
    }

    const scopedIds = await getScopedStudentIds(req);
    if (scopedIds !== null && !scopedIds.includes(Number(studentId))) {
      return res.status(403).json({ error: 'Forbidden: Student is not authorized for your account.' });
    }

    const isParentSubmission = user.role === 'parent';
    const isUrgent = Boolean(urgentAlertSent) || ['fever_reported', 'feeling_unwell', 'ill'].includes(String(healthStatus));

    const [created] = await db
      .insert(healthRecords)
      .values({
        institutionId: instId,
        studentId: Number(studentId),
        recordDate: String(recordDate),
        heightCm: heightCm ? String(heightCm) : null,
        weightKg: weightKg ? String(weightKg) : null,
        temperatureC: temperatureC ? String(temperatureC) : null,
        healthStatus: String(healthStatus),
        illnessInfo: illnessInfo ? String(illnessInfo) : null,
        medicationNotes: medicationNotes ? String(medicationNotes) : null,
        followUpStatus: followUpStatus ? String(followUpStatus) : isUrgent && !isParentSubmission ? 'parent_notified' : 'monitoring',
        submittedByRole: isParentSubmission ? 'parent' : 'staff',
        parentUpdateNotes: parentUpdateNotes ? String(parentUpdateNotes) : null,
        urgentAlertSent: Boolean(urgentAlertSent),
        restrictedAccess: true,
        recordedBy: user.id,
        updatedAt: new Date(),
      })
      .returning();

    if (isParentSubmission) {
      await db.insert(notifications).values({
        institutionId: instId,
        title: `Parent Health Note: ${stRows[0].fullName}`,
        message: `Parent submitted health status (${healthStatus}): ${parentUpdateNotes || illnessInfo || 'See restricted Health portal.'}`,
        type: 'health',
        targetRole: 'admin',
        createdBy: user.id,
      });
    } else if (stRows[0]?.parentId && (healthStatus !== 'feeling_well' && healthStatus !== 'healthy' || urgentAlertSent)) {
      const allowHealth = urgentAlertSent || (await shouldNotifyPreference(instId, stRows[0].parentId, 'healthAlerts'));
      if (allowHealth) {
        await db.insert(notifications).values({
          institutionId: instId,
          title: `${urgentAlertSent ? '[Urgent Contact Requested] ' : ''}Health Update: ${stRows[0].fullName}`,
          message: `Status: ${healthStatus}. ${illnessInfo || 'Please check the restricted Health tab in your Parent Portal.'}`,
          type: 'health',
          targetRole: 'parent',
          targetUserId: stRows[0].parentId,
          createdBy: user.id,
        });
      }
    }

    await logAudit({
      institutionId: instId,
      userId: user.id,
      userEmail: user.email,
      action: urgentAlertSent ? 'URGENT_HEALTH_ALERT' : 'CREATE_HEALTH_RECORD',
      entityType: 'health_records',
      entityId: created.id,
      details: `Recorded health status (${healthStatus}, role=${isParentSubmission ? 'parent' : 'staff'}) for student ID ${studentId}`,
    });

    res.status(201).json(created);
  } catch (err) {
    console.error('Create health record error:', err);
    res.status(500).json({ error: 'Failed to save health record' });
  }
});

router.patch('/health/:id', requireAuth, requireTenant, requireRole('admin', 'teacher', 'parent'), async (req: AuthRequest, res) => {
  try {
    const id = Number(req.params.id);
    const user = req.dbUser!;
    const instId = user.institutionId!;

    const existing = await db
      .select()
      .from(healthRecords)
      .where(and(eq(healthRecords.id, id), eq(healthRecords.institutionId, instId)))
      .limit(1);
    if (existing.length === 0) return res.status(404).json({ error: 'Health record not found.' });

    const scopedIds = await getScopedStudentIds(req);
    if (scopedIds !== null && !scopedIds.includes(existing[0].studentId)) {
      return res.status(403).json({ error: 'Forbidden: Unauthorized access to health record.' });
    }

    const { followUpStatus, parentUpdateNotes, urgentAlertSent, healthStatus, illnessInfo, medicationNotes } = req.body;
    const updateSet: any = { updatedAt: new Date() };
    if (parentUpdateNotes !== undefined) updateSet.parentUpdateNotes = parentUpdateNotes ? String(parentUpdateNotes) : null;
    if (user.role === 'admin' || user.role === 'teacher') {
      if (followUpStatus !== undefined) updateSet.followUpStatus = String(followUpStatus);
      if (urgentAlertSent !== undefined) updateSet.urgentAlertSent = Boolean(urgentAlertSent);
      if (healthStatus !== undefined) updateSet.healthStatus = String(healthStatus);
      if (illnessInfo !== undefined) updateSet.illnessInfo = illnessInfo ? String(illnessInfo) : null;
      if (medicationNotes !== undefined) updateSet.medicationNotes = medicationNotes ? String(medicationNotes) : null;
    }

    const [updated] = await db
      .update(healthRecords)
      .set(updateSet)
      .where(and(eq(healthRecords.id, id), eq(healthRecords.institutionId, instId)))
      .returning();

    if (urgentAlertSent && !existing[0].urgentAlertSent) {
      const st = (await db.select().from(students).where(eq(students.id, existing[0].studentId)).limit(1))[0];
      if (st?.parentId) {
        await db.insert(notifications).values({
          institutionId: instId,
          title: `[Urgent Parent Contact] ${st.fullName}`,
          message: `Immediate parent follow-up requested by Maktab staff regarding health status (${updated.healthStatus}).`,
          type: 'health',
          targetRole: 'parent',
          targetUserId: st.parentId,
          createdBy: user.id,
        });
      }
      await logAudit({
        institutionId: instId,
        userId: user.id,
        userEmail: user.email,
        action: 'URGENT_HEALTH_ALERT',
        entityType: 'health_records',
        entityId: id,
        details: `Triggered urgent parent contact escalation for student ID ${existing[0].studentId}`,
      });
    }

    res.json(updated);
  } catch (err) {
    console.error('Update health record error:', err);
    res.status(500).json({ error: 'Failed to update health record' });
  }
});

// ==================== DAILY ACTIVITIES & 5 MEAL TRACKING ====================

router.get('/daily-activities', requireAuth, requireTenant, async (req: AuthRequest, res) => {
  try {
    const instId = req.dbUser!.institutionId!;
    const scopedIds = await getScopedStudentIds(req);
    if (scopedIds !== null && scopedIds.length === 0) return res.json([]);
    const rows =
      scopedIds === null
        ? await db
            .select()
            .from(dailyActivities)
            .where(eq(dailyActivities.institutionId, instId))
            .orderBy(desc(dailyActivities.date))
        : await db
            .select()
            .from(dailyActivities)
            .where(and(eq(dailyActivities.institutionId, instId), inArray(dailyActivities.studentId, scopedIds)))
            .orderBy(desc(dailyActivities.date));
    res.json(rows);
  } catch (err) {
    console.error('Daily activities fetch error:', err);
    res.status(500).json({ error: 'Failed to load daily activities' });
  }
});

router.post('/daily-activities', requireAuth, requireTenant, requireRole('admin', 'teacher'), async (req: AuthRequest, res) => {
  try {
    const instId = req.dbUser!.institutionId!;
    const {
      studentId,
      date,
      breakfastStatus,
      lunchStatus,
      eveningMealStatus,
      dinnerStatus,
      otherMealStatus,
      mealRemarks,
      homeworkCompleted,
      disciplineRating,
      deeniActivities,
      activityLogs,
      teacherRemarks,
    } = req.body;

    if (!studentId || !date) {
      return res.status(400).json({ error: 'Student and date are required.' });
    }

    const stRows = await db
      .select()
      .from(students)
      .where(and(eq(students.id, Number(studentId)), eq(students.institutionId, instId)))
      .limit(1);
    if (stRows.length === 0) {
      return res.status(403).json({ error: 'Forbidden: Student does not belong to your institution.' });
    }

    const scopedIds = await getScopedStudentIds(req);
    if (scopedIds !== null && !scopedIds.includes(Number(studentId))) {
      return res.status(403).json({ error: 'Forbidden: Student is not in your assigned classes.' });
    }

    const validMealStates = ['taken', 'not_taken', 'not_applicable', 'not_recorded', 'partial', 'skipped'];
    const sanitizeMeal = (v: any) => (validMealStates.includes(v) ? String(v) : 'not_recorded');
    const cleanLogs = Array.isArray(activityLogs)
      ? activityLogs
          .filter((a) => a && a.name)
          .map((a) => ({
            name: String(a.name).trim(),
            status: String(a.status || 'completed'),
            remarks: a.remarks ? String(a.remarks).trim() : undefined,
          }))
      : [];

    const [record] = await db
      .insert(dailyActivities)
      .values({
        institutionId: instId,
        studentId: Number(studentId),
        date: String(date),
        breakfastStatus: sanitizeMeal(breakfastStatus),
        lunchStatus: sanitizeMeal(lunchStatus),
        eveningMealStatus: sanitizeMeal(eveningMealStatus),
        dinnerStatus: sanitizeMeal(dinnerStatus),
        otherMealStatus: sanitizeMeal(otherMealStatus),
        mealRemarks: mealRemarks ? String(mealRemarks) : null,
        homeworkCompleted: Boolean(homeworkCompleted),
        disciplineRating: Math.min(5, Math.max(1, Number(disciplineRating) || 5)),
        deeniActivities: deeniActivities || null,
        activityLogs: cleanLogs,
        teacherRemarks: teacherRemarks || null,
        recordedBy: req.dbUser!.id,
        updatedAt: new Date(),
      })
      .onConflictDoUpdate({
        target: [dailyActivities.studentId, dailyActivities.date],
        set: {
          breakfastStatus: sanitizeMeal(breakfastStatus),
          lunchStatus: sanitizeMeal(lunchStatus),
          eveningMealStatus: sanitizeMeal(eveningMealStatus),
          dinnerStatus: sanitizeMeal(dinnerStatus),
          otherMealStatus: sanitizeMeal(otherMealStatus),
          mealRemarks: mealRemarks ? String(mealRemarks) : null,
          homeworkCompleted: Boolean(homeworkCompleted),
          disciplineRating: Math.min(5, Math.max(1, Number(disciplineRating) || 5)),
          deeniActivities: deeniActivities || null,
          activityLogs: cleanLogs,
          teacherRemarks: teacherRemarks || null,
          recordedBy: req.dbUser!.id,
          updatedAt: new Date(),
        },
      })
      .returning();

    if (stRows[0]?.parentId) {
      const allowFood = await shouldNotifyPreference(instId, stRows[0].parentId, 'foodUpdates');
      if (allowFood) {
        await db.insert(notifications).values({
          institutionId: instId,
          title: `Daily Meal & Activity Summary: ${stRows[0].fullName}`,
          message: `Daily meal and activity report posted for ${date}.`,
          type: 'food',
          targetRole: 'parent',
          targetUserId: stRows[0].parentId,
          createdBy: req.dbUser!.id,
        });
      }
    }

    res.status(201).json(record);
  } catch (err) {
    console.error('Save daily activity error:', err);
    res.status(500).json({ error: 'Failed to save daily activity' });
  }
});

router.patch('/daily-activities/:id/parent-remark', requireAuth, requireTenant, requireRole('parent'), async (req: AuthRequest, res) => {
  try {
    const id = Number(req.params.id);
    const instId = req.dbUser!.institutionId!;
    const { parentRemarks } = req.body;

    const existing = await db
      .select()
      .from(dailyActivities)
      .where(and(eq(dailyActivities.id, id), eq(dailyActivities.institutionId, instId)))
      .limit(1);
    if (existing.length === 0) return res.status(404).json({ error: 'Daily activity record not found.' });

    const scopedIds = await getScopedStudentIds(req);
    if (!scopedIds || !scopedIds.includes(existing[0].studentId)) {
      return res.status(403).json({ error: 'Forbidden: Not your linked child.' });
    }

    const [updated] = await db
      .update(dailyActivities)
      .set({
        parentRemarks: parentRemarks ? String(parentRemarks).trim() : null,
        updatedAt: new Date(),
      })
      .where(and(eq(dailyActivities.id, id), eq(dailyActivities.institutionId, instId)))
      .returning();

    res.json(updated);
  } catch (err) {
    console.error('Parent remark error:', err);
    res.status(500).json({ error: 'Failed to save parent remark' });
  }
});

// ==================== HOMEWORK & ASSIGNMENTS ====================

router.get('/homework', requireAuth, requireTenant, async (req: AuthRequest, res) => {
  try {
    const user = req.dbUser!;
    const instId = user.institutionId!;
    const scopedIds = await getScopedStudentIds(req);

    let hwRows = await db
      .select()
      .from(homework)
      .where(eq(homework.institutionId, instId))
      .orderBy(desc(homework.createdAt));
    if (user.role === 'teacher') {
      const classIds = await getTeacherClassIds(user.id, instId);
      hwRows = hwRows.filter((h) => h.teacherId === user.id || classIds.includes(h.classId));
    } else if (user.role === 'student' || user.role === 'parent') {
      if (scopedIds && scopedIds.length > 0) {
        const myStudents = await db
          .select()
          .from(students)
          .where(and(eq(students.institutionId, instId), inArray(students.id, scopedIds)));
        const myClassIds = myStudents.map((s) => s.classId).filter(Boolean) as number[];
        hwRows = hwRows.filter((h) => myClassIds.includes(h.classId));
      } else {
        hwRows = [];
      }
    }

    const assignRows =
      scopedIds === null
        ? await db.select().from(assignments).where(eq(assignments.institutionId, instId))
        : scopedIds.length > 0
          ? await db
              .select()
              .from(assignments)
              .where(and(eq(assignments.institutionId, instId), inArray(assignments.studentId, scopedIds)))
          : [];

    res.json({ homework: hwRows, assignments: assignRows });
  } catch (err) {
    console.error('Homework fetch error:', err);
    res.status(500).json({ error: 'Failed to load homework' });
  }
});

router.post('/homework', requireAuth, requireTenant, requireRole('admin', 'teacher'), async (req: AuthRequest, res) => {
  try {
    const instId = req.dbUser!.institutionId!;
    const { title, description, classId, subjectId, dueDate, attachmentUrl } = req.body;
    if (!title || !description || !classId || !subjectId || !dueDate) {
      return res.status(400).json({ error: 'Title, description, class, subject, and due date are required.' });
    }

    const cls = await db
      .select()
      .from(classes)
      .where(and(eq(classes.id, Number(classId)), eq(classes.institutionId, instId)))
      .limit(1);
    if (cls.length === 0) return res.status(403).json({ error: 'Forbidden: Class outside your institution.' });

    if (req.dbUser!.role === 'teacher') {
      const myClasses = await getTeacherClassIds(req.dbUser!.id, instId);
      if (!myClasses.includes(Number(classId))) {
        return res.status(403).json({ error: 'Forbidden: Class is not assigned to you.' });
      }
    }

    const [created] = await db
      .insert(homework)
      .values({
        institutionId: instId,
        title: String(title).trim(),
        description: String(description).trim(),
        classId: Number(classId),
        subjectId: Number(subjectId),
        teacherId: req.dbUser!.id,
        dueDate: String(dueDate),
        attachmentUrl: attachmentUrl || null,
      })
      .returning();

    await db.insert(notifications).values({
      institutionId: instId,
      title: `New Homework: ${created.title}`,
      message: `Due on ${created.dueDate}. Check the Homework portal for details.`,
      type: 'homework',
      targetRole: 'student',
      createdBy: req.dbUser!.id,
    });

    res.status(201).json(created);
  } catch (err) {
    console.error('Create homework error:', err);
    res.status(500).json({ error: 'Failed to assign homework' });
  }
});

router.post('/homework/:id/submit', requireAuth, requireTenant, requireRole('student', 'parent'), async (req: AuthRequest, res) => {
  try {
    const instId = req.dbUser!.institutionId!;
    const homeworkId = Number(req.params.id);
    const hwRows = await db
      .select()
      .from(homework)
      .where(and(eq(homework.id, homeworkId), eq(homework.institutionId, instId)))
      .limit(1);
    if (hwRows.length === 0) return res.status(404).json({ error: 'Homework not found in your institution' });

    const { studentId, submissionText } = req.body;
    const scopedIds = await getScopedStudentIds(req);
    const targetStudentId = studentId ? Number(studentId) : scopedIds?.[0];
    if (!targetStudentId || (scopedIds && !scopedIds.includes(targetStudentId))) {
      return res.status(403).json({ error: 'Unauthorized student submission' });
    }

    const [saved] = await db
      .insert(assignments)
      .values({
        institutionId: instId,
        homeworkId,
        studentId: targetStudentId,
        status: 'submitted',
        submissionText: String(submissionText || 'Completed'),
        submittedAt: new Date(),
      })
      .onConflictDoUpdate({
        target: [assignments.homeworkId, assignments.studentId],
        set: {
          status: 'submitted',
          submissionText: String(submissionText || 'Completed'),
          submittedAt: new Date(),
        },
      })
      .returning();

    res.status(201).json(saved);
  } catch (err) {
    console.error('Submit homework error:', err);
    res.status(500).json({ error: 'Failed to submit homework' });
  }
});

router.patch('/assignments/:id/grade', requireAuth, requireTenant, requireRole('admin', 'teacher'), async (req: AuthRequest, res) => {
  try {
    const id = Number(req.params.id);
    const instId = req.dbUser!.institutionId!;
    const { score, feedback } = req.body;
    const [updated] = await db
      .update(assignments)
      .set({
        status: 'graded',
        score: Number(score),
        feedback: feedback || null,
      })
      .where(and(eq(assignments.id, id), eq(assignments.institutionId, instId)))
      .returning();
    if (!updated) return res.status(404).json({ error: 'Assignment not found in your institution' });
    res.json(updated);
  } catch (err) {
    console.error('Grade assignment error:', err);
    res.status(500).json({ error: 'Failed to grade assignment' });
  }
});

// ==================== EXAMS, ONLINE QUIZZES & MARKS ====================

router.get('/exams', requireAuth, requireTenant, async (req: AuthRequest, res) => {
  try {
    const user = req.dbUser!;
    const instId = user.institutionId!;
    let examRows = await db.select().from(exams).where(eq(exams.institutionId, instId)).orderBy(desc(exams.examDate));
    const scopedIds = await getScopedStudentIds(req);

    if (user.role === 'teacher') {
      const classIds = await getTeacherClassIds(user.id, instId);
      examRows = examRows.filter((e) => classIds.includes(e.classId));
    } else if (user.role === 'student' || user.role === 'parent') {
      if (scopedIds && scopedIds.length > 0) {
        const myStudents = await db
          .select()
          .from(students)
          .where(and(eq(students.institutionId, instId), inArray(students.id, scopedIds)));
        const myClassIds = myStudents.map((s) => s.classId).filter(Boolean) as number[];
        examRows = examRows.filter((e) => myClassIds.includes(e.classId));
      } else {
        examRows = [];
      }
    }

    const [markRows, attemptRows] = await Promise.all([
      scopedIds === null
        ? db.select().from(marks).where(eq(marks.institutionId, instId))
        : scopedIds.length > 0
          ? db
              .select()
              .from(marks)
              .where(and(eq(marks.institutionId, instId), inArray(marks.studentId, scopedIds)))
          : Promise.resolve([]),
      scopedIds === null
        ? db.select().from(testAttempts).where(eq(testAttempts.institutionId, instId)).orderBy(desc(testAttempts.submittedAt))
        : scopedIds.length > 0
          ? db
              .select()
              .from(testAttempts)
              .where(and(eq(testAttempts.institutionId, instId), inArray(testAttempts.studentId, scopedIds)))
              .orderBy(desc(testAttempts.submittedAt))
          : Promise.resolve([]),
    ]);

    // Security: NEVER expose answer keys (correctIndex / correctAnswerText) to students or parents before evaluation
    const sanitizedExams =
      user.role === 'student' || user.role === 'parent'
        ? examRows.map((exam) => {
            const evaluatedAttempt = attemptRows.find(
              (a) => a.examId === exam.id && a.status === 'evaluated'
            );
            if (evaluatedAttempt) return exam;
            return {
              ...exam,
              questionsJson: (exam.questionsJson || []).map(({ correctIndex: _ci, correctAnswerText: _ca, ...q }) => q),
            };
          })
        : examRows;

    const scopedAttempts =
      user.role === 'teacher'
        ? attemptRows.filter((a) => examRows.some((e) => e.id === a.examId))
        : attemptRows;

    res.json({ exams: sanitizedExams, marks: markRows, attempts: scopedAttempts });
  } catch (err) {
    console.error('Exams fetch error:', err);
    res.status(500).json({ error: 'Failed to load exams and results' });
  }
});

router.post('/exams', requireAuth, requireTenant, requireRole('admin', 'teacher'), async (req: AuthRequest, res) => {
  try {
    const instId = req.dbUser!.institutionId!;
    const {
      title,
      examType,
      classId,
      subjectId,
      examDate,
      startDate,
      endDate,
      totalMarks,
      passingMarks,
      durationMinutes,
      isOnline,
      questionsJson,
    } = req.body;
    if (!title || !classId || !subjectId || !examDate) {
      return res.status(400).json({ error: 'Title, class, subject, and exam date are required.' });
    }
    const cls = await db
      .select()
      .from(classes)
      .where(and(eq(classes.id, Number(classId)), eq(classes.institutionId, instId)))
      .limit(1);
    if (cls.length === 0) return res.status(403).json({ error: 'Forbidden: Class outside your institution.' });

    if (req.dbUser!.role === 'teacher') {
      const myClasses = await getTeacherClassIds(req.dbUser!.id, instId);
      if (!myClasses.includes(Number(classId))) {
        return res.status(403).json({ error: 'Forbidden: Class is not assigned to you.' });
      }
    }

    const [created] = await db
      .insert(exams)
      .values({
        institutionId: instId,
        title: String(title).trim(),
        examType: examType || 'unit',
        classId: Number(classId),
        subjectId: Number(subjectId),
        examDate: String(examDate),
        startDate: startDate ? String(startDate) : String(examDate),
        endDate: endDate ? String(endDate) : null,
        totalMarks: Number(totalMarks) || 100,
        passingMarks: passingMarks !== undefined ? Number(passingMarks) : Math.round((Number(totalMarks) || 100) * 0.4),
        durationMinutes: Number(durationMinutes) || 60,
        isOnline: Boolean(isOnline),
        questionsJson: Array.isArray(questionsJson) ? questionsJson : [],
        createdBy: req.dbUser!.id,
      })
      .returning();

    await db.insert(notifications).values({
      institutionId: instId,
      title: `Exam Scheduled: ${created.title}`,
      message: `Date: ${created.examDate} · Total Marks: ${created.totalMarks} · Pass: ${created.passingMarks}`,
      type: 'exam',
      targetRole: 'all',
      createdBy: req.dbUser!.id,
    });

    res.status(201).json(created);
  } catch (err) {
    console.error('Create exam error:', err);
    res.status(500).json({ error: 'Failed to create exam' });
  }
});

router.post('/exams/:id/submit-quiz', requireAuth, requireTenant, requireRole('student'), async (req: AuthRequest, res) => {
  try {
    const instId = req.dbUser!.institutionId!;
    const examId = Number(req.params.id);
    const { answers } = req.body;
    const examRows = await db
      .select()
      .from(exams)
      .where(and(eq(exams.id, examId), eq(exams.institutionId, instId)))
      .limit(1);
    if (examRows.length === 0) return res.status(404).json({ error: 'Quiz not found in your institution' });

    const exam = examRows[0];
    const studentRows = await db
      .select()
      .from(students)
      .where(and(eq(students.userId, req.dbUser!.id), eq(students.institutionId, instId)))
      .limit(1);
    if (studentRows.length === 0) return res.status(400).json({ error: 'Student profile not linked' });

    const student = studentRows[0];
    if (student.classId !== exam.classId) {
      return res.status(403).json({ error: 'Forbidden: This test is not assigned to your class.' });
    }

    const existingAttempt = await db
      .select()
      .from(testAttempts)
      .where(and(eq(testAttempts.examId, examId), eq(testAttempts.studentId, student.id)))
      .limit(1);
    if (existingAttempt.length > 0) {
      return res.status(409).json({ error: 'Duplicate attempt blocked: You have already submitted this test.' });
    }

    const today = new Date().toISOString().slice(0, 10);
    if (exam.startDate && today < exam.startDate) {
      return res.status(400).json({ error: `This test opens on ${exam.startDate}.` });
    }
    if (exam.endDate && today > exam.endDate) {
      return res.status(400).json({ error: `Submission window closed on ${exam.endDate}.` });
    }

    const questions = exam.questionsJson || [];
    let objectiveScore = 0;
    let total = 0;
    let hasSubjective = false;
    const questionScores: Record<string, number> = {};

    for (const q of questions) {
      const qType = q.type || 'mcq';
      const qMarks = Number(q.marks) || 5;
      total += qMarks;
      if (qType === 'short_answer' || qType === 'long_answer') {
        hasSubjective = true;
        questionScores[q.id] = 0;
      } else {
        const isCorrect = answers && answers[q.id] === q.correctIndex;
        const awarded = isCorrect ? qMarks : 0;
        objectiveScore += awarded;
        questionScores[q.id] = awarded;
      }
    }
    if (total === 0) total = exam.totalMarks;

    const status = hasSubjective ? 'submitted_pending_review' : 'evaluated';
    const [attempt] = await db
      .insert(testAttempts)
      .values({
        institutionId: instId,
        examId,
        studentId: student.id,
        answersJson: answers || {},
        questionScoresJson: questionScores,
        objectiveScore,
        subjectiveScore: 0,
        totalScore: objectiveScore,
        status,
        teacherRemarks: hasSubjective ? 'Objective items graded; awaiting teacher review for subjective responses.' : 'Auto-graded online assessment',
      })
      .returning();

    let savedMark: any = null;
    if (!hasSubjective) {
      const grade = computeGrade(objectiveScore, total);
      const [markRow] = await db
        .insert(marks)
        .values({
          institutionId: instId,
          examId,
          studentId: student.id,
          obtainedMarks: objectiveScore,
          totalMarks: total,
          grade,
          remarks: 'Auto-graded online assessment',
        })
        .onConflictDoUpdate({
          target: [marks.examId, marks.studentId],
          set: {
            obtainedMarks: objectiveScore,
            totalMarks: total,
            grade,
            remarks: 'Auto-graded online assessment',
          },
        })
        .returning();
      savedMark = markRow;
    } else {
      await db.insert(notifications).values({
        institutionId: instId,
        title: `Online Test Pending Review: ${exam.title}`,
        message: `${student.fullName} submitted answers requiring subjective evaluation.`,
        type: 'exam',
        targetRole: 'teacher',
        createdBy: req.dbUser!.id,
      });
    }

    res.status(201).json({ attempt, mark: savedMark, obtainedMarks: objectiveScore, totalMarks: total });
  } catch (err) {
    console.error('Submit quiz error:', err);
    res.status(500).json({ error: 'Failed to submit online quiz' });
  }
});

router.patch('/test-attempts/:id/evaluate', requireAuth, requireTenant, requireRole('admin', 'teacher'), async (req: AuthRequest, res) => {
  try {
    const id = Number(req.params.id);
    const user = req.dbUser!;
    const instId = user.institutionId!;
    const { questionScores, teacherRemarks } = req.body;

    const attemptRows = await db
      .select()
      .from(testAttempts)
      .where(and(eq(testAttempts.id, id), eq(testAttempts.institutionId, instId)))
      .limit(1);
    if (attemptRows.length === 0) return res.status(404).json({ error: 'Test attempt not found.' });

    const attempt = attemptRows[0];
    const examRows = await db
      .select()
      .from(exams)
      .where(and(eq(exams.id, attempt.examId), eq(exams.institutionId, instId)))
      .limit(1);
    if (examRows.length === 0) return res.status(404).json({ error: 'Exam not found.' });
    const exam = examRows[0];

    if (user.role === 'teacher') {
      const classIds = await getTeacherClassIds(user.id, instId);
      if (!classIds.includes(exam.classId)) {
        return res.status(403).json({ error: 'Forbidden: Exam class not assigned to you.' });
      }
    }

    const questions = exam.questionsJson || [];
    const mergedScores: Record<string, number> = { ...(attempt.questionScoresJson || {}) };
    let subjectiveScore = 0;
    let totalMarks = 0;

    for (const q of questions) {
      const qMarks = Number(q.marks) || 5;
      totalMarks += qMarks;
      const qType = q.type || 'mcq';
      if (qType === 'short_answer' || qType === 'long_answer') {
        const raw = questionScores && questionScores[q.id] !== undefined ? Number(questionScores[q.id]) : mergedScores[q.id] || 0;
        const clamped = Math.min(qMarks, Math.max(0, raw));
        mergedScores[q.id] = clamped;
        subjectiveScore += clamped;
      }
    }
    if (totalMarks === 0) totalMarks = exam.totalMarks;
    const totalScore = attempt.objectiveScore + subjectiveScore;
    const grade = computeGrade(totalScore, totalMarks);

    const [updatedAttempt] = await db
      .update(testAttempts)
      .set({
        questionScoresJson: mergedScores,
        subjectiveScore,
        totalScore,
        status: 'evaluated',
        teacherRemarks: teacherRemarks ? String(teacherRemarks).trim() : null,
        evaluatedBy: user.id,
        evaluatedAt: new Date(),
      })
      .where(and(eq(testAttempts.id, id), eq(testAttempts.institutionId, instId)))
      .returning();

    const [savedMark] = await db
      .insert(marks)
      .values({
        institutionId: instId,
        examId: exam.id,
        studentId: attempt.studentId,
        obtainedMarks: totalScore,
        totalMarks,
        grade,
        remarks: teacherRemarks ? String(teacherRemarks).trim() : 'Evaluated by teacher',
        gradedBy: user.id,
      })
      .onConflictDoUpdate({
        target: [marks.examId, marks.studentId],
        set: {
          obtainedMarks: totalScore,
          totalMarks,
          grade,
          remarks: teacherRemarks ? String(teacherRemarks).trim() : 'Evaluated by teacher',
          gradedBy: user.id,
        },
      })
      .returning();

    const st = (await db.select().from(students).where(eq(students.id, attempt.studentId)).limit(1))[0];
    if (st?.userId) {
      await db.insert(notifications).values({
        institutionId: instId,
        title: `Test Result Published: ${exam.title}`,
        message: `Scored ${totalScore}/${totalMarks} (${grade}).`,
        type: 'exam',
        targetRole: 'student',
        targetUserId: st.userId,
        createdBy: user.id,
      });
    }
    if (st?.parentId) {
      await db.insert(notifications).values({
        institutionId: instId,
        title: `Result Published for ${st.fullName}: ${exam.title}`,
        message: `Scored ${totalScore}/${totalMarks} (${grade}).`,
        type: 'exam',
        targetRole: 'parent',
        targetUserId: st.parentId,
        createdBy: user.id,
      });
    }

    res.json({ attempt: updatedAttempt, mark: savedMark });
  } catch (err) {
    console.error('Evaluate attempt error:', err);
    res.status(500).json({ error: 'Failed to evaluate test attempt' });
  }
});

router.post('/marks', requireAuth, requireTenant, requireRole('admin', 'teacher'), async (req: AuthRequest, res) => {
  try {
    const instId = req.dbUser!.institutionId!;
    const { examId, studentId, obtainedMarks, totalMarks, remarks } = req.body;
    if (!examId || !studentId || obtainedMarks === undefined || !totalMarks) {
      return res.status(400).json({ error: 'Exam, student, obtained marks, and total marks are required.' });
    }

    const [exCheck, stCheck] = await Promise.all([
      db.select().from(exams).where(and(eq(exams.id, Number(examId)), eq(exams.institutionId, instId))).limit(1),
      db.select().from(students).where(and(eq(students.id, Number(studentId)), eq(students.institutionId, instId))).limit(1),
    ]);
    if (exCheck.length === 0 || stCheck.length === 0) {
      return res.status(403).json({ error: 'Forbidden: Exam or Student does not belong to your institution.' });
    }

    const scopedIds = await getScopedStudentIds(req);
    if (scopedIds !== null && !scopedIds.includes(Number(studentId))) {
      return res.status(403).json({ error: 'Forbidden: Student is not in your assigned classes.' });
    }
    const grade = computeGrade(Number(obtainedMarks), Number(totalMarks));

    const [saved] = await db
      .insert(marks)
      .values({
        institutionId: instId,
        examId: Number(examId),
        studentId: Number(studentId),
        obtainedMarks: Number(obtainedMarks),
        totalMarks: Number(totalMarks),
        grade,
        remarks: remarks || null,
        gradedBy: req.dbUser!.id,
      })
      .onConflictDoUpdate({
        target: [marks.examId, marks.studentId],
        set: {
          obtainedMarks: Number(obtainedMarks),
          totalMarks: Number(totalMarks),
          grade,
          remarks: remarks || null,
          gradedBy: req.dbUser!.id,
        },
      })
      .returning();

    res.status(201).json(saved);
  } catch (err) {
    console.error('Save marks error:', err);
    res.status(500).json({ error: 'Failed to enter marks' });
  }
});

// ==================== FEES & PAYMENTS ====================

router.get('/fees', requireAuth, requireTenant, requireRole('admin', 'parent'), async (req: AuthRequest, res) => {
  try {
    const instId = req.dbUser!.institutionId!;
    const scopedIds = await getScopedStudentIds(req);
    if (scopedIds !== null && scopedIds.length === 0) return res.json({ fees: [], payments: [] });

    const [feeRows, paymentRows] = await Promise.all([
      scopedIds === null
        ? db.select().from(fees).where(eq(fees.institutionId, instId)).orderBy(desc(fees.createdAt))
        : db
            .select()
            .from(fees)
            .where(and(eq(fees.institutionId, instId), inArray(fees.studentId, scopedIds)))
            .orderBy(desc(fees.createdAt)),
      scopedIds === null
        ? db.select().from(payments).where(eq(payments.institutionId, instId)).orderBy(desc(payments.paidAt))
        : db
            .select()
            .from(payments)
            .where(and(eq(payments.institutionId, instId), inArray(payments.studentId, scopedIds)))
            .orderBy(desc(payments.paidAt)),
    ]);

    res.json({ fees: feeRows, payments: paymentRows });
  } catch (err) {
    console.error('Fees fetch error:', err);
    res.status(500).json({ error: 'Failed to load fees' });
  }
});

router.post('/fees', requireAuth, requireTenant, requireRole('admin'), async (req: AuthRequest, res) => {
  try {
    const instId = req.dbUser!.institutionId!;
    const { studentId, monthYear, title, amount, dueDate } = req.body;
    if (!studentId || !monthYear || !title || !amount || !dueDate) {
      return res.status(400).json({ error: 'All fee invoice fields are required.' });
    }
    const st = await db
      .select()
      .from(students)
      .where(and(eq(students.id, Number(studentId)), eq(students.institutionId, instId)))
      .limit(1);
    if (st.length === 0) {
      return res.status(403).json({ error: 'Forbidden: Student does not belong to your institution.' });
    }

    const [created] = await db
      .insert(fees)
      .values({
        institutionId: instId,
        studentId: Number(studentId),
        monthYear: String(monthYear),
        title: String(title).trim(),
        amount: Number(amount),
        dueDate: String(dueDate),
        status: 'pending',
      })
      .returning();

    if (st[0]?.parentId) {
      await db.insert(notifications).values({
        institutionId: instId,
        title: `New Fee Invoice: ${created.title}`,
        message: `Amount: INR ${created.amount} · Due: ${created.dueDate}`,
        type: 'fee',
        targetRole: 'parent',
        targetUserId: st[0].parentId,
        createdBy: req.dbUser!.id,
      });
    }

    res.status(201).json(created);
  } catch (err) {
    console.error('Create fee error:', err);
    res.status(500).json({ error: 'Failed to generate fee invoice' });
  }
});

router.post('/fees/:id/pay', requireAuth, requireTenant, requireRole('admin', 'parent'), async (req: AuthRequest, res) => {
  try {
    const instId = req.dbUser!.institutionId!;
    const feeId = Number(req.params.id);
    const { paymentMethod, transactionRef } = req.body;
    const feeRows = await db
      .select()
      .from(fees)
      .where(and(eq(fees.id, feeId), eq(fees.institutionId, instId)))
      .limit(1);
    if (feeRows.length === 0) return res.status(404).json({ error: 'Fee invoice not found in your institution' });

    const fee = feeRows[0];
    if (fee.status === 'paid') {
      return res.status(400).json({ error: 'This fee invoice is already paid.' });
    }

    if (req.dbUser!.role === 'parent') {
      const scopedIds = await getScopedStudentIds(req);
      if (!scopedIds || !scopedIds.includes(fee.studentId)) {
        return res.status(403).json({ error: 'Forbidden: Not your child fee invoice' });
      }
    }

    const receiptNo = `RCPT-${instId}-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
    const txRef = transactionRef || `${(paymentMethod || 'UPI').toUpperCase()}-${Date.now()}`;

    const [payment] = await db
      .insert(payments)
      .values({
        institutionId: instId,
        feeId,
        studentId: fee.studentId,
        amountPaid: fee.amount,
        paymentMethod: paymentMethod || 'upi',
        transactionRef: String(txRef),
        receiptNo,
        recordedBy: req.dbUser!.id,
      })
      .returning();

    const [updatedFee] = await db
      .update(fees)
      .set({ status: 'paid' })
      .where(and(eq(fees.id, feeId), eq(fees.institutionId, instId)))
      .returning();

    await logAudit({
      institutionId: instId,
      userId: req.dbUser!.id,
      userEmail: req.dbUser!.email,
      action: 'FEE_PAYMENT',
      entityType: 'payments',
      entityId: payment.id,
      details: `Paid ${fee.amount} for ${fee.title} (${receiptNo})`,
    });

    res.status(201).json({ fee: updatedFee, payment });
  } catch (err) {
    console.error('Pay fee error:', err);
    res.status(500).json({ error: 'Payment processing failed' });
  }
});

// ==================== ONLINE EDUCATION & TIMETABLE ====================

router.get('/online-education', requireAuth, requireTenant, async (req: AuthRequest, res) => {
  try {
    const user = req.dbUser!;
    const instId = user.institutionId!;
    const scopedIds = await getScopedStudentIds(req);
    let [materialsRows, lessonsRows, timetableRows, liveAttRows] = await Promise.all([
      db
        .select()
        .from(studyMaterials)
        .where(eq(studyMaterials.institutionId, instId))
        .orderBy(desc(studyMaterials.createdAt)),
      db
        .select()
        .from(recordedLessons)
        .where(eq(recordedLessons.institutionId, instId))
        .orderBy(desc(recordedLessons.createdAt)),
      db.select().from(timetable).where(eq(timetable.institutionId, instId)).orderBy(timetable.id),
      scopedIds === null
        ? db.select().from(liveClassAttendance).where(eq(liveClassAttendance.institutionId, instId))
        : scopedIds.length > 0
          ? db
              .select()
              .from(liveClassAttendance)
              .where(and(eq(liveClassAttendance.institutionId, instId), inArray(liveClassAttendance.studentId, scopedIds)))
          : Promise.resolve([]),
    ]);

    if (user.role === 'teacher') {
      const classIds = await getTeacherClassIds(user.id, instId);
      materialsRows = materialsRows.filter((m) => classIds.includes(m.classId));
      lessonsRows = lessonsRows.filter((l) => classIds.includes(l.classId) || l.teacherId === user.id || l.accessScope === 'institution_all');
      timetableRows = timetableRows.filter((t) => classIds.includes(t.classId) || t.teacherId === user.id);
    } else if ((user.role === 'student' || user.role === 'parent') && scopedIds) {
      const myStudents =
        scopedIds.length > 0
          ? await db
              .select()
              .from(students)
              .where(and(eq(students.institutionId, instId), inArray(students.id, scopedIds)))
          : [];
      const myClassIds = myStudents.map((s) => s.classId).filter(Boolean) as number[];
      materialsRows = materialsRows.filter((m) => myClassIds.includes(m.classId));
      lessonsRows = lessonsRows.filter((l) => myClassIds.includes(l.classId) || l.accessScope === 'institution_all');
      timetableRows = timetableRows.filter((t) => myClassIds.includes(t.classId));
    }

    res.json({
      materials: materialsRows,
      lessons: lessonsRows,
      timetable: timetableRows,
      liveAttendance: liveAttRows,
    });
  } catch (err) {
    console.error('Online education error:', err);
    res.status(500).json({ error: 'Failed to load online education modules' });
  }
});

router.post('/materials', requireAuth, requireTenant, requireRole('admin', 'teacher'), async (req: AuthRequest, res) => {
  try {
    const instId = req.dbUser!.institutionId!;
    const { title, description, classId, subjectId, materialType, resourceUrl } = req.body;
    if (!title || !classId || !subjectId || !resourceUrl) {
      return res.status(400).json({ error: 'Title, class, subject, and resource URL are required.' });
    }
    const cls = await db
      .select()
      .from(classes)
      .where(and(eq(classes.id, Number(classId)), eq(classes.institutionId, instId)))
      .limit(1);
    if (cls.length === 0) return res.status(403).json({ error: 'Forbidden: Class outside your institution.' });

    const [created] = await db
      .insert(studyMaterials)
      .values({
        institutionId: instId,
        title: String(title).trim(),
        description: description || null,
        classId: Number(classId),
        subjectId: Number(subjectId),
        materialType: materialType || 'pdf',
        resourceUrl: String(resourceUrl).trim(),
        uploadedBy: req.dbUser!.id,
      })
      .returning();
    res.status(201).json(created);
  } catch (err) {
    console.error('Create material error:', err);
    res.status(500).json({ error: 'Failed to upload study material' });
  }
});

router.post('/lessons', requireAuth, requireTenant, requireRole('admin', 'teacher'), async (req: AuthRequest, res) => {
  try {
    const instId = req.dbUser!.institutionId!;
    const {
      title,
      description,
      chapter,
      thumbnailUrl,
      classId,
      subjectId,
      lessonType,
      provider,
      accessScope,
      videoUrl,
      meetingLink,
      scheduledAt,
      durationMinutes,
    } = req.body;
    if (!title || !classId || !subjectId) {
      return res.status(400).json({ error: 'Title, class, and subject are required.' });
    }
    const cls = await db
      .select()
      .from(classes)
      .where(and(eq(classes.id, Number(classId)), eq(classes.institutionId, instId)))
      .limit(1);
    if (cls.length === 0) return res.status(403).json({ error: 'Forbidden: Class outside your institution.' });

    const cleanType = lessonType === 'live' ? 'live' : 'recorded';
    const [created] = await db
      .insert(recordedLessons)
      .values({
        institutionId: instId,
        title: String(title).trim(),
        description: description || null,
        chapter: chapter ? String(chapter).trim() : null,
        thumbnailUrl: thumbnailUrl ? String(thumbnailUrl).trim() : null,
        classId: Number(classId),
        subjectId: Number(subjectId),
        teacherId: req.dbUser!.id,
        lessonType: cleanType,
        provider: provider ? String(provider) : cleanType === 'live' ? 'jitsi_external' : 'secure_storage',
        accessScope: accessScope === 'institution_all' ? 'institution_all' : 'enrolled_class',
        videoUrl: videoUrl || null,
        meetingLink: meetingLink || null,
        scheduledAt: scheduledAt || null,
        durationMinutes: Number(durationMinutes) || 40,
        updatedAt: new Date(),
      })
      .returning();

    await db.insert(notifications).values({
      institutionId: instId,
      title: cleanType === 'live' ? `Live Class Scheduled: ${created.title}` : `New Recorded Lesson: ${created.title}`,
      message:
        cleanType === 'live'
          ? `Scheduled for ${created.scheduledAt || 'upcoming slot'} (${created.durationMinutes} min).`
          : `New recorded lesson uploaded for ${cls[0].name}.`,
      type: cleanType === 'live' ? 'live_class' : 'lesson',
      targetRole: 'all',
      createdBy: req.dbUser!.id,
    });

    res.status(201).json(created);
  } catch (err) {
    console.error('Create lesson error:', err);
    res.status(500).json({ error: 'Failed to create lesson' });
  }
});

router.get('/lessons/:id/attendance', requireAuth, requireTenant, async (req: AuthRequest, res) => {
  try {
    const lessonId = Number(req.params.id);
    const instId = req.dbUser!.institutionId!;
    const lesson = (
      await db
        .select()
        .from(recordedLessons)
        .where(and(eq(recordedLessons.id, lessonId), eq(recordedLessons.institutionId, instId)))
        .limit(1)
    )[0];
    if (!lesson) return res.status(404).json({ error: 'Lesson not found.' });

    const scopedIds = await getScopedStudentIds(req);
    const rows =
      scopedIds === null
        ? await db
            .select()
            .from(liveClassAttendance)
            .where(and(eq(liveClassAttendance.lessonId, lessonId), eq(liveClassAttendance.institutionId, instId)))
        : scopedIds.length > 0
          ? await db
              .select()
              .from(liveClassAttendance)
              .where(
                and(
                  eq(liveClassAttendance.lessonId, lessonId),
                  eq(liveClassAttendance.institutionId, instId),
                  inArray(liveClassAttendance.studentId, scopedIds)
                )
              )
          : [];
    res.json(rows);
  } catch (err) {
    console.error('Live attendance fetch error:', err);
    res.status(500).json({ error: 'Failed to load live class attendance' });
  }
});

router.post('/lessons/:id/attendance', requireAuth, requireTenant, async (req: AuthRequest, res) => {
  try {
    const lessonId = Number(req.params.id);
    const user = req.dbUser!;
    const instId = user.institutionId!;
    const { studentId, status } = req.body;

    const lesson = (
      await db
        .select()
        .from(recordedLessons)
        .where(and(eq(recordedLessons.id, lessonId), eq(recordedLessons.institutionId, instId)))
        .limit(1)
    )[0];
    if (!lesson) return res.status(404).json({ error: 'Live class not found in your institution.' });

    const scopedIds = await getScopedStudentIds(req);
    const targetStudentId = studentId ? Number(studentId) : scopedIds?.[0];
    if (!targetStudentId) return res.status(400).json({ error: 'Student ID is required.' });
    if (scopedIds !== null && !scopedIds.includes(targetStudentId)) {
      return res.status(403).json({ error: 'Forbidden: Not authorized for this student.' });
    }

    const st = (
      await db
        .select()
        .from(students)
        .where(and(eq(students.id, targetStudentId), eq(students.institutionId, instId)))
        .limit(1)
    )[0];
    if (!st) return res.status(403).json({ error: 'Forbidden: Student outside your institution.' });

    const cleanStatus = ['present', 'absent', 'joined'].includes(String(status)) ? String(status) : 'joined';
    const [saved] = await db
      .insert(liveClassAttendance)
      .values({
        institutionId: instId,
        lessonId,
        studentId: targetStudentId,
        status: cleanStatus,
        joinedAt: new Date(),
      })
      .onConflictDoUpdate({
        target: [liveClassAttendance.lessonId, liveClassAttendance.studentId],
        set: {
          status: cleanStatus,
          joinedAt: new Date(),
        },
      })
      .returning();

    res.status(201).json(saved);
  } catch (err) {
    console.error('Live attendance save error:', err);
    res.status(500).json({ error: 'Failed to record live class attendance' });
  }
});

router.post('/timetable', requireAuth, requireTenant, requireRole('admin'), async (req: AuthRequest, res) => {
  try {
    const instId = req.dbUser!.institutionId!;
    const { classId, dayOfWeek, startTime, endTime, subjectId, teacherId, room } = req.body;
    if (!classId || !dayOfWeek || !startTime || !endTime || !subjectId) {
      return res.status(400).json({ error: 'All timetable fields are required.' });
    }
    const cls = await db
      .select()
      .from(classes)
      .where(and(eq(classes.id, Number(classId)), eq(classes.institutionId, instId)))
      .limit(1);
    if (cls.length === 0) return res.status(403).json({ error: 'Forbidden: Class outside your institution.' });

    const [created] = await db
      .insert(timetable)
      .values({
        institutionId: instId,
        classId: Number(classId),
        dayOfWeek: String(dayOfWeek),
        startTime: String(startTime),
        endTime: String(endTime),
        subjectId: Number(subjectId),
        teacherId: teacherId ? Number(teacherId) : null,
        room: room || null,
      })
      .returning();
    res.status(201).json(created);
  } catch (err) {
    console.error('Create timetable error:', err);
    res.status(500).json({ error: 'Failed to create timetable entry' });
  }
});

// ==================== NOTIFICATIONS, NOTICES, ADMISSIONS, SETTINGS, AUDIT ====================

router.get('/notifications', requireAuth, requireTenant, async (req: AuthRequest, res) => {
  try {
    const user = req.dbUser!;
    const instId = user.institutionId!;
    const rows =
      user.role === 'admin'
        ? await db
            .select()
            .from(notifications)
            .where(eq(notifications.institutionId, instId))
            .orderBy(desc(notifications.createdAt))
            .limit(40)
        : await db
            .select()
            .from(notifications)
            .where(
              and(
                eq(notifications.institutionId, instId),
                or(
                  eq(notifications.targetRole, 'all'),
                  eq(notifications.targetRole, user.role),
                  eq(notifications.targetUserId, user.id)
                )
              )
            )
            .orderBy(desc(notifications.createdAt))
            .limit(40);
    res.json(rows);
  } catch (err) {
    console.error('Notifications fetch error:', err);
    res.status(500).json({ error: 'Failed to load notifications' });
  }
});

router.post('/notifications', requireAuth, requireTenant, requireRole('admin', 'teacher'), async (req: AuthRequest, res) => {
  try {
    const instId = req.dbUser!.institutionId!;
    const { title, message, type, targetRole, targetUserId } = req.body;
    if (!title || !message) {
      return res.status(400).json({ error: 'Title and message are required.' });
    }
    const [created] = await db
      .insert(notifications)
      .values({
        institutionId: instId,
        title: String(title).trim(),
        message: String(message).trim(),
        type: type || 'announcement',
        targetRole: targetRole || 'all',
        targetUserId: targetUserId ? Number(targetUserId) : null,
        createdBy: req.dbUser!.id,
      })
      .returning();
    res.status(201).json(created);
  } catch (err) {
    console.error('Create notification error:', err);
    res.status(500).json({ error: 'Failed to send notification' });
  }
});

router.patch('/notifications/:id/read', requireAuth, requireTenant, async (req: AuthRequest, res) => {
  try {
    const id = Number(req.params.id);
    const instId = req.dbUser!.institutionId!;
    const [updated] = await db
      .update(notifications)
      .set({ isRead: true })
      .where(and(eq(notifications.id, id), eq(notifications.institutionId, instId)))
      .returning();
    if (!updated) return res.status(404).json({ error: 'Notification not found in your institution' });
    res.json(updated);
  } catch (err) {
    console.error('Read notification error:', err);
    res.status(500).json({ error: 'Failed to mark notification read' });
  }
});

router.get('/admissions', requireAuth, requireTenant, requireRole('admin'), async (req: AuthRequest, res) => {
  try {
    const instId = req.dbUser!.institutionId!;
    const rows = await db
      .select()
      .from(admissions)
      .where(eq(admissions.institutionId, instId))
      .orderBy(desc(admissions.submittedAt));
    res.json(rows);
  } catch (err) {
    console.error('Admissions fetch error:', err);
    res.status(500).json({ error: 'Failed to load admissions' });
  }
});

router.patch('/admissions/:id', requireAuth, requireTenant, requireRole('admin'), async (req: AuthRequest, res) => {
  try {
    const id = Number(req.params.id);
    const instId = req.dbUser!.institutionId!;
    const { status } = req.body;
    const [updated] = await db
      .update(admissions)
      .set({ status })
      .where(and(eq(admissions.id, id), eq(admissions.institutionId, instId)))
      .returning();
    if (!updated) return res.status(404).json({ error: 'Admission record not found in your institution' });

    await logAudit({
      institutionId: instId,
      userId: req.dbUser!.id,
      userEmail: req.dbUser!.email,
      action: 'UPDATE_ADMISSION_STATUS',
      entityType: 'admissions',
      entityId: id,
      details: `Set status to ${status}`,
    });
    res.json(updated);
  } catch (err) {
    console.error('Update admission error:', err);
    res.status(500).json({ error: 'Failed to update admission status' });
  }
});

router.get('/notices', requireAuth, requireTenant, async (req: AuthRequest, res) => {
  try {
    const instId = req.dbUser!.institutionId!;
    const rows = await db
      .select()
      .from(notices)
      .where(eq(notices.institutionId, instId))
      .orderBy(desc(notices.isPinned), desc(notices.publishedAt));
    res.json(rows);
  } catch (err) {
    console.error('Notices fetch error:', err);
    res.status(500).json({ error: 'Failed to load notices' });
  }
});

router.post('/notices', requireAuth, requireTenant, requireRole('admin'), async (req: AuthRequest, res) => {
  try {
    const instId = req.dbUser!.institutionId!;
    const { title, content, category, isPinned } = req.body;
    if (!title || !content) return res.status(400).json({ error: 'Title and content are required.' });
    const [created] = await db
      .insert(notices)
      .values({
        institutionId: instId,
        title: String(title).trim(),
        content: String(content).trim(),
        category: category || 'General',
        isPinned: Boolean(isPinned),
        authorId: req.dbUser!.id,
      })
      .returning();
    res.status(201).json(created);
  } catch (err) {
    console.error('Create notice error:', err);
    res.status(500).json({ error: 'Failed to publish notice' });
  }
});

router.delete('/notices/:id', requireAuth, requireTenant, requireRole('admin'), async (req: AuthRequest, res) => {
  try {
    const instId = req.dbUser!.institutionId!;
    const deleted = await db
      .delete(notices)
      .where(and(eq(notices.id, Number(req.params.id)), eq(notices.institutionId, instId)))
      .returning();
    if (deleted.length === 0) return res.status(404).json({ error: 'Notice not found in your institution' });
    res.json({ success: true });
  } catch (err) {
    console.error('Delete notice error:', err);
    res.status(500).json({ error: 'Failed to delete notice' });
  }
});

router.get('/settings', requireAuth, requireTenant, requireRole('admin'), async (req: AuthRequest, res) => {
  try {
    const instId = req.dbUser!.institutionId!;
    const rows = await db.select().from(websiteSettings).where(eq(websiteSettings.institutionId, instId));
    const settings: Record<string, string> = {};
    for (const row of rows) settings[row.key] = row.value;
    res.json(settings);
  } catch (err) {
    console.error('Get settings error:', err);
    res.status(500).json({ error: 'Failed to load settings' });
  }
});

router.put('/settings', requireAuth, requireTenant, requireRole('admin'), async (req: AuthRequest, res) => {
  try {
    const instId = req.dbUser!.institutionId!;
    const entries = Object.entries(req.body || {});
    for (const [key, value] of entries) {
      await db
        .insert(websiteSettings)
        .values({ institutionId: instId, key, value: String(value), updatedAt: new Date() })
        .onConflictDoUpdate({
          target: [websiteSettings.institutionId, websiteSettings.key],
          set: { value: String(value), updatedAt: new Date() },
        });
    }
    await logAudit({
      institutionId: instId,
      userId: req.dbUser!.id,
      userEmail: req.dbUser!.email,
      action: 'UPDATE_WEBSITE_SETTINGS',
      entityType: 'website_settings',
      details: `Updated ${entries.length} setting key(s)`,
    });
    res.json({ success: true });
  } catch (err) {
    console.error('Update settings error:', err);
    res.status(500).json({ error: 'Failed to update website settings' });
  }
});

router.get('/audit-logs', requireAuth, requireTenant, requireRole('admin'), async (req: AuthRequest, res) => {
  try {
    const instId = req.dbUser!.institutionId!;
    const rows = await db
      .select()
      .from(auditLogs)
      .where(eq(auditLogs.institutionId, instId))
      .orderBy(desc(auditLogs.createdAt))
      .limit(50);
    res.json(rows);
  } catch (err) {
    console.error('Audit logs error:', err);
    res.status(500).json({ error: 'Failed to load audit logs' });
  }
});

router.delete('/admin/demo-data', requireAuth, requireTenant, requireRole('admin'), async (req: AuthRequest, res) => {
  try {
    const instId = req.dbUser!.institutionId!;
    await db.delete(students).where(and(eq(students.isDemo, true), eq(students.institutionId, instId)));
    await db
      .delete(users)
      .where(and(eq(users.isDemo, true), eq(users.institutionId, instId), sql`${users.id} != ${req.dbUser!.id}`));
    await logAudit({
      institutionId: instId,
      userId: req.dbUser!.id,
      userEmail: req.dbUser!.email,
      action: 'PURGE_DEMO_DATA',
      entityType: 'system',
      details: 'Cleared sample demonstration records for this institution while retaining production data.',
    });
    res.json({ success: true });
  } catch (err) {
    console.error('Purge demo error:', err);
    res.status(500).json({ error: 'Failed to clear demo data' });
  }
});

// ==================== TEACHER-PARENT MESSAGES, DAILY REPORT & NOTIFICATION PREFERENCES ====================

router.get('/messages', requireAuth, requireTenant, async (req: AuthRequest, res) => {
  try {
    const user = req.dbUser!;
    const instId = user.institutionId!;
    const scopedIds = await getScopedStudentIds(req);
    const studentIdFilter = req.query.studentId ? Number(req.query.studentId) : null;

    if (studentIdFilter && scopedIds !== null && !scopedIds.includes(studentIdFilter)) {
      return res.status(403).json({ error: 'Forbidden: Unauthorized access to student conversation.' });
    }
    if (scopedIds !== null && scopedIds.length === 0) {
      return res.json([]);
    }

    const conditions: any[] = [eq(teacherMessages.institutionId, instId)];
    if (studentIdFilter) {
      conditions.push(eq(teacherMessages.studentId, studentIdFilter));
    } else if (scopedIds !== null) {
      conditions.push(inArray(teacherMessages.studentId, scopedIds));
    }

    const msgRows = await db
      .select()
      .from(teacherMessages)
      .where(and(...conditions))
      .orderBy(desc(teacherMessages.createdAt))
      .limit(100);

    const instUsers = await db
      .select({ id: users.id, name: users.name, role: users.role })
      .from(users)
      .where(eq(users.institutionId, instId));
    const userMap = new Map(instUsers.map((u) => [u.id, u]));

    const instStudents = await db
      .select({ id: students.id, fullName: students.fullName, admissionNo: students.admissionNo })
      .from(students)
      .where(eq(students.institutionId, instId));
    const stMap = new Map(instStudents.map((s) => [s.id, s]));

    res.json(
      msgRows.map((m) => ({
        ...m,
        senderName: userMap.get(m.senderId)?.name || 'Staff',
        recipientName: m.recipientId ? userMap.get(m.recipientId)?.name || null : null,
        studentName: stMap.get(m.studentId)?.fullName || 'Student',
      }))
    );
  } catch (err) {
    console.error('Messages fetch error:', err);
    res.status(500).json({ error: 'Failed to load messages' });
  }
});

router.post('/messages', requireAuth, requireTenant, requireRole('admin', 'teacher', 'parent'), async (req: AuthRequest, res) => {
  try {
    const user = req.dbUser!;
    const instId = user.institutionId!;
    const { studentId, message, recipientId } = req.body;
    if (!studentId || !message || !String(message).trim()) {
      return res.status(400).json({ error: 'Student and non-empty message are required.' });
    }

    const st = (
      await db
        .select()
        .from(students)
        .where(and(eq(students.id, Number(studentId)), eq(students.institutionId, instId)))
        .limit(1)
    )[0];
    if (!st) return res.status(403).json({ error: 'Forbidden: Student does not belong to your institution.' });

    const scopedIds = await getScopedStudentIds(req);
    if (scopedIds !== null && !scopedIds.includes(st.id)) {
      return res.status(403).json({ error: 'Forbidden: You are not authorized to message for this student.' });
    }

    let resolvedRecipientId: number | null = recipientId ? Number(recipientId) : null;
    if (!resolvedRecipientId) {
      if (user.role === 'parent' && st.classId) {
        const cls = (await db.select().from(classes).where(eq(classes.id, st.classId)).limit(1))[0];
        resolvedRecipientId = cls?.teacherId || null;
      } else if ((user.role === 'teacher' || user.role === 'admin') && st.parentId) {
        resolvedRecipientId = st.parentId;
      }
    }

    const [created] = await db
      .insert(teacherMessages)
      .values({
        institutionId: instId,
        studentId: st.id,
        senderId: user.id,
        recipientId: resolvedRecipientId,
        senderRole: user.role,
        message: String(message).trim(),
        isRead: false,
      })
      .returning();

    if (resolvedRecipientId) {
      const allowMsg = await shouldNotifyPreference(instId, resolvedRecipientId, 'teacherMessages');
      if (allowMsg) {
        await db.insert(notifications).values({
          institutionId: instId,
          title: `New Message (${st.fullName})`,
          message: `${user.name}: ${String(message).trim().slice(0, 120)}`,
          type: 'message',
          targetRole: user.role === 'parent' ? 'teacher' : 'parent',
          targetUserId: resolvedRecipientId,
          createdBy: user.id,
        });
      }
    }

    res.status(201).json({ ...created, senderName: user.name, studentName: st.fullName });
  } catch (err) {
    console.error('Send message error:', err);
    res.status(500).json({ error: 'Failed to send message' });
  }
});

router.get('/daily-report', requireAuth, requireTenant, async (req: AuthRequest, res) => {
  try {
    const user = req.dbUser!;
    const instId = user.institutionId!;
    const studentId = Number(req.query.studentId);
    const baseDate = req.query.date ? String(req.query.date) : new Date().toISOString().slice(0, 10);
    const range = req.query.range === 'weekly' || req.query.range === 'monthly' ? String(req.query.range) : 'daily';

    const scopedIds = await getScopedStudentIds(req);
    const targetStudentId = studentId || scopedIds?.[0];
    if (!targetStudentId) {
      return res.status(400).json({ error: 'Student ID is required.' });
    }
    if (scopedIds !== null && !scopedIds.includes(targetStudentId)) {
      return res.status(403).json({ error: 'Forbidden: Unauthorized access to student report.' });
    }

    const st = (
      await db
        .select()
        .from(students)
        .where(and(eq(students.id, targetStudentId), eq(students.institutionId, instId)))
        .limit(1)
    )[0];
    if (!st) return res.status(404).json({ error: 'Student not found in your institution.' });

    const endMs = new Date(`${baseDate}T00:00:00Z`).getTime();
    const daysBack = range === 'monthly' ? 29 : range === 'weekly' ? 6 : 0;
    const startDate = new Date(endMs - daysBack * 86400000).toISOString().slice(0, 10);

    const policy = await getInstitutionPolicy(instId);
    const canSeeMedical = user.role === 'admin' || user.role === 'parent' || st.parentalConsent;
    const canSeePrayer = policy.prayerTrackingEnabled && (user.role !== 'parent' || policy.prayerShowToParents);

    const [attRows, namazRows, activityRows, healthRows, classSyllabus, hwRows, assignRows, markRows, msgRows] =
      await Promise.all([
        db
          .select()
          .from(attendance)
          .where(and(eq(attendance.institutionId, instId), eq(attendance.studentId, st.id)))
          .orderBy(desc(attendance.date)),
        canSeePrayer
          ? db
              .select()
              .from(namazRecords)
              .where(and(eq(namazRecords.institutionId, instId), eq(namazRecords.studentId, st.id)))
              .orderBy(desc(namazRecords.date))
          : Promise.resolve([]),
        db
          .select()
          .from(dailyActivities)
          .where(and(eq(dailyActivities.institutionId, instId), eq(dailyActivities.studentId, st.id)))
          .orderBy(desc(dailyActivities.date)),
        canSeeMedical
          ? db
              .select()
              .from(healthRecords)
              .where(and(eq(healthRecords.institutionId, instId), eq(healthRecords.studentId, st.id)))
              .orderBy(desc(healthRecords.recordDate))
          : Promise.resolve([]),
        st.classId
          ? db.select().from(syllabusTopics).where(and(eq(syllabusTopics.institutionId, instId), eq(syllabusTopics.classId, st.classId)))
          : Promise.resolve([]),
        st.classId
          ? db.select().from(homework).where(and(eq(homework.institutionId, instId), eq(homework.classId, st.classId)))
          : Promise.resolve([]),
        db.select().from(assignments).where(and(eq(assignments.institutionId, instId), eq(assignments.studentId, st.id))),
        db.select().from(marks).where(and(eq(marks.institutionId, instId), eq(marks.studentId, st.id))),
        db
          .select()
          .from(teacherMessages)
          .where(and(eq(teacherMessages.institutionId, instId), eq(teacherMessages.studentId, st.id)))
          .orderBy(desc(teacherMessages.createdAt))
          .limit(10),
      ]);

    const inRange = (d: string) => d >= startDate && d <= baseDate;
    const rangeAtt = attRows.filter((a) => inRange(a.date));
    const rangeNamaz = namazRows.filter((n) => inRange(n.date));
    const rangeActivities = activityRows.filter((a) => inRange(a.date));
    const rangeHealth = healthRows.filter((h) => inRange(h.recordDate));

    res.json({
      student: canSeeMedical ? st : { ...st, medicalNotes: null, allergies: null },
      range,
      startDate,
      endDate: baseDate,
      attendance: rangeAtt,
      namaz: rangeNamaz,
      activities: rangeActivities,
      health: rangeHealth,
      syllabus: classSyllabus,
      homework: hwRows.map((h) => ({ ...h, assignment: assignRows.find((a) => a.homeworkId === h.id) || null })),
      marks: markRows,
      recentMessages: msgRows,
      policy: {
        prayerTrackingEnabled: policy.prayerTrackingEnabled,
        prayerShowToParents: policy.prayerShowToParents,
        prayerPolicyNote: policy.prayerPolicyNote,
      },
    });
  } catch (err) {
    console.error('Daily report error:', err);
    res.status(500).json({ error: 'Failed to compile student report' });
  }
});

router.get('/notification-preferences', requireAuth, requireTenant, async (req: AuthRequest, res) => {
  try {
    const user = req.dbUser!;
    const instId = user.institutionId!;
    let rows = await db
      .select()
      .from(notificationPreferences)
      .where(and(eq(notificationPreferences.institutionId, instId), eq(notificationPreferences.userId, user.id)))
      .limit(1);
    if (rows.length === 0) {
      const [created] = await db
        .insert(notificationPreferences)
        .values({
          institutionId: instId,
          userId: user.id,
          deliveryStatus: 'in_app_only',
        })
        .returning();
      rows = [created];
    }
    res.json(rows[0]);
  } catch (err) {
    console.error('Notification pref fetch error:', err);
    res.status(500).json({ error: 'Failed to load notification preferences' });
  }
});

router.put('/notification-preferences', requireAuth, requireTenant, async (req: AuthRequest, res) => {
  try {
    const user = req.dbUser!;
    const instId = user.institutionId!;
    const {
      absentAlerts,
      attendanceUpdates,
      homeworkAlerts,
      examAlerts,
      liveClassAlerts,
      prayerUpdates,
      foodUpdates,
      healthAlerts,
      teacherMessages: teacherMessagesPref,
      fcmConsentGranted,
      fcmToken,
      deliveryStatus,
    } = req.body;

    const existing = await db
      .select()
      .from(notificationPreferences)
      .where(and(eq(notificationPreferences.institutionId, instId), eq(notificationPreferences.userId, user.id)))
      .limit(1);

    const payload = {
      ...(absentAlerts !== undefined ? { absentAlerts: Boolean(absentAlerts) } : {}),
      ...(attendanceUpdates !== undefined ? { attendanceUpdates: Boolean(attendanceUpdates) } : {}),
      ...(homeworkAlerts !== undefined ? { homeworkAlerts: Boolean(homeworkAlerts) } : {}),
      ...(examAlerts !== undefined ? { examAlerts: Boolean(examAlerts) } : {}),
      ...(liveClassAlerts !== undefined ? { liveClassAlerts: Boolean(liveClassAlerts) } : {}),
      ...(prayerUpdates !== undefined ? { prayerUpdates: Boolean(prayerUpdates) } : {}),
      ...(foodUpdates !== undefined ? { foodUpdates: Boolean(foodUpdates) } : {}),
      ...(healthAlerts !== undefined ? { healthAlerts: Boolean(healthAlerts) } : {}),
      ...(teacherMessagesPref !== undefined ? { teacherMessages: Boolean(teacherMessagesPref) } : {}),
      ...(fcmConsentGranted !== undefined ? { fcmConsentGranted: Boolean(fcmConsentGranted) } : {}),
      ...(fcmToken !== undefined ? { fcmToken: fcmToken ? String(fcmToken) : null } : {}),
      ...(deliveryStatus !== undefined ? { deliveryStatus: String(deliveryStatus) } : {}),
      updatedAt: new Date(),
    };

    if (existing.length === 0) {
      const [created] = await db
        .insert(notificationPreferences)
        .values({ institutionId: instId, userId: user.id, ...payload })
        .returning();
      return res.json(created);
    }

    const [updated] = await db
      .update(notificationPreferences)
      .set(payload)
      .where(and(eq(notificationPreferences.institutionId, instId), eq(notificationPreferences.userId, user.id)))
      .returning();

    res.json(updated);
  } catch (err) {
    console.error('Notification pref save error:', err);
    res.status(500).json({ error: 'Failed to update notification preferences' });
  }
});

// ==================== INSTITUTION SUBSCRIPTION (₹399/MONTH PLAN) ====================

router.get('/institution/subscription', requireAuth, requireTenant, requireRole('admin'), async (req: AuthRequest, res) => {
  try {
    const instId = req.dbUser!.institutionId!;
    const [instRows, paymentRows] = await Promise.all([
      db
        .select({
          id: institutions.id,
          name: institutions.name,
          code: institutions.code,
          subscriptionPlan: institutions.subscriptionPlan,
          subscriptionAmount: institutions.subscriptionAmount,
          subscriptionStatus: institutions.subscriptionStatus,
          subscriptionExpiresAt: institutions.subscriptionExpiresAt,
          lastPaymentRef: institutions.lastPaymentRef,
        })
        .from(institutions)
        .where(eq(institutions.id, instId))
        .limit(1),
      db
        .select()
        .from(institutionSubscriptions)
        .where(eq(institutionSubscriptions.institutionId, instId))
        .orderBy(desc(institutionSubscriptions.createdAt))
        .limit(50),
    ]);

    if (instRows.length === 0) {
      return res.status(404).json({ error: 'Institution not found' });
    }

    res.json({
      plan: MAKTAB_SUBSCRIPTION_PLAN,
      institution: instRows[0],
      payments: paymentRows,
    });
  } catch (err) {
    console.error('Institution subscription fetch error:', err);
    res.status(500).json({ error: 'Failed to load subscription details' });
  }
});

router.post('/institution/subscription/pay', requireAuth, requireTenant, requireRole('admin'), async (req: AuthRequest, res) => {
  try {
    const user = req.dbUser!;
    const instId = user.institutionId!;
    const { paymentMethod, transactionRef } = req.body || {};

    const rawRef = transactionRef ? String(transactionRef).trim() : '';
    const paymentRef = rawRef.length >= 4 ? rawRef : `WA-${Date.now().toString().slice(-6)}`;

    const instRows = await db.select().from(institutions).where(eq(institutions.id, instId)).limit(1);
    if (instRows.length === 0) {
      return res.status(404).json({ error: 'Institution not found' });
    }
    const inst = instRows[0];

    const now = new Date();
    const cleanMethod = ['upi', 'card', 'netbanking'].includes(String(paymentMethod))
      ? String(paymentMethod)
      : 'upi';
    const nextInstSubStatus = inst.subscriptionStatus === 'active' ? 'active' : 'pending_approval';

    // Security: Always enforce server-side ₹399 price regardless of client payload
    const [updatedInst] = await db
      .update(institutions)
      .set({
        subscriptionPlan: MAKTAB_SUBSCRIPTION_PLAN.code,
        subscriptionAmount: MAKTAB_SUBSCRIPTION_PLAN.priceInr,
        subscriptionStatus: nextInstSubStatus,
        lastPaymentRef: paymentRef,
      })
      .where(eq(institutions.id, instId))
      .returning({
        id: institutions.id,
        name: institutions.name,
        code: institutions.code,
        subscriptionPlan: institutions.subscriptionPlan,
        subscriptionAmount: institutions.subscriptionAmount,
        subscriptionStatus: institutions.subscriptionStatus,
        subscriptionExpiresAt: institutions.subscriptionExpiresAt,
        lastPaymentRef: institutions.lastPaymentRef,
      });

    const [receipt] = await db
      .insert(institutionSubscriptions)
      .values({
        institutionId: instId,
        planCode: MAKTAB_SUBSCRIPTION_PLAN.code,
        planName: MAKTAB_SUBSCRIPTION_PLAN.name,
        amount: MAKTAB_SUBSCRIPTION_PLAN.priceInr,
        currency: MAKTAB_SUBSCRIPTION_PLAN.currency,
        billingCycle: MAKTAB_SUBSCRIPTION_PLAN.billingCycle,
        paymentMethod: cleanMethod,
        transactionRef: paymentRef,
        status: 'pending_approval',
        periodStart: now,
        periodEnd: now,
        paidByEmail: user.email,
      })
      .returning();

    await db.insert(notifications).values({
      institutionId: instId,
      title: `Subscription Payment Submitted (Ref: ${paymentRef})`,
      message: `₹${MAKTAB_SUBSCRIPTION_PLAN.priceInr} payment submitted via ${cleanMethod.toUpperCase()} (Ref: ${paymentRef}). Awaiting Super Admin approval.`,
      type: 'fee',
      targetRole: 'admin',
      createdBy: user.id,
    });

    await logAudit({
      institutionId: instId,
      userId: user.id,
      userEmail: user.email,
      action: 'SUBMIT_MAKTAB_SUBSCRIPTION_PAYMENT',
      entityType: 'institution_subscriptions',
      entityId: receipt.id,
      details: `Submitted ₹${MAKTAB_SUBSCRIPTION_PLAN.priceInr} (${cleanMethod.toUpperCase()}) Ref ${paymentRef} for ${inst.name}. Pending Super Admin approval.`,
      ipAddress: req.ip,
    });

    res.status(201).json({
      plan: MAKTAB_SUBSCRIPTION_PLAN,
      institution: updatedInst,
      receipt,
    });
  } catch (err) {
    console.error('Institution subscription payment error:', err);
    res.status(500).json({ error: 'Failed to submit ₹399 Maktab subscription payment' });
  }
});

export default router;
