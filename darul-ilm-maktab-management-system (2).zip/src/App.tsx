import React, { useEffect, useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext.tsx';
import { PublicWebsite } from './components/PublicWebsite.tsx';
import { LoginView } from './components/LoginView.tsx';
import { PortalLayout } from './components/PortalLayout.tsx';

const RootRouter: React.FC = () => {
  const { user, loading } = useAuth();
  const [view, setView] = useState<'public' | 'login' | 'portal'>('public');

  // Automatically redirect authenticated users to their authorized portal dashboard
  useEffect(() => {
    if (user && view === 'login') {
      setView('portal');
    } else if (!user && view === 'portal') {
      setView('public');
    }
  }, [user, view]);

  if (loading) {
    return (
      <div className="min-h-screen bg-[#FAFBF9] flex items-center justify-center">
        <div className="text-sm font-medium text-emerald-900">Loading Kabeer Sb Maktab...</div>
      </div>
    );
  }

  if (view === 'portal' && user) {
    return <PortalLayout onGoPublic={() => setView('public')} />;
  }

  if (view === 'login' && !user) {
    return <LoginView onBack={() => setView('public')} onSuccess={() => setView('portal')} />;
  }

  return (
    <PublicWebsite
      onOpenLogin={() => setView(user ? 'portal' : 'login')}
      onOpenPortal={() => setView('portal')}
    />
  );
};

export default function App() {
  return (
    <AuthProvider>
      <RootRouter />
    </AuthProvider>
  );
}
