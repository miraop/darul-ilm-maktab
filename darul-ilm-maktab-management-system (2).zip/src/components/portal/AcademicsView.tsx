import React, { useEffect, useState } from 'react';
import {
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { Award, CheckCircle2, FileText, Plus, Trash2 } from 'lucide-react';
import { useAuth } from '../../context/AuthContext.tsx';
import { t } from '../../i18n/translations.ts';
import { exportToPdf } from '../../utils/exports.ts';

interface QuizQuestionDraft {
  id: string;
  type: 'mcq' | 'true_false' | 'short_answer' | 'long_answer';
  question: string;
  options: string[];
  correctIndex: number;
  marks: number;
}

export const AcademicsView: React.FC = () => {
  const { user, lang, apiFetch } = useAuth();
  const [tab, setTab] = useState<'homework' | 'exams' | 'quiz'>('homework');
  const [classes, setClasses] = useState<any[]>([]);
  const [subjects, setSubjects] = useState<any[]>([]);
  const [students, setStudents] = useState<any[]>([]);
  const [homeworkList, setHomeworkList] = useState<any[]>([]);
  const [assignments, setAssignments] = useState<any[]>([]);
  const [exams, setExams] = useState<any[]>([]);
  const [marks, setMarks] = useState<any[]>([]);
  const [attempts, setAttempts] = useState<any[]>([]);
  const [attendanceRows, setAttendanceRows] = useState<any[]>([]);
  const [feedback, setFeedback] = useState<string | null>(null);

  const isStudent = user?.role === 'student';
  const canEdit = user?.role === 'admin' || user?.role === 'teacher';

  // Forms
  const [hwForm, setHwForm] = useState({ title: '', description: '', classId: '', subjectId: '', dueDate: '' });
  const [subText, setSubText] = useState<Record<number, string>>({});
  const [markForm, setMarkForm] = useState({ examId: '', studentId: '', obtainedMarks: '', totalMarks: '100', remarks: '' });
  const [examForm, setExamForm] = useState({
    title: '',
    examType: 'unit',
    classId: '',
    subjectId: '',
    examDate: '',
    startDate: '',
    endDate: '',
    totalMarks: 100,
    passingMarks: 40,
    durationMinutes: 60,
  });

  // Online Test Builder state
  const [showQuizBuilder, setShowQuizBuilder] = useState(false);
  const [quizDraft, setQuizDraft] = useState({
    title: '',
    classId: '',
    subjectId: '',
    examDate: new Date().toISOString().slice(0, 10),
    startDate: new Date().toISOString().slice(0, 10),
    endDate: '',
    passingMarks: 4,
    durationMinutes: 25,
  });
  const [draftQuestions, setDraftQuestions] = useState<QuizQuestionDraft[]>([
    {
      id: `q-${Date.now()}`,
      type: 'mcq',
      question: '',
      options: ['Option A', 'Option B', 'Option C', 'Option D'],
      correctIndex: 0,
      marks: 5,
    },
  ]);

  // Active Quiz Runner state
  const [activeQuiz, setActiveQuiz] = useState<any | null>(null);
  const [quizAnswers, setQuizAnswers] = useState<Record<string, any>>({});
  const [quizResult, setQuizResult] = useState<any | null>(null);

  // Teacher Evaluation State
  const [evaluatingAttempt, setEvaluatingAttempt] = useState<any | null>(null);
  const [evalScores, setEvalScores] = useState<Record<string, number>>({});
  const [evalRemarks, setEvalRemarks] = useState('');

  const loadAll = async () => {
    const [cl, sb, st, hwData, exData, att] = await Promise.all([
      apiFetch('/api/classes'),
      apiFetch('/api/subjects'),
      apiFetch('/api/students'),
      apiFetch('/api/homework'),
      apiFetch('/api/exams'),
      apiFetch('/api/attendance'),
    ]);
    setClasses(cl || []);
    setSubjects(sb || []);
    setStudents(st || []);
    setHomeworkList(hwData.homework || []);
    setAssignments(hwData.assignments || []);
    setExams(exData.exams || []);
    setMarks(exData.marks || []);
    setAttempts(exData.attempts || []);
    setAttendanceRows(att || []);

    if ((cl || []).length > 0 && !hwForm.classId) {
      setHwForm((p) => ({ ...p, classId: String(cl[0].id) }));
      setExamForm((p) => ({ ...p, classId: String(cl[0].id) }));
      setQuizDraft((p) => ({ ...p, classId: String(cl[0].id) }));
    }
    if ((sb || []).length > 0 && !hwForm.subjectId) {
      setHwForm((p) => ({ ...p, subjectId: String(sb[0].id) }));
      setExamForm((p) => ({ ...p, subjectId: String(sb[0].id) }));
      setQuizDraft((p) => ({ ...p, subjectId: String(sb[0].id) }));
    }
    if ((exData.exams || []).length > 0 && !markForm.examId) {
      setMarkForm((p) => ({ ...p, examId: String(exData.exams[0].id), totalMarks: String(exData.exams[0].totalMarks) }));
    }
    if ((st || []).length > 0 && !markForm.studentId) {
      setMarkForm((p) => ({ ...p, studentId: String(st[0].id) }));
    }
  };

  useEffect(() => {
    loadAll();
  }, []);

  const classMap = new Map(classes.map((c) => [c.id, c.name]));
  const subjectMap = new Map(subjects.map((s) => [s.id, s.name]));
  const studentMap = new Map(students.map((s) => [s.id, s]));
  const examMap = new Map(exams.map((e) => [e.id, e]));

  const handleCreateHomework = async (e: React.FormEvent) => {
    e.preventDefault();
    const created = await apiFetch('/api/homework', { method: 'POST', body: JSON.stringify(hwForm) });
    setHomeworkList((prev) => [created, ...prev]);
    setHwForm({ ...hwForm, title: '', description: '' });
    setFeedback('Homework assigned and students notified.');
  };

  const handleSubmitHw = async (hwId: number) => {
    const saved = await apiFetch(`/api/homework/${hwId}/submit`, {
      method: 'POST',
      body: JSON.stringify({ submissionText: subText[hwId] || 'Completed assignment' }),
    });
    setAssignments((prev) => [saved, ...prev.filter((a) => a.id !== saved.id)]);
    setFeedback('Homework submitted to Ustad.');
  };

  const handleGradeAssignment = async (assignId: number, score: number) => {
    const updated = await apiFetch(`/api/assignments/${assignId}/grade`, {
      method: 'PATCH',
      body: JSON.stringify({ score, feedback: 'Reviewed and graded' }),
    });
    setAssignments((prev) => prev.map((a) => (a.id === assignId ? updated : a)));
  };

  const handleCreateExam = async (e: React.FormEvent) => {
    e.preventDefault();
    const created = await apiFetch('/api/exams', { method: 'POST', body: JSON.stringify(examForm) });
    setExams((prev) => [created, ...prev]);
    setExamForm({ ...examForm, title: '' });
    setFeedback('Examination scheduled.');
  };

  const handleCreateOnlineTest = async (e: React.FormEvent) => {
    e.preventDefault();
    const totalMarks = draftQuestions.reduce((acc, q) => acc + (Number(q.marks) || 5), 0);
    const cleanedQuestions = draftQuestions.map((q) => {
      if (q.type === 'true_false') {
        return { ...q, options: ['True', 'False'], correctIndex: q.correctIndex === 1 ? 1 : 0 };
      }
      if (q.type === 'short_answer' || q.type === 'long_answer') {
        return { id: q.id, type: q.type, question: q.question, marks: Number(q.marks) || 5 };
      }
      return { ...q, marks: Number(q.marks) || 5 };
    });

    const created = await apiFetch('/api/exams', {
      method: 'POST',
      body: JSON.stringify({
        ...quizDraft,
        examType: 'online_test',
        totalMarks,
        passingMarks: Number(quizDraft.passingMarks) || Math.round(totalMarks * 0.4),
        isOnline: true,
        questionsJson: cleanedQuestions,
      }),
    });
    setExams((prev) => [created, ...prev]);
    setShowQuizBuilder(false);
    setQuizDraft((p) => ({ ...p, title: '' }));
    setFeedback('Online test published cleanly to students.');
  };

  const handleSaveMarks = async (e: React.FormEvent) => {
    e.preventDefault();
    const saved = await apiFetch('/api/marks', { method: 'POST', body: JSON.stringify(markForm) });
    setMarks((prev) => [saved, ...prev.filter((m) => !(m.examId === saved.examId && m.studentId === saved.studentId))]);
    setFeedback('Examination marks saved.');
  };

  const handleSubmitQuiz = async () => {
    if (!activeQuiz) return;
    try {
      const res = await apiFetch(`/api/exams/${activeQuiz.id}/submit-quiz`, {
        method: 'POST',
        body: JSON.stringify({ answers: quizAnswers }),
      });
      setQuizResult(res);
      if (res.attempt) {
        setAttempts((prev) => [res.attempt, ...prev]);
      }
      if (res.mark) {
        setMarks((prev) => [res.mark, ...prev.filter((m) => !(m.examId === res.mark.examId && m.studentId === res.mark.studentId))]);
      }
      setFeedback(
        res.attempt?.status === 'submitted_pending_review'
          ? 'Submitted! Objective items auto-graded; subjective items queued for teacher review.'
          : 'Online test evaluated and saved!'
      );
    } catch (err: any) {
      setFeedback(err.message);
    }
  };

  const handleEvaluateAttempt = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!evaluatingAttempt) return;
    const res = await apiFetch(`/api/test-attempts/${evaluatingAttempt.id}/evaluate`, {
      method: 'PATCH',
      body: JSON.stringify({
        questionScores: evalScores,
        teacherRemarks: evalRemarks,
      }),
    });
    setAttempts((prev) => prev.map((a) => (a.id === evaluatingAttempt.id ? res.attempt : a)));
    if (res.mark) {
      setMarks((prev) => [res.mark, ...prev.filter((m) => !(m.examId === res.mark.examId && m.studentId === res.mark.studentId))]);
    }
    setEvaluatingAttempt(null);
    setFeedback('Test evaluation published cleanly to student & parent.');
  };

  const handleDownloadReportCard = () => {
    const rows = marks.map((m) => {
      const ex = examMap.get(m.examId);
      const passMark = ex?.passingMarks ?? Math.round((m.totalMarks || 100) * 0.4);
      const resultStatus = m.obtainedMarks >= passMark ? 'Pass' : 'Needs Review';
      return [
        studentMap.get(m.studentId)?.fullName || `Student #${m.studentId}`,
        ex?.title || `Exam #${m.examId}`,
        `${m.obtainedMarks}/${m.totalMarks}`,
        `${Math.round((m.obtainedMarks / (m.totalMarks || 1)) * 100)}%`,
        `${m.grade} (${resultStatus})`,
        m.remarks || '',
      ];
    });
    exportToPdf({
      title: 'Academic Examination Report Card',
      subtitle: `Generated for ${user?.name}`,
      headers: ['Student', 'Examination', 'Marks', 'Percentage', 'Grade & Status', 'Remarks'],
      rows,
      filename: 'maktab-report-card',
    });
  };

  const performanceChartData = marks.map((m) => ({
    name: (examMap.get(m.examId)?.title || `Exam ${m.examId}`).slice(0, 18),
    percentage: Math.round((m.obtainedMarks / (m.totalMarks || 1)) * 100),
    student: studentMap.get(m.studentId)?.fullName || '',
  }));

  // Attendance vs Academic comparison by student (or personal subject/exam benchmark for single student)
  const attendanceVsScore = students.slice(0, 10).map((st) => {
    const stAtt = attendanceRows.filter((a) => a.studentId === st.id);
    const presentCnt = stAtt.filter((a) => a.status === 'present' || a.status === 'late').length;
    const attPct = stAtt.length > 0 ? Math.round((presentCnt / stAtt.length) * 100) : 0;

    const stMarks = marks.filter((m) => m.studentId === st.id);
    const scorePct =
      stMarks.length > 0
        ? Math.round(
            stMarks.reduce((acc, m) => acc + (m.totalMarks > 0 ? (m.obtainedMarks / m.totalMarks) * 100 : 0), 0) /
              stMarks.length
          )
        : 0;
    return {
      student: st.fullName.split(' ')[0],
      attendancePct: attPct,
      scorePct,
    };
  });

  const personalScoreProgression = marks.map((m) => {
    const ex = examMap.get(m.examId);
    const pct = m.totalMarks > 0 ? Math.round((m.obtainedMarks / m.totalMarks) * 100) : 0;
    const passMark = ex?.passingMarks ?? Math.round((m.totalMarks || 100) * 0.4);
    const passPct = m.totalMarks > 0 ? Math.round((passMark / m.totalMarks) * 100) : 40;
    return {
      exam: (ex?.title || `Exam ${m.examId}`).slice(0, 16),
      scorePct: pct,
      passPct,
    };
  });

  const onlineQuizzes = exams.filter((e) => e.isOnline && (e.questionsJson || []).length > 0);
  const pendingReviews = attempts.filter((a) => a.status === 'submitted_pending_review');

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-1 p-1 bg-white border border-emerald-900/10 rounded-xl">
          <button
            type="button"
            onClick={() => setTab('homework')}
            className={`px-4 py-2 text-xs font-semibold rounded-lg cursor-pointer whitespace-nowrap ${
              tab === 'homework' ? 'bg-emerald-800 text-white' : 'text-slate-600'
            }`}
          >
            Homework & Assignments
          </button>
          <button
            type="button"
            onClick={() => setTab('exams')}
            className={`px-4 py-2 text-xs font-semibold rounded-lg cursor-pointer whitespace-nowrap ${
              tab === 'exams' ? 'bg-emerald-800 text-white' : 'text-slate-600'
            }`}
          >
            Exams, Marks & Report Cards
          </button>
          <button
            type="button"
            onClick={() => setTab('quiz')}
            className={`px-4 py-2 text-xs font-semibold rounded-lg cursor-pointer whitespace-nowrap ${
              tab === 'quiz' ? 'bg-emerald-800 text-white' : 'text-slate-600'
            }`}
          >
            Online Tests & Quizzes ({onlineQuizzes.length})
          </button>
        </div>

        <button
          type="button"
          onClick={handleDownloadReportCard}
          className="px-4 py-2 text-xs font-semibold rounded-xl border border-emerald-800 text-emerald-900 hover:bg-emerald-50 inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
        >
          <FileText className="h-3.5 w-3.5" />
          <span>Download Report Card PDF</span>
        </button>
      </div>

      {feedback && (
        <div className="rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-2.5 text-xs text-emerald-900">
          {feedback}
        </div>
      )}

      {tab === 'homework' && (
        <div className="space-y-6">
          {canEdit && (
            <form onSubmit={handleCreateHomework} className="bg-white border border-emerald-900/10 rounded-2xl p-6 space-y-3">
              <h2 className="font-display text-lg font-bold text-slate-950">Assign New Homework</h2>
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
                <input
                  type="text"
                  required
                  placeholder="Homework Title *"
                  value={hwForm.title}
                  onChange={(e) => setHwForm({ ...hwForm, title: e.target.value })}
                  className="sm:col-span-2 rounded-xl border border-slate-200 px-3 py-2"
                />
                <select
                  value={hwForm.classId}
                  onChange={(e) => setHwForm({ ...hwForm, classId: e.target.value })}
                  className="rounded-xl border border-slate-200 px-3 py-2 bg-white"
                >
                  {classes.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
                <select
                  value={hwForm.subjectId}
                  onChange={(e) => setHwForm({ ...hwForm, subjectId: e.target.value })}
                  className="rounded-xl border border-slate-200 px-3 py-2 bg-white"
                >
                  {subjects.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
                </select>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
                <input
                  type="text"
                  required
                  placeholder="Instructions & exercises..."
                  value={hwForm.description}
                  onChange={(e) => setHwForm({ ...hwForm, description: e.target.value })}
                  className="sm:col-span-3 rounded-xl border border-slate-200 px-3 py-2"
                />
                <input
                  type="date"
                  required
                  value={hwForm.dueDate}
                  onChange={(e) => setHwForm({ ...hwForm, dueDate: e.target.value })}
                  className="rounded-xl border border-slate-200 px-3 py-2"
                />
              </div>
              <button type="submit" className="px-4 py-2 text-xs font-semibold rounded-xl bg-emerald-800 text-white cursor-pointer">
                Publish Homework
              </button>
            </form>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {homeworkList.map((hw) => {
              const mySub = assignments.find((a) => a.homeworkId === hw.id);
              return (
                <div key={hw.id} className="bg-white border border-emerald-900/10 rounded-2xl p-5 space-y-3">
                  <div className="flex items-center justify-between text-xs text-slate-500">
                    <span>{classMap.get(hw.classId)} · {subjectMap.get(hw.subjectId)}</span>
                    <span className="font-mono-num font-semibold text-amber-700">Due: {hw.dueDate}</span>
                  </div>
                  <h3 className="font-semibold text-slate-950">{hw.title}</h3>
                  <p className="text-xs text-slate-600 leading-relaxed">{hw.description}</p>

                  {mySub && (
                    <div className="p-3 rounded-xl bg-emerald-50/50 border border-emerald-200/70 text-xs">
                      <div className="font-semibold text-emerald-900">
                        Status: {mySub.status.toUpperCase()} {mySub.score !== null && mySub.score !== undefined ? `· Score: ${mySub.score}/100` : ''}
                      </div>
                      <div className="text-slate-700 mt-1">{mySub.submissionText}</div>
                      {canEdit && mySub.status === 'submitted' && (
                        <button
                          type="button"
                          onClick={() => handleGradeAssignment(mySub.id, 95)}
                          className="mt-2 px-3 py-1 rounded-lg bg-emerald-800 text-white text-[11px] font-semibold cursor-pointer"
                        >
                          Mark Graded (95/100)
                        </button>
                      )}
                    </div>
                  )}

                  {(user?.role === 'student' || user?.role === 'parent') && (
                    <div className="flex gap-2 pt-1">
                      <input
                        type="text"
                        placeholder="Write submission note or link..."
                        value={subText[hw.id] || ''}
                        onChange={(e) => setSubText({ ...subText, [hw.id]: e.target.value })}
                        className="flex-1 rounded-xl border border-slate-200 px-3 py-1.5 text-xs"
                      />
                      <button
                        type="button"
                        onClick={() => handleSubmitHw(hw.id)}
                        className="px-3.5 py-1.5 rounded-xl bg-emerald-800 text-white text-xs font-semibold cursor-pointer"
                      >
                        {mySub ? 'Resubmit' : t(lang, 'submit')}
                      </button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {tab === 'exams' && (
        <div className="space-y-6">
          {canEdit && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <form onSubmit={handleCreateExam} className="bg-white border border-emerald-900/10 rounded-2xl p-6 space-y-3 text-xs">
                <h2 className="font-display text-base font-bold text-slate-950">Schedule Examination</h2>
                <input
                  type="text"
                  required
                  placeholder="Exam Title *"
                  value={examForm.title}
                  onChange={(e) => setExamForm({ ...examForm, title: e.target.value })}
                  className="w-full rounded-xl border border-slate-200 px-3 py-2"
                />
                <div className="grid grid-cols-2 gap-2">
                  <select
                    value={examForm.classId}
                    onChange={(e) => setExamForm({ ...examForm, classId: e.target.value })}
                    className="rounded-xl border border-slate-200 px-3 py-2 bg-white"
                  >
                    {classes.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                  </select>
                  <select
                    value={examForm.subjectId}
                    onChange={(e) => setExamForm({ ...examForm, subjectId: e.target.value })}
                    className="rounded-xl border border-slate-200 px-3 py-2 bg-white"
                  >
                    {subjects.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
                  </select>
                  <input
                    type="date"
                    required
                    value={examForm.examDate}
                    onChange={(e) => setExamForm({ ...examForm, examDate: e.target.value })}
                    className="rounded-xl border border-slate-200 px-3 py-2"
                  />
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="number"
                      placeholder="Total"
                      value={examForm.totalMarks}
                      onChange={(e) => setExamForm({ ...examForm, totalMarks: Number(e.target.value) })}
                      className="rounded-xl border border-slate-200 px-3 py-2"
                    />
                    <input
                      type="number"
                      placeholder="Pass"
                      value={examForm.passingMarks}
                      onChange={(e) => setExamForm({ ...examForm, passingMarks: Number(e.target.value) })}
                      className="rounded-xl border border-slate-200 px-3 py-2"
                    />
                  </div>
                </div>
                <button type="submit" className="px-4 py-2 rounded-xl bg-emerald-800 text-white font-semibold cursor-pointer">
                  Create Exam
                </button>
              </form>

              <form onSubmit={handleSaveMarks} className="bg-white border border-emerald-900/10 rounded-2xl p-6 space-y-3 text-xs">
                <h2 className="font-display text-base font-bold text-slate-950">Marks Entry</h2>
                <div className="grid grid-cols-2 gap-2">
                  <select
                    value={markForm.examId}
                    onChange={(e) => setMarkForm({ ...markForm, examId: e.target.value })}
                    className="rounded-xl border border-slate-200 px-3 py-2 bg-white"
                  >
                    {exams.map((ex) => <option key={ex.id} value={ex.id}>{ex.title}</option>)}
                  </select>
                  <select
                    value={markForm.studentId}
                    onChange={(e) => setMarkForm({ ...markForm, studentId: e.target.value })}
                    className="rounded-xl border border-slate-200 px-3 py-2 bg-white"
                  >
                    {students.map((s) => <option key={s.id} value={s.id}>{s.fullName}</option>)}
                  </select>
                  <input
                    type="number"
                    required
                    placeholder="Obtained Marks"
                    value={markForm.obtainedMarks}
                    onChange={(e) => setMarkForm({ ...markForm, obtainedMarks: e.target.value })}
                    className="rounded-xl border border-slate-200 px-3 py-2"
                  />
                  <input
                    type="number"
                    required
                    placeholder="Total Marks"
                    value={markForm.totalMarks}
                    onChange={(e) => setMarkForm({ ...markForm, totalMarks: e.target.value })}
                    className="rounded-xl border border-slate-200 px-3 py-2"
                  />
                </div>
                <input
                  type="text"
                  placeholder="Evaluator Remarks"
                  value={markForm.remarks}
                  onChange={(e) => setMarkForm({ ...markForm, remarks: e.target.value })}
                  className="w-full rounded-xl border border-slate-200 px-3 py-2"
                />
                <button type="submit" className="px-4 py-2 rounded-xl bg-emerald-800 text-white font-semibold cursor-pointer">
                  Save Marks
                </button>
              </form>
            </div>
          )}

          {/* Performance Charts */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-white border border-emerald-900/10 rounded-2xl p-6">
              <h2 className="font-display text-lg font-bold text-slate-950 mb-4">
                {isStudent ? 'My Exam Scores by Subject (%)' : 'Academic Performance Trend (%)'}
              </h2>
              <div className="h-60 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={performanceChartData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
                    <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                    <YAxis domain={[0, 100]} tick={{ fontSize: 12 }} />
                    <Tooltip />
                    <Bar dataKey="percentage" name="Score %" fill="#047857" radius={[6, 6, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="bg-white border border-emerald-900/10 rounded-2xl p-6">
              <h2 className="font-display text-lg font-bold text-slate-950 mb-4">
                {isStudent ? 'My Score vs. Passing Benchmark (%)' : 'Attendance vs. Academic Score (%)'}
              </h2>
              <div className="h-60 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  {isStudent ? (
                    <LineChart data={personalScoreProgression}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
                      <XAxis dataKey="exam" tick={{ fontSize: 11 }} />
                      <YAxis domain={[0, 100]} tick={{ fontSize: 12 }} />
                      <Tooltip />
                      <Legend wrapperStyle={{ fontSize: '12px' }} />
                      <Line type="monotone" dataKey="scorePct" name="My Score %" stroke="#047857" strokeWidth={2} />
                      <Line type="monotone" dataKey="passPct" name="Pass Target %" stroke="#D97706" strokeWidth={2} strokeDasharray="4 4" />
                    </LineChart>
                  ) : (
                    <LineChart data={attendanceVsScore}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
                      <XAxis dataKey="student" tick={{ fontSize: 11 }} />
                      <YAxis domain={[0, 100]} tick={{ fontSize: 12 }} />
                      <Tooltip />
                      <Legend wrapperStyle={{ fontSize: '12px' }} />
                      <Line type="monotone" dataKey="attendancePct" name="Attendance %" stroke="#D97706" strokeWidth={2} />
                      <Line type="monotone" dataKey="scorePct" name="Avg Exam %" stroke="#047857" strokeWidth={2} />
                    </LineChart>
                  )}
                </ResponsiveContainer>
              </div>
            </div>
          </div>

          {/* Report Card Table */}
          <div className="bg-white border border-emerald-900/10 rounded-2xl overflow-hidden">
            <table className="w-full text-start border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-100 bg-slate-50/70 text-[11px] font-semibold text-slate-500">
                  {!isStudent && <th className="py-3 px-4 text-start">Student</th>}
                  <th className="py-3 px-4 text-start">Examination</th>
                  <th className="py-3 px-4 text-end">Score</th>
                  <th className="py-3 px-4 text-start">Result & Grade</th>
                  <th className="py-3 px-4 text-start">Remarks</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {marks.map((m) => {
                  const ex = examMap.get(m.examId);
                  const passMark = ex?.passingMarks ?? Math.round((m.totalMarks || 100) * 0.4);
                  const passed = m.obtainedMarks >= passMark;
                  return (
                    <tr key={m.id}>
                      {!isStudent && (
                        <td className="py-3 px-4 font-semibold text-slate-900">
                          {studentMap.get(m.studentId)?.fullName || `Student #${m.studentId}`}
                        </td>
                      )}
                      <td className="py-3 px-4 text-slate-700">{ex?.title || `Exam #${m.examId}`}</td>
                      <td className="py-3 px-4 text-end font-mono-num font-semibold text-emerald-900">
                        {m.obtainedMarks} / {m.totalMarks}
                      </td>
                      <td className="py-3 px-4">
                        <span className={`font-semibold ${passed ? 'text-emerald-700' : 'text-amber-700'}`}>
                          {m.grade} · {passed ? 'Pass' : `Below Pass (${passMark})`}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-slate-600">{m.remarks || '—'}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {tab === 'quiz' && (
        <div className="space-y-6">
          {canEdit && !activeQuiz && (
            <div className="space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="text-xs text-slate-600">
                  Create multi-format assessments (MCQ, True/False, Short & Long Answer) and review pending subjective submissions.
                </div>
                <button
                  type="button"
                  onClick={() => setShowQuizBuilder(!showQuizBuilder)}
                  className="px-4 py-2 rounded-xl bg-emerald-800 hover:bg-emerald-900 text-white text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer"
                >
                  <Plus className="h-4 w-4" />
                  <span>{showQuizBuilder ? 'Close Test Builder' : 'Create Online Test'}</span>
                </button>
              </div>

              {showQuizBuilder && (
                <form onSubmit={handleCreateOnlineTest} className="bg-white border border-emerald-900/12 rounded-2xl p-6 space-y-4 text-xs">
                  <h3 className="font-display text-base font-bold text-slate-950">Online Test & Quiz Builder</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                    <input
                      type="text"
                      required
                      placeholder="Test Title *"
                      value={quizDraft.title}
                      onChange={(e) => setQuizDraft({ ...quizDraft, title: e.target.value })}
                      className="sm:col-span-2 rounded-xl border border-slate-200 px-3 py-2"
                    />
                    <select
                      value={quizDraft.classId}
                      onChange={(e) => setQuizDraft({ ...quizDraft, classId: e.target.value })}
                      className="rounded-xl border border-slate-200 px-3 py-2 bg-white"
                    >
                      {classes.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                    </select>
                    <select
                      value={quizDraft.subjectId}
                      onChange={(e) => setQuizDraft({ ...quizDraft, subjectId: e.target.value })}
                      className="rounded-xl border border-slate-200 px-3 py-2 bg-white"
                    >
                      {subjects.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
                    </select>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                    <input
                      type="date"
                      value={quizDraft.startDate}
                      onChange={(e) => setQuizDraft({ ...quizDraft, startDate: e.target.value, examDate: e.target.value })}
                      className="rounded-xl border border-slate-200 px-3 py-2 font-mono-num"
                    />
                    <input
                      type="date"
                      placeholder="End Date"
                      value={quizDraft.endDate}
                      onChange={(e) => setQuizDraft({ ...quizDraft, endDate: e.target.value })}
                      className="rounded-xl border border-slate-200 px-3 py-2 font-mono-num"
                    />
                    <input
                      type="number"
                      min={5}
                      placeholder="Time Limit (mins)"
                      value={quizDraft.durationMinutes}
                      onChange={(e) => setQuizDraft({ ...quizDraft, durationMinutes: Number(e.target.value) })}
                      className="rounded-xl border border-slate-200 px-3 py-2"
                    />
                    <input
                      type="number"
                      min={1}
                      placeholder="Passing Marks"
                      value={quizDraft.passingMarks}
                      onChange={(e) => setQuizDraft({ ...quizDraft, passingMarks: Number(e.target.value) })}
                      className="rounded-xl border border-slate-200 px-3 py-2"
                    />
                  </div>

                  <div className="space-y-3">
                    {draftQuestions.map((q, idx) => (
                      <div key={q.id} className="p-4 rounded-xl bg-[#FAFBF9] border border-slate-200 space-y-2.5">
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <span className="font-semibold text-slate-900">Question {idx + 1}</span>
                          <div className="flex items-center gap-2">
                            <select
                              value={q.type}
                              onChange={(e) => {
                                const nextType = e.target.value as QuizQuestionDraft['type'];
                                setDraftQuestions((prev) =>
                                  prev.map((item, i) => (i === idx ? { ...item, type: nextType } : item))
                                );
                              }}
                              className="rounded-lg border border-slate-200 px-2.5 py-1 bg-white"
                            >
                              <option value="mcq">Multiple Choice (MCQ)</option>
                              <option value="true_false">True / False</option>
                              <option value="short_answer">Short Answer (Teacher Graded)</option>
                              <option value="long_answer">Long Answer (Teacher Graded)</option>
                            </select>
                            <input
                              type="number"
                              min={1}
                              value={q.marks}
                              onChange={(e) =>
                                setDraftQuestions((prev) =>
                                  prev.map((item, i) => (i === idx ? { ...item, marks: Number(e.target.value) } : item))
                                )
                              }
                              className="w-16 rounded-lg border border-slate-200 px-2 py-1 bg-white"
                              title="Marks"
                            />
                            {draftQuestions.length > 1 && (
                              <button
                                type="button"
                                onClick={() => setDraftQuestions((prev) => prev.filter((_, i) => i !== idx))}
                                className="p-1 text-slate-400 hover:text-red-600 cursor-pointer"
                              >
                                <Trash2 className="h-3.5 w-3.5" />
                              </button>
                            )}
                          </div>
                        </div>
                        <input
                          type="text"
                          required
                          placeholder="Enter question prompt *"
                          value={q.question}
                          onChange={(e) =>
                            setDraftQuestions((prev) =>
                              prev.map((item, i) => (i === idx ? { ...item, question: e.target.value } : item))
                            )
                          }
                          className="w-full rounded-lg border border-slate-200 px-3 py-2 bg-white"
                        />
                        {q.type === 'mcq' && (
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                            {q.options.map((opt, optIdx) => (
                              <div key={optIdx} className="flex items-center gap-2">
                                <input
                                  type="radio"
                                  name={`correct-${q.id}`}
                                  checked={q.correctIndex === optIdx}
                                  onChange={() =>
                                    setDraftQuestions((prev) =>
                                      prev.map((item, i) => (i === idx ? { ...item, correctIndex: optIdx } : item))
                                    )
                                  }
                                />
                                <input
                                  type="text"
                                  required
                                  value={opt}
                                  onChange={(e) =>
                                    setDraftQuestions((prev) =>
                                      prev.map((item, i) =>
                                        i === idx
                                          ? {
                                              ...item,
                                              options: item.options.map((o, oi) => (oi === optIdx ? e.target.value : o)),
                                            }
                                          : item
                                      )
                                    )
                                  }
                                  className="flex-1 rounded-lg border border-slate-200 px-2.5 py-1.5 bg-white"
                                />
                              </div>
                            ))}
                          </div>
                        )}
                        {q.type === 'true_false' && (
                          <div className="flex gap-4">
                            {['True', 'False'].map((lbl, oi) => (
                              <label key={lbl} className="inline-flex items-center gap-1.5 cursor-pointer">
                                <input
                                  type="radio"
                                  name={`tf-${q.id}`}
                                  checked={q.correctIndex === oi}
                                  onChange={() =>
                                    setDraftQuestions((prev) =>
                                      prev.map((item, i) => (i === idx ? { ...item, correctIndex: oi } : item))
                                    )
                                  }
                                />
                                <span>Correct Answer: {lbl}</span>
                              </label>
                            ))}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>

                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <button
                      type="button"
                      onClick={() =>
                        setDraftQuestions((prev) => [
                          ...prev,
                          {
                            id: `q-${Date.now()}-${prev.length}`,
                            type: 'mcq',
                            question: '',
                            options: ['Option A', 'Option B', 'Option C', 'Option D'],
                            correctIndex: 0,
                            marks: 5,
                          },
                        ])
                      }
                      className="px-3.5 py-2 rounded-xl border border-emerald-800 text-emerald-900 font-semibold cursor-pointer"
                    >
                      + Add Question
                    </button>
                    <button type="submit" className="px-5 py-2 rounded-xl bg-emerald-800 text-white font-semibold cursor-pointer">
                      Publish Online Test
                    </button>
                  </div>
                </form>
              )}

              {/* Teacher Subjective Evaluation Queue */}
              {pendingReviews.length > 0 && (
                <div className="bg-white border border-amber-200 rounded-2xl p-5 space-y-3 text-xs">
                  <div className="font-display text-base font-bold text-slate-950">
                    Pending Teacher Subjective Evaluation ({pendingReviews.length})
                  </div>
                  <div className="divide-y divide-slate-100">
                    {pendingReviews.map((att) => (
                      <div key={att.id} className="py-2.5 flex items-center justify-between gap-3">
                        <div>
                          <div className="font-semibold text-slate-900">
                            {studentMap.get(att.studentId)?.fullName || `Student #${att.studentId}`} ·{' '}
                            {examMap.get(att.examId)?.title || `Exam #${att.examId}`}
                          </div>
                          <div className="text-slate-500">
                            Objective Score: {att.objectiveScore} · Submitted {new Date(att.submittedAt).toLocaleString()}
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            setEvaluatingAttempt(att);
                            setEvalScores(att.questionScoresJson || {});
                            setEvalRemarks(att.teacherRemarks || '');
                          }}
                          className="px-3 py-1.5 rounded-lg bg-emerald-800 text-white font-semibold cursor-pointer"
                        >
                          Evaluate Answers
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {!activeQuiz ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {onlineQuizzes.map((qz) => {
                const attempt = attempts.find((a) => a.examId === qz.id);
                return (
                  <div key={qz.id} className="bg-white border border-emerald-900/10 rounded-2xl p-6 flex flex-col justify-between gap-4">
                    <div>
                      <div className="text-xs text-amber-700 font-semibold mb-1">
                        Online Assessment · {qz.durationMinutes} mins · {qz.totalMarks} Marks (Pass: {qz.passingMarks ?? Math.round(qz.totalMarks * 0.4)})
                      </div>
                      <h3 className="font-display text-lg font-bold text-slate-950">{qz.title}</h3>
                      <p className="text-xs text-slate-600 mt-1">
                        {(qz.questionsJson || []).length} questions · {classMap.get(qz.classId)} · {subjectMap.get(qz.subjectId)}
                      </p>
                      {attempt && (
                        <div className="mt-2 p-2.5 rounded-lg bg-emerald-50 border border-emerald-200 text-xs text-emerald-900 font-semibold">
                          {attempt.status === 'evaluated'
                            ? `Evaluated Score: ${attempt.totalScore} / ${qz.totalMarks}`
                            : `Submitted — Pending Teacher Evaluation (Objective: ${attempt.objectiveScore})`}
                        </div>
                      )}
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        setActiveQuiz(qz);
                        setQuizAnswers(attempt?.answersJson || {});
                        setQuizResult(attempt || null);
                      }}
                      className="px-4 py-2 rounded-xl bg-emerald-800 text-white text-xs font-semibold self-start cursor-pointer"
                    >
                      {attempt
                        ? 'View Submitted Attempt'
                        : user?.role === 'student'
                          ? 'Start Online Test'
                          : 'Preview Questions'}
                    </button>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="bg-white border border-emerald-900/15 rounded-2xl p-6 space-y-5">
              <div className="flex items-center justify-between border-b border-slate-100 pb-4">
                <div>
                  <h3 className="font-display text-lg font-bold text-slate-950">{activeQuiz.title}</h3>
                  <p className="text-xs text-slate-500">
                    Duration: {activeQuiz.durationMinutes} min · Total Marks: {activeQuiz.totalMarks}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setActiveQuiz(null)}
                  className="px-3 py-1.5 rounded-lg border border-slate-200 text-xs cursor-pointer"
                >
                  Back to Tests
                </button>
              </div>

              {quizResult && (
                <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center gap-3 text-sm text-emerald-950">
                  <Award className="h-5 w-5 text-emerald-700 shrink-0" />
                  <div>
                    <strong>
                      {quizResult.attempt?.status === 'submitted_pending_review' || quizResult.status === 'submitted_pending_review'
                        ? 'Submitted for Teacher Review'
                        : 'Test Evaluated & Saved'}
                    </strong>{' '}
                    · Score: {quizResult.obtainedMarks ?? quizResult.totalScore} / {quizResult.totalMarks ?? activeQuiz.totalMarks}
                  </div>
                </div>
              )}

              <div className="space-y-4">
                {(activeQuiz.questionsJson || []).map((q: any, idx: number) => {
                  const qType = q.type || 'mcq';
                  const disabled = Boolean(quizResult);
                  return (
                    <div key={q.id} className="p-4 rounded-xl border border-slate-200 space-y-2.5">
                      <div className="flex items-center justify-between gap-2">
                        <div className="font-semibold text-sm text-slate-900">
                          {idx + 1}. {q.question}
                        </div>
                        <span className="text-[11px] font-mono-num text-slate-500 shrink-0">
                          {q.marks || 5} marks · {qType.replace('_', ' ')}
                        </span>
                      </div>

                      {(qType === 'mcq' || qType === 'true_false') ? (
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          {(q.options || ['True', 'False']).map((opt: string, optIdx: number) => (
                            <button
                              key={opt}
                              type="button"
                              disabled={disabled}
                              onClick={() => setQuizAnswers({ ...quizAnswers, [q.id]: optIdx })}
                              className={`p-2.5 rounded-xl border text-start text-xs font-medium cursor-pointer transition-colors ${
                                quizAnswers[q.id] === optIdx
                                  ? 'border-emerald-800 bg-emerald-50 text-emerald-950'
                                  : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                              }`}
                            >
                              {opt}
                            </button>
                          ))}
                        </div>
                      ) : qType === 'short_answer' ? (
                        <input
                          type="text"
                          disabled={disabled}
                          placeholder="Write short answer..."
                          value={quizAnswers[q.id] || ''}
                          onChange={(e) => setQuizAnswers({ ...quizAnswers, [q.id]: e.target.value })}
                          className="w-full rounded-xl border border-slate-200 px-3 py-2 text-xs"
                        />
                      ) : (
                        <textarea
                          rows={3}
                          disabled={disabled}
                          placeholder="Write detailed answer..."
                          value={quizAnswers[q.id] || ''}
                          onChange={(e) => setQuizAnswers({ ...quizAnswers, [q.id]: e.target.value })}
                          className="w-full rounded-xl border border-slate-200 px-3 py-2 text-xs"
                        />
                      )}
                    </div>
                  );
                })}
              </div>

              {user?.role === 'student' && !quizResult && (
                <button
                  type="button"
                  onClick={handleSubmitQuiz}
                  className="px-6 py-2.5 rounded-xl bg-emerald-800 text-white text-xs font-semibold inline-flex items-center gap-2 cursor-pointer"
                >
                  <CheckCircle2 className="h-4 w-4" />
                  <span>Submit Online Test</span>
                </button>
              )}
            </div>
          )}
        </div>
      )}

      {/* Teacher Evaluation Modal */}
      {evaluatingAttempt && (
        <div
          className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4"
          onClick={() => setEvaluatingAttempt(null)}
        >
          <form
            onSubmit={handleEvaluateAttempt}
            onClick={(e) => e.stopPropagation()}
            className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6 space-y-4 text-xs"
          >
            <h3 className="font-display text-lg font-bold text-slate-950">
              Evaluate Attempt — {studentMap.get(evaluatingAttempt.studentId)?.fullName}
            </h3>
            <div className="space-y-3">
              {(examMap.get(evaluatingAttempt.examId)?.questionsJson || []).map((q: any, idx: number) => {
                const qType = q.type || 'mcq';
                const ans = evaluatingAttempt.answersJson?.[q.id];
                const isSubj = qType === 'short_answer' || qType === 'long_answer';
                return (
                  <div key={q.id} className="p-3.5 rounded-xl border border-slate-200 space-y-2">
                    <div className="font-semibold text-slate-900">
                      {idx + 1}. {q.question} ({q.marks || 5} marks)
                    </div>
                    <div className="p-2 rounded bg-[#FAFBF9] text-slate-700">
                      Student Answer: <strong>{isSubj ? String(ans || 'No answer') : q.options?.[ans] ?? String(ans ?? '—')}</strong>
                    </div>
                    {isSubj ? (
                      <div className="flex items-center gap-2">
                        <label className="font-semibold text-emerald-900">Award Marks (0 – {q.marks || 5}):</label>
                        <input
                          type="number"
                          min={0}
                          max={q.marks || 5}
                          value={evalScores[q.id] ?? 0}
                          onChange={(e) => setEvalScores({ ...evalScores, [q.id]: Number(e.target.value) })}
                          className="w-20 rounded-lg border border-slate-200 px-2.5 py-1"
                        />
                      </div>
                    ) : (
                      <div className="text-emerald-800 font-semibold">
                        Auto-graded: {evalScores[q.id] ?? 0} / {q.marks || 5}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
            <input
              type="text"
              placeholder="Teacher Evaluation Remarks"
              value={evalRemarks}
              onChange={(e) => setEvalRemarks(e.target.value)}
              className="w-full rounded-xl border border-slate-200 px-3 py-2"
            />
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setEvaluatingAttempt(null)}
                className="px-4 py-2 rounded-xl border border-slate-200 cursor-pointer"
              >
                {t(lang, 'cancel')}
              </button>
              <button type="submit" className="px-4 py-2 rounded-xl bg-emerald-800 text-white font-semibold cursor-pointer">
                Publish Final Grade
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
